import bpy
import bmesh
from bpy.props import BoolProperty, FloatProperty


def face_islands(bm):

    result = []
    used = set()

    bm.faces.ensure_lookup_table()

    for seed_face in bm.faces:

        if seed_face in used:
            continue

        used.add(seed_face)
        island = [seed_face]
        stack = [seed_face]  # Faces still to consider on this island.

        while stack:
            current_face = stack.pop()

            for e in current_face.edges:

                if e.seam:
                    continue

                for f in e.link_faces:
                    if f is current_face or f in used:
                        continue

                    # `f` is part of island, add to island and stack
                    used.add(f)
                    island.append(f)
                    stack.append(f)

        result.append(island)

    return result


class MESH_OT_FaceSetsToUVIslands(bpy.types.Operator):

    """Create edge seams based on face set boundaries"""

    bl_idname = "mesh.facesets_to_uv_islands"
    bl_label = "Face Sets to UV Islands"
    bl_options = {'REGISTER', 'UNDO'}

    overwrite_seams: BoolProperty(name="Overwrite Existing Seams",
                                  description='Clears old seams before applying new ones',
                                  default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):

        act = context.active_object
        data = act.data
        bm = bmesh.from_edit_mesh(data)
        face_set = bm.faces.layers.int['.sculpt_face_set']

        overwrite = self.overwrite_seams

        for e in bm.edges:
            faces = e.link_faces

            if len(faces) != 2:
                # not dealing with that
                continue

            # we only like manifold meshes in these parts, mister.
            if faces[0][face_set] != faces[1][face_set]:
                e.seam = True
            elif overwrite and e.seam:
                # if we are overwriting seams, then we clear the seam
                e.seam = False

        bmesh.update_edit_mesh(data)

        return {'FINISHED'}


class MESH_OT_UVIslandsToFaceSets(bpy.types.Operator):

    """Create face sets based on UV island boundaries based on UV seams"""

    bl_idname = "mesh.uv_islands_to_facesets"
    bl_label = "UV Islands to Face Sets"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):

        act = context.active_object
        data = act.data

        if '.sculpt_face_set' not in data.attributes:
            data.attributes.new('.sculpt_face_set', 'INT', 'FACE')

        bm = None

        if act.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(data)
        else:
            bm = bmesh.new()
            bm.from_mesh(data)

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        face_set = bm.faces.layers.int['.sculpt_face_set']

        islands = face_islands(bm)

        for i, island in enumerate(islands):
            for f in island:
                f[face_set] = i

        if act.mode == 'EDIT':
            bmesh.update_edit_mesh(data)
        else:
            bm.to_mesh(data)

        bm.free()
        data.update_tag()
        context.view_layer.update()
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}


class MESH_OT_SelectionToSculptMask(bpy.types.Operator):

    """Set sculpt mask based on vertex selection"""

    bl_idname = "mesh.selection_to_sculpt_mask"
    bl_label = "Selection to Sculpt Mask"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode != 'EDIT'

    def execute(self, context):
        act = context.active_object
        data = act.data

        if '.sculpt_mask' not in data.attributes:
            data.attributes.new('.sculpt_mask', 'FLOAT', 'POINT')

        attr = data.attributes['.sculpt_mask'].data

        for v in data.vertices:
            attr[v.index].value = 0.0 if v.select else 1.0

        return {'FINISHED'}


class MESH_OT_SculptMaskToSelection(bpy.types.Operator):

    """Set vertex selection based on sculpt mask"""

    bl_idname = "mesh.sculpt_mask_to_selection"
    bl_label = "Sculpt Mask to Selection"
    bl_options = {'REGISTER', 'UNDO'}

    extend: BoolProperty(name="Extend Selection",
                         description='Extend selection to include all vertices with a mask value below the pivot',
                         default=False)

    pivot: FloatProperty(name="Pivot",
                         description='Pivot value for selection',
                         default=0.5,
                         min=0.0, max=1.0)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        act = context.active_object
        data = act.data

        if '.sculpt_mask' not in data.attributes:
            return {'CANCELLED'}

        extend = self.extend
        pivot = self.pivot
        bm = bmesh.from_edit_mesh(data)

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        mask = bm.verts.layers.float['.sculpt_mask']

        if not extend:
            for f in bm.faces:
                f.select = False
            bm.select_flush(True)

        for v in bm.verts:
            val = v[mask]
            v.select_set(val < pivot)

        bm.select_flush(True)

        bmesh.update_edit_mesh(data)
        bm.free()

        return {'FINISHED'}
