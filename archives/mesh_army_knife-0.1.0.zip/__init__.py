# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "Mesh Army Knife",
    "author": "Keith 'Wahooney' Boshoff",
    "description": "A collection of mesh tools",
    "blender": (4, 5, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Mesh"
}

if "bpy" in locals():

    import importlib

    importlib.reload(transfer_sculpt_data)

else:

    import bpy

    from . import transfer_sculpt_data


classes = [
    transfer_sculpt_data.MESH_OT_FaceSetsToUVIslands,
    transfer_sculpt_data.MESH_OT_UVIslandsToFaceSets,
    transfer_sculpt_data.MESH_OT_SelectionToSculptMask,
    transfer_sculpt_data.MESH_OT_SculptMaskToSelection,
]


menu_funcs = []


def register():

    for c in classes:
        bpy.utils.register_class(c)

    for menu, func in menu_funcs:
        menu.append(func)


def unregister():

    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass

    for menu, func in menu_funcs:
        menu.remove(func)
