"""Level data model + JSON load/save for the TGS level editor.

A level file is the source of truth for one arena. The generator turns the set of
level files into Content/Verse/Data/Arenas.verse. Values for `building.type`,
`team`, and `direction` are validated against the sets defined in the Verse Data
modules so an invalid level cannot be saved or generated.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

# Mirrors of the Verse Data enums/metric sets. Keep in sync with:
#   Content/Verse/Data/Building.verse  -> Building.<name>
#   Content/Verse/Data/Team.verse      -> Team.<name>
#   Content/Verse/Kini/SquareGrid.verse -> named_direction
BUILDING_TYPES = (
    "airport", "armory", "barracks", "dock", "factory", "helipad", "oil_field",
)
TEAMS = ("neutral", "blue", "red", "yellow", "green", "hostile")
DIRECTIONS = (
    "North", "NorthEast", "East", "SouthEast",
    "South", "SouthWest", "West", "NorthWest",
)


class LevelError(Exception):
    """Raised when level data fails validation."""


@dataclass
class Building:
    type: str
    order: int
    direction: str = "North"
    team: str = "neutral"

    def validate(self, where: str) -> None:
        if self.type not in BUILDING_TYPES:
            raise LevelError(f"{where}: unknown building type {self.type!r}; "
                             f"expected one of {BUILDING_TYPES}")
        if self.direction not in DIRECTIONS:
            raise LevelError(f"{where}: unknown direction {self.direction!r}; "
                             f"expected one of {DIRECTIONS}")
        if self.team not in TEAMS:
            raise LevelError(f"{where}: unknown team {self.team!r}; "
                             f"expected one of {TEAMS}")

    @classmethod
    def from_dict(cls, data: dict) -> "Building":
        return cls(
            type=data["type"],
            order=int(data["order"]),
            direction=data.get("direction", "North"),
            team=data.get("team", "neutral"),
        )

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "order": self.order,
            "direction": self.direction,
            "team": self.team,
        }


@dataclass
class Cell:
    q: int
    r: int
    height: int = 0
    building: Building | None = None

    def validate(self, where: str) -> None:
        if self.building is not None:
            self.building.validate(f"{where} cell ({self.q},{self.r})")

    @classmethod
    def from_dict(cls, data: dict) -> "Cell":
        building = data.get("building")
        return cls(
            q=int(data["q"]),
            r=int(data["r"]),
            height=int(data.get("height", 0)),
            building=Building.from_dict(building) if building else None,
        )

    def to_dict(self) -> dict:
        out: dict = {"q": self.q, "r": self.r, "height": self.height}
        if self.building is not None:
            out["building"] = self.building.to_dict()
        return out


@dataclass
class Level:
    invariant_name: str            # e.g. "Arena.solo"; drives the Key hash
    cells: list[Cell] = field(default_factory=list)
    name: str | None = None
    description: str | None = None
    short_description: str | None = None

    @property
    def class_name(self) -> str:
        """The Verse class name, e.g. "solo" from "Arena.solo"."""
        return self.invariant_name.rsplit(".", 1)[-1]

    def validate(self) -> None:
        if "." not in self.invariant_name:
            raise LevelError(
                f"invariantName {self.invariant_name!r} must be of the form "
                f"'Arena.<name>'")
        seen: set[tuple[int, int]] = set()
        for cell in self.cells:
            key = (cell.q, cell.r)
            if key in seen:
                raise LevelError(
                    f"{self.invariant_name}: duplicate cell at ({cell.q},{cell.r})")
            seen.add(key)
            cell.validate(self.invariant_name)

    @classmethod
    def from_dict(cls, data: dict) -> "Level":
        return cls(
            invariant_name=data["invariantName"],
            cells=[Cell.from_dict(c) for c in data.get("cells", [])],
            name=data.get("name"),
            description=data.get("description"),
            short_description=data.get("shortDescription"),
        )

    def to_dict(self) -> dict:
        out: dict = {"invariantName": self.invariant_name}
        if self.name is not None:
            out["name"] = self.name
        if self.description is not None:
            out["description"] = self.description
        if self.short_description is not None:
            out["shortDescription"] = self.short_description
        out["cells"] = [c.to_dict() for c in self.cells]
        return out


def load_level(path: Path) -> Level:
    level = Level.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
    level.validate()
    return level


def save_level(level: Level, path: Path) -> None:
    level.validate()
    text = json.dumps(level.to_dict(), indent=2, ensure_ascii=False)
    Path(path).write_text(text + "\n", encoding="utf-8")


def load_all(levels_dir: Path) -> list[Level]:
    """Load every *.json in `levels_dir`, sorted by filename for deterministic order."""
    return [load_level(p) for p in sorted(Path(levels_dir).glob("*.json"))]
