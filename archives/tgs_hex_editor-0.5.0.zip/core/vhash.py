"""Port of Kini's `(Input:string).Hash()` polynomial rolling hash.

Defined in Verse at Content/Verse/Kini/Extensions.verse (~line 289). A metric's
`Key` is `Hash(InvariantName)`, so this lets the generator derive arena Keys
without a hardcoded table. Verified against the known Arenas.verse / Building.verse
/ Team.verse Key values.
"""

_P = 53
_M = 10000000009


def vhash(text: str) -> int:
    """Return the Verse polynomial rolling hash of `text`.

    Verse's `ToInt[Char]` yields the Unicode codepoint (Python `ord`). The Verse
    code falls back to 26 only when `ToInt` fails, which never happens for normal
    string characters, so we mirror it without the fallback.
    """
    value = 0
    power = 1
    for char in text:
        value = (value + ord(char) * power) % _M
        power = (power * _P) % _M
    return value
