"""Pure-stdlib core shared with Tools/LevelEditor/tgs_levels.

Kept dependency-free so it runs unchanged inside Blender's bundled Python.
If you edit these, keep them in sync with Tools/LevelEditor/tgs_levels/.
"""
