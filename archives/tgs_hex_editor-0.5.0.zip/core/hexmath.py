"""Axial hex <-> world mapping, ported from Kini HexGrid.verse.

Mirrors `(coordinate).ToGlobalPosition` for a flat-top hex grid so the editor's
layout matches in-game placement. Verse vector3 is (Left, Up, Forward); the editor
maps Left->X, Forward->Y, Up->Z.

Note (see feedback_hexgrid_r_axis): +R moves -Forward (screen-up), +Q moves -Left.
The signs below are taken verbatim from the Verse source, so round-tripping is exact.
"""

from __future__ import annotations

import math

CELL_RADIUS = 1792.0      # centre-to-vertex in cm (arena_component.CellRadius)
CELL_HEIGHT_STEP = 192.0  # vertical cm per height step (arena_component.CellHeightStep)

_SQRT3 = math.sqrt(3.0)


def axial_to_world(q: int, r: int, radius: float = CELL_RADIUS) -> tuple[float, float]:
    """Return (left, forward) cell-centre coordinates for axial (q, r)."""
    left = radius * 1.5 * -q
    forward = -radius * ((_SQRT3 / 2.0) * q + _SQRT3 * r)
    return left, forward


def hex_corners(q: int, r: int, radius: float = CELL_RADIUS) -> list[tuple[float, float]]:
    """Six (left, forward) corners of a flat-top hex centred on axial (q, r).

    Flat-top: vertices at 0,60,120,... degrees, with the vertex axis along Left.
    """
    cx, cy = axial_to_world(q, r, radius)
    corners = []
    for i in range(6):
        angle = math.radians(60.0 * i)
        corners.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
    return corners


def height_to_z(height: int) -> float:
    return height * CELL_HEIGHT_STEP


def _axial_round(q_frac: float, r_frac: float) -> tuple[int, int]:
    """Round fractional axial coords to the nearest hex via cube rounding."""
    x, z = q_frac, r_frac
    y = -x - z
    rx, ry, rz = round(x), round(y), round(z)
    dx, dy, dz = abs(rx - x), abs(ry - y), abs(rz - z)
    if dx > dy and dx > dz:
        rx = -ry - rz
    elif dy > dz:
        ry = -rx - rz
    else:
        rz = -rx - ry
    return int(rx), int(rz)


def world_to_axial(left: float, forward: float,
                   radius: float = CELL_RADIUS) -> tuple[int, int]:
    """Inverse of axial_to_world: nearest cell (q, r) for a (left, forward) point."""
    q_frac = -left / (1.5 * radius)
    r_frac = (-forward / radius - (_SQRT3 / 2.0) * q_frac) / _SQRT3
    return _axial_round(q_frac, r_frac)
