"""Generate Content/Verse/Data/Arenas.verse from the level JSON files.

The generated file contains one `arena_metric` subclass per level plus a trailing
`Message` module holding the localized Name/Description strings for levels that
define them. Hand-written scaffolding (the arena_metric base class, cell_spec,
building_spec) lives in arena_component.verse and is NOT generated here.
"""

from __future__ import annotations

from pathlib import Path

from .schema import Level
from .vhash import vhash

_INDENT = "    "


def _esc(text: str) -> str:
    """Escape a Python string for a Verse double-quoted string literal."""
    return text.replace("\\", "\\\\").replace("\"", "\\\"")


def _message_name(level: Level, suffix: str = "") -> str:
    """Message identifier for a level, e.g. 'Atoll' / 'AtollDescription'."""
    base = level.class_name[:1].upper() + level.class_name[1:]
    return base + suffix


def _emit_cell(cell, indent: str) -> list[str]:
    """Emit a cell as either compact `cell_spec{...}` or the block form with a building."""
    if cell.building is None:
        return [f"{indent}cell_spec{{Q := {cell.q}, R := {cell.r}, Height := {cell.height}}}"]

    b = cell.building
    inner = indent + _INDENT
    binner = inner + _INDENT
    return [
        f"{indent}cell_spec:",
        f"{inner}Q := {cell.q}",
        f"{inner}R := {cell.r}",
        f"{inner}Height := {cell.height}",
        f"{inner}Building := option. building_spec:",
        f"{binner}Building := Building.{b.type}{{}}",
        f"{binner}Order := {b.order}",
        f"{binner}Direction := named_direction.{b.direction}",
        f"{binner}Team := Team.{b.team}{{}}",
    ]


def _emit_arena(level: Level) -> list[str]:
    cls = level.class_name
    key = vhash(level.invariant_name)
    lines: list[str] = []
    lines.append(f"{_INDENT}{cls}<public> := class<final>(arena_metric):")
    lines.append(f"{_INDENT * 2}InvariantName<override>:string = \"{level.invariant_name}\"")
    lines.append(f"{_INDENT * 2}Key<override>:int = {key}")
    if level.name is not None:
        lines.append(f"{_INDENT * 2}var Name<override><final>:message = Message.{_message_name(level)}")
    if level.description is not None:
        lines.append(f"{_INDENT * 2}var Description<override><final>:message = Message.{_message_name(level, 'Description')}")
    if level.short_description is not None:
        lines.append(f"{_INDENT * 2}var ShortDescription<override><final>:message = Message.{_message_name(level, 'ShortDescription')}")
    lines.append(f"{_INDENT * 2}Cells<override> : []cell_spec = array:")
    for cell in level.cells:
        lines.extend(_emit_cell(cell, _INDENT * 3))
    return lines


def _emit_message_module(levels: list[Level]) -> list[str]:
    entries: list[Level] = [lv for lv in levels if lv.name is not None]
    if not entries:
        return []
    lines: list[str] = [f"{_INDENT}Message := module:"]
    for i, level in enumerate(entries):
        if i > 0:
            lines.append("")
        name = _message_name(level)
        lines.append(f"{_INDENT * 2}{name}<public><localizes>:message = \"{_esc(level.name)}\"")
        if level.description is not None:
            lines.append(f"{_INDENT * 2}{name}Description<public><localizes>:message = \"{_esc(level.description)}\"")
        if level.short_description is not None:
            lines.append(f"{_INDENT * 2}{name}ShortDescription<public><localizes>:message = \"{_esc(level.short_description)}\"")
    return lines


def generate(levels: list[Level]) -> str:
    """Render the full Arenas.verse source from the ordered list of levels."""
    out: list[str] = [
        "using { Data.Building }",
        "using { Data.Team }",
        "using { Kini.HexGrid }",
        "",
        "Arena<public> := module:",
    ]
    for i, level in enumerate(levels):
        if i > 0:
            out.append("")
        out.extend(_emit_arena(level))

    message_lines = _emit_message_module(levels)
    if message_lines:
        out.append("")
        out.extend(message_lines)

    return "\n".join(out) + "\n"


def write_generated(levels: list[Level], target: Path) -> None:
    Path(target).write_text(generate(levels), encoding="utf-8")
