"""TGS Hex Level Editor â€” Blender add-on.

Edits Tactical Guard Squad hex arenas as Blender objects in a single .blend that
holds every arena. Each arena is a Collection (named by its InvariantName, e.g.
"Arena.solo") containing one hex-prism mesh object per land cell; each cell carries
its Q/R/height/building data as custom properties; building teams drive territory colors.

The .blend is the working file. On save, every arena is auto-exported to a level
JSON in the Levels Folder â€” those JSON files plus the generated Arenas.verse are the
version-controlled source of truth.
"""

from pathlib import Path
import math

import blf
import bpy
import gpu
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    EnumProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup, WorkSpaceTool
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from .core import hexmath, schema
from .core.generate import generate
from .core.schema import Building, Cell, Level

# Enum item lists derived from the validated Verse sets.
_BUILDING_ITEMS = [("none", "None", "No building")] + [
    (b, b.replace("_", " ").title(), "") for b in schema.BUILDING_TYPES
]
_TEAM_ITEMS = [(t, f"{i + 1}: {t.title()}", "") for i, t in enumerate(schema.TEAMS)]
_BUILDING_DIRECTIONS = (
    "North", "NorthEast", "SouthEast",
    "South", "SouthWest", "NorthWest",
)
_DIRECTION_ITEMS = [(d, d, "") for d in _BUILDING_DIRECTIONS]
_PAINT_MODE_ITEMS = [
    ("add", "Add / Remove", "Click empty cell to add; click a cell to remove"),
    ("height", "Raise / Lower", "LMB raises; RMB lowers existing cells by one step"),
    ("set_height", "Set Height", "Set painted cells to the configured height"),
    ("building", "Building", "Place or remove the selected building"),
    ("team", "Building Team", "Assign team affiliation to buildings without symmetry"),
]
_PAINT_MODE_KEYS = {
    "Q": "add",
    "W": "height",
    "E": "height",
    "R": "set_height",
    "T": "building",
    "Y": "team",
}
_PAINT_SETTING_DIGIT_KEYS = {
    "ZERO": 0, "NUMPAD_0": 0,
    "ONE": 1, "NUMPAD_1": 1,
    "TWO": 2, "NUMPAD_2": 2,
    "THREE": 3, "NUMPAD_3": 3,
    "FOUR": 4, "NUMPAD_4": 4,
    "FIVE": 5, "NUMPAD_5": 5,
    "SIX": 6, "NUMPAD_6": 6,
    "SEVEN": 7, "NUMPAD_7": 7,
    "EIGHT": 8, "NUMPAD_8": 8,
    "NINE": 9, "NUMPAD_9": 9,
}
_HEXANT_TOGGLE_KEYS = {
    "U": 0,
    "I": 1,
    "K": 2,
    "M": 3,
    "N": 4,
    "H": 5,
}
_MIRROR_TOGGLE_KEYS = {
    "O": "horizontal",
    "L": "rising",
    "P": "falling",
}
_MIRROR_PROPS = {
    "horizontal": "symmetry_mirror_horizontal",
    "rising": "symmetry_mirror_rising",
    "falling": "symmetry_mirror_falling",
}
_HEX_PAINT_TOOL_ID = "tgs.hex_paint"
_HEX_PAINT_TOOL_ICON = str(Path(__file__).parent / "icons" / "icon_tgs_tool")
_RADIAL_SYMMETRY_ITEMS = [
    ("none", "None", "No radial symmetry"),
    ("60", "6-Way (60 deg)", "Repeat around the center every 60 degrees"),
    ("120", "3-Way (120 deg)", "Repeat around the center every 120 degrees"),
    ("180", "2-Way (180 deg)", "Repeat around the center every 180 degrees"),
]
_SYMMETRY_OFFSET_ITEMS = [
    ("0", "0 deg", "No axis offset"),
    ("1", "60 deg", "Offset mirror axes by 60 degrees"),
    ("2", "120 deg", "Offset mirror axes by 120 degrees"),
    ("3", "180 deg", "Offset mirror axes by 180 degrees"),
    ("4", "240 deg", "Offset mirror axes by 240 degrees"),
    ("5", "300 deg", "Offset mirror axes by 300 degrees"),
]
_PAINT_PREVIEW_PRIMARY_COLOR = (0.20, 0.80, 1.00, 0.32)
_PAINT_PREVIEW_SYMMETRY_COLOR = (1.00, 0.68, 0.18, 0.28)
_PAINT_PREVIEW_Z = 0.03
_paint_preview_cell = None

_ARENA_MARK = "tgs_arena"          # bool prop marking an arena collection
_ARENAS_COLLECTION_NAME = "Arenas"
_BUILDINGS_COLLECTION_NAME = "Buildings"
_NO_ARENA_ID = "__no_arena__"      # valid hidden fallback for empty enum items
_NO_BUILDING_ID = "__no_building__"
_INVARIANT_KEY = "tgs_invariant_name"
_NAME_KEY = "tgs_name"             # display name (-> Arena Name message)
_DESCRIPTION_KEY = "tgs_description"
_SHORT_DESCRIPTION_KEY = "tgs_short_description"
_CELL_MARK = "tgs_q"               # presence marks a cell object
_BUILDING_INSTANCE_MARK = "tgs_building_instance"
_BUILDING_CELL_Q = "tgs_cell_q"
_BUILDING_CELL_R = "tgs_cell_r"
_SCALE = 0.01                      # cm -> m so the grid is a sane viewport size


# --------------------------------------------------------------------------- #
# Allowed-cell region (the legal placement extents)
#
# The legal play area is a hexagonal region centred on axial (0, 0): every cell
# within `radius` steps of the centre. Defined purely in Kini.HexGrid axial (Q, R)
# coordinates, so the wireframe overlay and cell placement both come straight from
# ToGlobalPosition with no display-only remapping. The radius is a panel setting.
# --------------------------------------------------------------------------- #
_DEFAULT_ARENA_RADIUS = 5          # 3N^2+3N+1 = 91 cells, ~the old grid's count


def _hex_distance(q: int, r: int) -> int:
    """Axial distance of (q, r) from the origin (cube-coordinate hex metric)."""
    return (abs(q) + abs(r) + abs(q + r)) // 2


def _allowed_axial_cells(radius: int) -> list[tuple[int, int]]:
    """Every (Q, R) within `radius` steps of centre â€” a hexagonal region."""
    cells = []
    for q in range(-radius, radius + 1):
        for r in range(max(-radius, -q - radius), min(radius, -q + radius) + 1):
            cells.append((q, r))
    return cells


def _arena_radius(context) -> int:
    settings = getattr(context.scene, "tgs_hex", None)
    return settings.arena_radius if settings is not None else _DEFAULT_ARENA_RADIUS


# --------------------------------------------------------------------------- #
# Allowed-cell wireframe overlay (GPU draw handler)
#
# Controlled by the Show Allowed Grid scene setting. The draw handler stays
# registered, but returns early while the overlay is disabled.
# --------------------------------------------------------------------------- #
_draw_handle = None
_hud_handle = None
_hud_shader = None
_GRID_COLOR = (0.35, 0.55, 0.95, 0.6)
_HUD_STATE_COLOR = (0.96, 1.00, 1.00, 1.0)
_HUD_DETAIL_COLOR = (0.86, 0.94, 1.00, 0.92)
_HUD_KEYS_COLOR = (0.62, 0.72, 0.84, 0.82)
_HUD_PANEL_COLOR = (0.02, 0.04, 0.07, 0.58)
_HUD_PANEL_EDGE_COLOR = (0.35, 0.58, 0.88, 0.42)
_HUD_SHADOW_COLOR = (0.0, 0.0, 0.0, 0.78)


def _grid_line_coords(radius: int) -> list[tuple[float, float, float]]:
    """Flattened LINE segment endpoints (world m, z=0) for every allowed cell."""
    coords = []
    for q, r in _allowed_axial_cells(radius):
        corners = hexmath.hex_corners(q, r)
        for i in range(6):
            ax, ay = corners[i]
            bx, by = corners[(i + 1) % 6]
            coords.append((ax * _SCALE, ay * _SCALE, 0.0))
            coords.append((bx * _SCALE, by * _SCALE, 0.0))
    return coords


# Cached per-radius; invalidated when the arena radius changes (see _on_radius_update).
_grid_batch = None
_grid_shader = None
_grid_batch_radius = None


def _invalidate_grid_batch():
    global _grid_batch, _grid_batch_radius
    _grid_batch = None
    _grid_batch_radius = None


def _ensure_grid_batch(radius: int):
    global _grid_batch, _grid_shader, _grid_batch_radius
    if _grid_batch is not None and _grid_batch_radius == radius:
        return
    if _grid_shader is None:
        _grid_shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    _grid_batch = batch_for_shader(
        _grid_shader, "LINES", {"pos": _grid_line_coords(radius)})
    _grid_batch_radius = radius


def _active_view3d_tool_id(context=None):
    context = context or bpy.context
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        return None
    mode = getattr(context, "mode", "OBJECT")
    try:
        tool = workspace.tools.from_space_view3d_mode(mode, create=False)
    except TypeError:
        tool = workspace.tools.from_space_view3d_mode(mode)
    except Exception:
        return None
    return getattr(tool, "idname", None)


def _hex_paint_tool_active(context=None) -> bool:
    return _active_view3d_tool_id(context) == _HEX_PAINT_TOOL_ID


def _hex_fill_coords(q: int, r: int, z: float = _PAINT_PREVIEW_Z) -> list[tuple[float, float, float]]:
    cx, cy = hexmath.axial_to_world(q, r)
    corners = hexmath.hex_corners(q, r)
    center = (cx * _SCALE, cy * _SCALE, z)
    coords = []
    for i in range(6):
        ax, ay = corners[i]
        bx, by = corners[(i + 1) % 6]
        coords.extend([
            center,
            (ax * _SCALE, ay * _SCALE, z),
            (bx * _SCALE, by * _SCALE, z),
        ])
    return coords


def _draw_filled_hexes(cells, color) -> None:
    if not cells:
        return
    coords = []
    for q, r in cells:
        coords.extend(_hex_fill_coords(q, r))
    batch = batch_for_shader(_grid_shader, "TRIS", {"pos": coords})
    _grid_shader.uniform_float("color", color)
    batch.draw(_grid_shader)


def _draw_paint_preview(context, settings) -> None:
    if _paint_preview_cell is None:
        return
    if settings.paint_tool == "team":
        targets = [_paint_preview_cell]
    else:
        targets = _symmetry_targets(context, _paint_preview_cell[0], _paint_preview_cell[1], settings)
    if not targets:
        return
    primary = [_paint_preview_cell] if _paint_preview_cell in targets else []
    symmetric = [cell for cell in targets if cell != _paint_preview_cell]
    _draw_filled_hexes(symmetric, _PAINT_PREVIEW_SYMMETRY_COLOR)
    _draw_filled_hexes(primary, _PAINT_PREVIEW_PRIMARY_COLOR)

def _set_blf_size(font_id: int, size: int) -> None:
    try:
        blf.size(font_id, size)
    except TypeError:
        blf.size(font_id, size, 72)


def _text_dimensions(font_id: int, text: str, size: int) -> tuple[float, float]:
    _set_blf_size(font_id, size)
    return blf.dimensions(font_id, text)


def _ensure_hud_shader():
    global _hud_shader
    if _hud_shader is None:
        _hud_shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    return _hud_shader


def _draw_hud_panel(x: float, y: float, width: float, height: float) -> None:
    shader = _ensure_hud_shader()
    coords = [
        (x, y, 0.0), (x + width, y, 0.0), (x + width, y + height, 0.0),
        (x, y, 0.0), (x + width, y + height, 0.0), (x, y + height, 0.0),
    ]
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("color", _HUD_PANEL_COLOR)
    batch_for_shader(shader, "TRIS", {"pos": coords}).draw(shader)

    edge = 3.0
    edge_coords = [
        (x, y + height - edge, 0.0), (x + width, y + height - edge, 0.0), (x + width, y + height, 0.0),
        (x, y + height - edge, 0.0), (x + width, y + height, 0.0), (x, y + height, 0.0),
    ]
    shader.uniform_float("color", _HUD_PANEL_EDGE_COLOR)
    batch_for_shader(shader, "TRIS", {"pos": edge_coords}).draw(shader)
    gpu.state.blend_set("NONE")


def _draw_tool_hud():
    context = bpy.context
    if not _hex_paint_tool_active(context):
        return
    settings = getattr(context.scene, "tgs_hex", None)
    region = getattr(context, "region", None)
    if settings is None or region is None:
        return

    rows = _paint_hud_rows(context, settings)
    if not rows:
        return

    font_id = 0
    padding_x = 16
    padding_y = 12
    row_gap = 6
    widths = []
    heights = []
    for row in rows:
        width, height = _text_dimensions(font_id, row["text"], row["size"])
        widths.append(width)
        heights.append(height)

    panel_x = 18
    panel_y = 20
    panel_w = max(widths) + padding_x * 2
    panel_h = sum(heights) + row_gap * (len(rows) - 1) + padding_y * 2
    _draw_hud_panel(panel_x, panel_y, panel_w, panel_h)

    try:
        blf.enable(font_id, blf.SHADOW)
        blf.shadow(font_id, 5, *_HUD_SHADOW_COLOR)
        blf.shadow_offset(font_id, 2, -2)
    except Exception:
        pass

    y = panel_y + panel_h - padding_y
    for row, height in zip(rows, heights):
        _set_blf_size(font_id, row["size"])
        try:
            blf.color(font_id, *row["color"])
        except Exception:
            pass
        y -= height
        blf.position(font_id, panel_x + padding_x, y, 0)
        blf.draw(font_id, row["text"])
        y -= row_gap

    try:
        blf.disable(font_id, blf.SHADOW)
    except Exception:
        pass

def _draw_grid_overlay():
    context = bpy.context
    if not _hex_paint_tool_active(context):
        return
    settings = getattr(context.scene, "tgs_hex", None)
    if settings is None:
        return
    if not settings.show_allowed_grid:
        return
    radius = settings.arena_radius if settings is not None else _DEFAULT_ARENA_RADIUS
    _ensure_grid_batch(radius)
    gpu.state.blend_set("ALPHA")
    _grid_shader.bind()
    _draw_paint_preview(context, settings)
    gpu.state.line_width_set(1.0)
    _grid_shader.uniform_float("color", _GRID_COLOR)
    _grid_batch.draw(_grid_shader)
    gpu.state.blend_set("NONE")
# --------------------------------------------------------------------------- #
# Arena collections
# --------------------------------------------------------------------------- #
def _arenas_root(scene=None):
    """Return the scene-root Arenas collection, if it exists."""
    scene = scene or bpy.context.scene
    for coll in scene.collection.children:
        if coll.name == _ARENAS_COLLECTION_NAME:
            return coll
    return None


def _ensure_arenas_root(context=None) -> bpy.types.Collection:
    """Get or create the scene-root collection that owns all arenas."""
    scene = context.scene if context is not None else bpy.context.scene
    root = _arenas_root(scene)
    if root is not None:
        return root

    root = bpy.data.collections.get(_ARENAS_COLLECTION_NAME)
    if root is None:
        root = bpy.data.collections.new(_ARENAS_COLLECTION_NAME)
    scene.collection.children.link(root)
    return root


# --------------------------------------------------------------------------- #
# Building libraries
# --------------------------------------------------------------------------- #
def _buildings_root(scene=None):
    """Return the scene-root Buildings collection, if it exists."""
    scene = scene or bpy.context.scene
    for coll in scene.collection.children:
        if coll.name == _BUILDINGS_COLLECTION_NAME:
            return coll
    return None


def _ensure_buildings_root(context=None) -> bpy.types.Collection:
    """Get or create the scene-root collection that owns building prefabs."""
    scene = context.scene if context is not None else bpy.context.scene
    root = _buildings_root(scene)
    if root is not None:
        return root

    root = bpy.data.collections.get(_BUILDINGS_COLLECTION_NAME)
    if root is None:
        root = bpy.data.collections.new(_BUILDINGS_COLLECTION_NAME)
    scene.collection.children.link(root)
    return root


def _iter_building_collections(scene=None):
    root = _buildings_root(scene)
    if root is None:
        return
    for coll in root.children:
        yield coll


def _building_names(scene=None) -> list[str]:
    return sorted(coll.name for coll in _iter_building_collections(scene))


def _building_collection_by_name(name: str, scene=None):
    if not name or name in {"none", _NO_BUILDING_ID}:
        return None
    for coll in _iter_building_collections(scene):
        if coll.name == name:
            return coll
    return None


def _arena_invariant(coll: bpy.types.Collection) -> str:
    return coll.get(_INVARIANT_KEY, coll.name)


def _iter_arenas(scene=None):
    root = _arenas_root(scene)
    if root is None:
        return
    for coll in root.children:
        yield coll


def _arena_by_invariant(invariant_name: str, scene=None):
    if not invariant_name or invariant_name == _NO_ARENA_ID:
        return None
    for coll in _iter_arenas(scene):
        if _arena_invariant(coll) == invariant_name:
            return coll
    return None


def _ensure_arena(invariant_name: str, context=None) -> bpy.types.Collection:
    """Get or create an arena collection under the scene-root Arenas collection."""
    scene = context.scene if context is not None else bpy.context.scene
    root = _ensure_arenas_root(context)
    coll = _arena_by_invariant(invariant_name, scene)
    if coll is None:
        coll = bpy.data.collections.new(invariant_name)
        root.children.link(coll)
    coll[_ARENA_MARK] = True
    coll[_INVARIANT_KEY] = invariant_name
    # Seed metadata props so the panel can always bind to them (empty == None).
    for key in (_NAME_KEY, _DESCRIPTION_KEY, _SHORT_DESCRIPTION_KEY):
        if key not in coll.keys():
            coll[key] = ""
    return coll


def _active_arena(context):
    name = context.scene.tgs_hex.active_arena
    return _arena_by_invariant(name, context.scene)

def _iter_cells(coll: bpy.types.Collection):
    for obj in coll.objects:
        if _CELL_MARK in obj.keys():
            yield obj


def _cell_at(coll: bpy.types.Collection, q: int, r: int):
    for obj in _iter_cells(coll):
        if int(obj["tgs_q"]) == q and int(obj["tgs_r"]) == r:
            return obj
    return None


def _cell_arena_collection(obj: bpy.types.Object):
    for coll in obj.users_collection:
        if coll.get(_ARENA_MARK):
            return coll
    return None


def _iter_building_instances(coll: bpy.types.Collection):
    for obj in coll.objects:
        if _BUILDING_INSTANCE_MARK in obj.keys():
            yield obj


def _building_instance_for_cell(coll: bpy.types.Collection, q: int, r: int):
    for obj in _iter_building_instances(coll):
        if int(obj.get(_BUILDING_CELL_Q, 999999)) == q and int(obj.get(_BUILDING_CELL_R, 999999)) == r:
            return obj
    return None


def _remove_building_instance(obj: bpy.types.Object) -> None:
    bpy.data.objects.remove(obj, do_unlink=True)


def _remove_cell_building_instance(obj: bpy.types.Object) -> None:
    coll = _cell_arena_collection(obj)
    if coll is None:
        return
    inst = _building_instance_for_cell(coll, int(obj["tgs_q"]), int(obj["tgs_r"]))
    if inst is not None:
        _remove_building_instance(inst)


def _remove_cell_obj(obj: bpy.types.Object) -> None:
    _remove_cell_building_instance(obj)
    mesh = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if mesh and mesh.users == 0:
        bpy.data.meshes.remove(mesh)

# --------------------------------------------------------------------------- #
# Geometry / materials
# --------------------------------------------------------------------------- #
def _cell_coord(obj: bpy.types.Object) -> tuple[int, int]:
    return int(obj["tgs_q"]), int(obj["tgs_r"])


def _cell_has_building(obj: bpy.types.Object) -> bool:
    return obj.get("tgs_building", "none") not in {"", "none", _NO_BUILDING_ID}


def _clear_cell_building_team(obj: bpy.types.Object) -> None:
    if "tgs_team" in obj.keys():
        del obj["tgs_team"]


def _cell_building_team(obj: bpy.types.Object) -> str:
    if not _cell_has_building(obj):
        return "neutral"
    team = obj.get("tgs_team", "neutral")
    return team if team in schema.TEAMS else "neutral"


def _set_cell_building_team(obj: bpy.types.Object, team: str) -> None:
    obj["tgs_team"] = team if team in schema.TEAMS else "neutral"


def _normalize_cell_building_team(obj: bpy.types.Object) -> None:
    if _cell_has_building(obj):
        _set_cell_building_team(obj, _cell_building_team(obj))
    else:
        _clear_cell_building_team(obj)


_HEX_NEIGHBOR_STEPS = (
    (1, 0), (1, -1), (0, -1),
    (-1, 0), (-1, 1), (0, 1),
)


def _neighbor_coords(q: int, r: int):
    for dq, dr in _HEX_NEIGHBOR_STEPS:
        yield q + dq, r + dr


def _territory_team_map(coll: bpy.types.Collection, normalize: bool = True) -> dict[tuple[int, int], str]:
    cells_by_coord = {_cell_coord(obj): obj for obj in _iter_cells(coll)}
    controlling: dict[tuple[int, int], tuple[bpy.types.Object, int]] = {}
    frontier = []

    for obj in _iter_cells(coll):
        if normalize:
            _normalize_cell_building_team(obj)
        if not _cell_has_building(obj):
            continue
        coord = _cell_coord(obj)
        controlling[coord] = (obj, 0)
        for neighbor in _neighbor_coords(*coord):
            if neighbor in cells_by_coord:
                frontier.append((obj, neighbor, 1))

    read_index = 0
    while read_index < len(frontier):
        building_obj, coord, step_distance = frontier[read_index]
        read_index += 1
        current = controlling.get(coord)
        if current is not None and step_distance >= current[1]:
            continue
        controlling[coord] = (building_obj, step_distance)
        for neighbor in _neighbor_coords(*coord):
            if neighbor in cells_by_coord:
                frontier.append((building_obj, neighbor, step_distance + 1))

    return {
        coord: _cell_building_team(controller[0]) if controller else "neutral"
        for coord, controller in ((coord, controlling.get(coord)) for coord in cells_by_coord)
    }


def _team_color(team: str):
    table = {
        "neutral": (0.60, 0.60, 0.62, 1.0),
        "blue":    (0.20, 0.40, 0.90, 1.0),
        "red":     (0.90, 0.25, 0.25, 1.0),
        "yellow":  (0.92, 0.85, 0.20, 1.0),
        "green":   (0.25, 0.75, 0.35, 1.0),
        "hostile": (0.70, 0.20, 0.70, 1.0),
    }
    return table.get(team, (0.45, 0.55, 0.45, 1.0))


def _material_for(team_or_land: str) -> bpy.types.Material:
    name = f"TGS_{team_or_land}"
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
        mat.use_nodes = False
    mat.diffuse_color = _team_color(team_or_land)
    return mat


def _hex_prism_mesh(q: int, r: int, height: int) -> bpy.types.Mesh:
    """Build a hex-prism mesh centred on the cell origin, scaled cm -> m."""
    corners = hexmath.hex_corners(q, r)
    cx, cy = hexmath.axial_to_world(q, r)
    top_z = (hexmath.height_to_z(height) + hexmath.CELL_HEIGHT_STEP) * _SCALE

    verts = [((x - cx) * _SCALE, (y - cy) * _SCALE, 0.0) for (x, y) in corners]
    verts += [((x - cx) * _SCALE, (y - cy) * _SCALE, top_z) for (x, y) in corners]

    faces = [(0, 1, 2, 3, 4, 5), (6, 7, 8, 9, 10, 11)]
    for i in range(6):
        j = (i + 1) % 6
        faces.append((i, j, j + 6, i + 6))

    mesh = bpy.data.meshes.new(f"TGS_Cell_{q}_{r}")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    return mesh


def _style_cell(obj: bpy.types.Object, display_team: str | None = None) -> None:
    """Set material, object color, and world location from the object's props."""
    q = int(obj["tgs_q"])
    r = int(obj["tgs_r"])
    team = display_team or (_cell_building_team(obj) if _cell_has_building(obj) else "neutral")

    obj.color = _team_color(team)
    obj.data.materials.clear()
    obj.data.materials.append(_material_for(team))

    cx, cy = hexmath.axial_to_world(q, r)
    obj.location = Vector((cx * _SCALE, cy * _SCALE, 0.0))


def _cell_top_z(obj: bpy.types.Object) -> float:
    height = int(obj.get("tgs_height", 0))
    return (hexmath.height_to_z(height) + hexmath.CELL_HEIGHT_STEP) * _SCALE


def _direction_angle(direction: str) -> float:
    degrees = {
        "North": 0.0,
        "NorthEast": -60.0,
        "SouthEast": -120.0,
        "South": 180.0,
        "SouthWest": 120.0,
        "NorthWest": 60.0,
        # Legacy/imported 8-way values remain readable, but editor rotation snaps to hex directions.
        "East": -90.0,
        "West": 90.0,
    }.get(direction, 0.0)
    return math.radians(degrees)


def _direction_heading(direction: str) -> float:
    return (math.degrees(_direction_angle(direction)) + 90.0) % 360.0


def _angle_distance(a: float, b: float) -> float:
    return abs((a - b + 180.0) % 360.0 - 180.0)


def _direction_from_heading(heading: float) -> str:
    heading %= 360.0
    return min(_BUILDING_DIRECTIONS,
               key=lambda direction: _angle_distance(_direction_heading(direction), heading))


def _rotate_direction(direction: str, steps: int) -> str:
    return _direction_from_heading(_direction_heading(direction) + 60.0 * steps)


def _mirror_axis_angle(mirror_fn, offset_steps: int) -> float:
    base_axis = {
        _mirror_horizontal: 0.0,
        _mirror_rising: -120.0,
        _mirror_falling: 120.0,
    }.get(mirror_fn, 0.0)
    return base_axis + 60.0 * offset_steps


def _mirror_direction(direction: str, mirror_fn, offset_steps: int) -> str:
    axis = _mirror_axis_angle(mirror_fn, offset_steps)
    return _direction_from_heading(2.0 * axis - _direction_heading(direction))


def _sync_cell_building_instance(obj: bpy.types.Object) -> None:
    coll = _cell_arena_collection(obj)
    if coll is None:
        return

    q = int(obj["tgs_q"])
    r = int(obj["tgs_r"])
    building_name = obj.get("tgs_building", "none")
    inst = _building_instance_for_cell(coll, q, r)
    if building_name in {"", "none", _NO_BUILDING_ID}:
        if inst is not None:
            _remove_building_instance(inst)
        return

    source = _building_collection_by_name(building_name, bpy.context.scene)
    if source is None:
        if inst is not None:
            _remove_building_instance(inst)
        return

    if inst is None or inst.instance_collection != source:
        if inst is not None:
            _remove_building_instance(inst)
        inst = bpy.data.objects.new(f"Building_{building_name}_{q}_{r}", None)
        inst.empty_display_type = "CUBE"
        inst.empty_display_size = hexmath.CELL_RADIUS * _SCALE * 0.18
        inst.instance_type = "COLLECTION"
        inst.instance_collection = source
        inst[_BUILDING_INSTANCE_MARK] = True
        inst[_BUILDING_CELL_Q] = q
        inst[_BUILDING_CELL_R] = r
        coll.objects.link(inst)

    team = _cell_building_team(obj)
    inst.name = f"Building_{building_name}_{q}_{r}"
    inst[_BUILDING_INSTANCE_MARK] = True
    inst[_BUILDING_CELL_Q] = q
    inst[_BUILDING_CELL_R] = r
    inst["tgs_building"] = building_name
    inst["tgs_team"] = team
    inst["tgs_direction"] = obj.get("tgs_direction", "North")
    inst.color = _team_color(team)

    cx, cy = hexmath.axial_to_world(q, r)
    inst.location = Vector((cx * _SCALE, cy * _SCALE, _cell_top_z(obj)))
    inst.rotation_euler = (0.0, 0.0, _direction_angle(inst["tgs_direction"]))


def _refresh_arena_territory(coll: bpy.types.Collection) -> None:
    territory = _territory_team_map(coll)
    for obj in _iter_cells(coll):
        _normalize_cell_building_team(obj)
        _style_cell(obj, territory.get(_cell_coord(obj), "neutral"))
        _sync_cell_building_instance(obj)


def _sync_arena_building_instances(coll: bpy.types.Collection) -> None:
    live_cells = set()
    for obj in _iter_cells(coll):
        key = (int(obj["tgs_q"]), int(obj["tgs_r"]))
        live_cells.add(key)
        _apply_cell(obj)
    for inst in list(_iter_building_instances(coll)):
        key = (int(inst.get(_BUILDING_CELL_Q, 999999)), int(inst.get(_BUILDING_CELL_R, 999999)))
        if key not in live_cells:
            _remove_building_instance(inst)
    _refresh_arena_territory(coll)


def _apply_cell(obj: bpy.types.Object) -> None:
    """Rebuild mesh, restyle, and keep any building instance attached."""
    old_mesh = obj.data
    obj.data = _hex_prism_mesh(int(obj["tgs_q"]), int(obj["tgs_r"]),
                               int(obj.get("tgs_height", 0)))
    if old_mesh and old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)
    _normalize_cell_building_team(obj)
    _style_cell(obj)
    _sync_cell_building_instance(obj)


def _spawn_cell(coll: bpy.types.Collection, cell: Cell) -> bpy.types.Object:
    # Create the object around a real mesh; an Empty (data=None) cannot later take a Mesh.
    mesh = _hex_prism_mesh(cell.q, cell.r, cell.height)
    obj = bpy.data.objects.new(f"Cell_{cell.q}_{cell.r}", mesh)
    obj["tgs_q"] = cell.q
    obj["tgs_r"] = cell.r
    obj["tgs_height"] = cell.height
    obj["tgs_building"] = cell.building.type if cell.building else "none"
    if cell.building:
        obj["tgs_team"] = cell.building.team
    obj["tgs_order"] = cell.building.order if cell.building else 1
    obj["tgs_direction"] = cell.building.direction if cell.building else "North"
    coll.objects.link(obj)
    _style_cell(obj)
    _sync_cell_building_instance(obj)
    return obj


def _clear_arena(coll: bpy.types.Collection) -> None:
    for obj in list(_iter_cells(coll)):
        _remove_cell_obj(obj)
    for inst in list(_iter_building_instances(coll)):
        _remove_building_instance(inst)


def _arena_to_level(coll: bpy.types.Collection) -> Level:
    cells = []
    for obj in _iter_cells(coll):
        building = None
        if obj.get("tgs_building", "none") != "none":
            building = Building(
                type=obj["tgs_building"],
                order=int(obj.get("tgs_order", 1)) or 1,
                direction=obj.get("tgs_direction", "North"),
                team=_cell_building_team(obj),
            )
        cells.append(Cell(
            q=int(obj["tgs_q"]), r=int(obj["tgs_r"]),
            height=int(obj.get("tgs_height", 0)), building=building,
        ))
    cells.sort(key=lambda c: (c.q, c.r))

    def _meta(key):
        value = str(coll.get(key, "")).strip()
        return value or None

    return Level(
        invariant_name=_arena_invariant(coll),
        cells=cells,
        name=_meta(_NAME_KEY),
        description=_meta(_DESCRIPTION_KEY),
        short_description=_meta(_SHORT_DESCRIPTION_KEY),
    )


# --------------------------------------------------------------------------- #
# Auto-export on save
# --------------------------------------------------------------------------- #
def _export_all_arenas() -> tuple[int, str | None]:
    """Write every arena to <levels_dir>/<class_name>.json. Returns (count, error)."""
    scene = bpy.context.scene
    if not getattr(scene, "tgs_hex", None):
        return 0, None
    levels_dir = bpy.path.abspath(scene.tgs_hex.levels_dir)
    if not levels_dir or not Path(levels_dir).is_dir():
        return 0, "Levels Folder not set or missing"
    count = 0
    for coll in _iter_arenas(scene):
        level = _arena_to_level(coll)
        schema.save_level(level, Path(levels_dir) / f"{level.class_name}.json")
        count += 1
    return count, None


@persistent
def _on_save_pre(_dummy):
    try:
        count, err = _export_all_arenas()
        if err:
            print(f"[TGS Hex] auto-export skipped: {err}")
        elif count:
            print(f"[TGS Hex] auto-exported {count} arena(s) to JSON")
    except Exception as exc:  # never block the .blend save
        print(f"[TGS Hex] auto-export failed: {exc}")


# --------------------------------------------------------------------------- #
# Settings
# --------------------------------------------------------------------------- #
def _arena_names(scene=None) -> list[str]:
    return sorted(_arena_invariant(c) for c in _iter_arenas(scene))


def _arena_enum_items(self, context):
    scene = context.scene if context is not None else None
    names = _arena_names(scene)
    if not names:
        return [(_NO_ARENA_ID, "<no arenas>", "No arena collections in the Arenas collection")]
    return [(n, n, "") for n in names]


def _building_enum_items(self, context):
    scene = context.scene if context is not None else None
    items = [("none", "None", "Remove building from painted cells")]
    items.extend((n, n.replace("_", " ").title(), "Instance this building collection")
                 for n in _building_names(scene))
    return items


def _team_index(team: str) -> int:
    try:
        return schema.TEAMS.index(team) + 1
    except ValueError:
        return 0


def _team_setting_label(team: str) -> str:
    index = _team_index(team)
    label = team.replace("_", " ").title()
    return f"{index}: {label}" if index else label


def _building_setting_ids(scene=None) -> list[str]:
    return ["none", *_building_names(scene)]


def _active_building_name(settings, scene=None) -> str:
    names = _building_setting_ids(scene)
    current = getattr(settings, "active_building", "none") or "none"
    return current if current in names else names[0]


def _step_active_building(settings, scene, step: int) -> str:
    names = _building_setting_ids(scene)
    current = _active_building_name(settings, scene)
    index = names.index(current) if current in names else 0
    settings.active_building = names[(index + step) % len(names)]
    return settings.active_building


def _next_direction(direction: str, step: int = 1) -> str:
    directions = list(_BUILDING_DIRECTIONS)
    try:
        index = directions.index(direction)
    except ValueError:
        snapped = _direction_from_heading(_direction_heading(direction))
        index = directions.index(snapped) if snapped in directions else 0
    return directions[(index + step) % len(directions)]


def _apply_paint_setting_digit(context, digit: int) -> bool:
    settings = context.scene.tgs_hex
    mode = settings.paint_tool
    if mode == "building":
        if digit == 1:
            _step_active_building(settings, context.scene, -1)
        elif digit == 2:
            _step_active_building(settings, context.scene, 1)
        else:
            return False
    elif mode == "team":
        if digit < 1 or digit > len(schema.TEAMS):
            return False
        settings.paint_team = schema.TEAMS[digit - 1]
    elif mode == "set_height":
        settings.paint_height = digit
    else:
        return False
    _set_paint_status(context)
    _tag_viewport_redraw(context)
    return True


def _cycle_radial_symmetry(context) -> None:
    settings = context.scene.tgs_hex
    radial_ids = [identifier for identifier, _label, _description in _RADIAL_SYMMETRY_ITEMS]
    current = settings.symmetry_radial
    try:
        index = radial_ids.index(current)
    except ValueError:
        index = 0
    settings.symmetry_radial = radial_ids[(index + 1) % len(radial_ids)]
    _set_paint_status(context)
    _tag_viewport_redraw(context)


def _toggle_symmetry_hexant(context, index: int) -> None:
    settings = context.scene.tgs_hex
    prop = f"symmetry_hexant_{index % 6}"
    setattr(settings, prop, not getattr(settings, prop))
    _tag_viewport_redraw(context)


def _toggle_symmetry_mirror(context, mirror: str) -> None:
    settings = context.scene.tgs_hex
    prop = _MIRROR_PROPS.get(mirror)
    if prop is None:
        return
    setattr(settings, prop, not getattr(settings, prop))
    _tag_viewport_redraw(context)


def _handle_symmetry_key(context, event_type: str) -> bool:
    if event_type == "J":
        _cycle_radial_symmetry(context)
        return True
    if event_type in _HEXANT_TOGGLE_KEYS:
        _toggle_symmetry_hexant(context, _HEXANT_TOGGLE_KEYS[event_type])
        return True
    if event_type in _MIRROR_TOGGLE_KEYS:
        _toggle_symmetry_mirror(context, _MIRROR_TOGGLE_KEYS[event_type])
        return True
    return False
def _find_layer_collection(layer_coll, collection):
    """Depth-first search for the LayerCollection wrapping `collection`."""
    if layer_coll.collection == collection:
        return layer_coll
    for child in layer_coll.children:
        found = _find_layer_collection(child, collection)
        if found is not None:
            return found
    return None


def _isolate_arena(context, invariant_name):
    """Show only the named arena's collection; hide every other arena."""
    if not invariant_name or invariant_name == _NO_ARENA_ID:
        return
    view_layer = context.view_layer
    for coll in _iter_arenas(context.scene):
        layer_coll = _find_layer_collection(view_layer.layer_collection, coll)
        if layer_coll is None:
            continue
        layer_coll.hide_viewport = _arena_invariant(coll) != invariant_name

def _on_active_arena_update(self, context):
    _isolate_arena(context, self.active_arena)


def _tag_viewport_redraw(context):
    screen = getattr(context, "screen", None)
    if screen is None:
        return
    for area in screen.areas:
        if area.type == "VIEW_3D":
            area.tag_redraw()


def _on_radius_update(self, context):
    _invalidate_grid_batch()
    _tag_viewport_redraw(context)


def _on_grid_visibility_update(self, context):
    _tag_viewport_redraw(context)


class TGSHexSettings(PropertyGroup):
    levels_dir: StringProperty(
        name="Levels Folder", subtype="DIR_PATH",
        description="Folder of level JSON files; arenas auto-export here on save")
    active_arena: EnumProperty(
        name="Arena", items=_arena_enum_items,
        description="The arena that Add/Delete/Import act on",
        update=_on_active_arena_update)
    arena_radius: IntProperty(
        name="Arena Radius", default=_DEFAULT_ARENA_RADIUS, min=1, max=20,
        description="Legal play area is every hex within this many steps of centre",
        update=_on_radius_update)
    show_allowed_grid: BoolProperty(
        name="Show Allowed Grid", default=True,
        description="Outline every legal cell so the map extents are visible",
        update=_on_grid_visibility_update)
    paint_tool: EnumProperty(
        name="Paint Mode",
        items=_PAINT_MODE_ITEMS,
        default="add",
        description="What the active TGS Hex Paint tool does on click")
    active_building: EnumProperty(
        name="Building",
        items=_building_enum_items,
        description="Building collection to place in Building paint mode")
    building_direction: EnumProperty(
        name="Direction",
        items=_DIRECTION_ITEMS,
        default="North",
        description="Direction assigned to newly painted buildings")
    paint_team: EnumProperty(
        name="Building Team",
        items=_TEAM_ITEMS,
        default="neutral",
        description="Team assigned to buildings; cells derive their color from building territory")
    paint_height: IntProperty(
        name="Set Height",
        default=0,
        min=0,
        max=20,
        description="Height assigned by Set Height paint mode")
    symmetry_center_q: IntProperty(
        name="Center Q", default=0,
        description="Q coordinate for the symmetry center")
    symmetry_center_r: IntProperty(
        name="Center R", default=0,
        description="R coordinate for the symmetry center")
    symmetry_mirror_horizontal: BoolProperty(
        name="Mirror Horizontal", default=False,
        description="Mirror across the horizontal axis through the symmetry center")
    symmetry_mirror_rising: BoolProperty(
        name="Mirror Rising Diagonal", default=False,
        description="Mirror across the rising diagonal axis through the symmetry center")
    symmetry_mirror_falling: BoolProperty(
        name="Mirror Falling Diagonal", default=False,
        description="Mirror across the falling diagonal axis through the symmetry center")
    symmetry_radial: EnumProperty(
        name="Radial Symmetry", items=_RADIAL_SYMMETRY_ITEMS, default="none",
        description="Repeat paint strokes around the symmetry center")
    symmetry_axis_offset: EnumProperty(
        name="Axis Offset", items=_SYMMETRY_OFFSET_ITEMS, default="0",
        description="Rotate mirror axes around the symmetry center")
    symmetry_hexant_0: BoolProperty(name="0", default=True, description="Include the 0 degree radial copy")
    symmetry_hexant_1: BoolProperty(name="60", default=True, description="Include the 60 degree radial copy")
    symmetry_hexant_2: BoolProperty(name="120", default=True, description="Include the 120 degree radial copy")
    symmetry_hexant_3: BoolProperty(name="180", default=True, description="Include the 180 degree radial copy")
    symmetry_hexant_4: BoolProperty(name="240", default=True, description="Include the 240 degree radial copy")
    symmetry_hexant_5: BoolProperty(name="300", default=True, description="Include the 300 degree radial copy")

def _set_active_cell_prop(key: str, value, context) -> None:
    obj = context.active_object
    if obj is not None and _CELL_MARK in obj.keys():
        obj[key] = value
        _apply_cell(obj)
        coll = _cell_arena_collection(obj)
        if coll is not None:
            _refresh_arena_territory(coll)


# --------------------------------------------------------------------------- #
# Operators
# --------------------------------------------------------------------------- #
class TGS_OT_create_arenas_collection(Operator):
    bl_idname = "tgs.create_arenas_collection"
    bl_label = "Create Arenas Collection"
    bl_description = "Create the scene-root Arenas collection that holds arena collections"

    def execute(self, context):
        if _arenas_root(context.scene) is not None:
            self.report({"INFO"}, "Arenas collection already exists")
            return {"FINISHED"}
        _ensure_arenas_root(context)
        self.report({"INFO"}, "Created Arenas collection")
        return {"FINISHED"}


class TGS_OT_create_buildings_collection(Operator):
    bl_idname = "tgs.create_buildings_collection"
    bl_label = "Create Buildings Collection"
    bl_description = "Create the scene-root Buildings collection that holds building prefab collections"

    def execute(self, context):
        if _buildings_root(context.scene) is not None:
            self.report({"INFO"}, "Buildings collection already exists")
            return {"FINISHED"}
        _ensure_buildings_root(context)
        self.report({"INFO"}, "Created Buildings collection")
        return {"FINISHED"}

class TGS_OT_new_arena(Operator):
    bl_idname = "tgs.new_arena"
    bl_label = "New Arena"
    bl_description = "Create a new empty arena collection"
    invariant_name: StringProperty(name="Arena Name", default="Arena.untitled")

    def execute(self, context):
        name = self.invariant_name.strip()
        if "." not in name:
            self.report({"ERROR"}, "Arena Name must look like 'Arena.<name>'")
            return {"CANCELLED"}
        if _arena_by_invariant(name, context.scene) is not None:
            self.report({"WARNING"}, f"Arena {name} already exists")
            return {"CANCELLED"}
        _ensure_arena(name, context)
        context.scene.tgs_hex.active_arena = name
        self.report({"INFO"}, f"Created {name}")
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class TGS_OT_import_level(Operator):
    bl_idname = "tgs.import_level"
    bl_label = "Import Level JSON"
    bl_description = "Load a level JSON as a new (or replaced) arena"
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        level = schema.load_level(Path(self.filepath))
        coll = _ensure_arena(level.invariant_name, context)
        coll[_NAME_KEY] = level.name or ""
        coll[_DESCRIPTION_KEY] = level.description or ""
        coll[_SHORT_DESCRIPTION_KEY] = level.short_description or ""
        _clear_arena(coll)
        for cell in level.cells:
            _spawn_cell(coll, cell)
        _refresh_arena_territory(coll)
        context.scene.tgs_hex.active_arena = level.invariant_name
        self.report({"INFO"},
                    f"Imported {len(level.cells)} cells into {level.invariant_name}")
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class TGS_OT_export_all(Operator):
    bl_idname = "tgs.export_all"
    bl_label = "Export All JSON"
    bl_description = "Write every arena to the Levels Folder now"

    def execute(self, context):
        count, err = _export_all_arenas()
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}
        self.report({"INFO"}, f"Exported {count} arena(s)")
        return {"FINISHED"}


class TGS_OT_add_cell(Operator):
    bl_idname = "tgs.add_cell"
    bl_label = "Add Cell"
    bl_description = "Add a new cell to the active arena"
    q: IntProperty(name="Q", default=0)
    r: IntProperty(name="R", default=0)

    def execute(self, context):
        coll = _active_arena(context)
        if coll is None:
            self.report({"ERROR"}, "No active arena â€” create or import one first")
            return {"CANCELLED"}
        for obj in _iter_cells(coll):
            if int(obj["tgs_q"]) == self.q and int(obj["tgs_r"]) == self.r:
                self.report({"WARNING"}, f"Cell ({self.q},{self.r}) already exists")
                return {"CANCELLED"}
        obj = _spawn_cell(coll, Cell(q=self.q, r=self.r))
        _refresh_arena_territory(coll)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class TGS_OT_delete_cell(Operator):
    bl_idname = "tgs.delete_cell"
    bl_label = "Delete Selected Cells"
    bl_description = "Remove the selected cell objects"

    def execute(self, context):
        count = 0
        affected = set()
        for obj in list(context.selected_objects):
            if _CELL_MARK in obj.keys():
                coll = _cell_arena_collection(obj)
                if coll is not None:
                    affected.add(coll)
                _remove_cell_obj(obj)
                count += 1
        for coll in affected:
            _refresh_arena_territory(coll)
        self.report({"INFO"}, f"Deleted {count} cell(s)")
        return {"FINISHED"}



class TGS_OT_refresh_building_instances(Operator):
    bl_idname = "tgs.refresh_building_instances"
    bl_label = "Refresh Building Instances"
    bl_description = "Rebuild building collection instances for the active arena"

    def execute(self, context):
        coll = _active_arena(context)
        if coll is None:
            self.report({"ERROR"}, "No active arena - create or import one first")
            return {"CANCELLED"}
        _sync_arena_building_instances(coll)
        self.report({"INFO"}, "Refreshed building instances")
        return {"FINISHED"}

# --------------------------------------------------------------------------- #
# Modal paint tool
# --------------------------------------------------------------------------- #
def _paint_mode_label(mode: str) -> str:
    for identifier, label, _description in _PAINT_MODE_ITEMS:
        if identifier == mode:
            return label
    return mode


def _paint_state_line(context, settings) -> str:
    mode = settings.paint_tool
    if mode == "building":
        building = _active_building_name(settings, context.scene).replace("_", " ").title()
        return f"Building: {building}"
    if mode == "team":
        return f"Building Team: {_team_setting_label(settings.paint_team)}"
    if mode == "set_height":
        return f"Set Height: {settings.paint_height}"
    return _paint_mode_label(mode)


def _paint_setting_summary(context, settings) -> str:
    mode = settings.paint_tool
    if mode == "building":
        return f"Direction: {settings.building_direction} | 1 Prev  2 Next  RMB Rotate"
    if mode == "team":
        return f"1-{min(9, len(schema.TEAMS))} assigns hovered building team | symmetry ignored"
    if mode == "set_height":
        return "0-9 chooses target height | LMB paints selected height"
    if mode == "height":
        return "LMB raises existing cells | RMB lowers existing cells"
    return "LMB empty adds | LMB filled removes | drag keeps first action"


def _paint_hud_rows(context, settings) -> list[dict]:
    return [
        {"text": _paint_state_line(context, settings), "size": 32, "color": _HUD_STATE_COLOR},
        {"text": _paint_setting_summary(context, settings), "size": 20, "color": _HUD_DETAIL_COLOR},
        {"text": "Q Add/Remove   W/E Raise-Lower   R Set Height   T Building   Y Team", "size": 14, "color": _HUD_KEYS_COLOR},
        {"text": "J Radial   U I K M N H Hexants   O L P Mirrors", "size": 13, "color": _HUD_KEYS_COLOR},
    ]


def _paint_status_text(context) -> str:
    mode = context.scene.tgs_hex.paint_tool
    return (f"TGS Hex Paint: {_paint_mode_label(mode)} | "
            "Q Add/Remove  W/E Raise-Lower  R Set Height  T Building  Y Team")

def _set_paint_status(context) -> None:
    workspace = getattr(context, "workspace", None)
    if workspace is not None:
        workspace.status_text_set(_paint_status_text(context))


def _cursor_to_axial(context, region, rv3d, mouse_x, mouse_y):
    """Raycast the cursor onto the z=0 plane and return the allowed (q, r), or None."""
    coord = (mouse_x - region.x, mouse_y - region.y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    if abs(direction.z) < 1e-6:
        return None
    distance = -origin.z / direction.z
    if distance < 0.0:
        return None
    hit = origin + direction * distance
    # Blender metres -> cm world (left, forward) used by the hex math.
    left = hit.x / _SCALE
    forward = hit.y / _SCALE
    q, r = hexmath.world_to_axial(left, forward)
    return (q, r) if _hex_distance(q, r) <= _arena_radius(context) else None


def _rotate_axial(q: int, r: int, steps: int) -> tuple[int, int]:
    steps %= 6
    for _ in range(steps):
        q, r = -r, q + r
    return q, r


def _mirror_horizontal(q: int, r: int) -> tuple[int, int]:
    return q, -q - r


def _mirror_rising(q: int, r: int) -> tuple[int, int]:
    return r, q


def _mirror_falling(q: int, r: int) -> tuple[int, int]:
    return -q - r, r


def _offset_mirror(q: int, r: int, mirror_fn, offset_steps: int) -> tuple[int, int]:
    pre_q, pre_r = _rotate_axial(q, r, -offset_steps)
    mirrored_q, mirrored_r = mirror_fn(pre_q, pre_r)
    return _rotate_axial(mirrored_q, mirrored_r, offset_steps)


def _target_allowed(context, q: int, r: int) -> bool:
    return _hex_distance(q, r) <= _arena_radius(context)


def _add_symmetry_target(context, out, seen, center_q: int, center_r: int,
                         delta_q: int, delta_r: int) -> None:
    target = (center_q + delta_q, center_r + delta_r)
    if target in seen or not _target_allowed(context, target[0], target[1]):
        return
    seen.add(target)
    out.append(target)



def _symmetry_hexant_enabled(settings, steps: int) -> bool:
    return getattr(settings, f"symmetry_hexant_{steps % 6}", True)

def _symmetry_targets(context, q: int, r: int, settings) -> list[tuple[int, int]]:
    center_q = settings.symmetry_center_q
    center_r = settings.symmetry_center_r
    delta_q = q - center_q
    delta_r = r - center_r

    deltas = []
    seen_deltas = set()

    def add_delta(next_q: int, next_r: int) -> bool:
        key = (next_q, next_r)
        if key in seen_deltas:
            return False
        seen_deltas.add(key)
        deltas.append(key)
        return True

    add_delta(delta_q, delta_r)

    radial_steps = {"60": 1, "120": 2, "180": 3}.get(settings.symmetry_radial)
    if radial_steps is not None:
        for steps in range(radial_steps, 6, radial_steps):
            if _symmetry_hexant_enabled(settings, steps):
                add_delta(*_rotate_axial(delta_q, delta_r, steps))
    offset_steps = int(settings.symmetry_axis_offset)
    mirror_fns = []
    if settings.symmetry_mirror_horizontal:
        mirror_fns.append(_mirror_horizontal)
    if settings.symmetry_mirror_rising:
        mirror_fns.append(_mirror_rising)
    if settings.symmetry_mirror_falling:
        mirror_fns.append(_mirror_falling)

    if mirror_fns:
        changed = True
        while changed:
            changed = False
            for existing_q, existing_r in list(deltas):
                for mirror_fn in mirror_fns:
                    mirror_q, mirror_r = _offset_mirror(existing_q, existing_r, mirror_fn, offset_steps)
                    changed = add_delta(mirror_q, mirror_r) or changed

    out = []
    seen_targets = set()
    for target_delta_q, target_delta_r in deltas:
        _add_symmetry_target(
            context, out, seen_targets, center_q, center_r,
            target_delta_q, target_delta_r)
    return out


def _symmetry_targets_with_directions(context, q: int, r: int, settings,
                                      direction: str) -> list[tuple[int, int, str]]:
    center_q = settings.symmetry_center_q
    center_r = settings.symmetry_center_r
    delta_q = q - center_q
    delta_r = r - center_r

    states = []
    seen_deltas = set()

    def add_state(next_q: int, next_r: int, next_direction: str) -> bool:
        key = (next_q, next_r)
        if key in seen_deltas:
            return False
        seen_deltas.add(key)
        states.append((next_q, next_r, next_direction))
        return True

    add_state(delta_q, delta_r, direction)

    radial_steps = {"60": 1, "120": 2, "180": 3}.get(settings.symmetry_radial)
    if radial_steps is not None:
        for steps in range(radial_steps, 6, radial_steps):
            if _symmetry_hexant_enabled(settings, steps):
                add_state(
                    *_rotate_axial(delta_q, delta_r, steps),
                    _rotate_direction(direction, steps))

    offset_steps = int(settings.symmetry_axis_offset)
    mirror_fns = []
    if settings.symmetry_mirror_horizontal:
        mirror_fns.append(_mirror_horizontal)
    if settings.symmetry_mirror_rising:
        mirror_fns.append(_mirror_rising)
    if settings.symmetry_mirror_falling:
        mirror_fns.append(_mirror_falling)

    if mirror_fns:
        changed = True
        while changed:
            changed = False
            for existing_q, existing_r, existing_direction in list(states):
                for mirror_fn in mirror_fns:
                    mirror_q, mirror_r = _offset_mirror(existing_q, existing_r, mirror_fn, offset_steps)
                    mirror_direction = _mirror_direction(existing_direction, mirror_fn, offset_steps)
                    changed = add_state(mirror_q, mirror_r, mirror_direction) or changed

    out = []
    seen_targets = set()
    for target_delta_q, target_delta_r, target_direction in states:
        target = (center_q + target_delta_q, center_r + target_delta_r)
        if target in seen_targets or not _target_allowed(context, target[0], target[1]):
            continue
        seen_targets.add(target)
        out.append((target[0], target[1], target_direction))
    return out
def _update_paint_preview(context, event):
    global _paint_preview_cell
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None or _active_arena(context) is None:
        _paint_preview_cell = None
    else:
        _paint_preview_cell = _cursor_to_axial(context, region, rv3d, event.mouse_x, event.mouse_y)
    _tag_viewport_redraw(context)
    return _paint_preview_cell



def _rotate_building_at_cell(context, cell) -> bool:
    settings = context.scene.tgs_hex
    next_direction = _next_direction(settings.building_direction)
    coll = _active_arena(context)
    if coll is None or cell is None:
        settings.building_direction = next_direction
        _set_paint_status(context)
        _tag_viewport_redraw(context)
        return True

    rotated_direction = None
    for target_q, target_r in _symmetry_targets(context, cell[0], cell[1], settings):
        existing = _cell_at(coll, target_q, target_r)
        if existing is None or existing.get("tgs_building", "none") == "none":
            continue
        next_cell_direction = _next_direction(
            existing.get("tgs_direction", settings.building_direction))
        if rotated_direction is None:
            rotated_direction = next_cell_direction
        existing["tgs_direction"] = next_cell_direction
        _apply_cell(existing)

    if rotated_direction is not None:
        _refresh_arena_territory(coll)
    settings.building_direction = rotated_direction or next_direction
    _set_paint_status(context)
    _tag_viewport_redraw(context)
    return True

class TGS_OT_paint_preview(Operator):
    bl_idname = "tgs.paint_preview"
    bl_label = "Preview Hex Paint"
    bl_description = "Update the TGS Hex Paint hover preview"

    def invoke(self, context, event):
        if _hex_paint_tool_active(context):
            _update_paint_preview(context, event)
        return {"FINISHED"}

class TGS_OT_set_paint_mode(Operator):
    bl_idname = "tgs.set_paint_mode"
    bl_label = "Set Hex Paint Mode"
    bl_description = "Change the active TGS Hex Paint mode"

    mode: EnumProperty(items=_PAINT_MODE_ITEMS)

    def execute(self, context):
        context.scene.tgs_hex.paint_tool = self.mode
        _set_paint_status(context)
        return {"FINISHED"}



class TGS_OT_adjust_paint_setting(Operator):
    bl_idname = "tgs.adjust_paint_setting"
    bl_label = "Adjust Hex Paint Setting"
    bl_description = "Adjust the current TGS Hex Paint mode setting"

    digit: IntProperty(name="Digit", default=1, min=0, max=9)

    def execute(self, context):
        return {"FINISHED"} if _apply_paint_setting_digit(context, self.digit) else {"PASS_THROUGH"}



class TGS_OT_cycle_radial_symmetry(Operator):
    bl_idname = "tgs.cycle_radial_symmetry"
    bl_label = "Cycle Radial Symmetry"
    bl_description = "Cycle the radial symmetry mode"

    def execute(self, context):
        _cycle_radial_symmetry(context)
        return {"FINISHED"}


class TGS_OT_toggle_symmetry_hexant(Operator):
    bl_idname = "tgs.toggle_symmetry_hexant"
    bl_label = "Toggle Symmetry Hexant"
    bl_description = "Toggle one radial symmetry hexant"

    index: IntProperty(name="Hexant", default=0, min=0, max=5)

    def execute(self, context):
        _toggle_symmetry_hexant(context, self.index)
        return {"FINISHED"}


class TGS_OT_toggle_symmetry_mirror(Operator):
    bl_idname = "tgs.toggle_symmetry_mirror"
    bl_label = "Toggle Symmetry Mirror"
    bl_description = "Toggle one mirror symmetry axis"

    mirror: StringProperty(name="Mirror", default="horizontal")

    def execute(self, context):
        _toggle_symmetry_mirror(context, self.mirror)
        return {"FINISHED"}

class TGS_OT_rotate_building(Operator):
    bl_idname = "tgs.rotate_building"
    bl_label = "Rotate Building"
    bl_description = "Rotate the hovered building, or the building placement direction"

    def invoke(self, context, event):
        if context.scene.tgs_hex.paint_tool != "building":
            return {"PASS_THROUGH"}
        cell = _update_paint_preview(context, event)
        return {"FINISHED"} if _rotate_building_at_cell(context, cell) else {"CANCELLED"}

    def execute(self, context):
        if context.scene.tgs_hex.paint_tool != "building":
            return {"PASS_THROUGH"}
        return {"FINISHED"} if _rotate_building_at_cell(context, _paint_preview_cell) else {"CANCELLED"}


class TGS_OT_paint(Operator):
    bl_idname = "tgs.paint"
    bl_label = "Paint Cells"
    bl_description = "Paint cells with the active TGS Hex Paint workspace tool"

    _painting = False
    _last_cell = None
    _stroke_add_action = None
    _paint_button = "LEFTMOUSE"
    _height_step = 1

    def _apply(self, context, cell):
        if cell is None or cell == self._last_cell:
            return
        self._last_cell = cell
        settings = context.scene.tgs_hex
        coll = _active_arena(context)
        if coll is None:
            return
        q, r = cell
        tool = settings.paint_tool
        targets = [(q, r)] if tool == "team" else _symmetry_targets(context, q, r, settings)
        changed = False

        if tool == "add":
            add_cells = self._stroke_add_action
            if add_cells is None:
                add_cells = _cell_at(coll, q, r) is None
                self._stroke_add_action = add_cells
            for target_q, target_r in targets:
                existing = _cell_at(coll, target_q, target_r)
                if add_cells:
                    if existing is None:
                        _spawn_cell(coll, Cell(q=target_q, r=target_r))
                        changed = True
                elif existing is not None:
                    _remove_cell_obj(existing)
                    changed = True
        elif tool == "height":
            for target_q, target_r in targets:
                existing = _cell_at(coll, target_q, target_r)
                if existing is not None:
                    current_height = int(existing.get("tgs_height", 0))
                    new_height = max(0, current_height + self._height_step)
                    if new_height != current_height:
                        existing["tgs_height"] = new_height
                        _apply_cell(existing)
                        changed = True
        elif tool == "set_height":
            for target_q, target_r in targets:
                existing = _cell_at(coll, target_q, target_r)
                if existing is not None:
                    if int(existing.get("tgs_height", 0)) != settings.paint_height:
                        existing["tgs_height"] = settings.paint_height
                        _apply_cell(existing)
                        changed = True
        elif tool == "building":
            building_name = _active_building_name(settings, context.scene)
            target_entries = _symmetry_targets_with_directions(
                context, q, r, settings, settings.building_direction)
            for target_q, target_r, target_direction in target_entries:
                existing = _cell_at(coll, target_q, target_r)
                if existing is None:
                    continue
                had_building = _cell_has_building(existing)
                existing["tgs_building"] = building_name
                if building_name != "none":
                    existing["tgs_direction"] = target_direction
                    existing["tgs_order"] = int(existing.get("tgs_order", 1)) or 1
                    if not had_building or "tgs_team" not in existing.keys():
                        _set_cell_building_team(existing, settings.paint_team)
                else:
                    _clear_cell_building_team(existing)
                _apply_cell(existing)
                changed = True
        elif tool == "team":
            existing = _cell_at(coll, q, r)
            if existing is not None and _cell_has_building(existing):
                _set_cell_building_team(existing, settings.paint_team)
                _apply_cell(existing)
                changed = True

        if changed:
            _refresh_arena_territory(coll)

    def modal(self, context, event):
        if event.type in _PAINT_MODE_KEYS and event.value == "PRESS":
            context.scene.tgs_hex.paint_tool = _PAINT_MODE_KEYS[event.type]
            _set_paint_status(context)
            return {"RUNNING_MODAL"}

        if event.type in _PAINT_SETTING_DIGIT_KEYS and event.value == "PRESS":
            if _apply_paint_setting_digit(context, _PAINT_SETTING_DIGIT_KEYS[event.type]):
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}
        if event.value == "PRESS" and _handle_symmetry_key(context, event.type):
            return {"RUNNING_MODAL"}

        if event.type == "ESC":
            self._painting = False
            self._last_cell = None
            self._stroke_add_action = None
            context.workspace.status_text_set(None)
            return {"CANCELLED"}

        if event.type == self._paint_button and event.value == "RELEASE":
            self._painting = False
            self._last_cell = None
            self._stroke_add_action = None
            context.workspace.status_text_set(None)
            return {"FINISHED"}

        if event.type == "MOUSEMOVE" and self._painting:
            self._paint_at(context, event)
            return {"RUNNING_MODAL"}

        return {"PASS_THROUGH"}

    def _paint_at(self, context, event):
        cell = _update_paint_preview(context, event)
        self._apply(context, cell)

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"ERROR"}, "Run from the 3D viewport")
            return {"CANCELLED"}
        if _active_arena(context) is None:
            self.report({"ERROR"}, "No active arena - create or import one first")
            return {"CANCELLED"}
        settings = context.scene.tgs_hex
        if event.type == "RIGHTMOUSE":
            if settings.paint_tool == "building":
                _rotate_building_at_cell(context, _update_paint_preview(context, event))
                return {"FINISHED"}
            if settings.paint_tool != "height":
                return {"PASS_THROUGH"}

        self._painting = True
        self._last_cell = None
        self._stroke_add_action = None
        self._paint_button = event.type if event.type in {"LEFTMOUSE", "RIGHTMOUSE"} else "LEFTMOUSE"
        self._height_step = -1 if settings.paint_tool == "height" and self._paint_button == "RIGHTMOUSE" else 1
        _set_paint_status(context)
        self._paint_at(context, event)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class TGS_WST_hex_paint(WorkSpaceTool):
    bl_space_type = "VIEW_3D"
    bl_context_mode = "OBJECT"
    bl_idname = _HEX_PAINT_TOOL_ID
    bl_label = "TGS Hex Paint"
    bl_description = "Paint TGS arena cells"
    bl_icon = _HEX_PAINT_TOOL_ICON
    bl_keymap = (
        ("tgs.paint_preview", {"type": "MOUSEMOVE", "value": "ANY"}, {"properties": []}),
        ("tgs.paint", {"type": "LEFTMOUSE", "value": "PRESS"}, {"properties": []}),
        ("tgs.paint", {"type": "RIGHTMOUSE", "value": "PRESS"}, {"properties": []}),
        ("tgs.set_paint_mode", {"type": "Q", "value": "PRESS"}, {"properties": [("mode", "add")]}),
        ("tgs.set_paint_mode", {"type": "W", "value": "PRESS"}, {"properties": [("mode", "height")]}),
        ("tgs.set_paint_mode", {"type": "E", "value": "PRESS"}, {"properties": [("mode", "height")]}),
        ("tgs.set_paint_mode", {"type": "R", "value": "PRESS"}, {"properties": [("mode", "set_height")]}),
        ("tgs.set_paint_mode", {"type": "T", "value": "PRESS"}, {"properties": [("mode", "building")]}),
        ("tgs.set_paint_mode", {"type": "Y", "value": "PRESS"}, {"properties": [("mode", "team")]}),
        ("tgs.cycle_radial_symmetry", {"type": "J", "value": "PRESS"}, {"properties": []}),
        ("tgs.toggle_symmetry_hexant", {"type": "U", "value": "PRESS"}, {"properties": [("index", 0)]}),
        ("tgs.toggle_symmetry_hexant", {"type": "I", "value": "PRESS"}, {"properties": [("index", 1)]}),
        ("tgs.toggle_symmetry_hexant", {"type": "K", "value": "PRESS"}, {"properties": [("index", 2)]}),
        ("tgs.toggle_symmetry_hexant", {"type": "M", "value": "PRESS"}, {"properties": [("index", 3)]}),
        ("tgs.toggle_symmetry_hexant", {"type": "N", "value": "PRESS"}, {"properties": [("index", 4)]}),
        ("tgs.toggle_symmetry_hexant", {"type": "H", "value": "PRESS"}, {"properties": [("index", 5)]}),
        ("tgs.toggle_symmetry_mirror", {"type": "O", "value": "PRESS"}, {"properties": [("mirror", "horizontal")]}),
        ("tgs.toggle_symmetry_mirror", {"type": "L", "value": "PRESS"}, {"properties": [("mirror", "rising")]}),
        ("tgs.toggle_symmetry_mirror", {"type": "P", "value": "PRESS"}, {"properties": [("mirror", "falling")]}),
        ("tgs.adjust_paint_setting", {"type": "ZERO", "value": "PRESS"}, {"properties": [("digit", 0)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_0", "value": "PRESS"}, {"properties": [("digit", 0)]}),
        ("tgs.adjust_paint_setting", {"type": "ONE", "value": "PRESS"}, {"properties": [("digit", 1)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_1", "value": "PRESS"}, {"properties": [("digit", 1)]}),
        ("tgs.adjust_paint_setting", {"type": "TWO", "value": "PRESS"}, {"properties": [("digit", 2)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_2", "value": "PRESS"}, {"properties": [("digit", 2)]}),
        ("tgs.adjust_paint_setting", {"type": "THREE", "value": "PRESS"}, {"properties": [("digit", 3)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_3", "value": "PRESS"}, {"properties": [("digit", 3)]}),
        ("tgs.adjust_paint_setting", {"type": "FOUR", "value": "PRESS"}, {"properties": [("digit", 4)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_4", "value": "PRESS"}, {"properties": [("digit", 4)]}),
        ("tgs.adjust_paint_setting", {"type": "FIVE", "value": "PRESS"}, {"properties": [("digit", 5)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_5", "value": "PRESS"}, {"properties": [("digit", 5)]}),
        ("tgs.adjust_paint_setting", {"type": "SIX", "value": "PRESS"}, {"properties": [("digit", 6)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_6", "value": "PRESS"}, {"properties": [("digit", 6)]}),
        ("tgs.adjust_paint_setting", {"type": "SEVEN", "value": "PRESS"}, {"properties": [("digit", 7)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_7", "value": "PRESS"}, {"properties": [("digit", 7)]}),
        ("tgs.adjust_paint_setting", {"type": "EIGHT", "value": "PRESS"}, {"properties": [("digit", 8)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_8", "value": "PRESS"}, {"properties": [("digit", 8)]}),
        ("tgs.adjust_paint_setting", {"type": "NINE", "value": "PRESS"}, {"properties": [("digit", 9)]}),
        ("tgs.adjust_paint_setting", {"type": "NUMPAD_9", "value": "PRESS"}, {"properties": [("digit", 9)]}),
    )

    @classmethod
    def draw_settings(cls, context, layout, tool):
        settings = getattr(context.scene, "tgs_hex", None)
        if settings is not None:
            layout.prop(settings, "paint_tool", text="Mode", expand=True)
            if settings.paint_tool == "set_height":
                layout.prop(settings, "paint_height", text="Height")
            elif settings.paint_tool == "building":
                layout.prop(settings, "active_building", text="Building")
                layout.prop(settings, "building_direction", text="Direction")
            elif settings.paint_tool == "team":
                layout.prop(settings, "paint_team", text="Building Team")
            layout.prop(settings, "symmetry_radial", text="Radial")

def _find_arena_data_dir(start: Path):
    """Locate Content/Verse/Data by walking up from `start` to the UEFN project root.

    The project root is the first ancestor containing a *.uefnproject file (falling
    back to one containing a Plugins/ dir). Returns the existing
    Plugins/<plugin>/Content/Verse/Data directory, or None if not found.
    """
    for ancestor in [start, *start.parents]:
        is_root = any(ancestor.glob("*.uefnproject")) or (ancestor / "Plugins").is_dir()
        if not is_root:
            continue
        for plugin in (ancestor / "Plugins").glob("*"):
            candidate = plugin / "Content" / "Verse" / "Data"
            if candidate.is_dir():
                return candidate
    return None


class TGS_OT_generate_arenas(Operator):
    bl_idname = "tgs.generate_arenas"
    bl_label = "Generate Arenas.verse"
    bl_description = "Regenerate Arenas.verse from all level JSON files in the Levels Folder"

    def execute(self, context):
        levels_dir = bpy.path.abspath(context.scene.tgs_hex.levels_dir)
        if not levels_dir or not Path(levels_dir).is_dir():
            self.report({"ERROR"}, "Set a valid Levels Folder first")
            return {"CANCELLED"}
        data_dir = _find_arena_data_dir(Path(levels_dir))
        if data_dir is None:
            self.report({"ERROR"}, "Could not locate Content/Verse/Data; "
                                   "is the Levels Folder inside the UEFN project?")
            return {"CANCELLED"}
        levels = schema.load_all(Path(levels_dir))
        target = data_dir / "Arenas.verse"
        target.write_text(generate(levels), encoding="utf-8")
        self.report({"INFO"}, f"Wrote {target} from {len(levels)} level(s)")
        return {"FINISHED"}


# --------------------------------------------------------------------------- #
# Panel
# --------------------------------------------------------------------------- #
class TGS_PT_hex_panel(Panel):
    bl_label = "TGS Hex"
    bl_idname = "TGS_PT_hex_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "TGS Hex"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.tgs_hex

        box = layout.box()
        box.label(text="Arenas", icon="WORLD")
        box.prop(settings, "levels_dir")
        arena_names = _arena_names(context.scene)
        arenas_root = _arenas_root(context.scene)
        if arena_names:
            if settings.active_arena not in arena_names:
                settings.active_arena = arena_names[0]
            box.prop(settings, "active_arena")
        elif arenas_root is None:
            box.operator("tgs.create_arenas_collection", icon="OUTLINER_COLLECTION")
        else:
            box.label(text="No arenas yet - create a new arena", icon="INFO")
        row = box.row(align=True)
        row.operator("tgs.new_arena", icon="ADD")
        row.operator("tgs.import_level", icon="IMPORT")
        box.operator("tgs.export_all", icon="EXPORT")

        arena = _active_arena(context)
        if arena is not None:
            for key in (_NAME_KEY, _DESCRIPTION_KEY, _SHORT_DESCRIPTION_KEY):
                if key not in arena.keys():
                    arena[key] = ""   # self-heal arenas from pre-metadata files
            meta = box.box()
            meta.label(text="Strings (blank = omitted)", icon="TEXT")
            meta.prop(arena, '["tgs_name"]', text="Name")
            meta.prop(arena, '["tgs_short_description"]', text="Short Desc")
            meta.prop(arena, '["tgs_description"]', text="Description")

        box = layout.box()
        box.label(text="Paint Tool", icon="BRUSH_DATA")
        op = box.operator("wm.tool_set_by_id", icon="BRUSH_DATA", text="Activate Hex Paint Tool")
        op.name = _HEX_PAINT_TOOL_ID
        box.prop(settings, "paint_tool", text="Mode", expand=True)

        payload = box.box()
        payload.label(text="Payload", icon="TOOL_SETTINGS")
        buildings_root = _buildings_root(context.scene)
        if buildings_root is None:
            payload.operator("tgs.create_buildings_collection", icon="OUTLINER_COLLECTION")
        else:
            if _building_names(context.scene):
                payload.prop(settings, "active_building", text="Building")
                payload.prop(settings, "building_direction", text="Direction")
            else:
                payload.label(text="Add building collections under Buildings", icon="INFO")
            payload.operator("tgs.refresh_building_instances", icon="FILE_REFRESH")
        payload.prop(settings, "paint_height", text="Set Height")
        payload.prop(settings, "paint_team", text="Building Team")

        sym = box.box()
        sym.label(text="Symmetry", icon="MOD_MIRROR")
        row = sym.row(align=True)
        row.prop(settings, "symmetry_center_q")
        row.prop(settings, "symmetry_center_r")
        sym.prop(settings, "symmetry_radial")
        sym.prop(settings, "symmetry_axis_offset")
        if settings.symmetry_radial != "none":
            mask = sym.column(align=True)
            mask.label(text="Radial Hexants")
            row = mask.row(align=True)
            row.prop(settings, "symmetry_hexant_0", toggle=True)
            row.prop(settings, "symmetry_hexant_1", toggle=True)
            row.prop(settings, "symmetry_hexant_2", toggle=True)
            row = mask.row(align=True)
            row.prop(settings, "symmetry_hexant_3", toggle=True)
            row.prop(settings, "symmetry_hexant_4", toggle=True)
            row.prop(settings, "symmetry_hexant_5", toggle=True)
        col = sym.column(align=True)
        col.prop(settings, "symmetry_mirror_horizontal", toggle=True)
        col.prop(settings, "symmetry_mirror_rising", toggle=True)
        col.prop(settings, "symmetry_mirror_falling", toggle=True)
        box = layout.box()
        box.label(text="Cells", icon="MESH_ICOSPHERE")
        box.prop(settings, "show_allowed_grid")
        box.prop(settings, "arena_radius")
        row = box.row(align=True)
        row.operator("tgs.add_cell", icon="ADD")
        row.operator("tgs.delete_cell", icon="REMOVE")

        obj = context.active_object
        if obj is not None and _CELL_MARK in obj.keys():
            sub = box.box()
            sub.label(text=f"Selected: ({obj['tgs_q']}, {obj['tgs_r']})")
            sub.prop(obj, '["tgs_height"]', text="Height")
            sub.prop(obj, '["tgs_building"]', text="Building")
            coll = _cell_arena_collection(obj)
            territory = _territory_team_map(coll, normalize=False).get(_cell_coord(obj), "neutral") if coll is not None else "neutral"
            sub.label(text=f"Territory: {territory.title()}")
            if obj.get("tgs_building", "none") != "none":
                sub.prop(obj, '["tgs_team"]', text="Building Team")
                sub.prop(obj, '["tgs_direction"]', text="Direction")
                sub.prop(obj, '["tgs_order"]', text="Order")
        else:
            box.label(text="Select a cell to edit", icon="INFO")

        box = layout.box()
        box.label(text="Generate", icon="FILE_SCRIPT")
        box.operator("tgs.generate_arenas", icon="PLAY")


# --------------------------------------------------------------------------- #
# Registration
# --------------------------------------------------------------------------- #
_classes = (
    TGSHexSettings,
    TGS_OT_create_arenas_collection,
    TGS_OT_create_buildings_collection,
    TGS_OT_new_arena,
    TGS_OT_import_level,
    TGS_OT_export_all,
    TGS_OT_add_cell,
    TGS_OT_delete_cell,
    TGS_OT_refresh_building_instances,
    TGS_OT_paint_preview,
    TGS_OT_set_paint_mode,
    TGS_OT_adjust_paint_setting,
    TGS_OT_cycle_radial_symmetry,
    TGS_OT_toggle_symmetry_hexant,
    TGS_OT_toggle_symmetry_mirror,
    TGS_OT_rotate_building,
    TGS_OT_paint,
    TGS_OT_generate_arenas,
    TGS_PT_hex_panel,
)


def _ensure_workspace_tool_icon() -> None:
    png_path = Path(__file__).parent / "icons" / "icon_tgs_tool.png"
    if not png_path.is_file():
        print(f"[TGS Hex] tool icon PNG missing: {png_path}")
        return
    try:
        import hashlib
        digest = hashlib.sha1(png_path.read_bytes()).hexdigest()[:12]
        dat_path = png_path.with_name(f"{png_path.stem}_v2_{digest}.dat")
        if not dat_path.is_file():
            _write_png_as_blender_icon_dat(png_path, dat_path)
        TGS_WST_hex_paint.bl_icon = str(dat_path.with_suffix(""))
        for old_path in png_path.parent.glob(f"{png_path.stem}_v2_*.dat"):
            if old_path != dat_path:
                old_path.unlink(missing_ok=True)
    except Exception as exc:
        print(f"[TGS Hex] failed to update tool icon: {exc}")


def _write_png_as_blender_icon_dat(png_path: Path, dat_path: Path) -> None:
    import struct
    import zlib

    data = png_path.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError(f"{png_path} is not a PNG")

    pos = 8
    width = height = bit_depth = color_type = interlace = None
    idat = bytearray()
    plte = None
    trns = b""
    while pos < len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        chunk_type = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if chunk_type == b"IHDR":
            width, height, bit_depth, color_type, _compression, _filter, interlace = struct.unpack(
                ">IIBBBBB", chunk)
        elif chunk_type == b"IDAT":
            idat.extend(chunk)
        elif chunk_type == b"PLTE":
            plte = [tuple(chunk[i:i + 3]) for i in range(0, len(chunk), 3)]
        elif chunk_type == b"tRNS":
            trns = chunk
        elif chunk_type == b"IEND":
            break

    if bit_depth != 8 or interlace != 0:
        raise ValueError("only 8-bit non-interlaced PNG icons are supported")
    channels_by_type = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}
    if color_type not in channels_by_type:
        raise ValueError(f"unsupported PNG color type {color_type}")
    channels = channels_by_type[color_type]
    stride = width * channels
    raw = zlib.decompress(bytes(idat))

    def paeth(left, up, up_left):
        estimate = left + up - up_left
        dist_left = abs(estimate - left)
        dist_up = abs(estimate - up)
        dist_up_left = abs(estimate - up_left)
        if dist_left <= dist_up and dist_left <= dist_up_left:
            return left
        if dist_up <= dist_up_left:
            return up
        return up_left

    rows = []
    prev = bytearray(stride)
    offset = 0
    for _row in range(height):
        filter_type = raw[offset]
        offset += 1
        scan = bytearray(raw[offset:offset + stride])
        offset += stride
        for i, value in enumerate(scan):
            left = scan[i - channels] if i >= channels else 0
            up = prev[i]
            up_left = prev[i - channels] if i >= channels else 0
            if filter_type == 1:
                scan[i] = (value + left) & 0xff
            elif filter_type == 2:
                scan[i] = (value + up) & 0xff
            elif filter_type == 3:
                scan[i] = (value + ((left + up) // 2)) & 0xff
            elif filter_type == 4:
                scan[i] = (value + paeth(left, up, up_left)) & 0xff
            elif filter_type != 0:
                raise ValueError(f"unsupported PNG filter {filter_type}")
        rows.append(scan)
        prev = scan

    coords = bytearray()
    colors = bytearray()
    for y, row in enumerate(rows):
        for x in range(width):
            i = x * channels
            if color_type == 0:
                gray = row[i]
                rgba = (gray, gray, gray, 255)
            elif color_type == 2:
                rgba = (row[i], row[i + 1], row[i + 2], 255)
            elif color_type == 3:
                if plte is None:
                    raise ValueError("indexed PNG is missing a palette")
                index = row[i]
                red, green, blue = plte[index]
                alpha = trns[index] if index < len(trns) else 255
                rgba = (red, green, blue, alpha)
            elif color_type == 4:
                gray = row[i]
                rgba = (gray, gray, gray, row[i + 1])
            else:
                rgba = (row[i], row[i + 1], row[i + 2], row[i + 3])
            if rgba[3] <= 8:
                continue
            if rgba[3] < 255:
                alpha = rgba[3]
                rgba = tuple((channel * alpha + 127) // 255 for channel in rgba[:3]) + (alpha,)

            x0 = round(x * 255 / width)
            x1 = round((x + 1) * 255 / width)
            y0 = round((height - y - 1) * 255 / height)
            y1 = round((height - y) * 255 / height)
            if x0 == x1 or y0 == y1:
                continue
            for tri in (((x0, y0), (x1, y0), (x1, y1)),
                        ((x0, y0), (x1, y1), (x0, y1))):
                for vx, vy in tri:
                    coords.extend((vx, vy))
                for _corner in range(3):
                    colors.extend(rgba)

    dat_path.parent.mkdir(parents=True, exist_ok=True)
    with dat_path.open("wb") as handle:
        handle.write(b"VCO\x00")
        handle.write(bytes((255, 255, 0, 0)))
        handle.write(coords)
        handle.write(colors)
    print(f"[TGS Hex] updated tool icon: {dat_path}")


_workspace_tool_registered = False


def _register_workspace_tools():
    global _workspace_tool_registered
    if _workspace_tool_registered:
        return
    _ensure_workspace_tool_icon()
    try:
        bpy.utils.register_tool(
            TGS_WST_hex_paint,
            separator=True,
            group=False,
        )
    except TypeError:
        bpy.utils.register_tool(
            TGS_WST_hex_paint,
            separator=True,
        )
    _workspace_tool_registered = True


def _unregister_workspace_tools():
    global _workspace_tool_registered
    if not _workspace_tool_registered:
        return
    bpy.utils.unregister_tool(TGS_WST_hex_paint)
    _workspace_tool_registered = False


def register():
    global _draw_handle, _hud_handle
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.tgs_hex = PointerProperty(type=TGSHexSettings)
    if _on_save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(_on_save_pre)
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_grid_overlay, (), "WINDOW", "POST_VIEW")
    if _hud_handle is None:
        _hud_handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_tool_hud, (), "WINDOW", "POST_PIXEL")
    _register_workspace_tools()


def unregister():
    global _draw_handle, _hud_handle, _grid_batch, _grid_shader, _grid_batch_radius, _hud_shader
    _unregister_workspace_tools()
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
        _draw_handle = None
    if _hud_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_hud_handle, "WINDOW")
        _hud_handle = None
    _grid_batch = None
    _grid_shader = None
    _grid_batch_radius = None
    _hud_shader = None
    if _on_save_pre in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_on_save_pre)
    del bpy.types.Scene.tgs_hex
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)