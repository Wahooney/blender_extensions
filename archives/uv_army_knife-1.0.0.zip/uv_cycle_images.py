
import bpy
from bpy.props import EnumProperty


class UV_OT_CycleUVImages(bpy.types.Operator):
    """Cycle through UV images relevant to this object"""
    bl_idname = "uv.cycle_uv_images"
    bl_label = "Cycle UV Images"

    direction: EnumProperty(name="Cycle Direction", default='FORWARD',
                            items=(('FORWARD', 'Forward', 'Forward Cycle'),
                                   ('BACK', 'Back', 'Backward Cycle')))

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        act = context.active_object
        data = act.data

        materials = []

        # get used materials in selected polygons
        for f in data.polygons:
            if f.select:
                material = data.materials[f.material_index]
                materials.append(material)

        # if there are no selected faces because there weren't any faces selected, get all materials on the object
        if len(materials) == 0:
            for material in data.materials:
                materials.append(material)

        # get all images used in the materials

        images = []

        for material in materials:
            for node in material.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image is not None and node.image not in images:
                    images.append(node.image)

        if len(images) == 0:
            print("No images")
            return {'FINISHED'}

        new_image = None
        direction = -1 if self.direction == 'BACK' else 1

        active_area = None

        if context.area.type == 'IMAGE_EDITOR':
            active_area = context.area

        if active_area is None:
            print("Invalid active area")
            return {'FINISHED'}

        orig_index = 0

        current_image = active_area.spaces[0].image
        if current_image is not None and current_image in images:
            orig_index = images.index(current_image)

        index = orig_index + direction
        if index >= len(images):
            index = 0
        elif index < 0:
            index = len(images) - 1

        new_image = images[index]

        if new_image is not None:
            active_area.spaces[0].image = new_image
            # bpy.ops.image.view_all(fit_view=True)

        return {'FINISHED'}


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        # image editor
        km = kc.keymaps.new(
            name="Image", space_type='IMAGE_EDITOR', region_type='WINDOW', modal=False)

        # forward cycle (image editor)
        kmi = km.keymap_items.new(
            "uv.cycle_uv_images", 'WHEELUPMOUSE', 'PRESS', ctrl=False, shift=True, alt=True)
        kmi.properties.direction = 'FORWARD'

        # back cycle (image editor)
        kmi = km.keymap_items.new(
            "uv.cycle_uv_images", 'WHEELDOWNMOUSE', 'PRESS', ctrl=False, shift=True, alt=True)
        kmi.properties.direction = 'BACK'

        addon_keymaps.append(km)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            for kmi in km.keymap_items:
                km.keymap_items.remove(kmi)

            if km.name in wm.keyconfigs.addon.keymaps and len(km.keymap_items) == 0:
                wm.keyconfigs.addon.keymaps.remove(km)

    # clear the list
    del addon_keymaps[:]
