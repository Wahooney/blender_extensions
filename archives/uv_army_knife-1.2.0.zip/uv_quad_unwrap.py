# uv_quad_unwrap.py Copyright (C) 2015-2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from math import sqrt, pi
from bpy.props import BoolProperty, EnumProperty
from mathutils import Vector, Matrix
import bmesh
import bpy

# HISTORY:
#
# 1.2:
#  - Updated so quads orient themselves to original UVs
#
# Before Integration into UV Army Knife
########################################
#
# 1.3:
#  - Blender 4.0.0 compatibility
#  - Don't try to straighten an already straight quad
#
# 1.2:
#  - Blender 2.8.0 compatibility
#
# 1.1:
#  - Blender 2.76 compatibility
#
# 1.0:
#  - Initial implementation


def main(self, context):

    def is_near_zero(val, threshold=1e-5):
        return abs(val) < threshold

    def is_near_equal(val1, val2, threshold=1e-5):
        return abs(val1 - val2) < threshold

    def is_rectangle(uvs, threshold=1e-5):
        vectors = [
            uvs[1] - uvs[0],
            uvs[2] - uvs[1],
            uvs[3] - uvs[2],
            uvs[0] - uvs[3]
        ]

        for i in range(4):
            dot_product = vectors[i].dot(vectors[(i+1) % 4])
            if not is_near_zero(dot_product, threshold):
                return False

        if not (is_near_equal(vectors[0].length, vectors[2].length, threshold) and
                is_near_equal(vectors[1].length, vectors[3].length, threshold)):
            return False

        return True

    def rotate_uvs(points, center, k):
        k %= 4
        angle = k * (pi / 2.0)
        R = Matrix.Rotation(angle, 2)  # 2x2 rotation
        return [(R @ (p - center)) + center for p in points]

    def test_quad_diff(uvs1, uvs2):
        diff = 0
        for i in range(4):
            diff += (uvs1[i] - uvs2[i]).length_squared
        return diff

    def is_quad_ccw(uvs):
        edge01 = uvs[1] - uvs[0]
        edge12 = uvs[2] - uvs[1]
        return (edge01.cross(edge12)) > 0

    use_linked = self.properties.use_linked
    mode = self.properties.mode

    obj = context.active_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)

    uv_layer = bm.loops.layers.uv.verify()
    # bm.faces.layers.face_map.verify()

    f = bm.faces.active

    if f is None:
        self.report({'INFO'}, "Active face required.")
        return

    if len(f.loops) != 4:
        self.report({'INFO'}, "Active face must have exactly 4 vertices.")
        return

    # get uvs and average edge lengths
    og_uv1 = f.loops[0][uv_layer]
    og_uv2 = f.loops[1][uv_layer]
    og_uv3 = f.loops[2][uv_layer]
    og_uv4 = f.loops[3][uv_layer]
    og_uvs = [og_uv1.uv.copy(), og_uv2.uv.copy(), og_uv3.uv.copy(), og_uv4.uv.copy()]

    # Try to fit into old coords
    u_len = ((og_uv1.uv - og_uv2.uv).length + (og_uv3.uv - og_uv4.uv).length) / 2
    v_len = ((og_uv2.uv - og_uv3.uv).length + (og_uv4.uv - og_uv1.uv).length) / 2

    verts = [v.co for v in f.verts]

    world_len_u = ((verts[0] - verts[1]).length + (verts[2] - verts[3]).length) / 2
    world_len_v = ((verts[1] - verts[2]).length + (verts[3] - verts[0]).length) / 2

    au = max(u_len, 1e-12) / max(v_len, 1e-12)
    aw = max(world_len_u, 1e-12) / max(world_len_v, 1e-12)

    su = sqrt(aw / au)
    sv = 1.0 / su

    u_scale = u_len * su
    v_scale = v_len * sv

    center = (og_uv1.uv + og_uv2.uv + og_uv3.uv + og_uv4.uv) / 4

    uvs = [center + Vector((-u_scale, -v_scale)) * 0.5,
           center + Vector((u_scale,  -v_scale)) * 0.5,
           center + Vector((u_scale,   v_scale)) * 0.5,
           center + Vector((-u_scale,  v_scale)) * 0.5]

    if not is_quad_ccw(og_uvs):
        uvs.reverse()

    best_shift = 0
    smallest_diff = test_quad_diff(og_uvs, uvs)

    for i in range(1, 4):
        test = rotate_uvs(uvs, center, i)
        diff = test_quad_diff(og_uvs, test)

        if diff < smallest_diff:
            smallest_diff = diff
            best_shift = i

    uvs = rotate_uvs(uvs, center, best_shift)

    if smallest_diff < 1e-10:
        pass
    else:
        og_uv1.uv = uvs[0]
        og_uv2.uv = uvs[1]
        og_uv3.uv = uvs[2]
        og_uv4.uv = uvs[3]

        bmesh.update_edit_mesh(me)
        bm = bmesh.from_edit_mesh(me)

    # store selection
    selection = []

    for f in bm.faces:
        if f.select:
            selection.append(f.index)

    bmesh.update_edit_mesh(me)

    # select linked
    if use_linked:
        bpy.ops.mesh.select_linked(delimit={'SEAM'})

    # follow active quads
    bpy.ops.uv.follow_active_quads(mode=mode)

    bm = bmesh.from_edit_mesh(me)

    # restore selection
    for f in bm.faces:
        f.select = f.index in selection

    bmesh.update_edit_mesh(me)


class UV_OT_QuadUnwrap (bpy.types.Operator):
    """Unwrap selection from to contiguous uniform quad layout"""
    bl_idname = "uv.quad_unwrap"
    bl_label = "Quad Unwrap"
    bl_options = {'UNDO', 'REGISTER'}

    use_linked: BoolProperty(name="Quad Linked Faces", description="Apply Quad Unwrap to linked faces",
                             default=False)

    mode: EnumProperty(items=(
        ('EVEN', 'Even', ''),
        ('LENGTH', 'Length', ''),
        ('LENGTH_AVERAGE', 'Average Length', '')),
        name="Unwrap Mode",
        description="Average length selection mode",
        default='LENGTH_AVERAGE')

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH')

    def execute(self, context):
        main(self, context)
        return {'FINISHED'}


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        # Quad unwrap - image area
        kmuv = kc.keymaps.new(
            name="UV Editor", space_type='EMPTY', region_type='WINDOW', modal=False)

        kmi = kmuv.keymap_items.new(
            "uv.quad_unwrap", 'Q', 'PRESS', ctrl=False, shift=True, alt=False)
        kmi.properties.use_linked = False

        kmi = kmuv.keymap_items.new(
            "uv.quad_unwrap", 'Q', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.use_linked = True

        addon_keymaps.append(kmuv)

        # Quad unwrap - view 3d
        km3d = kc.keymaps.new(name="Mesh")
        kmi = km3d.keymap_items.new("uv.quad_unwrap", 'Q', 'PRESS', ctrl=False, shift=True, alt=False)
        kmi.properties.use_linked = False

        kmi = km3d.keymap_items.new("uv.quad_unwrap", 'Q', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.use_linked = True

        addon_keymaps.append(km3d)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            try:
                for kmi in km.keymap_items:
                    km.keymap_items.remove(kmi)

                if km.name in wm.keyconfigs.addon.keymaps and len(km.keymap_items) == 0:
                    wm.keyconfigs.addon.keymaps.remove(km)

            finally:
                pass

    # clear the list
    del addon_keymaps[:]
