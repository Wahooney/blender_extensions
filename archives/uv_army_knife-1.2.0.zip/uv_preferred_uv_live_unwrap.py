import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty

ALLOWED = 'allowed_live_unwrap'
SEP = ';'
passed_name_check = True


def check_state(context):

    global passed_name_check

    scene = context.scene
    passed_name_check = True

    for sel in context.selected_objects:

        if sel.type != 'MESH':
            continue

        uv_layer = sel.data.uv_layers.active

        if uv_layer is None:
            continue

        if ALLOWED not in scene:
            scene[ALLOWED] = 'UVMap'

        if not uv_layer.name in scene[ALLOWED]:
            passed_name_check = False

    if passed_name_check:
        scene.tool_settings.use_edge_path_live_unwrap = context.scene.requesting_live_uv_unwrap
    else:
        scene.tool_settings.use_edge_path_live_unwrap = False


@persistent
def live_uv_unwrap_check(scene):
    check_state(bpy.context)


def update_live_uv_unwrap(self, context):
    check_state(context)


def get_allowed_unwrap(self):

    scene = bpy.context.scene

    if self.uv_layers.active is None or ALLOWED not in scene:
        return False

    uv_layer = self.uv_layers.active
    return uv_layer.name in scene[ALLOWED]


def set_allowed_unwrap(self, value):

    scene = bpy.context.scene
    if scene.uv_layers.active is None:
        return

    uv_layer = scene.uv_layers.active

    # changed to true
    if value:

        # allowed list is not present
        if ALLOWED not in scene:
            scene[ALLOWED] = uv_layer.name

        else:  # allowed list is present, add the current layer
            s = scene[ALLOWED].split(SEP)
            s.append(uv_layer.name)
            scene[ALLOWED] = SEP.join(s)

    # changed to false and we have an allowed list
    elif ALLOWED in scene:

        # remove current layer
        s = scene[ALLOWED].split(SEP)
        s.remove(uv_layer.name)
        scene[ALLOWED] = SEP.join(s)


def draw_live_uv(self, context):

    if context.active_object is None or context.active_object.type != 'MESH':
        return

    layout = self.layout
    row_check = layout.row(align=True)

    row_check.label(text='Live Unwrap')

    row = row_check.row(align=True)
    row.prop(context.scene, 'requesting_live_uv_unwrap', text='Auto', toggle=1)

    row = row_check.row(align=True)
    row.active = passed_name_check
    row.enabled = passed_name_check
    row.prop(context.scene.tool_settings, 'use_edge_path_live_unwrap', text='Enabled', toggle=1)

    row_check.prop(context.active_object.data, 'allowed_live_unwrap', text='', icon='UV', toggle=1)


def register():

    bpy.types.Scene.requesting_live_uv_unwrap = BoolProperty(
        name='Auto-Live Unwrap',
        update=update_live_uv_unwrap)

    bpy.types.Mesh.allowed_live_unwrap = BoolProperty(
        name='Allowed Unwrap',
        get=get_allowed_unwrap,
        set=set_allowed_unwrap)

    for func in bpy.app.handlers.depsgraph_update_post:
        if func.__name__ == 'live_uv_unwrap_check':
            bpy.app.handlers.depsgraph_update_post.remove(func)

    bpy.app.handlers.depsgraph_update_post.append(live_uv_unwrap_check)
