import bpy
from . import uv_multi_ops
from . import uv_preferred_uv_live_unwrap


class IMAGE_PT_WahooneyUVTools(bpy.types.Panel):
    """UV Tools Panel"""

    bl_label = 'UV Army Knife'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, context):

        layout = self.layout

        unique_uv_names = {}
        unique_active_uvs = {}
        unique_object_data = []

        for sel in context.selected_objects:

            if sel.data is None or sel.type != 'MESH':
                continue

            if sel.data in unique_object_data:
                continue

            if sel.data.uv_layers.active is None:
                unique_object_data.append(sel.data)
                continue

            if sel.data.uv_layers.active.name in unique_active_uvs:
                unique_active_uvs[sel.data.uv_layers.active.name] += 1
            else:
                unique_active_uvs[sel.data.uv_layers.active.name] = 1

            if sel.data not in unique_object_data:
                unique_object_data.append(sel.data)

            for uv in sel.data.uv_layers:
                if uv.name not in unique_uv_names:
                    unique_uv_names[uv.name] = [sel]
                else:
                    unique_uv_names[uv.name].append(sel)

        col = layout.column(align=True)
        data_count = len(unique_object_data)

        active_uv_names = []

        for uv, _ in unique_uv_names.items():

            icon = 'RADIOBUT_OFF'

            if uv in unique_active_uvs:
                active_uv_names.append(uv)
                if unique_active_uvs[uv] >= data_count:
                    icon = 'GROUP_UVS'
                else:
                    icon = 'RADIOBUT_ON'

            row = col.row(align=True)
            op = row.operator(
                uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text=uv, icon=icon)
            op.operation = 'SET_ACTIVE'
            op.affect_uv_layer_name = uv

            if len(unique_uv_names[uv]) != data_count:
                op = row.operator(
                    uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='AUTO')
                op.affect_uv_layer_name = uv
                op.operation = 'GUARANTEE'
                op.tooltip = F'{len(unique_uv_names[uv])} of {data_count} mesh data have Layer: "{uv}"'

            op = row.operator(
                uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='FILE_TEXT')
            op.affect_uv_layer_name = uv
            op.new_uv_layer_name = uv
            op.operation = 'RENAME'

            op = row.operator(
                uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='SELECT_INTERSECT')
            op.affect_uv_layer_name = uv
            op.operation = 'SELECT'

            op = row.operator(
                uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='SELECT_SUBTRACT')
            op.affect_uv_layer_name = uv
            op.operation = 'DESELECT'

            if uv not in unique_active_uvs:
                op = row.operator(
                    uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='COPYDOWN')
                op.affect_uv_layer_name = uv
                op.operation = 'COPY_FROM'
            else:
                row.label(text='', icon='CHECKMARK')

            op = row.operator(
                uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='', icon='X')
            op.affect_uv_layer_name = uv
            op.operation = 'REMOVE'

        col = layout.column()
        col.active = len(context.selected_objects) > 1
        op = col.operator(uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname,
                          text='Match UV Order', icon='SORTSIZE')
        op.operation = 'MATCH_ORDER'

        op = layout.operator(
            uv_multi_ops.UV_OT_ManageMultipleUVs.bl_idname, text='Add New UV Layer', icon='UV')
        op.new_uv_layer_name = 'UVMap'
        op.operation = 'ADD'

        row = layout.row(align=True)
        row.prop(context.scene, 'show_uv_objects',
                 text='Show UV Objects', icon='UV_ISLANDSEL')
        row.prop(context.scene, 'show_uv_objects_inv',
                 text='', icon='ARROW_LEFTRIGHT')

        if context.scene.show_uv_objects:
            for uv in active_uv_names:
                layout.separator()
                layout.label(text=uv)
                box = layout.box()
                for sel in context.selected_objects:
                    if context.scene.show_uv_objects_inv:
                        if sel not in unique_uv_names[uv]:
                            box.label(text=sel.name)
                    else:
                        if sel in unique_uv_names[uv]:
                            box.label(text=sel.name)

        uv_preferred_uv_live_unwrap.draw_live_uv(self, context)
