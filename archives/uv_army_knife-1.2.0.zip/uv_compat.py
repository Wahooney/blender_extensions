# uv_compat.py Copyright (C) 2026, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# ***** END GPL LICENCE BLOCK *****


def uv_loop_selected(loop, uv_layer):
    """Return UV vertex selection across Blender's BMesh UV API versions."""
    if hasattr(loop, "uv_select_vert"):
        return loop.uv_select_vert

    return loop[uv_layer].select


def uv_face_selected(face):
    """Return UV face selection across Blender's BMesh UV API versions."""
    if hasattr(face, "uv_select"):
        return face.uv_select

    return face.select
