import bpy
from bpy.types import PropertyGroup, CollectionProperty, PointerProperty


class SurfaceItem(PropertyGroup):

    assign_to: bpy.props.EnumProperty(name="Assign To",
                                      items=(("VERTEX_COLOR", "Vertex Color", "Vertex Color"),
                                             ("UV", "UVs", "UV Coordinates"),
                                             ("MATERIAL", "Material", "Material")), default="VERTEX_COLOR")

    force_color_channel: bpy.props.StringProperty(
        name="Color Channel", default="Color",
        description="Color channel to use for vertex color, leave empty to use the active color channel")

    force_uv_layer: bpy.props.StringProperty(
        name="UV Layer", default="UVMap",
        description="UV layer to use for UV, leave empty to use the active UV layer")

    vertex_color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=4, min=0.0, max=1.0)

    uv_coordinates: bpy.props.FloatVectorProperty(
        name="UV Coordinates",
        size=2, min=0.0, max=1.0)

    material: bpy.props.PointerProperty(bpy.types.Material)


class Surfaces(PropertyGroup):

    references: CollectionProperty(type=SurfaceItem)


classes = [
    SurfaceItem,
    Surfaces
]


def register_tool():

    bpy.types.Scene.material_surfaces = PointerProperty(type=Surfaces)

    for c in classes:
        bpy.utils.unregister_class(c)


def unregister_tool():

    pass
