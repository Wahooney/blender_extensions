#
#   MIT License
#
#   Copyright (c) 2024 Keith "Wahooney" Boshoff
#
#   Permission is hereby granted, free of charge, to any person obtaining a copy of this
#   software and associated documentation files (the "Software"), to deal in the Software
#   without restriction, including without limitation the rights to use, copy, modify,
#   merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
#   permit persons to whom the Software is furnished to do so, subject to the following
#   conditions:
#
#   The above copyright notice and this permission notice shall be included in all copies or
#   substantial portions of the Software.
#
#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
#   INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
#   PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
#   FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
#   OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
#   DEALINGS IN THE SOFTWARE.
#
#   For further queries, contact wahooney[at]gmail.com or keith.boshoff[at]gmail.com

import bpy
import re
import json
from mathutils import Vector

# Example:

#     Parse Unreal Engine spline clipboard data and create a new curve datablock:
#     parse_unreal_spline_from_clipboard(bpy.context)

#     Create a new curve object from Unreal Engine spline clipboard data:
#     create_unreal_spline_from_clipboard(bpy.context, "UnrealSplineCurve")


def replace_identifiers(s):

    # Replace all occurrences of 'key=value' with '"key": value'
    s = re.sub(r'(\w+)=', r'"\1"=', s)
    return re.sub(r'=([\w\.-]+)', r':"\1"', s)


def replace_at_index(source, index, string):

    if index >= 0 and len(source) > index:
        return source[:index] + string + source[index + 1:]
    return source


def try_get_vector(source, key, fallback):

    if key in source:
        return Vector((float(source[key]["X"]), float(source[key]["Y"]), float(source[key]["Z"])))
    return fallback.copy()


################################################################################
# PARSE UNREAL SPLINE FROM CLIPBOARD

def parse_unreal_spline_from_clipboard(context, curve=None):
    '''
    Parse Unreal Engine spline clipboard data and create a new curve datablock.

    Args:
        context (bpy.context): Blender context
        curve (bpy.types.Curve): Optional curve object to update

    Returns:
        dict: Dictionary containing the resultant data, result of the operation ("FINISHED" or "CANCELLED"), status ("COMPLETED" or "ERROR") and message of the operation
    '''

    text = context.window_manager.clipboard
    items = text.split("\n")
    data = {}

    # break the unreal clipboard into something more manageable
    for item in items:

        if item.startswith("Begin Object") or item.startswith("End Object"):
            continue

        item = item.strip()

        if len(item) == 0:
            continue

        parts = item.split("=", 1)

        if len(parts) > 1:
            data[parts[0].strip()] = parts[1].strip()
        else:
            print(item)

    spline_data = {}

    # if it's not a spline curve, abort
    if 'SplineCurves' not in data:
        return {'data': None, 'result': {'CANCELLED'}, 'status': {'ERROR'}, 'message': 'No spline data found in clipboard'}

    # start converting the unreal clipboard data to json for easy parsing
    text = replace_identifiers(data['SplineCurves'])
    if text.startswith("(") and text.endswith(")"):
        text = text[1:-1]

    open_count = 0
    starting_array = False

    # based on the unreal clipboard data, we have found certain patterns:
    # double open parenthesis "((" indicates the start of an array of objects, so we convert that to "[{""
    # if we get to a point where parenthesis are all closed and we are in an array area, and find "))" we convert that to "}]"
    # this isn't very robust, but it works for the data we expect
    for i, c in enumerate(text):

        if c == '(':

            open_count += 1

            if len(text) > i+1 and text[i+1] == '(':

                text = replace_at_index(text, i, "[")
                text = replace_at_index(text, i+1, "{")

                starting_array = True

        elif c == ')':

            open_count -= 1

            if i-1 >= 0 and text[i-1] == ')' and starting_array and open_count == 0:

                text = replace_at_index(text, i-1, "]")
                text = replace_at_index(text, i, "}")

                starting_array = False

    # replace the remaining parenthesis with curly braces
    # and the equals with colons, again not very robust, but works for the data we expect
    text = "{" + text.replace("=", ":").replace(")", "}").replace("(", "{").replace("{},", "") + "}"

    # push it to JSON!!! Is's easier this way
    try:
        spline_data = json.loads(text)

    except json.JSONDecodeError as e:
        print(text)
        return {'data': None, 'result': {'CANCELLED'}, 'status': {'ERROR'}, 'message': F'Error parsing JSON: {str(e)}'}

    ################################################################################
    # PROCESS CURVE OBJECT

    # if we don't have a curve, we create it
    if curve is None:
        curve_name = "UnrealSplineCurve"
        curve = bpy.data.curves.new(curve_name, 'CURVE')

    ################################################################################
    # CREATE / UPDATE CURVE DATA

    # clear the curve and add a new spline and get our canvas ready for our masterpiece
    curve.splines.clear()
    spline = curve.splines.new('BEZIER')
    spline.bezier_points.add(len(spline_data["Position"]["Points"]) - len(spline.bezier_points))
    points = spline.bezier_points

    # we want to convert the units to match unreal scale units, this makes sense, leave it alone!
    scale = 0.01 / context.scene.unit_settings.scale_length

    for i, v in enumerate(spline_data["Position"]["Points"]):

        # we get the position, and the tangent handles
        # and convert them from hermite to bezier (just divide by 3 and add/subtract from the position, who'da thunk it?)
        position = try_get_vector(v, "OutVal", Vector((0, 0, 0))) * scale
        handle_l = (position - try_get_vector(v, "LeaveTangent",  Vector((0, 0, 0))) / 3) * scale
        handle_r = (position + try_get_vector(v, "ArriveTangent", Vector((0, 0, 0))) / 3) * scale

        position.y = -position.y
        handle_l.y = -handle_l.y
        handle_r.y = -handle_r.y

        points[i].co = position

        # if the are different we assume it's a free handle, otherwise we assume it's aligned
        if handle_r != handle_l:

            points[i].handle_left_type = 'FREE'
            points[i].handle_right_type = 'FREE'

            points[i].handle_right = handle_r
            points[i].handle_left = handle_l

        else:

            # we need to make it free first, then aligned, otherwise it the handles go wonky
            points[i].handle_left_type = 'FREE'
            points[i].handle_right_type = 'FREE'

            points[i].handle_right = handle_r
            points[i].handle_left = handle_l

            points[i].handle_left_type = 'ALIGNED'
            points[i].handle_right_type = 'ALIGNED'

        # and select the points and we're done!
        points[i].select_control_point = True
        points[i].select_left_handle = True
        points[i].select_right_handle = True

    return {'data': curve, 'result': {'FINISHED'}, 'status': {'COMPLETED'}, 'message': 'Unreal Spline Converted'}


def create_unreal_spline_from_clipboard(context, name):
    '''
    Create a new curve object from Unreal Engine spline clipboard data.

    Args:
        context (bpy.context): Blender context
        name (str): Required name of the curve object and it's parent collection, if an object of this name is found, the object will be reused

    Returns:
        dict: Dictionary containing the resultant object, status and message of the operation
    '''

    curve = None
    curve_obj = None
    collection = None
    reuse_curve_data = False

    # first we use the active object if it's a curve
    if curve is None and \
            context.active_object is not None and \
            context.active_object.type == 'CURVE' and \
            context.active_object.select_get():

        curve_obj = bpy.context.active_object
        curve = curve_obj.data
        collection = curve_obj.users_collection[0]

    # if we have a selected collection with a curve in it, use that next
    if curve is None and context.collection is not None:
        for obj in context.collection.objects:
            if obj.type == 'CURVE':
                curve_obj = obj
                curve = obj.data
                collection = curve_obj.users_collection[0]

                print("Reusing active data")
                break

    if curve is None:
        if name in bpy.data.curves:
            print("Reusing old data")
            reuse_curve_data = True
            curve = bpy.data.curves[name]

    out = parse_unreal_spline_from_clipboard(context, curve)

    if out['result'] != {'FINISHED'}:
        print(out['result'], out['message'])
        return out

    curve = out['data']
    curve.name = name

    if collection is None:
        if name in bpy.data.collections:
            collection = bpy.data.collections[name]
        else:
            collection = bpy.data.collections.new(name)
            context.view_layer.layer_collection.collection.children.link(collection)

    if reuse_curve_data:
        for obj in context.view_layer.objects:
            if obj.type == 'CURVE' and obj.data == curve:
                curve_obj = obj
                break

    if curve_obj is None:
        curve_obj = bpy.data.objects.new(name, curve)
        collection.objects.link(curve_obj)
