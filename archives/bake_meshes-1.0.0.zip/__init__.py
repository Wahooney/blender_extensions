# wahooney_bake_meshes.py Copyright (C) 2023, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****


from bpy.props import *
import bpy

bl_info = {
    'name': 'Bake Mesh Modifiers',
    'author': 'Keith (Wahooney) Boshoff',
    'version': (1, 0),
    'blender': (4, 1, 0),
    'description': 'Bake modifiers into meshes',
    'warning': 'Requires Engine Export Tools to be activated',
    'wiki_url': '',
    'tracker_url': '',
    'category': 'Mesh'}

OG_MESH = 'OG_Mesh'
DEACTIVATED_MODS = 'Deactivated_Mods'


def update_state_color(obj):

    if obj.name.startswith('UCX_'):
        return

    if OG_MESH in obj:
        obj.color = (0.75, 0.5, 0.25, 1)
    else:
        obj.color = (1, 1, 1, 1)


def freeze_mesh_objects(context, objects):

    deps_graph = context.evaluated_depsgraph_get()

    count = 0

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in objects:

        if obj.type != 'MESH':
            continue

        if OG_MESH in obj or len(obj.modifiers) == 0:
            print('Already optimized, or no modifiers to bake')
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        modifiers = obj.modifiers[:]
        deactivated = [mod.name for mod in modifiers if not mod.show_viewport]

        if len(deactivated) > 0:
            obj[DEACTIVATED_MODS] = deactivated

        obj[OG_MESH] = obj.data
        obj.data.use_fake_user = True
        armatures = [mod for mod in obj.modifiers if mod.type == 'ARMATURE']

        for mod in armatures:
            mod.show_viewport = False

        # get vertex groups for resync
        # vertex_groups = obj.vertex_groups[:]

        eval_obj = obj.evaluated_get(deps_graph)
        new_data = eval_obj.to_mesh().copy()
        new_data.name = obj.name
        eval_obj.to_mesh_clear()

        for mod in obj.modifiers:
            if mod not in armatures:
                mod.show_viewport = False

        for mod in armatures:
            mod.show_viewport = True

        obj.data = new_data

        '''
        # Resync vertex groups
        for vg in vertex_groups:

            if vg.name not in new_data.attributes:
                continue

            attrib = new_data.attributes[vg.name].data

            g = None
            if vg.name in obj.vertex_groups:
                g = obj.vertex_groups[vg.name]
            g = obj.vertex_groups.new(name=vg.name)

            openset = {}
            for i, v in enumerate(attrib):
                openset[i] = v.value

            print(vg)
            while len(openset) > 0:

                idx = []

                current = openset.popitem()
                idx.append(current[0])

                for item in openset.items():
                    if current[1] == item[1]:
                        idx.append(item[0])

                print(idx, current[1])
                g.add(idx, current[1], 'REPLACE')
                for i in idx:
                    if i in openset:
                        del openset[i]

            new_data.attributes.remove(new_data.attributes[vg.name])
        '''

        update_state_color(obj)

        count += 1

    return count


def thaw_mesh_objects(context, objects):

    count = 0

    for obj in objects:

        if OG_MESH not in obj:
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        obj.data = obj[OG_MESH]
        del obj[OG_MESH]

        deactivated = []

        if DEACTIVATED_MODS in obj:
            deactivated = obj[DEACTIVATED_MODS]
            del obj[DEACTIVATED_MODS]

        for mod in obj.modifiers:
            mod.show_viewport = mod.name not in deactivated

        update_state_color(obj)

        count += 1

    return count


def cook_mesh_objects(context, objects, remove_mods):

    count = 0

    for obj in objects:

        if OG_MESH not in obj:
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        del obj[OG_MESH]

        deactivated = []
        if DEACTIVATED_MODS in obj:
            deactivated = obj[DEACTIVATED_MODS]
            del obj[DEACTIVATED_MODS]

        if remove_mods:
            for mod in obj.modifiers:
                if mod.name in deactivated:
                    obj.modifiers.remove(mod)

        update_state_color(obj)

        count += 1

    return count


class OBJECT_OT_ThawSelectedMeshes(bpy.types.Operator):
    """Restores a previously frozen object to its original state"""
    bl_idname = "object.thaw_selected_optimized_meshes"
    bl_label = "Thaw Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):
        count = thaw_mesh_objects(bpy.context, bpy.context.selected_objects)
        self.report({'INFO'}, f"Restored {count} objects")
        return {'FINISHED'}


class OBJECT_OT_FreezeSelectedMeshes(bpy.types.Operator):
    """Freezes an object with modifiers into a static mesh in a way that can be restored later."""
    bl_idname = "object.freeze_selected_meshes"
    bl_label = "Freeze Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):
        count = freeze_mesh_objects(bpy.context, bpy.context.selected_objects)
        self.report({'INFO'}, f"Optimized {count} objects")
        return {'FINISHED'}


class OBJECT_OT_CookSelectedObjects(bpy.types.Operator):
    """Commits state of to selected meshes, will remove historic data."""
    bl_idname = "object.cook_selected_meshes"
    bl_label = "Cook Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    remove_disabled_modifiers: BoolProperty(
        name='Remove deactivated modifiers', default=False,
        description='Removes the modifiers deactivated during freezing')

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def draw(self, context):
        layout = self.layout

        layout.prop(self, 'remove_disabled_modifiers')
        layout.label(text="Frozen objects will be applied permanently.")
        layout.label(text="Stored historic data may be lost. Continue?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        count = cook_mesh_objects(
            bpy.context, bpy.context.selected_objects, self.remove_disabled_modifiers)
        self.report({'INFO'}, f"Restored {count} objects")
        return {'FINISHED'}


class OBJECT_OT_UpdateObjectColoration(bpy.types.Operator):
    """"""
    bl_idname = "object.update_object_coloration"
    bl_label = "Update Object Coloration"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        for obj in context.view_layer.objects:
            update_state_color(obj)

        return {'FINISHED'}


class MODIFIER_PT_OptimizeObjects(bpy.types.Panel):
    """Freeze meshes with modifiers into static meshes"""

    bl_label = "Freeze Objects"
    bl_idname = "SCENE_PT_ObjectObjects"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "modifier"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):

        layout = self.layout

        row = layout.row(align=True)

        selected_meshes = [
            ob for ob in context.selected_objects if ob.type == 'MESH']
        frozen_meshes = [ob for ob in selected_meshes if OG_MESH in ob]
        thawed_meshes = [ob for ob in selected_meshes if OG_MESH not in ob]

        row.operator(OBJECT_OT_FreezeSelectedMeshes.bl_idname,
                     text=F"Freeze [ {len(thawed_meshes)} ]")
        row.operator(OBJECT_OT_ThawSelectedMeshes.bl_idname,
                     text=F"Thaw [ {len(frozen_meshes)} ]")
        row.operator(OBJECT_OT_CookSelectedObjects.bl_idname,
                     text="", icon="REMOVE")


classes = [
    MODIFIER_PT_OptimizeObjects,
    OBJECT_OT_FreezeSelectedMeshes,
    OBJECT_OT_ThawSelectedMeshes,
    OBJECT_OT_CookSelectedObjects,
    OBJECT_OT_UpdateObjectColoration,
]


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass


if __name__ == "__main__":
    register()
