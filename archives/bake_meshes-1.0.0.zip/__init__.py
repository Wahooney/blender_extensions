# wahooney_bake_meshes.py Copyright (C) 2023, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****


from bpy.props import *
import bpy

bl_info = {
    'name': 'Bake Mesh Modifiers',
    'author': 'Keith (Wahooney) Boshoff',
    'version': (1, 0),
    'blender': (4, 1, 0),
    'description': 'Bake modifiers into meshes',
    'warning': 'Requires Engine Export Tools to be activated',
    'wiki_url': '',
    'tracker_url': '',
    'category': 'Mesh'}

OG_MESH = 'OG_Mesh'
DEACTIVATED_MODS = 'Deactivated_Mods'


def update_state_color(obj):

    if obj.name.startswith('UCX_'):
        return

    if OG_MESH in obj:
        obj.color = (0.75, 0.5, 0.25, 1)
    else:
        obj.color = (1, 1, 1, 1)


def freeze_mesh_objects(context, objects, stack_depth=0):

    deps_graph = context.evaluated_depsgraph_get()

    count = 0

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in objects:

        if obj.type != 'MESH':
            continue

        if OG_MESH in obj or len(obj.modifiers) == 0:
            print('Already optimized, or no modifiers to bake')
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        modifiers = obj.modifiers[:]
        deactivated = None
        was_activated = []

        depth = 0

        if stack_depth == 'AUTO':
            if 'Freeze Stack Depth' in obj:
                depth = obj['Freeze Stack Depth']
            else:
                depth = len(modifiers)
                obj['Freeze Stack Depth'] = depth

        else:
            depth = stack_depth
            obj['Freeze Stack Depth'] = depth

        if depth > 0:
            deactivated = []
            for i, mod in enumerate(modifiers):
                if i >= depth:
                    print(F"{obj.name} {mod.name}")
                    deactivated.append(mod)
                    if mod.show_viewport:
                        print(F"Deactivating {mod.name}")
                        was_activated.append(mod)
                        mod.show_viewport = False
                        mod.show_render = False

        else:
            deactivated = [mod.name for mod in modifiers if not mod.show_viewport]

        if len(deactivated) > 0:
            obj[DEACTIVATED_MODS] = deactivated

        obj[OG_MESH] = obj.data
        obj.data.use_fake_user = True
        armatures = [mod for mod in obj.modifiers if mod.type == 'ARMATURE']

        for mod in armatures:
            mod.show_viewport = False

        eval_obj = obj.evaluated_get(deps_graph)
        new_data = eval_obj.to_mesh().copy()
        new_data.name = obj.name
        eval_obj.to_mesh_clear()

        for mod in obj.modifiers:
            if mod not in armatures:
                if mod not in deactivated:
                    mod.show_viewport = False
                    mod.show_render = False

            if mod in was_activated:
                mod.show_viewport = True
                mod.show_render = True

        for mod in armatures:
            mod.show_viewport = True
            mod.show_render = True

        obj.data = new_data

        update_state_color(obj)

        count += 1

    return count


def thaw_mesh_objects(context, objects):

    bpy.ops.object.mode_set(mode='OBJECT')

    count = 0

    for obj in objects:

        if OG_MESH not in obj:
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        frozen_data = obj.data

        obj.data = obj[OG_MESH]
        del obj[OG_MESH]

        if frozen_data.users == 0:
            bpy.data.meshes.remove(frozen_data)
        else:
            frozen_data.name = frozen_data.name + '_Frozen'

        deactivated = []

        if DEACTIVATED_MODS in obj:
            deactivated = obj[DEACTIVATED_MODS]
            del obj[DEACTIVATED_MODS]

        for mod in obj.modifiers:
            mod.show_viewport = mod.name not in deactivated
            mod.show_render = mod.name not in deactivated

        update_state_color(obj)

        count += 1

    return count


def cook_mesh_objects(context, objects, remove_mods):

    bpy.ops.object.mode_set(mode='OBJECT')

    count = 0

    for obj in objects:

        if OG_MESH not in obj:
            if DEACTIVATED_MODS in obj:
                del obj[DEACTIVATED_MODS]
            continue

        del obj[OG_MESH]

        deactivated = []
        if DEACTIVATED_MODS in obj:
            deactivated = obj[DEACTIVATED_MODS]
            del obj[DEACTIVATED_MODS]

        if remove_mods:
            for mod in obj.modifiers:
                if mod.name in deactivated:
                    obj.modifiers.remove(mod)

        update_state_color(obj)

        count += 1

    return count


class OBJECT_OT_ThawSelectedMeshes(bpy.types.Operator):
    """Restores a previously frozen object to its original state"""
    bl_idname = "object.thaw_selected_optimized_meshes"
    bl_label = "Thaw Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):
        count = thaw_mesh_objects(bpy.context, bpy.context.selected_objects)
        self.report({'INFO'}, f"Restored {count} objects")
        return {'FINISHED'}


class OBJECT_OT_FreezeSelectedMeshes(bpy.types.Operator):
    """Freezes an object with modifiers into a static mesh in a way that can be restored later."""
    bl_idname = "object.freeze_selected_meshes"
    bl_label = "Freeze Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):
        count = freeze_mesh_objects(bpy.context, bpy.context.selected_objects)
        self.report({'INFO'}, f"Optimized {count} objects")
        return {'FINISHED'}


class OBJECT_OT_FreezeSelectedMeshesDepth(bpy.types.Operator):
    """Freezes an object with modifiers into a static mesh in a way that can be restored later. Only freeze up to Stack Depth."""
    bl_idname = "object.freeze_selected_meshes_depth"
    bl_label = "Freeze Selected Meshes to Depth"
    bl_options = {'REGISTER', 'UNDO'}

    stack_depth: IntProperty(name='Stack Depth', default=1, min=1)

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        count = freeze_mesh_objects(bpy.context, bpy.context.selected_objects, stack_depth=self.stack_depth)
        self.report({'INFO'}, f"Optimized {count} objects")
        return {'FINISHED'}


class OBJECT_OT_FreezeSelectedMeshesAutoDepth(bpy.types.Operator):
    """Freezes an object with modifiers into a static mesh in a way that can be restored later. Only freeze up to Stack Depth."""
    bl_idname = "object.freeze_selected_meshes_auto_depth"
    bl_label = "Freeze Selected Meshes to Depth"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):
        count = freeze_mesh_objects(bpy.context, bpy.context.selected_objects, stack_depth='AUTO')
        self.report({'INFO'}, f"Optimized {count} objects")
        return {'FINISHED'}


class OBJECT_OT_CookSelectedObjects(bpy.types.Operator):
    """Commits state of to selected meshes, will remove historic data."""
    bl_idname = "object.cook_selected_meshes"
    bl_label = "Cook Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    remove_disabled_modifiers: BoolProperty(
        name='Remove deactivated modifiers', default=False,
        description='Removes the modifiers deactivated during freezing')

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def draw(self, context):
        layout = self.layout

        layout.prop(self, 'remove_disabled_modifiers')
        layout.label(text="Frozen objects will be applied permanently.")
        layout.label(text="Stored historic data may be lost. Continue?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        count = cook_mesh_objects(
            bpy.context, bpy.context.selected_objects, self.remove_disabled_modifiers)
        self.report({'INFO'}, f"Restored {count} objects")
        return {'FINISHED'}


class OBJECT_OT_UpdateObjectColoration(bpy.types.Operator):
    """"""
    bl_idname = "object.update_object_coloration"
    bl_label = "Update Object Coloration"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        for obj in context.view_layer.objects:
            update_state_color(obj)

        return {'FINISHED'}


class MODIFIER_PT_OptimizeObjects(bpy.types.Panel):
    """Freeze meshes with modifiers into static meshes"""

    bl_label = "Freeze Objects"
    bl_idname = "SCENE_PT_ObjectObjects"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "modifier"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):

        layout = self.layout

        row = layout.row(align=True)

        selected_meshes = [
            ob for ob in context.selected_objects if ob.type == 'MESH']
        frozen_meshes = [ob for ob in selected_meshes if OG_MESH in ob]
        thawed_meshes = [ob for ob in selected_meshes if OG_MESH not in ob]

        col = row.column(align=True)
        min_row = col.row(align=True)
        min_row.operator(OBJECT_OT_FreezeSelectedMeshes.bl_idname,
                         text=F"Freeze [ {len(thawed_meshes)} ]")
        min_row.operator(OBJECT_OT_FreezeSelectedMeshesDepth.bl_idname, icon='FREEZE', text="")

        if 'Freeze Stack Depth' in context.active_object:
            min_row = col.row(align=True)
            min_row.prop(context.active_object, '["Freeze Stack Depth"]', text='Depth')
            min_row.operator(OBJECT_OT_FreezeSelectedMeshesAutoDepth.bl_idname, icon='AUTO', text="")
        else:
            min_row = col.row(align=True)
            min_row.operator(OBJECT_OT_FreezeSelectedMeshesDepth.bl_idname, icon='AUTO', text="Initialize Auto-Depth")

        row.separator()
        row.operator(OBJECT_OT_ThawSelectedMeshes.bl_idname,
                     text=F"Thaw [ {len(frozen_meshes)} ]")
        row.operator(OBJECT_OT_CookSelectedObjects.bl_idname,
                     text="", icon="MOD_FLUID")


classes = [
    MODIFIER_PT_OptimizeObjects,
    OBJECT_OT_FreezeSelectedMeshes,
    OBJECT_OT_FreezeSelectedMeshesDepth,
    OBJECT_OT_FreezeSelectedMeshesAutoDepth,
    OBJECT_OT_ThawSelectedMeshes,
    OBJECT_OT_CookSelectedObjects,
    OBJECT_OT_UpdateObjectColoration,
]


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass


if __name__ == "__main__":
    register()
