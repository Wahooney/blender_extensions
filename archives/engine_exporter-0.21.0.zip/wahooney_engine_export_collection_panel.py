# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from .wahooney_engine_export_collection_drawer import draw_collection
from . import wahooney_collection_name_from_selected

import bpy
from bpy.types import(Panel)

class COLLECTION_PT_ExportEngine(Panel):
    
    bl_label = 'Engine Export'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'collection'
    bl_idname = 'COLLECTION_PT_ExportEngine'

    modify_collection = False

    def draw(self, context):

        scene = context.scene

        collections = scene.engine_export_collections
        collection = None
        
        for col in collections:
            if col.collection is context.collection:
                collection = col

        layout = self.layout

        layout.prop(context.collection, 'name')

        if collection is not None:

            col = layout.column()
            col.scale_y = 1.5

            op = col.operator('export.engine_export_collections', text=F'Export {collection.collection.name} to {scene.engine_export_format}', icon='GROUP')
            op.export_mode = 'ACTIVE_COLLECTION'
            op.export_target = 'ALL'

            # isolated exports
            row = col.row(align=True)

            op = row.operator('export.engine_export_collections', text='Mesh Only', icon='MESH_DATA')
            op.export_mode = 'ACTIVE_COLLECTION'
            op.export_target = 'MESH'

            op = row.operator('export.engine_export_collections', text='Animation Only', icon='ANIM')
            op.export_mode = 'ACTIVE_COLLECTION'
            op.export_target = 'ANIM'

            col = layout.column()
            col.separator()
            
            op = col.operator('collection.instance_offset_to_head')
            op.action = 'ACTIVE'

            op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename collection to head object')
            op.operation ='SYNC_COLLECTION_TO_HEAD'
            op.collection = context.collection.name

            op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename head object to collection')
            op.operation ='SYNC_HEAD_TO_COLLECTION'
            op.collection = context.collection.name

            draw_collection(self, context, collection)

        else:
            
            if 'export_subpath' not in context.collection:
                layout.operator('scene.engine_export_modify_collection', text='Mark Collection for Export',
                                icon='ADD').operation = 'ADD_ACTIVE'
                
                layout.operator('scene.engine_export_modify_collection', text='Mark Collection as Subpath',
                                icon='FILE_FOLDER').operation = 'ADD_SUBFOLDER'
            else:
                layout.prop(context.collection, '["export_subpath"]', 
                            text='Subpath') 
                            #description='Name to use when exporting children of this collection, defaults to collection name when left blank')
                
                layout.operator('scene.engine_export_modify_collection', text='Unmark Collection as Subpath',
                                icon='FILE_FOLDER').operation = 'REMOVE_SUBFOLDER'


class COLLECTION_PT_CollectionActions(Panel):
    
    bl_label = 'Collection Actions'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'collection'
    bl_idname = 'COLLECTION_PT_CollectionActions'

    modify_collection = False

    def draw(self, context):

        self.layout.operator('collection.smart_duplicate', icon='DUPLICATE')
        self.layout.operator('collection.instance_offset_to_tead', icon='OBJECT_ORIGIN')


