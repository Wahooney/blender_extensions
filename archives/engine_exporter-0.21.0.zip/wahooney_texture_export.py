# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

if "bpy" in locals():
    import importlib
    importlib.reload(wahooney_engine_export_functions)

else:
    import bpy
    from . import wahooney_engine_export_functions

is_exportable = wahooney_engine_export_functions.is_exportable


def get_texture_export_path(self, context, sub_path=''):

    scene = context.scene

    texture_export_path = ''

    if scene.engine_export_texture_export_path == '':
        filepath = context.blend_data.filepath
        filename = filepath[filepath.rfind(
            os.path.sep)+1:filepath.rfind('.blend')]
    else:
        texture_export_path = scene.engine_export_texture_export_path

    if not texture_export_path.endswith(os.path.sep):
        texture_export_path += os.path.sep

    if texture_export_path != '':
        texture_export_path = texture_export_path[:texture_export_path.rfind(
            os.path.sep)]
        texture_export_path = fix_path(texture_export_path)

    texture_export_path += os.path.sep + sub_path

    if not os.path.exists(texture_export_path):
        if context.scene.engine_export_make_path:
            os.makedirs(texture_export_path)
        else:
            self.report(
                {'WARNING'}, F"Path '{texture_export_path}' doesn't exist, try using 'Create missing folders on export'")

    return texture_export_path


def export_collections_textures(self, context, operator):

    images = []

    scene = context.scene

    use_lib = scene.engine_export_use_libraries
    active_collections = findAllViewLayerCollections(scene)

    # cycle through collections
    for collection in active_collections:

        if not collection.engine_export_export or (not use_lib and collection.library != None):
            continue

        objects = [
            ob for ob in collection.all_objects if not ob.hide_viewport and ob.visible_get()]

        print(F"Exporting Textures from {collection.name} : {len(objects)}")

        if not len(objects):
            print(F"{collection.name} has no objects")
            continue

        export_objects = []

        obj = None

        # filter objects for export
        for obj in objects:
            if is_exportable(obj):
                export_objects.append(obj)

        for obj in export_objects:

            if obj == None:
                continue

            for mat in obj.material_slots:
                if mat == None or mat.material == None:
                    continue

                for tex in mat.material.texture_slots:
                    if tex == None or tex.texture == None:
                        continue

                    if tex.texture.type == 'IMAGE' and tex.texture.image != None and images.count(tex.texture.image) < 1:
                        # Update texture if it has no data, it may not have loaded yet
                        if not tex.texture.image.has_data:
                            tex.texture.image.update()

                        if tex.texture.image.has_data:
                            images.append(tex.texture.image)

        if len(images) == 0:
            print('No textures to export')
            continue

        context.view_layer.objects.active = export_objects[0]
        scene.update()

        for image in images:

            if image.name.lower().endswith('.' + image.file_format.lower()):
                filename = image.name
            else:
                filename = image.name + '.' + image.file_format.lower()

            export_path = get_texture_export_path(
                self, context, wahooney_engine_export_functions.get_collection_exportpath(collection))

            orig_filepath_raw = image.filepath_raw

            image.filepath_raw = os.path.join(export_path, filename)
            image.update()

            image.save()

            # print(image.name)
            print(F"Saved to: {image.filepath_raw}")

            image.filepath_raw = orig_filepath_raw
            image.update()


class ExportGroupsTextures(bpy.types.Operator):
    ''''''
    bl_idname = 'export.engine_export_collections_textures'
    bl_label = 'Export Textures'

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        export_collections_textures(self, context, self)
        return {'FINISHED'}
