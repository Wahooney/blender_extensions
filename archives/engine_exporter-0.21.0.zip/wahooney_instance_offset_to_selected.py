# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import (StringProperty, EnumProperty)


class COLLECTION_OT_InstanceOffsetToSelected(bpy.types.Operator):
    ''''''
    bl_idname = "collection.instance_offset_to_selected"
    bl_label = "Move Instance-Offset to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object != None and len(context.selected_objects) > 0

    def execute(self, context):
        for sel in context.selected_objects:
            for col in sel.users_collection:
                col.instance_offset = sel.location
        return {'FINISHED'}


class COLLECTION_OT_InstanceOffsetToHead(bpy.types.Operator):
    ''''''
    bl_idname = "collection.instance_offset_to_head"
    bl_label = "Move Collections Instance-Offset to Head Object"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    action: EnumProperty(name='Action', items=(
        ('ACTIVE', "Active Collection", ""),
        ('COLLECTION', "Specific Collection", ""),
        ('ALL', "All Collections", "")), 
        default='ALL')

    collection_name: StringProperty(name='Collection')

    @classmethod
    def poll(cls, context):
        return len(context.scene.engine_export_collections) > 0

    def execute(self, context):

        action = self.action
        collection_name = self.collection_name

        for export_collection in context.scene.engine_export_collections:

            if export_collection.head is None:
                continue

            collection = export_collection.collection

            if action == 'ALL' or \
                (action == 'ACTIVE' and collection == context.collection) or \
                (action == 'COLLECTION' and collection.name == collection_name):

                collection.instance_offset = export_collection.head.location

        return {'FINISHED'}
    

def get_export_collection(collection):
    
    for col in bpy.context.scene.engine_export_collections:
        if col.collection == collection:
            return col
        
    return None


def get_export_collection_from_object(object):
    
    for col in bpy.context.scene.engine_export_collections:
        if object.name in col.collection.objects:
            return col
        
    return None


def findLayerCollection(layerCollection, collName):
    
    found = None
    
    if layerCollection.name == collName:
        return layerColl
    
    for layer in layerCollection.children:
        
        found = findLayerCollection(layer, collName)
        
        if found:
            return found


class OBJECT_OT_InstanceOffsetToHeadFromSelection(bpy.types.Operator):
    '''Relocates the instance offset of the collection to the head object of the collection based on the current selection'''

    bl_idname = "object.instance_offset_to_head"
    bl_label = "Instance-Offset to Head Object from Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):

        # we're going to relocate the referenced collections of instance collections
        for obj in bpy.context.selected_objects:
            
            if obj.type != 'EMPTY' or obj.instance_type != 'COLLECTION' or obj.instance_collection is None:
                continue
                
            exp_col = get_export_collection(obj.instance_collection)
            
            if exp_col is None or exp_col.head is None:

                col = obj.instance_collection

                obj = None
                if col.name in col.objects:
                    # do a name check to imply a head object
                    obj = col.objects[col.name]
                elif len(col.objects) == 1:
                    # if there is only one object in the collection, use that
                    obj = col.objects[0]
                    
                if obj is not None and col.instance_offset != obj.location:
                    col.instance_offset = obj.location
                    
                continue
            
            if exp_col.collection.instance_offset != exp_col.head.location:
                exp_col.collection.instance_offset = exp_col.head.location
                
                print(exp_col.name)

        # relocate the collections of the objects we have selected
        for sel in bpy.context.selected_objects:
            
            exp_col = get_export_collection_from_object(sel)
            
            if exp_col is None or exp_col.head is None:

                # do a name check, or a single object check to imply a head object
                for col in sel.users_collection:
                    if col.name == sel.name or len(col.objects) == 1:
                        if col.instance_offset != sel.location:
                            col.instance_offset = sel.location
                            break

                continue
            
            if exp_col.collection.instance_offset != exp_col.head.location:
                exp_col.collection.instance_offset = exp_col.head.location
                
                print(exp_col.name)

        return {'FINISHED'}


class OBJECT_OT_SetupLodGroups(bpy.types.Operator):
    '''Set LOD groups up for use in Unreal Engine'''

    bl_idname = "object.setup_lod_groups"
    bl_label = "Setup LOD Groups"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):

        def check_lod_group(obj):
            return sel.type == 'EMPTY'

        complete = []

        for sel in bpy.context.selected_objects:

            if not check_lod_group(sel):
                # check if our parent is an LOD group and use it
                if sel.parent is not None and check_lod_group('EMPTY'):
                    sel = sel.parent
                else:
                    continue

            if sel in complete:
                continue

            complete.append(sel)
            sel_collections = sel.users_collection

            # mark as an LOD group, this should be it's own operator or an operator option
            sel['fbx_type'] = 'LodGroup'

            counts = []
            map = {}
            collection_map = {}
            name_map = {}

            for c in sel.children:

                if c.type != 'MESH':
                    continue

                # get the final polycount of the object so we can auto-name the LODs
                eval = c.evaluated_get(bpy.context.evaluated_depsgraph_get())
                count = len(eval.data.polygons)
                eval.to_mesh_clear()

                counts.append(count)
                map[count] = (c, c.name, c.data.name)

                # prepare the object for LOD naming
                c.name = F"__BLAH_TEMP_NAME_{c.name}__"

                # we will remove this child object from any collections it shares with it's
                # parent LOD group, because lods are based on the order of the object in the
                # collection, which we will fix later
                collections = c.users_collection

                for col in collections:
                    if col in sel_collections:
                        if c not in collection_map:
                            collection_map[c] = [col]
                        else:
                            collection_map[c].append(col)

                        col.objects.unlink(c)

            # we want to sort from the highest polycount to lowest
            counts.sort(reverse=True)

            # now we iterate through the objects in order of polycount
            for i, c in enumerate(counts):

                data = map[c]
                obj = data[0]

                # rename
                obj.name = F"{sel.name}_LOD{i}"

                users = obj.data.users

                if obj.data.use_fake_user:
                    users -= 1
                
                obj['EngineExportLODGroup'] = i

                # try to keep the data name in sync if it makes sense
                # ie. data has a single (real) user, and we're it
                # or if the object name and data name were synced before
                if users == 1 or data[0] == data[1]:
                    obj.data.name = obj.name

                # relink the object to the collections the object was in before
                # but now that it's in order it will export correctly
                collections = collection_map[obj]
                for col in collections:
                    col.objects.link(obj)

        return {'FINISHED'}




