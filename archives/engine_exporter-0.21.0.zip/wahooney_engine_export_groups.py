# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
from bpy.types import PropertyGroup
from .wahooney_engine_export_collection_manager import (ExportCollectionItem, findAllViewLayerCollections)

class ExportGroupItem(PropertyGroup):

    export_collection: bpy.props.PointerProperty(name="Export Collection", type=bpy.types.Collection)

class ExportGroup(PropertyGroup):

    export_collections: bpy.props.CollectionProperty(type=ExportGroupItem)

class ENGINEEXPORT_OT_ModifyExportGroup(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_modify_export_group"
    bl_label = "Modify Export Group"
    bl_description = "Modify Export Group"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    operation: bpy.props.EnumProperty(
        items=(
            ('NONE', 'None', 'Perform no batch operations'),
            ('ADD', 'Add', 'Add an export collection'),
            ('ADD_ACTIVE', 'Add Active Collection', 'Add the active collection as an export collection'),
            ('SORT', 'Sort', 'Sort collections by name'),
            ('DUPLICATE', 'Duplicate', 'Duplicate the active export collection'),
            ('MOVE_UP', 'Move Up', 'Move the collection up the list'),
            ('MOVE_DOWN', 'Move Down', 'Move the collection down the list'),
            ('REMOVE_ACTIVE', 'Remove', 'Remove active export collection')
        ),
        default='NONE')

    @classmethod
    def description(cls, context, properties):

        if properties.operation == 'ADD':
            return 'Add an export collection'

        if properties.operation == 'ADD_ACTIVE':
            return "Add '%s' for export" % (context.collection.name)

        if properties.operation == 'ADD_ACTIVE_OBJECT':
            return "Add '%s' and it's collection '%s'" % (context.active_object, context.active_object.users_collection[0].name)

        if properties.operation == 'SORT':
            return 'Sort collections by name'

        if properties.operation == 'DUPLICATE':
            return 'Duplicate the active export collection'

        if properties.operation == 'MOVE_UP':
            return 'Move the collection up the list'

        if properties.operation == 'MOVE_DOWN':
            return 'Move the collection down the list'

        if properties.operation == 'REMOVE_ACTIVE':
            return 'Remove active export collection'

        return 'Perform no batch operations'

    def execute(self, context):

        scene = context.scene

        scene.engine_export_active_export_group_index = min(
            len(scene.engine_export_export_groups)-1,
            max(0, scene.engine_export_active_export_group_index))

        result = None

        if self.properties.operation == 'ADD':

            result = scene.engine_export_export_groups.add()
            scene.engine_export_active_export_group_index = len(
                scene.engine_export_export_groups) - 1

        elif self.properties.operation == 'CLEAR':

            scene.engine_export_export_groups.clear()

        elif self.properties.operation == 'REMOVE_ACTIVE':

            if len(scene.engine_export_export_groups) > 0:
                scene.engine_export_export_groups.remove(
                    scene.engine_export_active_export_group_index)

        elif self.properties.operation == 'AUTO_NAME':

            source = scene.engine_export_export_groups[scene.engine_export_active_export_group_index]
            if source.collection is not None:
                source.name = source.collection.name

        elif self.properties.operation == 'ADD_ACTIVE':

            result = scene.engine_export_export_groups.add()
            scene.engine_export_active_export_group_index = len(
                scene.engine_export_export_groups) - 1

            result.export_collection = context.collection

        elif self.properties.operation == 'INSERT':

            index = scene.engine_export_active_export_group_index
            collections = scene.engine_export_export_groups

            result = collections.add()
            collections.move(len(collections) - 1, index)

        elif self.properties.operation == 'SORT':

            map = {}
            name_list = []
            i = 0

            for i, c in enumerate(scene.engine_export_export_groups):
                name = c.name
                name_list.append(name)
                map[name] = c.name
                
                i += 1

            name_list.sort()
            name_list.reverse()

            for n in name_list:
                i = scene.engine_export_export_groups.find(map[n])
                scene.engine_export_export_groups.move(i, 0)

        elif self.properties.operation == 'MOVE_DOWN':

            index = scene.engine_export_active_export_group_index
            scene.engine_export_active_export_group_index += 1

        elif self.properties.operation == 'MOVE_UP':

            index = scene.engine_export_active_export_group_index
            scene.engine_export_export_groups.move(index, index - 1)
            scene.engine_export_active_export_group_index -= 1

        scene.engine_export_active_export_group_index = min(
            len(scene.engine_export_export_groups)-1,
            max(0, scene.engine_export_active_export_group_index))

        return {'FINISHED'}



class ENGINEEXPORT_OT_ModifyExportGroupCollection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_modify_export_group_collection"
    bl_label = "Modify Export Group Collection"
    bl_description = "Modify Export Group Collection"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    operation: EnumProperty(
        items=(
            ('ADD', "Add", "Add an export collection"),
            ('ADD_ACTIVE', "Add Active", "Add active collection to group (only child groups marked for export will be exported)"),
            ('ADD_ACTIVE_RECURSIVE', "Add Active Recursive", "Add all export collections below active collection"),
            ('REMOVE', "Remove", "Remove active export collection")
        ),
        default='ADD')

    index: IntProperty(default=-1)

    @classmethod
    def description(cls, context, properties):

        if properties.operation == 'ADD':
            return "Add an export collection"

        if properties.operation == 'ADD_ACTIVE':
            return "Add active collection to group (only child groups marked for export will be exported)"

        if properties.operation == 'ADD_ACTIVE_RECURSIVE':
            return "Add all export collections below active group",

        if properties.operation == 'REMOVE':
            return "Remove active export collection"

        return 'Perform no batch operations'

    def execute(self, context):

        scene = context.scene

        scene.engine_export_active_export_group_index = min(
            len(scene.engine_export_export_groups)-1,
            max(0, scene.engine_export_active_export_group_index))

        active_collection = context.collection

        result = None
        source = scene.engine_export_export_groups[scene.engine_export_active_export_group_index]

        def add_collection(collection):

            export_collection = None

            for ec in scene.engine_export_collections:
                if ec.collection is collection:
                    export_collection = ec
                    break
            
            '''
            for c in source.export_collections:
                if c.export_collection == export_collection:
                    export_collection = None
                    break
            '''

            if export_collection is not None and export_collection.name not in source.export_collections:
                result = source.export_collections.add()
                result.export_collection = export_collection.collection

        def add_recursive(collection):

            add_collection(collection)

            for c in collection.children:
                add_recursive(c)

        if self.properties.operation == 'ADD':

            result = source.export_collections.add()

        if self.properties.operation == 'ADD_ACTIVE':

            #add_collection(active_collection)
            result = source.export_collections.add()
            result.export_collection = active_collection

        if self.properties.operation == 'ADD_ACTIVE_RECURSIVE':

            add_recursive(active_collection)

        elif self.properties.operation == 'REMOVE':

            if self.properties.index >= 0 and self.properties.index < len(source.export_collections):
                source.export_collections.remove(self.properties.index)

        return {'FINISHED'}




class ENGINEEXPORT_OT_ExportExportGroup(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_export_group"
    bl_label = "Export Group"
    bl_description = "Export Group"
    bl_options = {'INTERNAL'}

    index: StringProperty()

    def execute(self, context):
        
        scene = context.scene

        bpy.ops.export.engine_export_collections(export_mode='EXPORT_GROUP', export_group_index=self.properties.index)

        return {'FINISHED'}



class ENGINEEXPORT_UL_export_groups(bpy.types.UIList):

    @staticmethod
    def filter_items_by_name_i(pattern, bitflag, items, propname="name", flags=None, reverse=False):
        """
        Set FILTER_ITEM for items which name matches filter_name one (case-insensitive).
        pattern is the filtering pattern.
        propname is the name of the string property to use for filtering.
        flags must be a list of integers the same length as items, or None!
        return a list of flags (based on given flags if not None),
        or an empty list if no flags were given and no filtering has been done.
        """
        import fnmatch

        if not pattern or not items:  # Empty pattern or list = no filtering!
            return flags or []

        if flags is None:
            flags = [0] * len(items)

        # Implicitly add heading/trailing wildcards.
        pattern = "*" + pattern + "*"

        for i, item in enumerate(items):
            name = getattr(item, propname, None)
            # This is similar to a logical xor
            if bool(name and fnmatch.fnmatch(name, pattern)) is not bool(reverse):
                flags[i] |= bitflag
        return flags

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        collection = item

        if self.layout_type in {'DEFAULT', 'COMPACT'}:

            row = layout.row(align=True)

            row.label(icon='DECORATE', text='')

            row.prop(collection, 'name', icon='EXPORT', text='')
            type_description = collection.name
            sub = False
            if collection.name not in context.scene.engine_export_collections:
                type_description = F"[ {type_description} ]"
                sub = True

            row.operator(ENGINEEXPORT_OT_ExportExportGroup.bl_idname, icon='AUTO' if sub else 'EXPORT', text="%s" % type_description).index = collection.name

        # 'GRID' layout type should be as compact as possible(typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)

    def draw_filter(self, context, layout):
        
        # Nothing much to say here, it's usual UI code...
        row = layout.row(align=True)

        # row = row.row(align=True)
        row.prop(self, "filter_name", text="")
        icon = 'SELECT_DIFFERENCE' if self.use_filter_invert else 'SELECT_INTERSECT'
        row.separator()
        row.prop(self, "use_filter_invert", text="", icon=icon)

        # row = layout.row(align=True)
        row.separator()
        row.prop(self, "use_filter_sort_alpha", text='', toggle=True)
        icon = 'SORT_DESC' if self.use_filter_sort_reverse else 'SORT_ASC'
        row.prop(self, "use_filter_sort_reverse", text="", icon=icon)

    def filter_items(self, context, data, propname):

        collections = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list
        rules = [c for c in collections]

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Filtering by name
        if self.filter_name:
            flt_flags = ENGINEEXPORTSCENE_UL_collections.filter_items_by_name_i(
                self.filter_name, self.bitflag_filter_item, rules, "name", reverse=False)

        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(rules)            

        # Reorder by name or average weight.
        if self.use_filter_sort_alpha:
            flt_neworder = helper_funcs.sort_items_by_name(rules, "name")

        return flt_flags, flt_neworder

EmptyString = ""

class ENGINEEXPORT_PT_ExportGroupPanel(bpy.types.Panel):

    bl_label = 'Engine Export Groups'
    bl_idname = 'ENGINEEXPORT_PT_ExportGroupPanel'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'
    bl_options = {'DEFAULT_CLOSED'}

    modify_collection = True

    def draw(self, context):

        scene = context.scene
        layout = self.layout

        row = layout.row()
        row.template_list('ENGINEEXPORT_UL_export_groups', '', scene,
                          'engine_export_export_groups', scene, 
                          'engine_export_active_export_group_index', rows=5)

        col = row.column(align=True)

        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="ADD").operation = 'ADD'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="LAYER_ACTIVE").operation = 'ADD_ACTIVE'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="REMOVE").operation = 'REMOVE_ACTIVE'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="SORTALPHA").operation = 'SORT'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="DUPLICATE").operation = 'DUPLICATE'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="TRIA_UP").operation = 'MOVE_UP'
        col.operator(ENGINEEXPORT_OT_ModifyExportGroup.bl_idname, text=EmptyString, icon="TRIA_DOWN").operation = 'MOVE_DOWN'

        if len(scene.engine_export_export_groups) > 0:

            group = scene.engine_export_export_groups[scene.engine_export_active_export_group_index]

            layout.label(text="", icon='GRIP')

            box = layout.box()

            box.prop(group, 'name')

            col = box.column(align=True)

            for i, collection in enumerate(group.export_collections):
                row = col.row(align=True)
                row.prop_search(collection, 'export_collection', bpy.data, 'collections', text='')
                op = row.operator(ENGINEEXPORT_OT_ModifyExportGroupCollection.bl_idname, text="", icon='REMOVE')
                op.operation = 'REMOVE'
                op.index = i

            box.separator()
        
            col = box.column(align=True)
            col.operator(ENGINEEXPORT_OT_ModifyExportGroupCollection.bl_idname, text="Add Collection", icon='ADD').operation = 'ADD'
            col.operator(ENGINEEXPORT_OT_ModifyExportGroupCollection.bl_idname, text="Add Active Collection", icon='ADD').operation = 'ADD_ACTIVE'
            col.operator(ENGINEEXPORT_OT_ModifyExportGroupCollection.bl_idname, text="Add Active Collection (Recursive)", icon='ADD').operation = 'ADD_ACTIVE_RECURSIVE'


