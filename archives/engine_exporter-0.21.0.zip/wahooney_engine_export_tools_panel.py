# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from . import wahooney_collection_name_from_selected


class ENGINEEXPORTSCENE_PT_ToolsSubPanel(bpy.types.Panel):

    bl_label = 'Export Tools'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'
    bl_idname = 'ENGINEEXPORTSCENE_PT_ToolsSubPanel'
    bl_parent_id = 'ENGINEEXPORTSCENE_PT_Panel'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):

        layout = self.layout

        # tools

        layout.label(text='Tools', icon='MODIFIER')

        col = layout.column(align=True)

        op = col.operator('collection.instance_offset_to_head')
        op.action = 'ALL'

        col.operator('scene.engine_export_update_nla',
                     text='Update Actions in NLA')

        '''
        col.operator('collection.collection_name_from_selected',
                     text='Rename Groups From Selected')

        if bpy.ops.object.rename_from_data:
            col.operator('object.rename_from_data',
                         text='Rename Objects From Data')
        '''
        col.separator()

        op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename collection to head object')
        op.operation = 'SYNC_COLLECTION_TO_HEAD'

        op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename head object to collection')
        op.operation = 'SYNC_HEAD_TO_COLLECTION'

        op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename objects to data')
        op.operation = 'RENAME_OBJECTS_TO_DATA'

        op = col.operator(wahooney_collection_name_from_selected.ExportCollectionRename.bl_idname, text='Rename data to objects')
        op.operation = 'RENAME_DATA_TO_OBJECTS'

        col.separator()

        row = col.row(align=True)
        row.operator('collection.instance_offset_to_selected',
                     text='Instance-Offset to Object')


class ENGINEEXPORTSCENE_PT_ActionPanel(bpy.types.Panel):

    bl_label = 'Export Tools'
    bl_space_type = "DOPESHEET_EDITOR"
    bl_region_type = "UI"
    bl_idname = 'ENGINEEXPORTSCENE_PT_ActionPanel'
    bl_category = "Action"

    def draw(self, context):
        act = context.active_action
        layout = self.layout

        if act is None:
            layout.label(text='No Action Selected')
            return

        layout.prop(act, "engine_export_export")

        col = layout.column(align=True)
        col.enabled = act.engine_export_export
        col.prop(act, "engine_export_is_static_animation", emboss=True, icon='FREEZE')

        if act.engine_export_export:
            row = layout.row(align=True)
            row.prop(act, "engine_export_use_rename", text='')

            col = row.column(align=True)
            col.enabled = act.engine_export_use_rename
            col.prop(act, "engine_export_explicit_rename", text='', placeholder='Explicit action name')
