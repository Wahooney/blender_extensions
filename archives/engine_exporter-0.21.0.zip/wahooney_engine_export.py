# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
from bpy.app.handlers import persistent
from mathutils import Vector, Matrix, Euler


from .wahooney_engine_export_functions import (pure_curve, fix_path)
from .wahooney_engine_export_collection_drawer import (draw_collection)
from . import wahooney_engine_export_rename


if "bpy" in locals():
    import importlib
    importlib.reload(wahooney_engine_export_functions)
    importlib.reload(wahooney_engine_export_collection_manager)

else:
    import bpy
    from . import wahooney_engine_export_functions
    from . import wahooney_engine_export_collection_manager


manager = wahooney_engine_export_collection_manager
is_exportable = wahooney_engine_export_functions.is_exportable


# General functions ############################################################

def find_all_view_layer_collections(scene):
    # collections = []
    # if (len(scene.view_layers) > 0):
    #    layer_collection = scene.view_layers[0].layer_collection
    #    return findAllChildLayers(layer_collection, collections)
    # return collections
    # return bpy.data.collections
    return scene.engine_export_collections


def find_layer_collections(layer, results):

    if layer not in results:
        results.append(layer)

    for c in layer.children:
        find_layer_collections(c, results)


def collect_collections(collection, collections):

    if not collection in collections:
        collections.append(collection)

    for c in collection.children:
        collect_collections(c, collections)


engine_export_targets = {'UNREAL': 'Unreal Engine',
                         'UNITY': 'Unity Engine'}


def get_export_path(self, context, sub_path=''):
    scene = context.scene

    export_path = ''

    if scene.engine_export_export_path == '':
        filepath = context.blend_data.filepath
        filename = filepath[filepath.rfind(
            os.path.sep)+1:filepath.rfind('.blend')]
    else:
        export_path = scene.engine_export_export_path

    if not export_path.endswith(os.path.sep):
        export_path += os.path.sep

    if export_path != '':
        export_path = export_path[:export_path.rfind(os.path.sep)]
        export_path = fix_path(export_path)

    export_path += os.path.sep + sub_path

    if not os.path.exists(export_path):
        if context.scene.engine_export_make_path:
            os.makedirs(export_path)
        else:
            self.report({'WARNING'}, F"Path '{export_path}' doesn't exist")

    return export_path


def is_hierarchy_in_list(object, list):

    parent = object.parent

    while parent is not None:
        if parent in list:
            return True

        parent = parent.parent

    return False


# Rename functions #############################################################

def store_real_name(ob):
    name = ob.name

    if 'real_name' in ob:
        name = ob['real_name']
    else:
        ob['real_name'] = ob.name
        ob.name = name + "_JUST_CHANGING_THIS_NAME_TEMPORARILY_BE_RIGHT_BACK"
        print(F"Stored {ob['real_name']} : {ob.name}")

    return name


def restore_real_name(ob):
    if 'real_name' in ob:
        ob.name = ob['real_name']
        print(F"Restored {ob['real_name']}")
        del ob['real_name']


# Export functions #############################################################

def collapse_collection(context, group_name):

    active_collections = find_all_view_layer_collections(context.scene)
    export_collection = active_collections[group_name]
    collection = export_collection.collection

    objects = [ob for ob in bpy.data.objects]
    scene = context.scene

    export = []
    cleanup = []

    for obj in objects:
        obj.select_set(False)

    meshes = []
    collapse_objects = []
    original_collapsed_objects = []
    objects = [ob for ob in collection.all_objects]

    head_object = None

    # don't collapse if the head is empty, a collision hull, or a non-meshable curve (should probably have a warning in the UI)
    if export_collection.head is None or export_collection.head.name.startswith('UCX') or pure_curve(export_collection.head):
        return []

    for obj in objects:

        # deselect everything
        for o in objects:
            o.select_set(False)

        obj_copy = None

        # don't collapse objects that aren't flagged to export, they may be part of a rig, a boolean operation, node tree, etc.
        if not is_exportable(obj):
            continue

        if obj.type in ['CURVE']:

            # convert curves(and other convertable objects) to meshes, skips non-mesh convertable objects
            if pure_curve(obj):
                continue

            context.view_layer.objects.active = obj
            obj.select_set(True)

            bpy.ops.object.convert(target='MESH', keep_original=True)
            obj_copy = context.view_layer.objects.active
            context.view_layer.objects.active = None

        elif obj.type == 'MESH':

            # don't collapse collision hulls
            if obj.name.startswith("UCX"):
                export.append(obj)
                continue

            obj_copy = obj.copy()

            if obj is export_collection.head and obj_copy.parent is not None and obj_copy.parent.type == 'MESH':
                obj_copy.parent = None

            # unlink from user collections
            while len(obj_copy.users_collection) > 0:
                obj_copy.users_collection[0].objects.unlink(obj_copy)

            # link to scene
            scene.collection.objects.link(obj_copy)

        else:
            # we probably have an object that's not a mesh or curve, so just skip it
            export.append(obj)
            print(F"Not collapsing {obj.type}:{obj.name} ({obj_copy})")
            continue

        # make multi-user meshes unique
        if obj_copy.data.users != 1:
            obj_copy.data = obj_copy.data.copy()

        if obj is export_collection.head:
            # the current object is the head of the collection, so it's copy
            # will be the head of the collapsed collection
            head_object = obj_copy
        else:
            # into the soup
            meshes.append(obj_copy.data)

        collapse_objects.append(obj_copy)
        original_collapsed_objects.append(obj)

    context.view_layer.update()

    # somehow, despite our checks we still have no head object, so just skip it
    # should probably have a better early check for this
    if head_object is None:

        try:
            # destroy the copies
            for obj in collapse_objects:

                if obj.type == 'MESH':
                    bpy.data.meshes.remove(obj.data)

                if obj is not None and obj.name in bpy.data.objects:
                    bpy.data.objects.remove(obj)

            # destroy any stray meshes
            for mesh in meshes:
                if mesh is not None:
                    bpy.data.meshes.remove(mesh)
        finally:

            print(F"{group_name} has no head, collapse skipped.")

        return []

    # account for armatured, collapsed meshes
    armature_obj = None
    armature_mods = []

    for obj in collapse_objects:

        # select the objects that we will collapse
        obj.select_set(True)

        for mod in obj.modifiers:
            if mod.type == "ARMATURE":
                # find the head object's armature modifier and target armature
                if obj == head_object and mod.show_viewport or mod.show_render:
                    armature_obj = mod.object

                # turn other armatures off
                mod.show_viewport = False
                mod.show_render = False

                armature_mods.append(mod)

    # if we don't have an armature object but we have some armature mods, do some guess work
    if armature_obj is None and len(armature_mods) > 0:
        for mod in armature_mods:
            if mod.object is not None:
                armature_obj = mod.object
                break

    # just check if there are mismatched armature objects
    for mod in armature_mods:
        if mod.object != armature_obj:
            print("All armatures in the collection don't share the same armature object.")

    # sort the naming out
    restore_real_name(head_object)
    store_real_name(export_collection.head)

    head_object.name = group_name
    context.view_layer.objects.active = head_object

    # convert to meshes and join
    bpy.ops.object.convert(target='MESH')
    bpy.ops.object.join()

    # pop that armature back on there
    if armature_obj is not None:
        arm = head_object.modifiers.new('Armature', 'ARMATURE')
        arm.object = armature_obj

    for mesh in meshes:
        if mesh is not None:
            bpy.data.meshes.remove(mesh)

    export.insert(0, head_object)
    cleanup.append(head_object)
    # context.view_layer.active_layer_collection = store_collection

    return [export, cleanup, original_collapsed_objects]


def do_export_collections(self, context):

    from . import EngineExportAddonPreferences

    scene = context.scene
    active = context.view_layer.objects.active

    # store scene state
    store_selection = []
    store_selectable = []
    store_collection_state = {}

    use_instance = scene.engine_export_use_instances

    active_exports = []

    # store selection and selection restriction
    for ob in scene.objects:
        if ob.select_get():
            store_selection.append(ob)

        ob.select_set(False)
        if ob.hide_select:
            ob.hide_select = False
            store_selectable.append(ob)

    # accumulate the collections we want to export based on the export mode
    if self.export_mode == 'ACTIVE':

        active_exports = [
            scene.engine_export_collections[scene.engine_export_active_export_collection_index]]

    elif self.export_mode == 'ACTIVE_COLLECTION':

        active_exports = [
            col for col in scene.engine_export_collections if col.collection == context.collection]

    elif self.export_mode == 'SELECTION':

        # find all the collections that contain selected objects, make sure we don't have duplicates

        active_exports = []

        print(F"{len(store_selection)} objects selected")

        for sel in store_selection:

            print(F"Checking {sel.name} ... ")

            for export_data in sel.users_collection:

                print(F"Matching {export_data.name} ...")

                for export_collection in scene.engine_export_collections:

                    if export_collection.collection == export_data and export_collection not in active_exports and \
                            not export_collection.is_utility_collection:

                        active_exports.append(export_collection)

    elif self.export_mode == 'EXPORT_GROUP':

        # find all collections in export groups that are flagged to export, make sure we don't have duplicates

        if self.properties.export_group_index not in scene.engine_export_export_groups:
            return

        group = scene.engine_export_export_groups[self.properties.export_group_index]

        collection_names = []

        for col in group.export_collections:

            if col.export_collection is None:

                print(
                    F"Export collection '{col.name}' has no associated collection: skipping...")
                continue

            print(col.name)

            for c in col.export_collection.children_recursive:
                print(c.name)

            root_collections = [
                c for c in col.export_collection.children_recursive]
            root_collections.append(col.export_collection)

            for c in root_collections:
                if c.name not in collection_names:
                    collection_names.append(c.name)

        active_exports = [
            col for col in scene.engine_export_collections if col.collection is not None and col.collection.name in collection_names and not col.is_utility_collection]

    else:
        layer_collections = find_all_view_layer_collections(scene)
        active_exports = [
            col for col in layer_collections if col.do_export and not col.is_utility_collection]

    for export_data in active_exports:

        collection = export_data.collection

        if collection is None:
            print(F"Collection {export_data.name} has no associated collection")
            continue

        if collection.engine_export_head is not None and export_data.head is not None:

            if collection.engine_export_head.name in collection.all_objects:
                export_data.head = collection.engine_export_head

            collection.engine_export_head = None

        if not export_data.do_export and self.export_mode == 'ENABLED':
            continue

        store_collection_state[export_data] = collection.hide_viewport
        export_data.hide_viewport = False

    # cycle through collections for export
    for export_data in active_exports:

        if not export_data.do_export and self.export_mode == 'ENABLED':
            continue

        collection = export_data.collection

        if export_data.name_method == 'AUTO':
            export_data.name = collection.name

        # calculate the new center offset, all collections are exported with their desired center at world origin
        center_offset = Vector((0, 0, 0))
        euler_offset = Euler((0, 0, 0))

        if export_data.offset_method == 'COLLECTION' or export_data.head is None:
            center_offset = collection.instance_offset

        elif export_data.offset_method == 'OBJECT' and export_data.offset_target_object is not None:
            center_offset = export_data.offset_target_object.location.copy()

            if export_data.use_rotation_offset:
                euler_offset = export_data.offset_target_object.rotation_euler.copy()

        elif export_data.head is not None:
            if export_data.offset_method == 'PARENT':

                if export_data.head.parent is not None:
                    center_offset = export_data.head.parent.location.copy()

                    if export_data.use_rotation_offset:
                        euler_offset = export_data.head.parent.rotation_euler.copy()
                else:
                    center_offset = export_data.head.location.copy()

                    if export_data.use_rotation_offset:
                        euler_offset = export_data.head.rotation_euler.copy()

            elif export_data.offset_method == 'HEAD':
                if export_data.head is not None:
                    center_offset = export_data.head.location.copy()

                    if export_data.use_rotation_offset:
                        euler_offset = export_data.head.rotation_euler.copy()
                else:
                    center_offset = collection.instance_offset

        restore_matrix = Matrix.LocRotScale(
            center_offset, euler_offset, Vector((1, 1, 1)))
        zero_matrix = restore_matrix.inverted()

        # state storage

        cleanup_objects = []
        export_objects = []
        support_objects = []
        store_solo_tracks = []
        store_mute_tracks = []
        store_nla_tracks = []
        store_rest_poses = []
        store_poses = []
        store_actions = {}
        store_tweak_mode = {}
        frame_store = ()
        store_collection_visibility = {}
        store_object_visibility = {}
        layer_collections = []

        ###############################################################################################
        # collect restore data (DON'T MODIFY OBJECTS OR COLLECTIONS IN THIS PHASE)

        find_layer_collections(bpy.context.view_layer.layer_collection, layer_collections)

        # attempt to unhide all collections and objects before export
        for layer_collection in layer_collections:
            store_collection_visibility[layer_collection] = layer_collection.hide_viewport
            layer_collection.hide_viewport = False

        for obj in bpy.data.objects:
            store_object_visibility[obj] = obj.hide_viewport

        # don't export objects that may still be hidden
        objects = [
            ob for ob in collection.all_objects if not ob.hide_viewport and ob.visible_get()]

        collection_name = export_data.name if export_data.name != '' else collection.name

        if len(objects) == 0:
            print(
                F'== Not exporting {collection.name}, no objects to export.')
            continue

        print(F'== Exporting {collection_name} {len(objects)} objects in {collection.name}')

        ob = None

        # list of objects that are not flagged to export, but are part of the collection,
        # we always assume the objects exist for a reason
        support_objects = [ob for ob in collection.all_objects if not is_exportable(ob)]

        print(F"Export type: {export_data.export_type}")

        if export_data.export_type == 'COLLAPSED':

            # handle collapsed objects

            if export_data.head is None:
                print(F"No head detected, skipping {collection_name}")
                continue

            ob = collapse_collection(context, collection_name)

            if not ob:
                print(F"No objects to collapse, skipping {collection_name}")
                continue

            if len(ob) > 0:
                export_objects.extend(ob[0])
            if len(ob) > 1:
                cleanup_objects.extend(ob[1])
            if len(ob) > 2:
                support_objects.extend(ob[2])

        else:

            # prepare special objects and animation state for export
            for ob in objects:

                if is_exportable(ob):
                    # convert non-mesh -> mesh(curve)
                    if ob.type == 'CURVE':
                        if ((ob.data.extrude > 0) or (ob.data.bevel_depth > 0) or (ob.data.bevel_object is not None)):
                            context.view_layer.objects.active = ob
                            bpy.ops.object.convert(
                                target='MESH', keep_original=True)
                            ob = context.view_layer.objects.active
                            cleanup_objects.append(ob)
                        else:
                            ob = None

                    if ob is not None:

                        export_objects.append(ob)
                        ob.hide_viewport = False

                        # set all tracks off solo, store tracks that are solo
                        if ob.animation_data is not None:
                            for nla in ob.animation_data.nla_tracks:

                                if nla.is_solo:
                                    store_solo_tracks.append(nla)

                                if nla.mute:
                                    store_mute_tracks.append(nla)

                                store_nla_tracks.append(nla)

                                nla.is_solo = False

        for sel in context.selected_objects:
            sel.select_set(False)

        all_objects = export_objects + support_objects
        transform_objects = [
            ob for ob in all_objects if not is_hierarchy_in_list(ob, all_objects)]

        print(transform_objects)

        # move non-exported, but non-grouped, objects, because they are most likely part of a rig
        for ob in support_objects:

            if ob is None:
                continue

            # we don't want to move objects that are constrained
            constrained = False
            for con in ob.constraints:
                if con.type == 'CHILD_OF' and con.target in transform_objects:
                    constrained = True
                    break

            # transform object to world center
            if ob in transform_objects and not constrained:
                ob.matrix_world = zero_matrix @ ob.matrix_world

        for ob in export_objects:

            if ob is None:
                continue

            # store actions
            if ob.animation_data is not None and ob.animation_data.action is not None:
                store_actions[ob] = ob.animation_data.action
                store_tweak_mode[ob] = ob.animation_data.use_tweak_mode

                ob.animation_data.use_tweak_mode = False
                ob.animation_data.action = None

            has_split_animation = False

            # set up single file animation data
            if ob.animation_data is not None:
                for nla in ob.animation_data.nla_tracks:
                    if nla.name in export_data.split_nla_tracks:
                        split = export_data.split_nla_tracks[nla.name]
                        nla.mute = split.use_split or not split.do_export

                        has_split_animation = has_split_animation or (
                            split.use_split and split.do_export)

                    else:  # this should never really happen, so hide it away
                        nla.mute = True

            # make sure armatures aren't in the rest position, animation won't export correctly
            if ob.type == 'ARMATURE':

                if ob.data.pose_position == 'REST':
                    store_rest_poses.append(ob.data)
                    print(F"== REST {ob.name}")
                else:
                    store_poses.append(ob.data)
                    print(F"== POSE {ob.name}")

                if has_split_animation:
                    # we want to export the main asset in its rest pose
                    ob.data.pose_position = 'REST'
                else:
                    ob.data.pose_position = 'POSE'

            # feedback
            if ob.animation_data is not None:
                print(F"======= {ob.name} '{ob.animation_data.action}'")

                if ob.type == 'ARMATURE':
                    print(F"========= {ob.data.pose_position}")

                for nla in ob.animation_data.nla_tracks:
                    if nla.name in export_data.split_nla_tracks:
                        print(
                            f"========= {nla.name} Active: {not nla.mute}")

            # don't export if we're null or not flagged to export (may be redundant)
            if not is_exportable(ob):
                continue

            ob.select_set(True)

            # do weird scale thing to sockets for unreal
            if ob.name.startswith("SOCKET_"):
                ob.scale /= 100 * scene.unit_settings.scale_length

            # actuate renaming rules
            if ob.engine_export_use_rename:

                # make sure we're not storing the new value, could cause renaming issues
                obj_name = store_real_name(ob)

                if not ob.engine_export_explicit_rename:
                    obj_name = wahooney_engine_export_rename.rename_all(
                        obj_name)
                else:
                    obj_name = ob.engine_export_explicit_rename

                if obj_name != ob.name and obj_name in bpy.data.objects:
                    store_real_name(bpy.data.objects[obj_name])

                ob.name = obj_name

                if ob.data is not None:
                    ob.data.name = wahooney_engine_export_rename.rename_all(
                        store_real_name(ob.data))

            # disable blend shapes if needed
            if export_data.disable_blend_shapes and ob.type == 'MESH':
                mesh = ob.data

                shape_keys = mesh.shape_keys

                if shape_keys is not None:
                    for key in shape_keys.key_blocks:
                        key.value = 0.0

            # we don't want to move objects that are constrained
            constrained = False
            for con in ob.constraints:
                if con.type == 'CHILD_OF' and con.target in transform_objects:
                    constrained = True
                    break

            # transform object to world center
            if ob in transform_objects and not constrained:
                ob.matrix_world = zero_matrix @ ob.matrix_world

            # convert instances to empties if we don't want to export instances
            if not (use_instance or export_data.use_instances):
                ob['instance'] = ob.instance_type
                ob.instance_type = 'NONE'

        if len(export_objects) > 0:

            for sel in context.selected_objects:
                print(F"== Preparing to export == {sel.name}")

            context.view_layer.objects.active = export_objects[0]
            frame_store = (scene.frame_start, scene.frame_end)

            if export_data.export_type == 'COLLECTION' or export_data.export_type == 'COLLAPSED':

                export_path = get_export_path(self,
                                              context, wahooney_engine_export_functions.get_collection_exportpath(export_data))

                filename = collection_name

                print(F"Exporting {len(export_objects)} objects...")

                if self.export_target != 'ANIM':

                    # export main file #########################################

                    do_export(context, scene, export_path,
                              filename, export_data)

                # export split animations ######################################

                if export_data.animation and self.export_target != 'MESH':

                    # deselect all objects
                    for ob in context.scene.objects:
                        ob.select_set(False)

                    # select track objects
                    for ob in export_data.split_nla_tracks_objects:
                        if ob is not None and ob.track_object is not None and is_exportable(ob.track_object):
                            ob.track_object.select_set(ob.include_in_split)

                    static = []

                    for nla in export_data.split_nla_tracks:
                        if nla.is_static:
                            static.append(nla.name)

                    for nla in export_data.split_nla_tracks:

                        start = 100000
                        end = -100000
                        valid_export = False

                        # skip unsplit nla tracks
                        if not nla.use_split or not nla.do_export:
                            continue

                        for ob in export_data.split_nla_tracks_objects:
                            if ob.track_object.animation_data is None:
                                continue

                            for track in ob.track_object.animation_data.nla_tracks:

                                if track not in store_nla_tracks:
                                    store_nla_tracks.append(track)

                                track.mute = (track.name not in static) and ((track.name != nla.name) or (
                                    not export_data.split_nla_tracks[track.name].use_split))

                                # we don't want to consider the range of an action if it's static, it can throw
                                # the true range off this was commented out for some reason, needs to be tested
                                if not track.mute and track.name not in static:
                                    for strip in track.strips:
                                        if strip.action is None:
                                            continue

                                        valid_export = True
                                        action = strip.action
                                        start = int(min(start, action.frame_start))
                                        end = int(max(end, action.frame_end))

                        if not valid_export:
                            continue

                        anim_export_path = export_path + export_data.anim_subpath

                        if not os.path.exists(anim_export_path):
                            os.makedirs(anim_export_path)

                        scene.frame_start = start
                        scene.frame_end = end

                        print(F"== {nla.name} == Range {start} {end}")

                        export_filename = nla.name

                        target = scene.engine_export_target
                        if target == 'DEFAULT':
                            target = EngineExportAddonPreferences.get_instance(
                                context).global_export_target

                        if target == 'UNITY':
                            export_filename = filename + "@" + export_filename

                        for ob in export_objects:

                            if ob is None:
                                continue

                            if ob.type == 'ARMATURE':
                                ob.data.pose_position = 'POSE'

                        if nla.animated_object.animation_data is not None and nla.animated_object.animation_data.action is not None:
                            store_actions[nla.animated_object] = nla.animated_object.animation_data.action
                            nla.animated_object.animation_data.action = None

                            if nla.animated_object.data.pose_position == 'REST':
                                store_rest_poses.append(
                                    nla.animated_object.data.pose_position)
                                nla.animated_object.data.pose_position = 'POSE'

                        # Export animation #####################################

                        do_export(context, scene, anim_export_path, export_filename,
                                  export_data, force_animation=True)

        else:

            print(F"== Not exporting {collection_name}, no objects to export.")

        dg = context.evaluated_depsgraph_get()
        dg.update()

        # House cleaning #######################################################

        # restore scene state
        scene.frame_start = frame_store[0]
        scene.frame_end = frame_store[1]

        # remove cleanup objects
        if len(cleanup_objects):

            for ob in cleanup_objects:

                if (ob is None):
                    continue

                # remove temporary export objects
                if ob in export_objects:
                    export_objects.remove(ob)

                for col in ob.users_collection:
                    col.objects.unlink(ob)

                data = ob.data
                bpy.data.objects.remove(ob)
                bpy.data.meshes.remove(data)

        # return objects to previous positions
        for ob in export_objects:

            ob.select_set(False)

            if ob.name.startswith("SOCKET_"):
                ob.scale *= 100 * scene.unit_settings.scale_length

            # we don't want to move objects that are constrained
            constrained = False
            for con in ob.constraints:
                if con.type == 'CHILD_OF' and con.target in transform_objects:
                    constrained = True
                    break

            # restore offsets
            if ob in transform_objects and not constrained:

                ob.matrix_world = restore_matrix @ ob.matrix_world

                if 'instance' in ob:
                    ob.instance_type = ob['instance']
                    del ob['instance']

        for ob in support_objects:

            # we don't want to move objects that are constrained
            constrained = False
            for con in ob.constraints:
                if con.type == 'CHILD_OF' and con.target in transform_objects:
                    constrained = True
                    break

            # restore offsets
            if ob in transform_objects and not constrained:
                ob.matrix_world = restore_matrix @ ob.matrix_world

        # restore nla tracks state #############################################

        for nla in store_nla_tracks:
            nla.mute = False
            nla.is_solo = False

        for nla in store_mute_tracks:
            nla.mute = True

        for nla in store_solo_tracks:
            nla.is_solo = True

        # restore rig pose state ###############################################

        for rest in store_rest_poses:
            rest.pose_position = 'REST'

        for rest in store_poses:
            rest.pose_position = 'POSE'

        # restore object state #################################################

        for ob in store_selectable:
            ob.hide_select = True

        for ob in bpy.data.objects:
            restore_real_name(ob)

        for me in bpy.data.meshes:
            restore_real_name(me)

        for ob, action in store_actions.items():
            ob.animation_data.action = action

        for ob, mode in store_tweak_mode.items():
            ob.animation_data.use_tweak_mode = mode

        for col, state in store_collection_visibility.items():
            col.hide_viewport = state

        for obj, state in store_object_visibility.items():
            obj.hide_viewport = state

    # restore collection state #################################################

    for (export_data, state) in store_collection_state.items():
        export_data.hide_viewport = state

    # restore object selection #################################################

    for ob in store_selection:
        ob.select_set(True)

    context.view_layer.objects.active = active

    # fin ######################################################################
    print("\n############# Export Complete")


# Perform File Export ##########################################################

def do_export(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    export_path = os.path.join(os.path.abspath(export_path), '')

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    # Apply naming conventions #################################################

    filename = wahooney_engine_export_functions.add_prefix(
        context, filename, force_animation)

    if len(bpy.context.selected_objects) == 0:
        print(F"'{collection.collection.name}' failed to export, no selection.")
        return

    export_format = scene.engine_export_format
    if collection.export_format != 'PROJECT':
        export_format = collection.export_format

    file_extention = ''

    if export_format == 'FBX':
        file_extention = '.fbx'
        export_selection_to_FBX(context, scene, export_path,
                                filename + file_extention,
                                collection, force_animation=force_animation)

    elif export_format == 'GLTF':
        file_extention = '.glb'
        export_selection_to_GlTF(context, scene, export_path,
                                 filename + file_extention,
                                 collection, force_animation=force_animation)

    elif export_format == 'USD':
        file_extention = '.usdc'
        export_selection_to_USD(context, scene, export_path,
                                filename + file_extention,
                                collection, force_animation=force_animation)
    else:
        print(F"Unknown export format '{export_format}'")
        return

    file_path = os.path.join(export_path, filename)

    print(F"'{collection.collection.name}' exported to '{file_path}{file_extention}'.")


# GLTF Export ##################################################################

def export_selection_to_GlTF(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    materials = []
    for sel in context.selected_objects:

        if sel.type != 'MESH':
            continue

        materials.extend(sel.data.materials[:])

    # unreal engine renames materials with a _DS suffix which is insufferable, lets temporarily disable it
    store_two_sided_materials = [mat for mat in materials if not mat.use_backface_culling]
    for mat in store_two_sided_materials:
        mat.use_backface_culling = True

    try:
        bpy.ops.export_scene.gltf(filepath=os.path.join(export_path, filename),

                                  # parameters
                                  use_selection=True,
                                  use_active_collection=False,
                                  export_format='GLB',
                                  export_image_format='NONE',
                                  # this is flipped for some reason
                                  export_yup=(target != 'UNITY'),
                                  export_extras=True,
                                  will_save_settings=False,

                                  # mesh data
                                  export_apply=True,
                                  export_texcoords=True,
                                  export_normals=True,
                                  export_tangents=True,
                                  export_materials='EXPORT',
                                  export_attributes=True,
                                  use_mesh_edges=False,
                                  use_mesh_vertices=False,

                                  # animation
                                  export_animations=collection.animation or force_animation,
                                  export_frame_range=False,
                                  export_frame_step=1,
                                  export_force_sampling=True,
                                  export_nla_strips=collection.animation and not force_animation,
                                  export_current_frame=False,

                                  # armatures
                                  export_skins=True,
                                  export_all_influences=True,

                                  # shape_keys
                                  export_morph=True,
                                  export_morph_normal=True,
                                  export_morph_tangent=True,
                                  )

    finally:
        # restore two sided materials
        for mat in store_two_sided_materials:
            mat.use_backface_culling = False


# Export FBX ###################################################################

def export_selection_to_FBX(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target

    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    if target == 'UNITY':

        bpy.ops.export_scene.fbx(filepath=os.path.join(export_path, filename),
                                 use_selection=True,
                                 batch_mode='OFF',

                                 # scene
                                 global_scale=scene.engine_export_global_scale,
                                 apply_unit_scale=True,
                                 apply_scale_options='FBX_SCALE_UNITS',

                                 # objects
                                 axis_forward='Y',
                                 axis_up='Z',
                                 # bake_space_transform=True,
                                 use_custom_props=True,

                                 # mesh
                                 mesh_smooth_type='FACE',

                                 # animation
                                 bake_anim=collection.animation or force_animation,
                                 bake_anim_use_all_actions=False,
                                 bake_anim_use_nla_strips=collection.animation or force_animation,
                                 bake_anim_step=1.0,
                                 bake_anim_simplify_factor=1.0,  # 0.0 if collection.optimize else 1.0,

                                 # rig
                                 add_leaf_bones=False,
                                 use_armature_deform_only=False)

    elif target == 'UNREAL':

        bpy.ops.export_scene.fbx(filepath=os.path.join(export_path, filename),
                                 use_selection=True,
                                 batch_mode='OFF',

                                 # scene
                                 global_scale=scene.engine_export_global_scale,
                                 apply_unit_scale=True,
                                 use_space_transform=False,
                                 apply_scale_options='FBX_SCALE_NONE',

                                 # objects
                                 axis_forward='X',
                                 axis_up='Z',
                                 bake_space_transform=False,
                                 use_custom_props=True,

                                 # mesh
                                 mesh_smooth_type='OFF',

                                 # animation
                                 bake_anim=collection.animation or force_animation,
                                 bake_anim_use_all_actions=False,
                                 bake_anim_use_nla_strips=collection.animation and not force_animation,
                                 bake_anim_simplify_factor=0.0 if collection.optimize else 1.0,
                                 bake_anim_use_all_bones=True,
                                 bake_anim_force_startend_keying=collection.animation,

                                 # rig
                                 add_leaf_bones=False,
                                 use_armature_deform_only=False)


# Export USD ###################################################################

def export_selection_to_USD(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    bpy.ops.wm.usd_export(filepath=os.path.join(export_path, filename),
                          selected_objects_only=True,
                          visible_objects_only=False,
                          export_animation=collection.animation or force_animation,
                          export_armatures=True,
                          export_hair=False,
                          export_uvmaps=True,
                          export_normals=True,
                          export_materials=False,
                          use_instancing=False,
                          evaluation_mode=scene.engine_export_evaluation_mode)


# Operators ####################################################################

class ExportCollections(bpy.types.Operator):
    ''''''
    bl_idname = 'export.engine_export_collections'
    bl_label = 'Export Collections for Engine'
    bl_options = {'INTERNAL'}

    export_mode: bpy.props.EnumProperty(items=(
        ('ENABLED', 'Enabled Collections',
         'Export Collections that are enabled for export'),
        ('ACTIVE', 'Active Only', 'Only export the active export collection'),
        ('ACTIVE_COLLECTION', 'Active Scene Collection Only',
         'Only export the active scene collection'),
        ('SELECTION', 'Object Selection',
         'Export the collection which have currently selected child objects'),
        ('EXPORT_GROUP', 'Export Group', 'Export whole Export Group')),
        default='ENABLED')

    export_target: bpy.props.EnumProperty(items=(
        ('ALL', 'All', 'Export Mesh and Animation data'),
        ('ANIM', 'Animation', 'Export Animation data only'),
        ('MESH', 'Mesh', 'Export Mesh data only')), default='ALL')

    export_group_index: bpy.props.StringProperty(
        name="Export Collection Index", default='')

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        do_export_collections(self, context)
        return {'FINISHED'}


def sanitize_collection(collection):

    result = 0
    added = 0

    if collection.name_method == 'AUTO' and collection.collection is not None and collection.collection.name != collection.name:
        print(F"== Engine Exporter: Renaming {collection.collection.name} to {collection.name} ==")
        collection.name = collection.collection.name

    sanitize_track_objects = []
    for i, ob in enumerate(collection.split_nla_tracks_objects):
        if ob is not None and ob.track_object is not None:
            ob.name = ob.track_object.name
        elif ob is None or ob.track_object is None:
            sanitize_track_objects.append(i)

    if len(sanitize_track_objects) > 0:

        sanitize_track_objects.sort(reverse=True)
        for i in sanitize_track_objects:
            collection.split_nla_tracks_objects.remove(i)
        del sanitize_track_objects

    if collection.animation and collection.collection is not None:

        for o in collection.collection.all_objects:

            # prep data
            # and collection.collection in o.users_collection: # the object is a direct child of this collection
            if o.name not in collection.split_nla_tracks_objects:

                track_obj = collection.split_nla_tracks_objects.add()
                track_obj.track_object = o
                track_obj.name = o.name

                added += 1

            if o.animation_data is not None:

                for nla in o.animation_data.nla_tracks:

                    # if nla.name not in collection.split_nla_tracks:
                    found = False

                    for track in collection.split_nla_tracks:
                        if track.name == nla.name:

                            # we found a matching track name
                            if track.animated_object == o:
                                # it's correctly assigned
                                found = True
                                continue

                            elif track.animated_object is None:
                                # it's incorrectly assigned, let's hijack it
                                track.animated_object = o
                                found = True
                                continue

                    if not found and nla.name not in collection.split_nla_tracks:
                        # make a new one
                        split = collection.split_nla_tracks.add()
                        split.name = nla.name
                        split.animated_object = o
                        added += 1

    # remove dangling nla tracks
    sanitize_tracks = []
    for nla in collection.split_nla_tracks:
        valid_track = True

        if nla.animated_object is None:
            valid_track = False

        elif nla.name not in nla.animated_object.animation_data.nla_tracks:
            valid_track = False

        '''else:
            has_strip = False
            for strip in nla.animated_object.animation_data.nla_tracks[nla.name].strips:
                if strip.action is not None:
                    has_strip = True

            if not has_strip:
                print(F"{nla.name} has no animated strips, removing")
                valid_track = False'''

        if not valid_track:
            sanitize_tracks.append(nla)

    # remove dangling nla track objects
    sanitize_objects = []

    for ob in collection.split_nla_tracks_objects:

        if ob.track_object is None:
            continue

        col = collection.collection

        if col is not None and (len(ob.track_object.users_scene) == 0 or ob.track_object.name not in col.all_objects):
            sanitize_objects.append(ob)

        elif ob.track_object is None:
            sanitize_objects.append(ob)

        else:
            ob.name = ob.track_object.name

    for field in sanitize_objects:
        idx = collection.split_nla_tracks_objects.find(field.name)

        if idx >= 0:
            collection.split_nla_tracks_objects.remove(idx)
            result += 1

    for track in sanitize_tracks:
        idx = collection.split_nla_tracks.find(track.name)

        if idx >= 0:
            collection.split_nla_tracks.remove(idx)
            result += 1

    return (result, added)


@persistent
def sanitize_collections(scene):

    for func in bpy.app.handlers.depsgraph_update_post:
        if func.__name__ == 'sanitize_collections':
            bpy.app.handlers.depsgraph_update_post.remove(func)

    for collection in scene.engine_export_collections:
        sanitize_collection(collection)

    bpy.app.handlers.depsgraph_update_post.append(sanitize_collections)


class ENGINEEXPORTSCENE_PT_Panel(bpy.types.Panel):

    bl_label = 'Engine Export Tools'
    bl_idname = 'ENGINEEXPORTSCENE_PT_Panel'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'

    modify_collection = True

    def draw(self, context):

        from . import EngineExportAddonPreferences

        layout = self.layout
        scene = context.scene

        active_collections = find_all_view_layer_collections(scene)

        # Export Groups List
        col = layout.column(align=True)
        col.label(text='Export Collections', icon='GROUP')

        box = col.box()
        box.label(text='Property Matrix', icon='SPREADSHEET')
        row = box.row(align=True)
        row.prop(scene, 'engine_export_matrix_show_path',
                 text='Path', emboss=True, icon='FILE_FOLDER')
        row.prop(scene, 'engine_export_matrix_show_origin',
                 text='Origin', emboss=True, icon='TRANSFORM_ORIGINS')
        row.prop(scene, 'engine_export_matrix_show_animation',
                 text='Animation', emboss=True, icon='ANIM')
        row.prop(scene, 'engine_export_matrix_show_export_type',
                 text='Export Type', emboss=True, icon='WORDWRAP_ON')
        row.separator()
        row.prop(scene, 'engine_export_matrix_show_expanded_matrix',
                 text='', emboss=True, icon='SPLIT_VERTICAL')

        row = col.row()
        row.template_list('ENGINEEXPORTSCENE_UL_collections', '', scene, 'engine_export_collections',
                          scene, 'engine_export_active_export_collection_index', rows=10)

        # basic management
        col = row.column(align=True)
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, icon='ADD',
                     text='').operation = 'ADD'

        if context.collection is not None:
            col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                         text='', icon='LAYER_ACTIVE').operation = 'ADD_ACTIVE'

        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_LEFT', text='').operation = 'ADD_ACTIVE_OBJECT'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='DUPLICATE', text='').operation = 'DUPLICATE'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='REMOVE', text='').operation = 'REMOVE_ACTIVE'

        # reordering
        col.separator()

        row = col.row(align=True)
        row.enabled = scene.engine_export_active_export_collection_index > 0
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_UP', text='').operation = 'MOVE_UP'

        row = col.row(align=True)
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, icon='SORTALPHA',
                     text='').operation = 'SORT'

        row = col.row(align=True)
        row.enabled = scene.engine_export_active_export_collection_index < (
            len(scene.engine_export_collections) - 1)
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_DOWN', text='').operation = 'MOVE_DOWN'

        col.separator()

        # weirder stuff for handling legacy files
        col.separator()

        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, text='',
                     icon='RESTRICT_RENDER_OFF').operation = 'RENDER'

        if len(active_collections) > 0 and active_collections[scene.engine_export_active_export_collection_index] is not None:

            collection = active_collections[scene.engine_export_active_export_collection_index]

            if collection.collection is not None:

                col = layout.column()
                col.scale_y = 1.5

                op = col.operator(ExportCollections.bl_idname,
                                  text=F'Export {collection.collection.name}',
                                  icon='GROUP')
                op.export_mode = 'ACTIVE'
                op.export_target = 'ALL'

                # isolated exports
                row = col.row(align=True)

                op = row.operator(ExportCollections.bl_idname,
                                  text='Mesh Only', icon='MESH_DATA')
                op.export_mode = 'ACTIVE'
                op.export_target = 'MESH'

                op = row.operator(ExportCollections.bl_idname,
                                  text='Animation Only', icon='ANIM')
                op.export_mode = 'ACTIVE'
                op.export_target = 'ANIM'

        # Collection Settings

        if len(active_collections) > 0 and len(active_collections) > scene.engine_export_active_export_collection_index:

            collection = active_collections[scene.engine_export_active_export_collection_index]

            draw_collection(self, context, collection)

        else:
            box = layout.box()
            box.label(text='No collections, add some', icon='ERROR')

        # get export counts
        num = 0
        exported_collections = []

        for collection in active_collections:
            if collection is not None and collection.do_export and collection.collection is not None:
                collect_collections(collection.collection,
                                    exported_collections)
                num += 1

        # layout
        options_panel = layout.panel_prop(
            context.scene, 'engine_export_expand_export_details')
        options_panel[0].label(text='Export Option')

        if options_panel[1] is not None:

            box = options_panel[1].box()

            col = box.column(align=True)

            col.prop(scene, 'engine_export_target', text='Engine')

            if scene.engine_export_target == 'DEFAULT':
                target = EngineExportAddonPreferences.get_instance(
                    context).global_export_target
                col.label(
                    text=F'Default Engine: {engine_export_targets[target]}')

            box = layout.box()
            col = box.column(align=True)
            col.prop(scene, 'engine_export_format', text='Format')

            col.prop(scene, 'engine_export_use_naming_convention')
            col.prop(scene, 'engine_export_use_instances')
            if scene.engine_export_format == 'FBX':
                col.prop(scene, 'engine_export_global_scale', text='Scale')
                col.prop(scene, 'apply_scale_options', text='Scale Mode')

            row = box.row()
            row.label(text='Export path')

            row = box.row(align=True)
            # row.operator(GuessExportPath.bl_idname, text=(''), icon='AUTO')
            row.prop(scene, 'engine_export_export_path', text='')
            row.prop(scene, 'engine_export_make_path',
                     text='', icon='NEWFOLDER')

        export_shape_keys_error = []
        viewport_hidden_collections = []

        for collection in exported_collections:

            for o in collection.all_objects:

                if o.type != 'MESH':
                    continue

                if o in export_shape_keys_error:
                    continue

                if o.data.shape_keys is not None:
                    for m in o.modifiers:
                        if m.type != 'ARMATURE':
                            export_shape_keys_error.append(o)

            if collection.hide_viewport:
                viewport_hidden_collections.append(collection)

        has_hidden_collections = len(viewport_hidden_collections) > 0
        if has_hidden_collections:
            box = layout.box()
            # box.alert = has_hidden_collections
            box.label(
                text='Export Disabled, the following collections are hidden in the viewport', icon='RESTRICT_VIEW_ON')

            col = box.column(align=True)
            for c in viewport_hidden_collections:
                col.prop(c, "hide_viewport", text=c.name, emboss=True)

        has_bad_shape_keys = len(export_shape_keys_error) > 0
        if has_bad_shape_keys:

            box = layout.box()
            box.alert = True
            box.label(text='Shapekeys and non-armature modifiers')

            col = box.column(align=True)
            for c in export_shape_keys_error:
                col.label(text=c.name, icon='SHAPEKEY_DATA')

            box.label(text='EXPECT WEIRDNESS')

        col = layout.column()
        col.scale_y = 2
        col.enabled = num > 0 and len(viewport_hidden_collections) == 0
        col.alert = has_hidden_collections

        plural = 'Collection' if num == 1 else 'Collections'

        op = col.operator(ExportCollections.bl_idname,
                          text=F'Export {num} {plural} to {scene.engine_export_format}',
                          icon='GROUP')
        op.export_mode = 'ENABLED'
        op.export_target = 'ALL'

        # isolated exports
        row = col.row(align=True)
        op = row.operator(ExportCollections.bl_idname,
                          text='Meshes Only',
                          icon='MESH_DATA')
        op.export_mode = 'ENABLED'
        op.export_target = 'MESH'

        op = row.operator(ExportCollections.bl_idname,
                          text='Animations Only',
                          icon='ANIM')
        op.export_mode = 'ENABLED'
        op.export_target = 'ANIM'


class ENGINEEXPORTOBJECT_PT_Properties(bpy.types.Panel):
    bl_label = 'Engine Export Properties'
    bl_id = 'ENGINEEXPORTOBJECT_PT_Properties'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'object'

    def draw(self, context):

        layout = self.layout
        obj = context.active_object

        layout.prop(obj, 'engine_export_export')
        layout.prop(obj, 'engine_export_use_rename')
        layout.prop(obj, 'engine_export_explicit_rename')
