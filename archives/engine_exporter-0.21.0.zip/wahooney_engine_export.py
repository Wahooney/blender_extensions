# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
import time
from bpy.app.handlers import persistent
from mathutils import Vector, Matrix, Euler


from .wahooney_engine_export_functions import (pure_curve, fix_path)
from .wahooney_engine_export_collection_drawer import (draw_collection)
from . import wahooney_engine_export_rename


if "bpy" in locals():
    import importlib
    from . import wahooney_engine_export_uv_order
    importlib.reload(wahooney_engine_export_functions)
    importlib.reload(wahooney_engine_export_uv_order)
    importlib.reload(wahooney_engine_export_collection_manager)

else:
    import bpy
    from . import wahooney_engine_export_functions
    from . import wahooney_engine_export_collection_manager
    from . import wahooney_engine_export_uv_order

exportable_types = {'MESH', 'EMPTY'}

manager = wahooney_engine_export_collection_manager
uv_order = wahooney_engine_export_uv_order


def is_exportable(collection, obj):
    return obj.type in exportable_types and wahooney_engine_export_functions.is_exportable(collection, obj)


def should_collapse_objects(export_data):
    return export_data.export_type in {'COLLAPSED', 'COLLAPSED_APPLY_MODIFIERS'}


def should_collapse_modifiers(export_data):
    return export_data.export_type in {'COLLECTION_APPLY_MODIFIERS', 'COLLAPSED_APPLY_MODIFIERS'}


def export_data_is_active(operator, export_data):
    if export_data.collection is None:
        return False

    return operator.export_mode != 'ENABLED' or export_data.do_export


def get_export_progress_steps(operator, active_exports):
    total = 1

    for export_data in active_exports:
        if not export_data_is_active(operator, export_data):
            continue

        total += 1  # collection setup
        total += sum(
            1 for ob in export_data.collection.all_objects
            if is_exportable(export_data, ob))

        if operator.export_target != 'ANIM':
            total += 1

        if export_data.animation and operator.export_target != 'MESH':
            total += len(export_data.animation_actions)

    return max(total, 1)


class ExportProgress:
    def __init__(self, context, operator, total_steps):
        return
        self.context = context
        self.operator = operator
        self.total_steps = max(total_steps, 1)
        self.current_step = 0
        self.closed = False

    def begin(self, message):
        return
        self._call_window_manager('progress_begin', 0, self.total_steps)
        self.message(message, report=True)

    def message(self, message, report=False):
        return
        label = F"Engine Export: {message}"
        self._set_status_text(label)

        if report:
            self.operator.report({'INFO'}, label)

        print(label)

    def step(self, message, report=False):
        return
        self.current_step = min(self.current_step + 1, self.total_steps)
        self._call_window_manager('progress_update', self.current_step)
        self.message(
            F"{self.current_step}/{self.total_steps} - {message}",
            report=report)

    def complete(self, message):
        return
        self.current_step = self.total_steps
        self._call_window_manager('progress_update', self.total_steps)
        self.message(message, report=True)
        self.close()

    def close(self):
        return
        if self.closed:
            return

        self._call_window_manager('progress_end')
        self._set_status_text(None)
        self.closed = True

    def _call_window_manager(self, function_name, *args):
        return
        window_manager = getattr(self.context, 'window_manager', None)

        if window_manager is None:
            return

        try:
            getattr(window_manager, function_name)(*args)
        except Exception:
            pass

    def _set_status_text(self, message):
        return
        workspace = getattr(self.context, 'workspace', None)

        if workspace is None or not hasattr(workspace, 'status_text_set'):
            return

        try:
            workspace.status_text_set(message)
        except Exception:
            pass


# General functions ############################################################

def find_all_view_layer_collections(scene):
    # collections = []
    # if (len(scene.view_layers) > 0):
    #    layer_collection = scene.view_layers[0].layer_collection
    #    return findAllChildLayers(layer_collection, collections)
    # return collections
    # return bpy.data.collections
    return scene.engine_export_collections


def find_layer_collections(layer, results):

    if layer not in results:
        results.append(layer)

    for c in layer.children:
        find_layer_collections(c, results)


def rna_key(value):
    if value is not None and hasattr(value, "as_pointer"):
        return value.as_pointer()

    return id(value)


def get_export_collections_by_collection(scene):
    lookup = {}

    for export_data in scene.engine_export_collections:
        if export_data.collection is None:
            continue

        lookup.setdefault(rna_key(export_data.collection), []).append(export_data)

    return lookup


def add_unique_export_collections(active_exports, export_collections, seen_exports, skip_utility=True):
    for export_collection in export_collections:
        if skip_utility and export_collection.is_utility_collection:
            continue

        export_id = rna_key(export_collection)
        if export_id in seen_exports:
            continue

        seen_exports.add(export_id)
        active_exports.append(export_collection)


def collect_collections(collection, collections):

    if not collection in collections:
        collections.append(collection)

    for c in collection.children:
        collect_collections(c, collections)


engine_export_targets = {'UNREAL': 'Unreal Engine',
                         'UNITY': 'Unity Engine'}


def get_export_path(self, context, sub_path=''):
    scene = context.scene

    export_path = ''

    if scene.engine_export_export_path == '':
        filepath = context.blend_data.filepath
        filename = filepath[filepath.rfind(
            os.path.sep)+1:filepath.rfind('.blend')]
    else:
        export_path = scene.engine_export_export_path

    if not export_path.endswith(os.path.sep):
        export_path += os.path.sep

    if export_path != '':
        export_path = export_path[:export_path.rfind(os.path.sep)]
        export_path = fix_path(export_path)

    export_path += os.path.sep + sub_path

    if not os.path.exists(export_path):
        if context.scene.engine_export_make_path:
            os.makedirs(export_path)
        else:
            self.report({'WARNING'}, F"Path '{export_path}' doesn't exist")

    return export_path


def is_hierarchy_in_list(obj, obj_list, obj_ids=None):

    if obj_ids is None:
        obj_ids = {rna_key(ob) for ob in obj_list}

    parent = obj.parent

    while parent is not None:
        if rna_key(parent) in obj_ids:
            return True

        parent = parent.parent

    return False


def has_child_of_constraint_to(obj, target_ids):
    for con in obj.constraints:
        if con.type == 'CHILD_OF' and con.target is not None and rna_key(con.target) in target_ids:
            return True

    return False


def get_export_offsets(export_data, collection):
    center_offset = Vector((0, 0, 0))
    euler_offset = Euler((0, 0, 0))

    if export_data.offset_method == 'COLLECTION' or export_data.head is None:
        center_offset = collection.instance_offset

    elif export_data.offset_method == 'OBJECT' and export_data.offset_target_object is not None:
        center_offset = export_data.offset_target_object.location.copy()

        if export_data.use_rotation_offset:
            euler_offset = export_data.offset_target_object.rotation_euler.copy()

    elif export_data.head is not None:
        if export_data.offset_method == 'PARENT':

            if export_data.head.parent is not None:
                center_offset = export_data.head.parent.location.copy()

                if export_data.use_rotation_offset:
                    euler_offset = export_data.head.parent.rotation_euler.copy()
            else:
                center_offset = export_data.head.location.copy()

                if export_data.use_rotation_offset:
                    euler_offset = export_data.head.rotation_euler.copy()

        elif export_data.offset_method == 'HEAD':
            center_offset = export_data.head.location.copy()

            if export_data.use_rotation_offset:
                euler_offset = export_data.head.rotation_euler.copy()

    return center_offset, euler_offset


# Rename functions #############################################################

def store_real_name(ob):
    name = ob.name

    if 'real_name' in ob:
        name = ob['real_name']
    else:
        ob['real_name'] = ob.name
        ob.name = name + "_JUST_CHANGING_THIS_NAME_TEMPORARILY_BE_RIGHT_BACK"
        # print(F"Stored {ob['real_name']} : {ob.name}")

    return name


def restore_real_name(ob):
    if 'real_name' in ob:
        ob.name = ob['real_name']
        # print(F"Restored {ob['real_name']}")
        del ob['real_name']


# Export functions #############################################################

def cleanup_temporary_export_object(obj):
    data = obj.data if obj.type == 'MESH' else None

    for col in obj.users_collection[:]:
        col.objects.unlink(obj)

    if obj.name in bpy.data.objects:
        bpy.data.objects.remove(obj)

    if data is not None and data.users == 0:
        bpy.data.meshes.remove(data)


def remove_mesh_if_unused(mesh):
    if mesh is None:
        return

    try:
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    except ReferenceError:
        pass


def use_real_export_name(source, export_copy):
    export_copy.name = store_real_name(source)

    if source.type == 'MESH' and export_copy.type == 'MESH':
        export_copy.data.name = store_real_name(source.data)


def forget_cleanup_object_state(obj, export_objects, store_actions, store_tweak_mode, cleanup_nodes):
    if obj in export_objects:
        export_objects.remove(obj)

    store_actions.pop(obj, None)
    store_tweak_mode.pop(obj, None)
    cleanup_nodes.pop(obj, None)


def restore_animation_state(store_actions, store_tweak_mode):
    for ob, action in store_actions.items():
        try:
            if ob.name in bpy.data.objects and ob.animation_data is not None:
                ob.animation_data.action = action
        except ReferenceError:
            pass

    for ob, mode in store_tweak_mode.items():
        try:
            if ob.name in bpy.data.objects and ob.animation_data is not None:
                ob.animation_data.use_tweak_mode = mode
        except ReferenceError:
            pass


def get_evaluated_depsgraph(context_in):
    return context_in.evaluated_depsgraph_get()


def get_evaluated_mesh_data(context, obj, mesh_name=None, deps_graph=None):
    if deps_graph is None:
        deps_graph = get_evaluated_depsgraph(context)

    eval_obj = obj.evaluated_get(deps_graph)
    eval_mesh = None

    try:
        eval_mesh = eval_obj.to_mesh()

        if eval_mesh is None:
            return None

        new_data = eval_mesh.copy()
        new_data.name = mesh_name or obj.name
        return new_data
    finally:
        if eval_mesh is not None:
            eval_obj.to_mesh_clear()


def snapshot_mesh_without_armature_modifiers(context, obj, mesh_name=None,
                                             deps_graph=None):
    armature_states = []

    if deps_graph is None:
        for modifier in obj.modifiers[:]:
            if modifier.type == 'ARMATURE':
                armature_states.append((modifier, modifier.show_viewport))
                modifier.show_viewport = False

    try:
        return get_evaluated_mesh_data(context, obj, mesh_name, deps_graph)
    finally:
        for modifier, show_viewport in armature_states:
            modifier.show_viewport = show_viewport


def remove_non_armature_modifiers(obj):
    for modifier in obj.modifiers[:]:
        if modifier.type != 'ARMATURE':
            obj.modifiers.remove(modifier)


def needs_evaluated_mesh_snapshot(export_data, objects):
    if should_collapse_modifiers(export_data):
        return True

    for obj in objects:
        if obj.type != 'CURVE':
            continue

        if not is_exportable(export_data, obj) or pure_curve(obj):
            continue

        if obj.data.extrude > 0 or obj.data.bevel_depth > 0 or obj.data.bevel_object is not None:
            return True

    return False


def mute_armatures_for_modifier_snapshots(objects):
    armature_states = []
    armature_lookup = {}

    for obj in objects:
        if obj is None or obj.type != 'MESH':
            continue

        for modifier in obj.modifiers[:]:
            if modifier.type != 'ARMATURE':
                continue

            armature_lookup.setdefault(
                rna_key(obj), {})[modifier.name] = modifier.show_viewport
            armature_states.append((modifier, modifier.show_viewport))
            modifier.show_viewport = False

    return armature_states, armature_lookup


def restore_snapshot_armatures(armature_states):
    for modifier, show_viewport in armature_states:
        try:
            modifier.show_viewport = show_viewport
        except ReferenceError:
            pass


def restore_copied_armature_visibility(source, export_copy, armature_lookup):
    source_lookup = armature_lookup.get(rna_key(source), {})

    for modifier in export_copy.modifiers[:]:
        if modifier.type != 'ARMATURE':
            continue

        if modifier.name in source_lookup:
            modifier.show_viewport = source_lookup[modifier.name]


def copy_custom_properties(source, target):
    for key in source.keys():
        try:
            target[key] = source[key]
        except Exception:
            pass


def duplicate_as_evaluated_mesh_object(context, source, name=None,
                                       deps_graph=None):
    new_data = get_evaluated_mesh_data(
        context, source, name or source.name, deps_graph)

    if new_data is None:
        return None

    obj_copy = bpy.data.objects.new(name or source.name, new_data)
    obj_copy.matrix_world = source.matrix_world.copy()
    obj_copy.parent = source.parent
    obj_copy.matrix_parent_inverse = source.matrix_parent_inverse.copy()
    obj_copy.hide_viewport = source.hide_viewport
    obj_copy.hide_render = source.hide_render
    copy_custom_properties(source, obj_copy)

    context.scene.collection.objects.link(obj_copy)
    obj_copy.matrix_world = source.matrix_world.copy()
    return obj_copy


def duplicate_as_modifier_snapshot_object(context, source, name=None,
                                          deps_graph=None,
                                          armature_lookup=None):
    new_data = snapshot_mesh_without_armature_modifiers(
        context, source, name or source.name, deps_graph)

    if new_data is None:
        return None

    obj_copy = source.copy()
    obj_copy.data = new_data
    remove_non_armature_modifiers(obj_copy)
    restore_copied_armature_visibility(source, obj_copy, armature_lookup or {})
    context.scene.collection.objects.link(obj_copy)
    obj_copy.matrix_world = source.matrix_world.copy()
    return obj_copy


def duplicate_export_object_for_modifier_collapse(context, export_data, obj,
                                                  deps_graph=None,
                                                  armature_lookup=None):
    scene = context.scene

    if obj.type == 'CURVE':
        if pure_curve(obj):
            return None

        obj_copy = duplicate_as_evaluated_mesh_object(
            context, obj, deps_graph=deps_graph)

        if obj_copy is None:
            return None

        use_real_export_name(obj, obj_copy)
        uv_order.apply_export_uv_order(scene, export_data, obj_copy, obj)
        return obj_copy

    if obj.type != 'MESH':
        obj_copy = obj.copy()
        scene.collection.objects.link(obj_copy)
        use_real_export_name(obj, obj_copy)
        return obj_copy

    obj_copy = duplicate_as_modifier_snapshot_object(
        context, obj, deps_graph=deps_graph,
        armature_lookup=armature_lookup)

    if obj_copy is None:
        return None

    use_real_export_name(obj, obj_copy)

    uv_order.apply_export_uv_order(scene, export_data, obj_copy, obj)

    obj_copy.select_set(False)
    return obj_copy


def collapse_collection(context, group_name, collapse_modifiers=True,
                        progress=None, deps_graph=None,
                        armature_lookup=None):

    active_collections = find_all_view_layer_collections(context.scene)
    export_collection = active_collections[group_name]
    collection = export_collection.collection

    scene = context.scene

    export = []
    cleanup = []

    for obj in bpy.data.objects:
        obj.select_set(False)

    meshes = []
    collapse_objects = []
    original_collapsed_objects = []
    objects = [ob for ob in collection.all_objects]

    head_object = None

    # don't collapse if the head is empty, a collision hull, or a non-meshable curve (should probably have a warning in the UI)
    if export_collection.head is None or export_collection.head.name.startswith('UCX') or pure_curve(export_collection.head):
        return []

    for obj in objects:

        obj_copy = None

        # don't collapse objects that aren't flagged to export, they may be part of a rig, a boolean operation, node tree, etc.
        if not is_exportable(export_collection, obj):
            continue

        if progress is not None:
            progress.step(F"Preparing {obj.name} for {group_name}")

        if obj.type in ['CURVE']:

            # convert curves(and other convertable objects) to meshes, skips non-mesh convertable objects
            if pure_curve(obj):
                continue

            obj_copy = duplicate_as_evaluated_mesh_object(
                context, obj, deps_graph=deps_graph)

            if obj_copy is None:
                continue

        elif obj.type == 'MESH':

            # don't collapse collision hulls
            if obj.name.startswith("UCX"):
                export.append(obj)
                continue

            if collapse_modifiers:
                obj_copy = duplicate_as_modifier_snapshot_object(
                    context, obj, deps_graph=deps_graph,
                    armature_lookup=armature_lookup)

                if obj_copy is None:
                    continue
            else:
                obj_copy = obj.copy()

                # unlink from user collections
                while len(obj_copy.users_collection) > 0:
                    obj_copy.users_collection[0].objects.unlink(obj_copy)

                # link to scene
                scene.collection.objects.link(obj_copy)

        else:
            # we probably have an object that's not a mesh or curve, so just skip it
            export.append(obj)
            print(F"Not collapsing {obj.type}:{obj.name} ({obj_copy})")
            continue

        if obj is export_collection.head and obj_copy.parent is not None and obj_copy.parent.type == 'MESH':
            obj_copy.parent = None

        # make multi-user meshes unique
        if obj_copy.data.users != 1:
            obj_copy.data = obj_copy.data.copy()

        if obj is export_collection.head:
            # the current object is the head of the collection, so it's copy
            # will be the head of the collapsed collection
            head_object = obj_copy
        else:
            # into the soup
            meshes.append(obj_copy.data)

        collapse_objects.append(obj_copy)
        original_collapsed_objects.append(obj)
        obj_copy.select_set(False)

        uv_order.apply_export_uv_order(scene, export_collection, obj_copy, obj)

    # TODO: probably unnecessary context.view_layer.update()

    # somehow, despite our checks we still have no head object, so just skip it
    # should probably have a better early check for this
    if head_object is None:

        for obj in collapse_objects:
            try:
                cleanup_temporary_export_object(obj)
            except:
                print(F"Issue found exporting: {group_name}")

        print(F"{group_name} has no head, collapse skipped.")

        return []

    # account for armatured, collapsed meshes
    armature_obj = None
    armature_mods = []

    if collapse_modifiers:
        for obj in collapse_objects:

            # select the objects that we will collapse
            obj.select_set(True)

            for mod in obj.modifiers:
                if mod.type == "ARMATURE":
                    # find the head object's armature modifier and target armature
                    if (obj == head_object and mod.show_viewport) or mod.show_render:
                        armature_obj = mod.object

                    # turn other armatures off
                    mod.show_viewport = False
                    mod.show_render = False

                    armature_mods.append(mod)
    else:
        for obj in collapse_objects:
            obj.select_set(True)

    # if we don't have an armature object but we have some armature mods, do some guess work
    if armature_obj is None and len(armature_mods) > 0:
        for mod in armature_mods:
            if mod.object is not None:
                armature_obj = mod.object
                break

    # just check if there are mismatched armature objects
    for mod in armature_mods:
        if mod.object != armature_obj:
            print("All armatures in the collection don't share the same armature object.")

    # sort the naming out
    restore_real_name(head_object)
    store_real_name(export_collection.head)

    head_object.name = group_name
    context.view_layer.objects.active = head_object

    bpy.ops.object.join()
    uv_order.apply_export_uv_order(scene, export_collection, head_object, export_collection.head)

    # pop that armature back on there
    if armature_obj is not None:
        arm = head_object.modifiers.new('Armature', 'ARMATURE')
        arm.object = armature_obj

    for mesh in meshes:
        remove_mesh_if_unused(mesh)

    export.insert(0, head_object)
    cleanup.append(head_object)
    # context.view_layer.active_layer_collection = store_collection

    return [export, cleanup, original_collapsed_objects]


def do_export_collections(self, context):

    from . import EngineExportAddonPreferences

    scene = context.scene
    active = context.view_layer.objects.active

    # store scene state
    store_selection = []
    store_selectable = []
    store_collection_state = {}

    use_instance = scene.engine_export_use_instances

    active_exports = []
    export_collections_by_collection = get_export_collections_by_collection(scene)

    # store selection and selection restriction
    for ob in scene.objects:
        if ob.select_get():
            store_selection.append(ob)

        ob.select_set(False)
        if ob.hide_select:
            ob.hide_select = False
            store_selectable.append(ob)

    # accumulate the collections we want to export based on the export mode
    if self.export_mode == 'ACTIVE':

        active_exports = [
            scene.engine_export_collections[scene.engine_export_active_export_collection_index]]

    elif self.export_mode == 'ACTIVE_COLLECTION':

        active_exports = list(export_collections_by_collection.get(rna_key(context.collection), ()))

    elif self.export_mode == 'SELECTION':

        # find all the collections that contain selected objects, make sure we don't have duplicates

        seen_exports = set()

        print(F"{len(store_selection)} objects selected")

        for sel in store_selection:

            print(F"Checking {sel.name} ... ")

            for blender_collection in sel.users_collection:

                print(F"Matching {blender_collection.name} ...")
                add_unique_export_collections(
                    active_exports,
                    export_collections_by_collection.get(rna_key(blender_collection), ()),
                    seen_exports)

    elif self.export_mode == 'EXPORT_GROUP':

        # find all collections in export groups that are flagged to export, make sure we don't have duplicates

        if self.properties.export_group_index not in scene.engine_export_export_groups:
            return

        group = scene.engine_export_export_groups[self.properties.export_group_index]

        collection_names = set()

        for col in group.export_collections:

            if col.export_collection is None:

                print(
                    F"Export collection '{col.name}' has no associated collection: skipping...")
                continue

            print(col.name)

            for c in col.export_collection.children_recursive:
                print(c.name)

            root_collections = [
                c for c in col.export_collection.children_recursive]
            root_collections.append(col.export_collection)

            for c in root_collections:
                collection_names.add(c.name)

        active_exports = [
            col for col in scene.engine_export_collections if col.collection is not None and col.collection.name in collection_names and not col.is_utility_collection]

    else:
        layer_collections = find_all_view_layer_collections(scene)
        active_exports = [
            col for col in layer_collections if col.do_export and not col.is_utility_collection]

    for export_data in active_exports:

        collection = export_data.collection

        if collection is None:
            print(F"Collection {export_data.name} has no associated collection")
            continue

        if collection.engine_export_head is not None and export_data.head is not None:

            if collection.engine_export_head.name in collection.all_objects:
                export_data.head = collection.engine_export_head

            collection.engine_export_head = None

        if not export_data.do_export and self.export_mode == 'ENABLED':
            continue

        store_collection_state[collection] = collection.hide_viewport
        collection.hide_viewport = False

    active_export_count = sum(
        1 for export_data in active_exports
        if export_data_is_active(self, export_data))

    progress = ExportProgress(
        context, self, get_export_progress_steps(self, active_exports))
    self._engine_export_progress = progress
    progress.begin(F"Starting {active_export_count} collection export(s)")

    # cycle through collections for export
    for export_data in active_exports:

        if not export_data.do_export and self.export_mode == 'ENABLED':
            continue

        collection = export_data.collection

        if collection is None:
            print(F"Collection {export_data.name} has no associated collection")
            continue

        collection_export_start_time = time.monotonic()

        if export_data.name_method == 'AUTO':
            export_data.name = collection.name

        # calculate the new center offset, all collections are exported with their desired center at world origin
        center_offset, euler_offset = get_export_offsets(export_data, collection)

        restore_matrix = Matrix.LocRotScale(
            center_offset, euler_offset, Vector((1, 1, 1)))
        zero_matrix = restore_matrix.inverted()

        # state storage

        cleanup_objects = []
        export_objects = []
        support_objects = []
        store_solo_tracks = []
        store_mute_tracks = []
        store_nla_tracks = []
        store_rest_poses = []
        store_poses = []
        store_actions = {}
        store_tweak_mode = {}
        frame_store = (scene.frame_start, scene.frame_end)
        store_collection_visibility = {}
        store_object_visibility = {}
        layer_collections = []
        cleanup_nodes = {}

        ###############################################################################################
        # collect restore data (DON'T MODIFY OBJECTS OR COLLECTIONS IN THIS PHASE)

        find_layer_collections(bpy.context.view_layer.layer_collection, layer_collections)

        # attempt to unhide all collections and objects before export
        for layer_collection in layer_collections:
            store_collection_visibility[layer_collection] = layer_collection.hide_viewport
            layer_collection.hide_viewport = False

        for obj in bpy.data.objects:
            store_object_visibility[obj] = obj.hide_viewport

        # don't export objects that may still be hidden
        objects = [
            ob for ob in collection.all_objects if not ob.hide_viewport and ob.visible_get()]

        collection_name = export_data.name if export_data.name != '' else collection.name

        progress.step(F"Preparing {collection_name}", report=True)

        if len(objects) == 0:
            print(F'== Not exporting {collection.name}, no visible objects to export.')
            continue

        print(F'== Exporting {collection_name} {len(objects)} objects in {collection.name}')

        ob = None

        # list of objects that are not flagged to export, but are part of the collection,
        # we always assume the objects exist for a reason
        support_objects = [ob for ob in collection.all_objects if not is_exportable(export_data, ob)]

        print(F"Export type: {export_data.export_type}")

        snapshot_deps_graph = None
        snapshot_armature_states = []
        snapshot_armature_lookup = {}
        snapshot_source_objects = objects

        if should_collapse_objects(export_data):
            snapshot_source_objects = collection.all_objects

        if needs_evaluated_mesh_snapshot(export_data, snapshot_source_objects):
            if should_collapse_modifiers(export_data):
                snapshot_armature_states, snapshot_armature_lookup = (
                    mute_armatures_for_modifier_snapshots(snapshot_source_objects))

            snapshot_deps_graph = get_evaluated_depsgraph(context)

        if should_collapse_objects(export_data):

            print(F"== Collapsing collection {export_data.collection.name}")

            # handle collapsed objects

            if export_data.head is None:
                print(F"No head detected, skipping {collection_name}")
                restore_snapshot_armatures(snapshot_armature_states)
                continue

            ob = collapse_collection(
                context,
                collection_name,
                should_collapse_modifiers(export_data),
                progress=progress,
                deps_graph=snapshot_deps_graph,
                armature_lookup=snapshot_armature_lookup)

            if not ob:
                print(F"No objects to collapse, skipping {collection_name}")
                restore_snapshot_armatures(snapshot_armature_states)
                continue

            if len(ob) > 0:
                export_objects.extend(ob[0])
            if len(ob) > 1:
                cleanup_objects.extend(ob[1])
            if len(ob) > 2:
                support_objects.extend(ob[2])

        else:

            # prepare special objects and animation state for export
            for ob in objects:

                if is_exportable(export_data, ob):
                    progress.step(F"Preparing {ob.name} for {collection_name}")

                    # convert non-mesh -> mesh(curve)
                    if should_collapse_modifiers(export_data):
                        ob = duplicate_export_object_for_modifier_collapse(
                            context, export_data, ob,
                            deps_graph=snapshot_deps_graph,
                            armature_lookup=snapshot_armature_lookup)

                        if ob is not None:
                            cleanup_objects.append(ob)

                    elif ob.type == 'CURVE':
                        if ((ob.data.extrude > 0) or (ob.data.bevel_depth > 0) or (ob.data.bevel_object is not None)):
                            ob = duplicate_as_evaluated_mesh_object(
                                context, ob, deps_graph=snapshot_deps_graph)

                            if ob is not None:
                                cleanup_objects.append(ob)
                        else:
                            ob = None

                    if ob is not None:

                        export_objects.append(ob)
                        ob.hide_viewport = False

                        # set all tracks off solo, store tracks that are solo
                        if ob.animation_data is not None:
                            for nla in ob.animation_data.nla_tracks:

                                if nla.is_solo:
                                    store_solo_tracks.append(nla)

                                if nla.mute:
                                    store_mute_tracks.append(nla)

                                store_nla_tracks.append(nla)

                                nla.is_solo = False

        restore_snapshot_armatures(snapshot_armature_states)

        for sel in context.selected_objects:
            sel.select_set(False)

        all_objects = export_objects + support_objects
        all_object_ids = {rna_key(ob) for ob in all_objects}
        transform_objects = [
            ob for ob in all_objects if not is_hierarchy_in_list(ob, all_objects, all_object_ids)]
        transform_object_ids = {rna_key(ob) for ob in transform_objects}

        # print(transform_objects)

        # move non-exported, but non-grouped, objects, because they are most likely part of a rig
        for ob in support_objects:

            if ob is None:
                continue

            # transform object to world center
            if rna_key(ob) in transform_object_ids and not has_child_of_constraint_to(ob, transform_object_ids):
                # print('== Originating', ob.name)
                ob.matrix_world = zero_matrix @ ob.matrix_world

        for ob in export_objects:

            if ob is None:
                continue

            # store actions
            if ob.animation_data is not None and ob.animation_data.action is not None:
                store_actions[ob] = ob.animation_data.action
                store_tweak_mode[ob] = ob.animation_data.use_tweak_mode

                ob.animation_data.use_tweak_mode = False
                ob.animation_data.action = None

            has_split_animation = False

            # set up single file animation data
            if ob.animation_data is not None:
                for nla in ob.animation_data.nla_tracks:
                    if nla.name in export_data.split_nla_tracks:
                        split = export_data.split_nla_tracks[nla.name]
                        nla.mute = split.use_split or not split.do_export

                        has_split_animation = has_split_animation or (
                            split.use_split and split.do_export)

                    else:  # this should never really happen, so hide it away
                        nla.mute = True

            # make sure armatures aren't in the rest position, animation won't export correctly
            if ob.type == 'ARMATURE':

                if ob.data.pose_position == 'REST':
                    store_rest_poses.append(ob.data)
                    print(F"== REST {ob.name}")
                else:
                    store_poses.append(ob.data)
                    print(F"== POSE {ob.name}")

                if has_split_animation:
                    # we want to export the main asset in its rest pose
                    ob.data.pose_position = 'REST'
                else:
                    ob.data.pose_position = 'POSE'
            elif ob.type == 'MESH':

                modifiers = ob.modifiers[:]
                preexport = "___PREEXPORT_NODE_TREE"

                # Remove pre-export node tree modifiers
                for mod in modifiers:
                    if mod.name.startswith(preexport):
                        ob.modifiers.remove(mod)
                        print("Cleaning up uncaught pre-export node tree")

                if export_data.is_utility_collection and export_data.pre_export_node_graph is not None:
                    # we want to export the main asset in its rest pose
                    node_mod = ob.modifiers.new(preexport, 'NODES')
                    node_mod.node_group = export_data.pre_export_node_graph
                    node_mod.use_pin_to_last = True

                    # move it to the end to override all other mods
                    idx = ob.modifiers.find(node_mod.name)
                    ob.modifiers.move(idx, len(ob.modifiers) - 1)

                    cleanup_nodes[ob] = node_mod
                    print(F"Adding pre-export node tree {export_data.pre_export_node_graph.name} to {ob.name}")

            # feedback
            if ob.animation_data is not None:
                print(F"======= {ob.name} '{ob.animation_data.action}'")

                if ob.type == 'ARMATURE':
                    print(F"========= {ob.data.pose_position}")

                for nla in ob.animation_data.nla_tracks:
                    if nla.name in export_data.split_nla_tracks:
                        print(
                            f"========= {nla.name} Active: {not nla.mute}")

            # don't export if we're null or not flagged to export (may be redundant)
            if not is_exportable(export_data, ob):
                continue

            ob.select_set(True)

            # do weird scale thing to sockets for unreal
            if ob.name.startswith("SOCKET_"):
                ob.scale /= 100 * scene.unit_settings.scale_length

            # actuate renaming rules
            if ob.engine_export_use_rename:

                # make sure we're not storing the new value, could cause renaming issues
                obj_name = store_real_name(ob)

                if not ob.engine_export_explicit_rename:
                    obj_name = wahooney_engine_export_rename.rename_all(
                        obj_name)
                else:
                    obj_name = ob.engine_export_explicit_rename

                if obj_name != ob.name and obj_name in bpy.data.objects:
                    store_real_name(bpy.data.objects[obj_name])

                ob.name = obj_name

                if ob.data is not None:
                    ob.data.name = wahooney_engine_export_rename.rename_all(
                        store_real_name(ob.data))

            # disable blend shapes if needed
            if export_data.disable_blend_shapes and ob.type == 'MESH':
                mesh = ob.data

                shape_keys = mesh.shape_keys

                if shape_keys is not None:
                    for key in shape_keys.key_blocks:
                        key.value = 0.0

            # transform object to world center
            if rna_key(ob) in transform_object_ids and not has_child_of_constraint_to(ob, transform_object_ids):
                # print('== Originating', ob.name, zero_matrix)
                ob.matrix_world = zero_matrix @ ob.matrix_world

            # convert instances to empties if we don't want to export instances
            if not (use_instance or export_data.use_instances):
                ob['instance'] = ob.instance_type
                ob.instance_type = 'NONE'

        if len(export_objects) > 0:

            for sel in context.selected_objects:
                print(F"== Preparing to export == {sel.name}")

            context.view_layer.objects.active = export_objects[0]
            frame_store = (scene.frame_start, scene.frame_end)

            if export_data.export_type in {'COLLECTION', 'COLLECTION_APPLY_MODIFIERS', 'COLLAPSED', 'COLLAPSED_APPLY_MODIFIERS'}:

                export_path = get_export_path(self,
                                              context, wahooney_engine_export_functions.get_collection_exportpath(export_data))

                filename = wahooney_engine_export_functions.add_subpath_to_filename(
                    export_data, collection_name)

                print(F"Exporting {len(export_objects)} objects...")

                if self.export_target != 'ANIM':

                    # export main file #########################################

                    progress.message(
                        F"Exporting {filename} ({len(export_objects)} object(s))",
                        report=True)
                    do_export(context, scene, export_path,
                              filename, export_data)
                    export_duration = time.monotonic() - collection_export_start_time
                    progress.step(
                        F"Exported {filename} ({export_duration:.1f}s)",
                        report=True)

                # export split animations ######################################

                if export_data.animation and self.export_target != 'MESH':

                    animated_objects = [ob for ob in all_objects if ob.engine_export_is_animated and ob.animation_data is not None]
                    static_action = export_data.animation_static_action

                    store_frame_start = scene.frame_start
                    store_frame_end = scene.frame_end

                    # deselect all objects
                    for ob in context.scene.objects:
                        ob.select_set(False)

                    # select objects to include in animation files
                    for ob in export_objects:
                        ob.select_set(ob.engine_export_include_animation)

                    for action_data in export_data.animation_actions:

                        action = action_data.action
                        animation_export_start_time = time.monotonic()

                        start = int(action.frame_start)
                        end = int(action.frame_end)

                        # store the action object
                        for ob in animated_objects:
                            store_actions[ob] = ob.animation_data.action
                            store_tweak_mode[ob] = ob.animation_data.use_tweak_mode
                            ob.animation_data.use_tweak_mode = False

                        # load in the static action
                        for ob in animated_objects:
                            ob.animation_data.action = static_action

                        # update the scene after setting the static action
                        context.view_layer.update()

                        print(len(animated_objects))

                        # load the real action
                        for ob in animated_objects:
                            ob.animation_data.action = action
                            print(action.name)

                        context.view_layer.update()

                        # Export animation #####################################
                        scene.frame_start = start
                        scene.frame_end = end

                        print(F"== {action.name} == Range {start} {end}")

                        anim_export_path = export_path + export_data.anim_subpath
                        export_filename = action.name

                        if not os.path.exists(anim_export_path):
                            os.makedirs(anim_export_path)

                        progress.message(F"Exporting animation {action.name}", report=True)
                        do_export(context,
                                  scene,
                                  anim_export_path,
                                  export_filename,
                                  export_data,
                                  force_animation=True)
                        export_duration = time.monotonic() - animation_export_start_time
                        progress.step(
                            F"Exported animation {action.name} ({export_duration:.1f}s)",
                            report=True)

                    scene.frame_start = store_frame_start
                    scene.frame_end = store_frame_end

                    # Note: this is part of the old animation system

                    # # select track objects
                    # for ob in export_data.split_nla_tracks_objects:
                    #     if ob is not None and ob.track_object is not None and is_exportable(export_data, ob.track_object):
                    #         ob.track_object.select_set(ob.include_in_split)

                    # static = []

                    # for nla in export_data.split_nla_tracks:
                    #     if nla.is_static:
                    #         static.append(nla.name)

                    # for nla in export_data.split_nla_tracks:

                    #     start = 100000
                    #     end = -100000
                    #     valid_export = False

                    #     # skip unsplit nla tracks
                    #     if not nla.use_split or not nla.do_export:
                    #         continue

                    #     for ob in export_data.split_nla_tracks_objects:
                    #         if ob.track_object.animation_data is None:
                    #             continue

                    #         for track in ob.track_object.animation_data.nla_tracks:

                    #             if track not in store_nla_tracks:
                    #                 store_nla_tracks.append(track)

                    #             track.mute = (track.name not in static) and ((track.name != nla.name) or (
                    #                 not export_data.split_nla_tracks[track.name].use_split))

                    #             # we don't want to consider the range of an action if it's static, it can throw
                    #             # the true range off this was commented out for some reason, needs to be tested
                    #             if not track.mute and track.name not in static:
                    #                 for strip in track.strips:
                    #                     if strip.action is None:
                    #                         continue

                    #                     valid_export = True
                    #                     action = strip.action
                    #                     start = int(min(start, action.frame_start))
                    #                     end = int(max(end, action.frame_end))

                    #     if not valid_export:
                    #         continue

                    #     anim_export_path = export_path + export_data.anim_subpath

                    #     if not os.path.exists(anim_export_path):
                    #         os.makedirs(anim_export_path)

                    #     scene.frame_start = start
                    #     scene.frame_end = end

                    #     print(F"== {nla.name} == Range {start} {end}")

                    #     export_filename = nla.name

                    #     target = scene.engine_export_target
                    #     if target == 'DEFAULT':
                    #         target = EngineExportAddonPreferences.get_instance(
                    #             context).global_export_target

                    #     if target == 'UNITY':
                    #         export_filename = filename + "@" + export_filename

                    #     for ob in export_objects:

                    #         if ob is None:
                    #             continue

                    #         if ob.type == 'ARMATURE':
                    #             ob.data.pose_position = 'POSE'

                    #     if nla.animated_object.animation_data is not None and nla.animated_object.animation_data.action is not None:
                    #         store_actions[nla.animated_object] = nla.animated_object.animation_data.action
                    #         nla.animated_object.animation_data.action = None

                    #         if nla.animated_object.data.pose_position == 'REST':
                    #             store_rest_poses.append(
                    #                 nla.animated_object.data.pose_position)
                    #             nla.animated_object.data.pose_position = 'POSE'

                    #     # Export animation #####################################

                    #     do_export(context, scene, anim_export_path, export_filename,
                    #               export_data, force_animation=True)

        else:

            print(F"== Not exporting {collection_name}, no objects to export.")

        dg = context.evaluated_depsgraph_get()
        dg.update()

        # House cleaning #######################################################
        progress.message(F"Cleaning up {collection_name}")

        # restore scene state
        scene.frame_start = frame_store[0]
        scene.frame_end = frame_store[1]

        # remove cleanup objects
        if len(cleanup_objects):

            for ob in cleanup_objects:

                if (ob is None):
                    continue

                forget_cleanup_object_state(ob, export_objects, store_actions, store_tweak_mode, cleanup_nodes)
                cleanup_temporary_export_object(ob)

        # return objects to previous positions
        for ob in export_objects:

            ob.select_set(False)

            if ob.name.startswith("SOCKET_"):
                ob.scale *= 100 * scene.unit_settings.scale_length

            # restore offsets
            if rna_key(ob) in transform_object_ids and not has_child_of_constraint_to(ob, transform_object_ids):

                ob.matrix_world = restore_matrix @ ob.matrix_world

                if 'instance' in ob:
                    ob.instance_type = ob['instance']
                    del ob['instance']

        for ob in support_objects:

            # restore offsets
            if rna_key(ob) in transform_object_ids and not has_child_of_constraint_to(ob, transform_object_ids):
                ob.matrix_world = restore_matrix @ ob.matrix_world

        # clean up nodes added during export ###################################
        if len(cleanup_nodes):
            print(F"Cleaning up {len(cleanup_nodes)} nodes.")
            for ob, mod in cleanup_nodes.items():
                try:
                    if ob is not None and mod is not None:
                        ob.modifiers.remove(mod)
                except:
                    pass

            cleanup_nodes = {}

        # restore nla tracks state #############################################

        for nla in store_nla_tracks:
            nla.mute = False
            nla.is_solo = False

        for nla in store_mute_tracks:
            nla.mute = True

        for nla in store_solo_tracks:
            nla.is_solo = True

        # restore rig pose state ###############################################

        for rest in store_rest_poses:
            rest.pose_position = 'REST'

        for rest in store_poses:
            rest.pose_position = 'POSE'

        # restore object state #################################################

        for ob in store_selectable:
            ob.hide_select = True

        for ob in bpy.data.objects:
            restore_real_name(ob)

        for me in bpy.data.meshes:
            restore_real_name(me)

        restore_animation_state(store_actions, store_tweak_mode)

        for col, state in store_collection_visibility.items():
            col.hide_viewport = state

        for obj, state in store_object_visibility.items():
            obj.hide_viewport = state

    # restore collection state #################################################

    for (collection, state) in store_collection_state.items():
        collection.hide_viewport = state

    # restore object selection #################################################

    for ob in store_selection:
        ob.select_set(True)

    context.view_layer.objects.active = active

    # fin ######################################################################
    progress.complete("Export complete")
    self._engine_export_progress = None
    print("\n############# Export Complete")


# Perform File Export ##########################################################

def do_export(context, scene, export_path, filename, export_data, force_animation=False):

    from . import EngineExportAddonPreferences

    export_path = os.path.join(os.path.abspath(export_path), '')

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    # Apply naming conventions #################################################

    filename = wahooney_engine_export_functions.add_prefix(
        context, export_data, filename, force_animation)

    if len(bpy.context.selected_objects) == 0:
        print(F"'{export_data.collection.name}' failed to export, no selection.")
        return

    export_format = scene.engine_export_format
    if export_data.export_format != 'PROJECT':
        export_format = export_data.export_format

    file_extention = ''

    if export_format == 'FBX':
        file_extention = '.fbx'
        export_selection_to_FBX(context, scene, export_path,
                                filename + file_extention,
                                export_data, force_animation=force_animation)

    elif export_format == 'GLTF':
        file_extention = '.glb'
        export_selection_to_GlTF(context, scene, export_path,
                                 filename + file_extention,
                                 export_data, force_animation=force_animation)

    elif export_format == 'USD':
        file_extention = '.usdc'
        export_selection_to_USD(context, scene, export_path,
                                filename + file_extention,
                                export_data, force_animation=force_animation)
    else:
        print(F"Unknown export format '{export_format}'")
        return

    file_path = os.path.join(export_path, filename)

    print(F"'{export_data.collection.name}' exported to '{file_path}{file_extention}'.")


# GLTF Export ##################################################################

def export_selection_to_GlTF(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    materials = []
    for sel in context.selected_objects:

        if sel.type != 'MESH':
            continue

        materials.extend(sel.data.materials[:])

    # unreal engine renames materials with a _DS suffix which is insufferable, lets temporarily disable it
    store_two_sided_materials = [mat for mat in materials if not mat.use_backface_culling]
    for mat in store_two_sided_materials:
        mat.use_backface_culling = True

    try:
        bpy.ops.export_scene.gltf(filepath=os.path.join(export_path, filename),

                                  # parameters
                                  use_selection=True,
                                  use_active_collection=False,
                                  export_format='GLB',
                                  export_image_format='NONE',
                                  # this is flipped for some reason
                                  export_yup=(target != 'UNITY'),
                                  export_extras=True,
                                  will_save_settings=False,

                                  # mesh data
                                  export_apply=True,
                                  export_texcoords=True,
                                  export_normals=True,
                                  export_tangents=True,
                                  export_materials='EXPORT',
                                  export_attributes=True,
                                  use_mesh_edges=False,
                                  use_mesh_vertices=False,

                                  # animation
                                  export_animations=collection.animation or force_animation,
                                  export_frame_range=False,
                                  export_frame_step=1,
                                  export_force_sampling=True,
                                  # NOTE: partof the old animation export system
                                  # export_nla_strips=collection.animation and not force_animation,
                                  export_nla_strips=False,
                                  export_current_frame=False,

                                  # armatures
                                  export_skins=True,
                                  export_all_influences=True,

                                  # shape_keys
                                  export_morph=True,
                                  export_morph_normal=True,
                                  export_morph_tangent=True,
                                  )

    finally:
        # restore two sided materials
        for mat in store_two_sided_materials:
            mat.use_backface_culling = False


# Export FBX ###################################################################

def export_selection_to_FBX(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target

    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    if target == 'UNITY':

        bpy.ops.export_scene.fbx(filepath=os.path.join(export_path, filename),
                                 use_selection=True,
                                 batch_mode='OFF',

                                 # scene
                                 global_scale=scene.engine_export_global_scale,
                                 apply_unit_scale=True,
                                 apply_scale_options='FBX_SCALE_UNITS',

                                 # objects
                                 axis_forward='Y',
                                 axis_up='Z',
                                 # bake_space_transform=True,
                                 use_custom_props=True,

                                 # mesh
                                 mesh_smooth_type='SMOOTH_GROUP',
                                 use_tspace=True,

                                 # animation
                                 bake_anim=collection.animation or force_animation,
                                 bake_anim_use_all_actions=False,

                                 # Note: part of old animation system
                                 # bake_anim_use_nla_strips=collection.animation or force_animation,
                                 bake_anim_use_nla_strips=False,
                                 bake_anim_step=1.0,
                                 bake_anim_simplify_factor=1.0,  # 0.0 if collection.optimize else 1.0,

                                 # rig
                                 add_leaf_bones=False,
                                 use_armature_deform_only=False)

    elif target == 'UNREAL':

        bpy.ops.export_scene.fbx(filepath=os.path.join(export_path, filename),
                                 use_selection=True,
                                 batch_mode='OFF',

                                 # scene
                                 global_scale=scene.engine_export_global_scale,
                                 apply_unit_scale=True,
                                 use_space_transform=False,
                                 apply_scale_options='FBX_SCALE_NONE',

                                 # objects
                                 axis_forward='X',
                                 axis_up='Z',
                                 bake_space_transform=False,
                                 use_custom_props=True,

                                 # mesh
                                 mesh_smooth_type='SMOOTH_GROUP',
                                 colors_type='LINEAR',

                                 # animation
                                 bake_anim=collection.animation or force_animation,
                                 bake_anim_use_all_actions=False,

                                 # Note: part of old animation system
                                 # bake_anim_use_nla_strips=collection.animation and not force_animation,
                                 bake_anim_use_nla_strips=False,
                                 bake_anim_simplify_factor=0.0 if collection.optimize else 1.0,
                                 bake_anim_use_all_bones=True,
                                 bake_anim_force_startend_keying=collection.animation,

                                 # rig
                                 add_leaf_bones=False,
                                 use_armature_deform_only=False)


# Export USD ###################################################################

def export_selection_to_USD(context, scene, export_path, filename, collection, force_animation=False):

    from . import EngineExportAddonPreferences

    target = scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    bpy.ops.wm.usd_export(filepath=os.path.join(export_path, filename),
                          selected_objects_only=True,
                          visible_objects_only=False,
                          export_animation=collection.animation or force_animation,
                          export_armatures=True,
                          export_hair=False,
                          export_uvmaps=True,
                          export_normals=True,
                          export_materials=False,
                          use_instancing=False,
                          evaluation_mode=scene.engine_export_evaluation_mode)


# Operators ####################################################################

class ENGINEEXPORT_OT_export_collections(bpy.types.Operator):
    ''''''
    bl_idname = 'export.engine_export_collections'
    bl_label = 'Export Collections for Engine'
    bl_options = {'INTERNAL'}

    export_mode: bpy.props.EnumProperty(items=(
        ('ENABLED', 'Enabled Collections',
         'Export Collections that are enabled for export'),
        ('ACTIVE', 'Active Only', 'Only export the active export collection'),
        ('ACTIVE_COLLECTION', 'Active Scene Collection Only',
         'Only export the active scene collection'),
        ('SELECTION', 'Object Selection',
         'Export the collection which have currently selected child objects'),
        ('EXPORT_GROUP', 'Export Group', 'Export whole Export Group')),
        default='ENABLED')

    export_target: bpy.props.EnumProperty(items=(
        ('ALL', 'All', 'Export Mesh and Animation data'),
        ('ANIM', 'Animation', 'Export Animation data only'),
        ('MESH', 'Mesh', 'Export Mesh data only')), default='ALL')

    export_group_index: bpy.props.StringProperty(
        name="Export Collection Index", default='')

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            do_export_collections(self, context)
        finally:
            progress = getattr(self, '_engine_export_progress', None)
            if progress is not None:
                progress.close()
                self._engine_export_progress = None

        return {'FINISHED'}


def sanitize_collection(collection):
    # rename collections marked as AUTO name
    if collection.name_method == 'AUTO' and collection.collection is not None and collection.collection.name != collection.name:
        print(F"== Engine Exporter: Renaming {collection.collection.name} to {collection.name} ==")
        collection.name = collection.collection.name


@persistent
def sanitize_collections(scene):

    if scene is None:
        print("######################## Scene is null for some reason")
        return

    handlers = [handle for handle in bpy.app.handlers.depsgraph_update_post]
    for func in handlers:
        if func.__name__ == 'sanitize_collections':
            bpy.app.handlers.depsgraph_update_post.remove(func)

    collections = [col for col in scene.engine_export_collections]
    for collection in collections:
        sanitize_collection(collection)

    bpy.app.handlers.depsgraph_update_post.append(sanitize_collections)


class ENGINEEXPORTSCENE_PT_Panel(bpy.types.Panel):

    bl_label = 'Engine Export Tools'
    bl_idname = 'ENGINEEXPORTSCENE_PT_Panel'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'

    modify_collection = True

    def draw(self, context):

        from . import EngineExportAddonPreferences

        layout = self.layout
        scene = context.scene

        active_collections = find_all_view_layer_collections(scene)

        # Export Groups List
        col = layout.column(align=True)
        col.label(text='Export Collections', icon='GROUP')

        box = col.box()
        box.label(text='Property Matrix', icon='SPREADSHEET')
        row = box.row(align=True)
        row.prop(scene, 'engine_export_matrix_show_path',
                 text='Path', emboss=True, icon='FILE_FOLDER')
        row.prop(scene, 'engine_export_matrix_show_origin',
                 text='Origin', emboss=True, icon='TRANSFORM_ORIGINS')
        row.prop(scene, 'engine_export_matrix_show_animation',
                 text='Animation', emboss=True, icon='ANIM')
        row.prop(scene, 'engine_export_matrix_show_export_type',
                 text='Export Type', emboss=True, icon='WORDWRAP_ON')
        row.separator()
        row.prop(scene, 'engine_export_matrix_show_expanded_matrix',
                 text='', emboss=True, icon='SPLIT_VERTICAL')

        row = col.row()
        row.template_list('ENGINEEXPORTSCENE_UL_collections', '', scene, 'engine_export_collections',
                          scene, 'engine_export_active_export_collection_index', rows=10)

        # basic management
        col = row.column(align=True)
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, icon='ADD',
                     text='').operation = 'ADD'

        if context.collection is not None:
            col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                         text='', icon='LAYER_ACTIVE').operation = 'ADD_ACTIVE'

        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_LEFT', text='').operation = 'ADD_ACTIVE_OBJECT'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='RESTRICT_SELECT_OFF', text='').operation = 'ADD_SELECTED_OBJECTS'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='DUPLICATE', text='').operation = 'DUPLICATE'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='REMOVE', text='').operation = 'REMOVE_ACTIVE'
        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='GHOST_DISABLED', text='').operation = 'REMOVE_EMPTY'

        # reordering
        col.separator()

        row = col.row(align=True)
        row.enabled = scene.engine_export_active_export_collection_index > 0
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_UP', text='').operation = 'MOVE_UP'

        row = col.row(align=True)
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, icon='SORTALPHA',
                     text='').operation = 'SORT'

        row = col.row(align=True)
        row.enabled = scene.engine_export_active_export_collection_index < (
            len(scene.engine_export_collections) - 1)
        row.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname,
                     icon='TRIA_DOWN', text='').operation = 'MOVE_DOWN'

        col.separator()

        # weirder stuff for handling legacy files
        col.separator()

        col.operator(manager.SCENE_OT_engine_export_modify_collection.bl_idname, text='',
                     icon='RESTRICT_RENDER_OFF').operation = 'RENDER'

        if len(active_collections) > 0 and active_collections[scene.engine_export_active_export_collection_index] is not None:

            collection = active_collections[scene.engine_export_active_export_collection_index]

            if collection.collection is not None:

                col = layout.column()
                col.scale_y = 1.5

                op = col.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                                  text=F'Export {collection.collection.name}',
                                  icon='GROUP')
                op.export_mode = 'ACTIVE'
                op.export_target = 'ALL'

                # isolated exports
                row = col.row(align=True)

                op = row.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                                  text='Mesh Only', icon='MESH_DATA')
                op.export_mode = 'ACTIVE'
                op.export_target = 'MESH'

                op = row.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                                  text='Animation Only', icon='ANIM')
                op.export_mode = 'ACTIVE'
                op.export_target = 'ANIM'

        # Collection Settings

        if len(active_collections) > 0 and len(active_collections) > scene.engine_export_active_export_collection_index:

            collection = active_collections[scene.engine_export_active_export_collection_index]

            draw_collection(self, context, collection)

        else:
            box = layout.box()
            box.label(text='No collections, add some', icon='ERROR')

        # get export counts
        num = 0
        exported_collections = []

        for collection in active_collections:
            if collection is not None and collection.do_export and collection.collection is not None:
                collect_collections(collection.collection,
                                    exported_collections)
                num += 1

        # layout
        options_panel = layout.panel_prop(
            context.scene, 'engine_export_expand_export_details')
        options_panel[0].label(text='Export Option')

        if options_panel[1] is not None:

            box = options_panel[1].box()

            col = box.column(align=True)

            col.prop(scene, 'engine_export_target', text='Engine')

            if scene.engine_export_target == 'DEFAULT':
                target = EngineExportAddonPreferences.get_instance(
                    context).global_export_target
                col.label(
                    text=F'Default Engine: {engine_export_targets[target]}')

            box = layout.box()
            col = box.column(align=True)
            col.prop(scene, 'engine_export_format', text='Format')

            col.prop(scene, 'engine_export_use_naming_convention')
            col.prop(scene, 'engine_export_use_instances')
            if scene.engine_export_format == 'FBX':
                col.prop(scene, 'engine_export_global_scale', text='Scale')
                col.prop(scene, 'apply_scale_options', text='Scale Mode')

            row = box.row()
            row.label(text='Export path')

            row = box.row(align=True)
            # row.operator(GuessExportPath.bl_idname, text=(''), icon='AUTO')
            row.prop(scene, 'engine_export_export_path', text='')
            row.prop(scene, 'engine_export_make_path',
                     text='', icon='NEWFOLDER')

            uv_box = layout.box()
            uv_box.label(text='Blend File UV Order', icon='GROUP_UVS')
            uv_order.draw_uv_order(uv_box, context, scene.engine_export_uv_order,
                                   scene, 'engine_export_uv_order_index', 'SCENE')

        export_shape_keys_error = []
        viewport_hidden_collections = []

        for collection in exported_collections:

            for o in collection.all_objects:

                if o.type != 'MESH':
                    continue

                if o in export_shape_keys_error:
                    continue

                if o.data.shape_keys is not None:
                    for m in o.modifiers:
                        if m.type != 'ARMATURE':
                            export_shape_keys_error.append(o)

            if collection.hide_viewport:
                viewport_hidden_collections.append(collection)

        has_hidden_collections = len(viewport_hidden_collections) > 0
        if has_hidden_collections:
            box = layout.box()
            # box.alert = has_hidden_collections
            box.label(
                text='Export Disabled, the following collections are hidden in the viewport', icon='RESTRICT_VIEW_ON')

            col = box.column(align=True)
            for c in viewport_hidden_collections:
                col.prop(c, "hide_viewport", text=c.name, emboss=True)

        has_bad_shape_keys = len(export_shape_keys_error) > 0
        if has_bad_shape_keys:

            box = layout.box()
            box.alert = True
            box.label(text='Shapekeys and non-armature modifiers')

            col = box.column(align=True)
            for c in export_shape_keys_error:
                col.label(text=c.name, icon='SHAPEKEY_DATA')

            box.label(text='EXPECT WEIRDNESS')

        col = layout.column()
        col.scale_y = 2
        col.enabled = num > 0 and len(viewport_hidden_collections) == 0
        col.alert = has_hidden_collections

        plural = 'Collection' if num == 1 else 'Collections'

        op = col.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                          text=F'Export {num} {plural} to {scene.engine_export_format}',
                          icon='GROUP')
        op.export_mode = 'ENABLED'
        op.export_target = 'ALL'

        # isolated exports
        row = col.row(align=True)
        op = row.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                          text='Meshes Only',
                          icon='MESH_DATA')
        op.export_mode = 'ENABLED'
        op.export_target = 'MESH'

        op = row.operator(ENGINEEXPORT_OT_export_collections.bl_idname,
                          text='Animations Only',
                          icon='ANIM')
        op.export_mode = 'ENABLED'
        op.export_target = 'ANIM'


class ENGINEEXPORTOBJECT_PT_Properties(bpy.types.Panel):
    bl_label = 'Engine Export Properties'
    bl_id = 'ENGINEEXPORTOBJECT_PT_Properties'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'object'

    def draw(self, context):

        layout = self.layout
        obj = context.active_object

        layout.prop(obj, 'engine_export_export')
        layout.prop(obj, 'engine_export_use_rename')
        layout.prop(obj, 'engine_export_explicit_rename')

        if obj.type == 'MESH':
            box = layout.box()
            box.label(text='Export UV Order', icon='GROUP_UVS')
            uv_order.draw_uv_order(box, context, obj.engine_export_uv_order,
                                   obj, 'engine_export_uv_order_index', 'OBJECT')
