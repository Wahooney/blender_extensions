# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
import bpy

SPECIAL_PREFIXES = ('UCX_',)
EXCLUSION_PREFIXES = ('REF_', '_REF_', 'MESH_', '_MESH_', 'UTL_', '_UTL_')


def has_exclusion_prefix(name: str) -> bool:
    """
    Check if the given name starts with any of the exclusion prefixes.
    """
    return name.startswith(EXCLUSION_PREFIXES)


def pure_curve(obj):
    return obj.type == 'CURVE' and obj.data.bevel_depth == 0 and obj.data.extrude == 0 and obj.data.bevel_object == None


def fix_path(path):
    return os.path.normpath(bpy.path.abspath(path))


def enable_action_export(context):
    action = context.active_object.animation_data.action

    if action:
        action['export'] = True


def find_all_child_layers(collection, collections):
    for c in collection.children:
        if len(c.collection.objects) > 0:
            collections.append(c)
        collection = find_all_child_layers(c, collections)

    return collections


def filter_items_by_name(pattern, bitflag, items, propname="name", flags=None, reverse=False):
    """
    Set FILTER_ITEM for items whose property matches filter_name case-insensitively.
    Mirrors Blender's UI list helper behavior, but handles arbitrary item lists.
    """
    import fnmatch

    if not pattern or not items:
        return flags or []

    if flags is None:
        flags = [0] * len(items)

    pattern = "*" + pattern + "*"

    for i, item in enumerate(items):
        name = getattr(item, propname, None)
        if bool(name and fnmatch.fnmatch(name, pattern)) is not bool(reverse):
            flags[i] |= bitflag

    return flags


def get_collection_hierarchy(collection):

    if collection is None:
        return []

    parent_by_name = {}
    for parent in bpy.data.collections:
        for child in parent.children:
            parent_by_name.setdefault(child.name, parent)

    path = [collection]
    parent = parent_by_name.get(collection.name)

    while parent is not None:
        path.append(parent)
        parent = parent_by_name.get(parent.name)

    path.reverse()

    return path


def get_collection_exportpath(collection):

    if collection is None or collection.collection is None:
        return os.path.sep

    subpath = ''
    if collection.path_modifier == 'AUTO' or collection.path_modifier == 'COMBO':

        path = get_collection_export_subpaths(collection)

        if len(path) == 0:
            # subpath = os.path.sep
            pass
        else:
            subpath = os.path.join(*path)

    if collection.path_modifier == 'CUSTOM' or collection.path_modifier == 'COMBO':
        subpath += collection.subpath

    return os.path.sep + subpath


def get_collection_export_subpaths(collection):

    if collection is None or collection.collection is None:
        return []

    path = []
    if collection.path_modifier == 'AUTO' or collection.path_modifier == 'COMBO':

        # find collection hierarchy
        collections = get_collection_hierarchy(collection.collection)[:-1]

        for p in collections:
            if 'export_subpath' in p and subpath_modifies_path(p):
                if p['export_subpath'] != '':
                    path.append(p['export_subpath'])
                else:
                    path.append(p.name)

    return path


def get_collection_export_filename_subpaths(collection):

    if collection is None or collection.collection is None:
        return []

    path = []
    if collection.path_modifier == 'AUTO' or collection.path_modifier == 'COMBO':

        collections = get_collection_hierarchy(collection.collection)[:-1]

        for p in collections:
            if ('export_subpath' in p
                    and subpath_modifies_path(p)
                    and p.engine_export_subpath_in_filename):
                if p['export_subpath'] != '':
                    path.extend(split_path_for_filename(p['export_subpath']))
                else:
                    path.append(p.name)

    return path


def subpath_modifies_path(collection):
    return getattr(collection, 'engine_export_subpath_modifies_path', True)


def split_path_for_filename(path):
    path = path.replace('\\', os.path.sep).replace('/', os.path.sep)
    return [part for part in path.split(os.path.sep) if part != '']


def add_subpath_to_filename(collection, filename):

    path = get_collection_export_filename_subpaths(collection)

    if len(path) == 0:
        return filename

    return F"{'_'.join(path)}_{filename}"


def add_prefix(context, export_data, filename, force_animation):

    from . import EngineExportAddonPreferences

    target = context.scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    use_naming_convention = context.scene.engine_export_use_naming_convention

    if use_naming_convention:
        # Otherwise we're a static mesh, export with SM_ prefix
        prefix = "SM_"

        if target == 'UNREAL':
            if export_data.is_utility_collection:
                prefix = 'SM_'
            elif force_animation:
                # Unreal export has separate animation files, prefix files with SK_
                prefix = ''

            else:
                for sel in context.selected_objects:
                    # check if the mesh has an armature modifier or shape keys
                    for mod in sel.modifiers:
                        if mod.type == 'ARMATURE':
                            # We're a skeletal mesh, export with SK_ prefix
                            prefix = 'SK_'
                            break

                    if prefix == 'SK_':
                        break

                    elif sel.type == 'MESH':
                        if sel.data.shape_keys is not None:
                            prefix = 'SK_'
                            break
        if not filename.startswith(prefix):
            return F"{prefix}{filename}"

    return filename


def startswith(string, prefixes):
    return string.startswith(tuple(prefixes))


def findstartswith(string, prefixes: list[str]):

    for prefix in prefixes:
        if string.startswith(prefix):
            return prefix
    return None


def is_exportable(collection, obj):

    if not obj.engine_export_export:
        return False

    if collection.is_utility_collection and collection.include_reference_meshes:
        return True

    return not has_exclusion_prefix(obj.name)
