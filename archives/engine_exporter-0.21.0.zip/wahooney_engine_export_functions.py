# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
import bpy

SPECIAL_PREFIXES = ['UCX_']
EXCLUSION_PREFIXES = ['REF_', '_REF_']


def has_exclusion_prefix(name: str) -> bool:
    """
    Check if the given name starts with any of the exclusion prefixes.
    """
    for prefix in EXCLUSION_PREFIXES:
        if name.startswith(prefix):
            return True
    return False


def pure_curve(obj):
    return obj.type == 'CURVE' and obj.data.bevel_depth == 0 and obj.data.extrude == 0 and obj.data.bevel_object == None


def fix_path(path):
    return os.path.normpath(bpy.path.abspath(path))


def enable_action_export(context):
    action = context.active_object.animation_data.action

    if action:
        action['export'] = True


def find_all_child_layers(collection, collections):
    for c in collection.children:
        if len(c.collection.objects) > 0:
            collections.append(c)
        collection = find_all_child_layers(c, collections)

    return collections


def get_collection_hierarchy(collection):

    def get_parent_collection(collection):
        if not collection:
            return None

        for c in bpy.data.collections:
            if collection.name in c.children:
                return c

        return None

    path = [collection]
    parent = get_parent_collection(collection)

    while parent is not None:
        path.append(parent)
        parent = get_parent_collection(parent)

    path.reverse()

    return path


def get_collection_exportpath(collection):

    if collection is None or collection.collection is None:
        return os.path.sep

    subpath = ''
    if collection.path_modifier == 'AUTO' or collection.path_modifier == 'COMBO':

        # find collection hierarchy
        collections = get_collection_hierarchy(collection.collection)[:-1]

        path = []
        for p in collections:
            if 'export_subpath' in p:
                if p['export_subpath'] != '':
                    path.append(p['export_subpath'])
                else:
                    path.append(p.name)

        if len(path) == 0:
            # subpath = os.path.sep
            pass
        else:
            subpath = os.path.join(*path)

    if collection.path_modifier == 'CUSTOM' or collection.path_modifier == 'COMBO':
        subpath += collection.subpath

    return os.path.sep + subpath


'''
def get_prefix(context, force_animation):

    from . import EngineExportAddonPreferences

    target = context.scene.engine_export_target

    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    use_naming_convention = context.scene.engine_export_use_naming_convention

    if use_naming_convention:
        # Otherwise we're a static mesh, export with SM_ prefix
        prefix = "SM_"

        if target == 'UNREAL':
            if force_animation:
                # Unreal export has separate animation files, prefix files with SK_
                prefix = ''

            elif 

            else:
                for sel in context.selected_objects:
                    # check if the mesh has an armature modifier or shape keys
                    for mod in sel.modifiers:
                        if mod.type == 'ARMATURE':
                            # We're a skeletal mesh, export with SK_ prefix
                            prefix = 'SK_'
                            break

                    if prefix == 'SK_':
                        break

                    elif sel.type == 'MESH':
                        if sel.data.shape_keys is not None:
                            prefix = 'SK_'
                            break

        return F"{prefix}"

    return ""
'''


def add_prefix(context, export_data, filename, force_animation):

    from . import EngineExportAddonPreferences

    target = context.scene.engine_export_target
    if target == 'DEFAULT':
        target = EngineExportAddonPreferences.get_instance(
            context).global_export_target

    use_naming_convention = context.scene.engine_export_use_naming_convention

    if use_naming_convention:
        # Otherwise we're a static mesh, export with SM_ prefix
        prefix = "SM_"

        if target == 'UNREAL':
            if export_data.is_utility_collection:
                prefix = 'SM_'
            elif force_animation:
                # Unreal export has separate animation files, prefix files with SK_
                prefix = ''

            else:
                for sel in context.selected_objects:
                    # check if the mesh has an armature modifier or shape keys
                    for mod in sel.modifiers:
                        if mod.type == 'ARMATURE':
                            # We're a skeletal mesh, export with SK_ prefix
                            prefix = 'SK_'
                            break

                    if prefix == 'SK_':
                        break

                    elif sel.type == 'MESH':
                        if sel.data.shape_keys is not None:
                            prefix = 'SK_'
                            break
        if not filename.startswith(prefix):
            return F"{prefix}{filename}"

    return filename


def startswith(string, prefixes: list[str]):

    for prefix in prefixes:
        if string.startswith(prefix):
            return True
    return False


def findstartswith(string, prefixes: list[str]):

    for prefix in prefixes:
        if string.startswith(prefix):
            return prefix
    return None


def is_exportable(collection, obj):

    if not obj.engine_export_export:
        return False

    if collection.is_utility_collection and collection.include_reference_meshes:
        return True

    return not has_exclusion_prefix(obj.name)
