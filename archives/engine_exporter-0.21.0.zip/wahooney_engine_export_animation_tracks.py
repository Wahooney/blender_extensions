# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
import math


class AddSelectedActionsAsTracks(bpy.types.Operator):
    """Add Selected Actions as Tracks"""
    bl_idname = "nla.add_selected_actions_as_tracks"
    bl_label = "Add Selected Actions"
    bl_description = "Select and add actions as new NLA tracks"
    bl_options = {'UNDO', 'REGISTER'}

    filter: bpy.props.StringProperty(
        default='',
        options={'SKIP_SAVE', 'TEXTEDIT_UPDATE'}
    )

    selection: bpy.props.BoolVectorProperty(
        size=32,
        options={'SKIP_SAVE'}
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        layout.prop(self, 'filter')

        actions = list(bpy.data.actions)

        filter = self.filter.lower()
        col = layout.column(align=True)

        for idx, action in enumerate(actions):

            if len(filter) > 0 and action.name.lower().find(filter) < 0:
                continue

            col.prop(self, "selection", index=idx, text=action.name,
                     toggle=True)

    def execute(self, context):

        active = bpy.context.active_object
        tracks = active.animation_data.nla_tracks
        actions = list(bpy.data.actions)

        '''
        for t in tracks:
            
            if t.lock:
                continue
            
            while len(t.strips) > 1:
                t.strips.remove(t.strips[1])
            
            if not t.strips[0].action is None:
                actions.remove(t.strips[0].action)
        actions.sort(key = lambda x: x.name, reverse=True)
        '''

        for i, action in enumerate(actions):

            if not self.selection[i]:
                continue

            track = tracks.new()
            strip = track.strips.new(name=action.name, start=1, action=action)
            track.name = action.name

        '''
        active = bpy.context.active_object
        tracks = active.animation_data.nla_tracks

        actions = list(bpy.data.actions)

        for t in tracks:
            
            if t.lock:
                continue
            
            if len(t.strips) == 0:
                tracks.remove(t)
            else:
                while len(t.strips) > 1:
                    t.strips.remove(t.strips[1])
                
                if not t.strips[0].action is None:
                    actions.remove(t.strips[0].action)

        actions.sort(key = lambda x: x.name, reverse=True)

        for action in actions:
            track = tracks.new()
            strip = track.strips.new(name=action.name, start=1, action=action)
            track.name = action.name
        '''
        return {'FINISHED'}


class RemoveAction(bpy.types.Operator):

    """"""

    bl_idname = "action.remove_action"
    bl_label = "Remove Action"
    bl_description = "Remove action"
    bl_options = {'UNDO', 'REGISTER'}

    action: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return "Remove '%s' action data" % properties.action

    def execute(self, context):

        bpy.data.actions.remove(bpy.data.actions[self.action])

        return {'FINISHED'}


class AddActionAsNewTrack(bpy.types.Operator):

    """"""

    bl_idname = "nla.add_action_as_new_track"
    bl_label = "Add Action as Track"
    bl_description = "Add an action as a new NLA track"
    bl_options = {'UNDO', 'REGISTER'}

    action: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    @classmethod
    def description(cls, context, properties):
        return "Add '%s' action as a new NLA track" % properties.action

    def execute(self, context):

        active = bpy.context.active_object
        tracks = active.animation_data.nla_tracks

        track = tracks.new()
        strip = track.strips.new(name=self.action,
                                 start=context.scene.frame_start,
                                 action=bpy.data.actions[self.action])
        track.name = self.action

        return {'FINISHED'}


class CopyAction(bpy.types.Operator):

    """"""

    bl_idname = "nla.copy_action"
    bl_label = "Copy Action"
    bl_description = "Copy Action"
    bl_options = {'UNDO', 'REGISTER'}

    action: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    @classmethod
    def description(cls, context, properties):
        return "Copy action '%s'" % properties.action

    def execute(self, context):

        bpy.data.actions[self.action].copy()

        return {'FINISHED'}


class RemoveNLATracks(bpy.types.Operator):

    """Remove NLA tracks"""

    bl_idname = "nla.remove_tracks"
    bl_label = "Remove Empty Tracks"
    bl_description = "Remove tracks"
    bl_options = {'UNDO', 'REGISTER'}

    action: bpy.props.EnumProperty(items=(
        ('EMPTY', 'Empty Tracks', 'Remove Empty Tracks'),
        ('ALL', 'All Tracks', 'Remove All Tracks')), default='EMPTY')

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    @classmethod
    def description(cls, context, properties):

        if properties.action == 'EMPTY':
            return 'Remove Empty Tracks'

        if properties.action == 'ALL':
            return 'Remove All Tracks'

        return 'Remove Tracks'

    def execute(self, context):

        tracks = bpy.context.active_object.animation_data.nla_tracks
        for t in tracks:
            if t.lock:
                continue

            if len(t.strips) == 0:
                tracks.remove(t)

        return {'FINISHED'}


class RenameTracksFromStrips(bpy.types.Operator):

    """Rename NLA Tracks from Strips"""

    bl_idname = "nla.rename_tracks_from_strips"
    bl_label = "Rename Tracks from Strips"
    bl_description = "Rename NLA tracks to the first strips action name"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    def execute(self, context):

        tracks = bpy.context.active_object.animation_data.nla_tracks
        for t in tracks:

            if len(t.strips) == 0 or t.strips[0].action is None:
                continue

            t.strips[0].name = t.strips[0].action.name
            t.name = t.strips[0].action.name

        return {'FINISHED'}


class SortTracksByName(bpy.types.Operator):

    """Sort NLA tracks by name"""

    bl_idname = "nla.sort_nla_tracks"
    bl_label = "Sort Tracks"
    bl_description = "Sort NLA tracks by name"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    def execute(self, context):

        data = bpy.context.active_object.animation_data
        tracks = data.nla_tracks[:]
        tracks.sort(key=lambda x: x.name, reverse=False)

        for t in tracks:
            for r in tracks:
                r.select = False
            t.select = True
            bpy.ops.anim.channels_move(direction='BOTTOM')

        for r in tracks:
            r.select = False

        # move static tracks to the bottom of the list
        tracks = [track for track in data.nla_tracks if len(track.strips) > 0 and track.strips[0].action is not None]
        tracks.sort(key=lambda x: x.name, reverse=False)

        for t in tracks:

            for r in tracks:
                r.select = False

            t.select = True
            bpy.ops.anim.channels_move(direction='BOTTOM')

        return {'FINISHED'}


class EngineExport_OT_strips_to_action_time(bpy.types.Operator):

    """"""

    bl_idname = "nla.strips_to_action_time"
    bl_label = "Strips to action time"
    bl_description = "Set strips start and end times to those defined in their actions"
    bl_options = {'UNDO', 'REGISTER'}

    loop: bpy.props.BoolProperty(
        name='Loop', default=True, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    def execute(self, context):

        for n in context.active_object.animation_data.nla_tracks:
            for s in n.strips:
                if not s.select:
                    continue

                s.action_frame_start = int(s.action.frame_start)
                s.action_frame_end = int(s.action.frame_end)

        return {'FINISHED'}


class FramesToStripTime(bpy.types.Operator):

    """"""

    bl_idname = "nla.frames_to_track_time"
    bl_label = "Frames to Strip Time"
    bl_description = "Set timeline range to the start and end frames of the currently selected strips in the NLA track"
    bl_options = {'UNDO', 'REGISTER'}

    loop: bpy.props.BoolProperty(
        name='Loop', default=True, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.animation_data != None)

    def execute(self, context):

        start = 100000
        end = -10000
        found = False

        data = bpy.context.active_object.animation_data

        if data != None:
            tracks = list(data.nla_tracks)

            for t in tracks:
                for s in t.strips:
                    found = True
                    start = min(start, s.frame_start)
                    end = max(start, s.frame_end)

        if not found:
            start = 0
            end = 250

        context.scene.frame_start = int(start)
        context.scene.frame_end = int((end - 1) if self.loop else end)

        return {'FINISHED'}


class ExportToolsAnimations(bpy.types.Panel):

    """Engine Export Tools for NLA Animations"""

    bl_label = "Export Tools"
    bl_idname = "NLA_ANIMATOR_PT_export_tools"
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Engine Export'

    def draw(self, context):

        layout = self.layout
        # layout.operator(AddSelectedActionsAsTracks.bl_idname)
        layout.operator(SortTracksByName.bl_idname)
        row = layout.row(align=True)
        row.operator(
            FramesToStripTime.bl_idname).loop = context.scene.engine_export_nla_use_loop_frame
        row.prop(context.scene, 'engine_export_nla_use_loop_frame',
                 text='', emboss=True, icon='KEYFRAME')
        layout.operator(RenameTracksFromStrips.bl_idname)
        layout.operator(RemoveNLATracks.bl_idname,
                        text='Remove Empty Tracks').action = 'EMPTY'
        layout.operator(EngineExport_OT_strips_to_action_time.bl_idname)

        active = bpy.context.active_object
        actions = list(bpy.data.actions)


class ExportToolsAnimationActions(bpy.types.Panel):

    """Engine Export Tools for Actions"""

    bl_label = "Action Tools"
    bl_idname = "NLA_ANIMATOR_PT_export_tools_actions"
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_parent_id = 'NLA_ANIMATOR_PT_export_tools'

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def draw(self, context):

        layout = self.layout

        slot = F'OB{context.active_object.name}'

        actions = None

        if bpy.app.version >= (4, 4):
            actions = [action for action in bpy.data.actions if slot in action.slots]
        else:
            actions = bpy.data.actions[:]

        data = bpy.context.active_object.animation_data

        if data is None:
            return

        tracks = list(data.nla_tracks)

        used_actions = []
        for t in tracks:
            for s in t.strips:
                used_actions.append(s.action)

        col = layout.column(align=True)
        col.prop(context.scene,
                 'engine_export_nla_show_unused_actions',
                 icon='DECORATE_LINKED', emboss=True)

        for a in actions:

            used = a in used_actions

            if used and context.scene.engine_export_nla_show_unused_actions:
                continue

            icon = 'DECORATE_LINKED' if used else 'BLANK1'

            row = col.row(align=True)
            row.prop(a, 'name', text='', icon=icon)
            row.prop(a, 'use_fake_user', text='')
            row.operator(AddActionAsNewTrack.bl_idname,
                         text='', icon='NLA').action = a.name
            row.operator(CopyAction.bl_idname,
                         text='', icon='DUPLICATE').action = a.name
            row.operator(RemoveAction.bl_idname, text='',
                         icon='X').action = a.name


class ExportToolsAnimationAdvanced(bpy.types.Panel):

    """Engine Export Advanced Tools"""

    bl_label = "Advanced Tools"
    bl_idname = "NLA_ANIMATOR_PT_export_tools_advanced"
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_parent_id = 'NLA_ANIMATOR_PT_export_tools'

    def draw(self, context):
        layout = self.layout
        layout.operator(RemoveNLATracks.bl_idname,
                        text='Remove All Tracks').action = 'ALL'


class GuessActionRange(bpy.types.Operator):
    """Guess the range of the current action"""
    bl_idname = "action.guess_action_range"
    bl_label = "Guess Action Range"
    bl_description = "Automatically guess the range of the action"
    bl_options = {'UNDO', 'REGISTER'}

    method: bpy.props.EnumProperty(items=(
        ('KEYFRAMES', 'Keyframe Range',
         'Sets action range to its start and end keyframe'),
        ('LOOP', 'Looping Range',
         'Sets action range to its start and clips off the end keyframe for looping'),
        ('SCENE', 'Scene Range', 'Sets action range from the current scene animation range')), default='SCENE')

    @classmethod
    def description(cls, context, properties):

        if properties.method == 'KEYFRAMES':
            return 'Sets action range to its start and end keyframe'

        if properties.method == 'LOOP':
            return 'Sets action range to its start and clips off the end keyframe for looping'

        if properties.method == 'SCENE':
            return 'Sets action range from the current scene animation range'

        return 'Guess Range'

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.animation_data is not None and context.active_object.animation_data.action is not None

    def execute(self, context):

        active = bpy.context.active_object
        action = active.animation_data.action
        action.use_frame_range = True

        if self.method == 'SCENE':
            action.frame_start = context.scene.frame_start
            action.frame_end = context.scene.frame_end

        if self.method == 'KEYFRAMES':
            action.frame_start = action.frame_range.x
            action.frame_end = action.frame_range.y

        if self.method == 'LOOP':
            action.frame_start = action.frame_range.x
            action.frame_end = action.frame_range.y
            action.use_cyclic = True

        return {'FINISHED'}
