# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from .wahooney_engine_export_groups import ExportGroup
from bpy.props import *
from bpy.app.handlers import persistent

if "bpy" in locals():

    import importlib

    importlib.reload(wahooney_engine_export_functions)
    importlib.reload(wahooney_collection_name_from_selected)
    importlib.reload(wahooney_engine_export_collection_head)
    importlib.reload(wahooney_instance_offset_to_selected)
    importlib.reload(wahooney_guess_export_path)
    importlib.reload(wahooney_engine_export_rename)
    importlib.reload(wahooney_engine_export_collection_manager)
    importlib.reload(wahooney_engine_export_groups)
    importlib.reload(wahooney_engine_export_collection_drawer)
    importlib.reload(wahooney_engine_export)
    importlib.reload(wahooney_nla_tools)
    importlib.reload(wahooney_engine_export_animation_tracks)
    importlib.reload(wahooney_engine_export_tools_panel)
    importlib.reload(wahooney_engine_export_collection_panel)
    importlib.reload(wahooney_engine_export_preferences)
    importlib.reload(wahooney_collection_operators)

else:

    import bpy

    from . import wahooney_engine_export_functions
    from . import wahooney_collection_name_from_selected
    from . import wahooney_engine_export_collection_head
    from . import wahooney_instance_offset_to_selected
    from . import wahooney_guess_export_path
    from . import wahooney_engine_export_collection_manager
    from . import wahooney_engine_export_groups
    from . import wahooney_engine_export_collection_drawer
    from . import wahooney_engine_export_rename
    from . import wahooney_engine_export
    from . import wahooney_nla_tools
    from . import wahooney_engine_export_animation_tracks
    from . import wahooney_engine_export_tools_panel
    from . import wahooney_engine_export_collection_panel
    from . import wahooney_engine_export_preferences
    from . import wahooney_collection_operators

bl_info = {
    "name": "Engine Export Tools",
    "author": "Keith (Wahooney) Boshoff",
    "version": (0, 20, 4),
    "blender": (4, 2, 0),
    "description": "A collection of tools for exporting meshes and animations to game engines",
    "url": "",
    "category": "Tools"}

"""
Based on Wahooney's Unity Export Tools

Version History:

0.7: Use blender's standard fbx exporter

0.8: Improve blend shape exporter(each mesh gets exported to it's own file and contains all of it's flex shapes)

0.9: Added prop_searches to Animation Collection and Collapse Head

0.9.5: Integrated action exporter into collection exporter

0.9.7: Added texture exporter

0.9.8: Added custom FBX export option

0.9.9: Technical debt
    - Improved guess buttons(auto-icon)
    - Reorganized options into more logical collectionings
    - Fixed Export Textures not exporting images that haven't been loaded yet.
    - Fixed Export Layers not updating the scene(breaks exporting shadow rigs)

0.9.10:
    - Made Sub Path optional

0.9.11:
    - Export textures only exports selected collections' textures

0.9.12:
    - Fixed non-meshed curve exporting

0.20.0:
    - Blender 3+ support
    - Improved usability
    - Added export groups
    - Added export collection manager
    - Added subpath collections

0.20.1:
    - Add Transform Checker warning
    - Warn about animation on meshes
    - Add option to set origin to specific object outside of collection
    TODO: Add operator to create an empty for this

0.20.2:
    - Fixed packed in animations exporting incorrectly
    - Fixed static animations affecting total animation length

    TODO: Change NLA - Split tracks system, make split-tracks dominant and rebuild NLA from it??
    TODO: Warn about no animation range [needs a think]
    TODO: Allow ignoring of scale warnings [needs a think]
    TODO: Add collapse sub-collection ?? usefulness ?? [needs a think]
            A collection that is the child of an Export Collection can be marked to collapse itself before its parent collection is exported

0.20.3: Armature export
    - Added methods to export collapsed collections with armatures correctly.

0.20.4:
    - Added auto-prefixing for unreal engine
    - Don't overwrite data names starting with "__"
    - Deprecating "Texture Exporter"
    - Added more comments
    - Better checks for invisibility

"""


class EngineExportAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    @staticmethod
    def get_instance(context: bpy.types.Context = None) -> 'EngineExportAddonPreferences':

        prefs = (
            context or bpy.context).preferences.addons[__package__].preferences
        assert isinstance(prefs, EngineExportAddonPreferences)
        return prefs

    global_export_target: EnumProperty(
        name='Global Export Target',
        description='Default export target for all collections, '
                    'can be overridden per Blend file in Scene > Engine Export panel',
        items=(('UNITY', "Unity", ""),
               ('UNREAL', "Unreal Engine", "")), default='UNREAL')

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "global_export_target")
        layout.prop(context.scene, "engine_export_target",
                    text="Project Export Target")


classes = (

    # export collections

    wahooney_engine_export_collection_manager.SplitExportOptions,
    wahooney_engine_export_collection_manager.SplitExportTrackOptions,
    wahooney_engine_export_collection_manager.ExportCollectionItem,
    wahooney_engine_export_collection_manager.ENGINEEXPORTSCENE_UL_collections,
    wahooney_engine_export_collection_manager.SCENE_OT_engine_export_modify_collection,


    # export groups

    wahooney_engine_export_groups.ExportGroupItem,
    wahooney_engine_export_groups.ExportGroup,
    wahooney_engine_export_groups.ENGINEEXPORT_OT_ModifyExportGroup,
    wahooney_engine_export_groups.ENGINEEXPORT_OT_ExportExportGroup,
    wahooney_engine_export_groups.ENGINEEXPORT_OT_ModifyExportGroupCollection,
    wahooney_engine_export_groups.ENGINEEXPORT_UL_export_groups,
    wahooney_engine_export_groups.ENGINEEXPORT_PT_ExportGroupPanel,

    wahooney_engine_export_collection_panel.COLLECTION_PT_ExportEngine,
    wahooney_engine_export_collection_panel.COLLECTION_PT_CollectionActions,


    # collection operators

    wahooney_collection_operators.COLLECTION_OT_SmartDuplicate,
    wahooney_collection_operators.COLLECTION_OT_InstanceOffsetToHead,
    wahooney_collection_operators.ENGINEEXPORT_OT_ClearAnimationData,
    wahooney_collection_operators.ENGINEEXPORT_OT_ApplyScale,
    wahooney_collection_operators.ENGINEEXPORT_OT_ClearScale,
    wahooney_collection_operators.ENGINEEXPORT_OT_CreateOrigin,


    # collection tools

    wahooney_engine_export_collection_head.MakeActiveObjectSelectedCollectionHead,


    # nla tools (WIP)
    wahooney_nla_tools.UpdateNLA,


    # house keeping tools

    wahooney_instance_offset_to_selected.COLLECTION_OT_InstanceOffsetToSelected,
    wahooney_instance_offset_to_selected.COLLECTION_OT_InstanceOffsetToHead,
    wahooney_instance_offset_to_selected.OBJECT_OT_InstanceOffsetToHeadFromSelection,
    wahooney_instance_offset_to_selected.OBJECT_OT_SetupLodGroups,
    wahooney_collection_name_from_selected.ExportCollectionRename,


    # export tools

    wahooney_guess_export_path.GuessExportPath,
    wahooney_guess_export_path.GuessTextureExportPath,


    # export tools

    wahooney_engine_export.ExportCollections,
    wahooney_engine_export.ENGINEEXPORTSCENE_PT_Panel,
    wahooney_engine_export.ENGINEEXPORTOBJECT_PT_Properties,
    # wahooney_engine_export.ExportGroupsTextures,
    # wahooney_engine_export.ENGINEEXPORTSCENE_UL_export_collections,


    # rename rules

    wahooney_engine_export_rename.RenameRuleItem,
    wahooney_engine_export_rename.ENGINEEXPORTSCENE_UL_rename_rules,
    wahooney_engine_export_rename.ENGINEEXPORTSCENE_PT_RenameSubPanel,
    wahooney_engine_export_rename.ENGINEEXPORTSCENE_RENAME_MT_presets,
    wahooney_engine_export_rename.EngineExportAddRenameRule,
    wahooney_engine_export_rename.AddPresetEngineRename,


    # tools

    wahooney_engine_export_tools_panel.ENGINEEXPORTSCENE_PT_ToolsSubPanel,


    # animation track tools

    wahooney_engine_export_animation_tracks.ExportToolsAnimations,
    wahooney_engine_export_animation_tracks.ExportToolsAnimationActions,
    wahooney_engine_export_animation_tracks.ExportToolsAnimationAdvanced,
    wahooney_engine_export_animation_tracks.SortTracksByName,
    wahooney_engine_export_animation_tracks.FramesToStripTime,
    wahooney_engine_export_animation_tracks.AddSelectedActionsAsTracks,
    wahooney_engine_export_animation_tracks.RenameTracksFromStrips,
    wahooney_engine_export_animation_tracks.RemoveNLATracks,
    wahooney_engine_export_animation_tracks.RemoveAction,
    wahooney_engine_export_animation_tracks.AddActionAsNewTrack,
    wahooney_engine_export_animation_tracks.CopyAction,
    wahooney_engine_export_animation_tracks.GuessActionRange,
    wahooney_engine_export_animation_tracks.EngineExport_OT_strips_to_action_time,


    # preferences

    EngineExportAddonPreferences
)


addon_panels = [
    # (wahooney_engine_export_animation_tracks.draw_action_addons_dopesheet, bpy.types.DOPESHEET_PT_action),
    # (wahooney_engine_export_animation_tracks.draw_action_addons_nla, bpy.types.NLA_PT_action)
]


@persistent
def engine_exporter_sanitize_scene(file):

    scene = bpy.context.scene

    for func in bpy.app.handlers.load_post:
        if func.__name__ == 'engine_exporter_sanitize_scene':
            bpy.app.handlers.load_post.remove(func)

    active_collections = wahooney_engine_export.find_all_view_layer_collections(
        scene)

    for collection in active_collections:
        wahooney_engine_export.sanitize_collection(collection)

    # update versioning - don't elif do one step after the other
    if scene.engine_export_version < 1:

        for c in scene.engine_export_collections:
            c.name_method = 'AUTO' if c.auto_name else 'CUSTOM'

            if c.use_subpath and c.use_auto_subpath:
                c.path_modifier = 'COMBO'
            elif c.use_subpath:
                c.path_modifier = 'CUSTOM'
            elif c.use_auto_subpath:
                c.path_modifier = 'AUTO'

            if c.auto_offset:
                c.offset_method = 'PARENT' if c.use_parent_auto_offset else 'HEAD'
            else:
                c.offset_method = 'COLLECTION'

        scene.engine_export_version = 1
        print("== Engine Exporter: Updated to version 1 ==")

    for c in scene.engine_export_collections:
        if c.name_method == 'AUTO' and c.collection is not None and c.collection.name != c.name:
            print(F"== Engine Exporter: Renaming {c.collection.name} to {c.name} ==")
            c.name = c.collection.name

    bpy.app.handlers.load_post.append(engine_exporter_sanitize_scene)


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        km3d = kc.keymaps.new(name="Object Mode")

        # Quad unwrap
        kmi = km3d.keymap_items.new(
            'export.engine_export_collections', 'E', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.export_mode = 'SELECTION'
        kmi.properties.export_target = 'MESH'

        kmi = km3d.keymap_items.new(
            'export.engine_export_collections', 'E', 'PRESS', ctrl=True, shift=True, alt=True)
        kmi.properties.export_mode = 'SELECTION'
        kmi.properties.export_target = 'ALL'

        addon_keymaps.append(km3d)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            for kmi in km.keymap_items:
                km.keymap_items.remove(kmi)

            wm.keyconfigs.addon.keymaps.remove(km)

    # clear the list
    del addon_keymaps[:]


# update function to tag all info areas for redraw
def update(self, context):

    areas = context.window.screen.areas

    for area in areas:
        if area.type == 'INFO':
            area.tag_redraw()

    context.window.screen.update_tag()


engine_export_icons = {}


def create_icons():

    import os

    global engine_export_icons
    icons_directory = os.path.join(os.path.dirname(__file__), "icons")
    icons = (
        # list of icons
    )

    """
    Needed icon list
    ==================
    set_head
    collection_head
    
    do_export_on
    do_export_off

    subpath_none
    subpath_custom
    subpath_auto
    subpath_combo

    autoname_custom
    autoname_auto

    offset_collection
    offset_head
    offset_parent
    """

    for icon in icons:
        filename = os.path.join(icons_directory, f"engine.export.{icon}.dat")
        icon_value = bpy.app.icons.new_triangles_from_file(filename)
        engine_export_icons[icon] = icon_value


def release_icons():
    global engine_export_icons
    for value in engine_export_icons.values():
        bpy.app.icons.release(value)


def register():

    b_type = bpy.types
    b_scene = b_type.Scene
    b_object = b_type.Object
    b_collection = b_type.Collection
    # action = type.Action
    # nla_track = type.NlaTrack

    for c in classes:
        bpy.utils.register_class(c)

    # create_icons()

    register_keymaps()

    b_scene.apply_scale_options = EnumProperty(
        items=(('FBX_SCALE_NONE', "All Local",
                "Apply custom scaling and units scaling to each object transformation, FBX scale remains at 1.0"),
               ('FBX_SCALE_UNITS', "FBX Units Scale",
                "Apply custom scaling to each object transformation, and units scaling to FBX scale"),
               ('FBX_SCALE_CUSTOM', "FBX Custom Scale",
                "Apply custom scaling to FBX scale, and units scaling to each object transformation"),
               ('FBX_SCALE_ALL', "FBX All",
                "Apply custom scaling and units scaling to FBX scale"),
               ),
        name="Apply Scalings",
        description="How to apply custom and units scalings in generated FBX file "
        "(Blender uses FBX scale to detect units on import, "
        "but many other applications do not handle the same way)",
    )

    # scene ####################################################################

    b_scene.engine_export_version = IntProperty(
        name='Export Version', default=0, min=0)

    b_scene.engine_export_collections = CollectionProperty(
        name='Export Collections',
        description='List of all collections eligible for export',
        type=wahooney_engine_export_collection_manager.ExportCollectionItem)

    b_scene.engine_export_export_groups = CollectionProperty(
        name='Export Collections',
        description='List of all collections eligible for export',
        type=wahooney_engine_export_groups.ExportGroup)

    b_scene.engine_export_export_path = StringProperty(
        name='Export Path', description='Location to export files to', subtype='DIR_PATH')

    b_scene.engine_export_make_path = BoolProperty(
        name='Make Paths',
        description='Creates missing folders defined by export path and subpaths', default=True)

    b_scene.engine_export_use_libraries = BoolProperty(
        name='Export Libraries',
        description='Export externally linked collections', default=False)

    b_scene.engine_export_use_instances = BoolProperty(
        name='Export Instances',
        description='Export Instance-Types as meshes, disables all Instance-Types when off', default=False)

    b_scene.engine_export_hide_external_collections = BoolProperty(
        name='Hide External Groups',
        description='Hide collections that are linked to external files', default=True)

    b_scene.engine_export_only_export_action_objects = BoolProperty(
        name='Only include action objects',
        description='Only exports objects defined in the action objects list', default=True)

    b_scene.engine_export_forward_axis = EnumProperty(
        name='Direction',
        items=(('Z', "Forward", ""), ('-Z', "-Forward", "")), default='Z')

    b_scene.engine_export_global_scale = FloatProperty(
        name='Global Scale',
        default=1, min=0)

    b_scene.engine_export_active_export_collection_index = IntProperty(
        name='Active Export Collection Index',
        default=0, min=0)

    b_scene.engine_export_active_export_group_index = IntProperty(
        name='Active Export Group Index',
        default=0, min=0)

    b_scene.engine_export_target = EnumProperty(
        name='Export Target',
        description='Export target for this Blend file, overrides Global Export Target in Addon Preferences > Engine Export',
        items=(('DEFAULT', "Use Global Default", "Use project default target engine"),
               ('UNITY', "Unity", "Export meshes to Unity Engine"),
               ('UNREAL', "Unreal Engine", "Export meshes to Unreal Engine")),
        default='DEFAULT')

    b_scene.engine_export_format = EnumProperty(
        name='Export Format',
        items=(('FBX', "FBX", ""),
               ('USD', "USD (unsupported)",
                "Universal Scene Description. NOTE: Not fully supported by Blender yet"),
               ('GLTF', "GLTF", "")),
        default='FBX')

    b_scene.engine_export_evaluation_mode = EnumProperty(
        name='Evaluation Mode',
        description='Evaluation mode for this Blend file, USD only',
        items=(('RENDER', "Render", ""),
               ('VIEWPORT', "Viewport", "")),
        default='RENDER')

    b_scene.engine_export_nla_show_unused_actions = BoolProperty(
        name='Unused Actions Only', description='Hide actions used in tracks already',
        default=False,
        options={'SKIP_SAVE'})

    b_scene.engine_export_nla_use_loop_frame = BoolProperty(
        name='Loop frame', description='Use loop frame when setting frame time',
        default=True)

    b_scene.engine_export_expand_collection_details = BoolProperty(
        default=True)
    b_scene.engine_export_expand_export_details = BoolProperty(default=True)
    b_scene.engine_export_expand_objects_detail = BoolProperty(default=True)

    # property matrix ##########################################################

    b_scene.engine_export_matrix_show_path = BoolProperty(
        name='Show Path', default=True, options={'SKIP_SAVE'})

    b_scene.engine_export_matrix_show_origin = BoolProperty(
        name='Show Origin', default=False, options={'SKIP_SAVE'})

    b_scene.engine_export_matrix_show_animation = BoolProperty(
        name='Show Animation', default=False, options={'SKIP_SAVE'})

    b_scene.engine_export_matrix_show_export_type = BoolProperty(
        name='Show Export Type', default=False, options={'SKIP_SAVE'})

    b_scene.engine_export_matrix_show_expanded_matrix = BoolProperty(
        name='Show Expanded Options', default=False, options={'SKIP_SAVE'})

    # rename rules #############################################################

    b_scene.engine_export_active_rename_rule_index = IntProperty(
        name='Active Rename Rule',
        default=0, min=0)

    b_scene.engine_export_preview_renaming = BoolProperty(
        name='Show Renaming',
        description='Show Renaming options',
        default=False, options={'SKIP_SAVE'})

    b_scene.engine_export_rename_rules = bpy.props.CollectionProperty(
        name="Rename Rules",
        type=wahooney_engine_export_rename.RenameRuleItem)

    b_scene.engine_export_preview_renaming = BoolProperty(
        name='Preview Renaming',
        description='Preview renaming on current collection',
        default=False,
        options={'SKIP_SAVE'})

    b_scene.use_custom_exporter = BoolProperty(
        name='Use Custom Exporter',
        description='Use the old Unity Exporter with better y-up exporter',
        default=False)

    b_scene.engine_export_use_naming_convention = BoolProperty(
        name='Use Engine Naming Conventions',
        description='Enforce naming conventions for the target engine',
        default=True)

    # texture export ###########################################################

    b_scene.engine_export_texture_export_path = StringProperty(
        name='Export Path',
        description='Location to export files to',
        subtype='DIR_PATH')

    b_scene.engine_export_texture_guess_path_relative = BoolProperty(
        name='Relative Path',
        description='Guess path as relative',
        default=True)

    # objects ##################################################################

    b_object.engine_export_export = BoolProperty(
        name='Export Object',
        description='Include Object in Engine Export',
        default=True)

    b_object.engine_export_use_rename = BoolProperty(
        name='Rename on Export',
        description='Rename this object and data on export',
        default=False)

    b_object.engine_export_explicit_rename = StringProperty(
        name='Explicit Export Name',
        description='Force the object to be renamed to this value on export, '
                    'if blank it will fall back to regular expression renaming',
        default="")

    # collections ##############################################################

    b_collection.engine_export_head = PointerProperty(
        name='Collection Head',
        type=bpy.types.Object,
        description='Main object in the collection, used for collapsing.')

    # handlers #################################################################

    for func in bpy.app.handlers.load_post:
        if func.__name__ == 'engine_exporter_sanitize_scene':
            bpy.app.handlers.load_post.remove(func)

    for func in bpy.app.handlers.depsgraph_update_post:
        if func.__name__ == 'sanitize_collections':
            bpy.app.handlers.depsgraph_update_post.remove(func)

    bpy.app.handlers.load_post.append(engine_exporter_sanitize_scene)
    bpy.app.handlers.depsgraph_update_post.append(
        wahooney_engine_export.sanitize_collections)

    # panels ###################################################################

    for a in addon_panels:
        a[1].append(a[0])


def unregister():

    # release_icons()
    unregister_keymaps()

    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass

    for a in addon_panels:
        a[1].remove(a[0])


if __name__ == "__main__":
    register()
