# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from bpy.props import *
from bl_operators.presets import AddPresetBase
from bpy.types import Context, Menu, Panel, Operator, PropertyGroup

if "bpy" in locals():

    import importlib

    importlib.reload(wahooney_engine_export_functions)

else:

    import bpy

    from . import wahooney_engine_export_functions

startswith = wahooney_engine_export_functions.startswith
findstartswith = wahooney_engine_export_functions.findstartswith
is_exportable = wahooney_engine_export_functions.is_exportable

EXCLUSION_PREFIXES = wahooney_engine_export_functions.EXCLUSION_PREFIXES


# Export Collections


def updateCollection(self, context):

    if self.collection is not None:
        self.name = self.collection.name


class SplitExportTrackOptions(bpy.types.PropertyGroup):

    animated_object: PointerProperty(type=bpy.types.Object)

    use_split: BoolProperty(
        name='Split Nla Track to File',
        description='Export this track to its own file, will be excluded from the main file',
        default=True, options=set())

    do_export: BoolProperty(
        name='Export NLA Track to File',
        description='Enable the export of this track, useful if you want to export specific tracks',
        default=True, options=set())

    is_static: BoolProperty(
        name='Is Static Track',
        description='A static track is always enabled, so it should be at the bottom of your NLA stack. '
                    'This can fix some animation errors when performing partial or additive animations',
        default=False, options=set())


class SplitExportOptions(bpy.types.PropertyGroup):

    track_object: PointerProperty(
        type=bpy.types.Object, options=set())

    include_in_split: BoolProperty(
        name='Use object in split track',
        description='When splitting animations to a new file, only include objects with this value enabled',
        default=False, options=set())


class ExportCollectionItem(PropertyGroup):

    do_export: BoolProperty(
        name="Do Export",
        description="Export this collection",
        default=True, options=set())

    is_utility_collection: BoolProperty(
        name="Is Utility Collection",
        description="This collection won't be exported by hotkeys or batch operations, will need to be explicitly exported in collection panel.",
        default=False, options=set())

    collection: PointerProperty(
        type=bpy.types.Collection, name="Collection",
        description="Collection to export", update=updateCollection, options=set())

    name_method: EnumProperty(name='Name Method', items=(
        ('AUTO', "Auto Name", "Use the collection name", 'AUTO', 0),
        ('CUSTOM', "Custom Name", "Use a custom name", 'GREASEPENCIL', 1)),
        default='AUTO', options=set())

    auto_name: BoolProperty(
        name='Auto Name',
        description='Auto name export collection to collection',
        default=True, update=updateCollection, options=set())

    use_instances: BoolProperty(
        name='Use Instances',
        description='Collapse instance types on meshes and empties before export',
        default=False, options=set())

    path_modifier: EnumProperty(name='Path Modifier', items=(
        ('NONE', 'No SubPath', 'Do not modify path', 'BLANK1', 0),
        ('AUTO', 'Auto SubPath',
         'Modify the path based on the collections parents', 'AUTO', 1),
        ('CUSTOM', 'Custom Path', 'Use a custom path', 'GREASEPENCIL', 2),
        ('COMBO', 'Combine Paths', 'Add custom path name after parent collection path', 'AUTOMERGE_ON', 3)),
        default='AUTO', options=set())

    subpath: StringProperty(
        name='Export Subpath',
        description='Location prefix to file name.\nNote: You must include your own path separators, ie. /Characters/',
        options=set())

    use_subpath: BoolProperty(
        name='Use Export Subpath',
        description='Use the subpath on this collection',
        default=False, options=set())

    use_auto_subpath: BoolProperty(
        name='Use Auto Export Subpath',
        description='Use the subpath as defined by parent collections subfolder setting when exporting this collection',
        default=True, options=set())

    # structure
    head: PointerProperty(
        type=bpy.types.Object,
        name='Head',
        description='Main object in the collection, used for collapsing, offsetting and naming (optional)', options=set())

    export_type: EnumProperty(
        name='Export Type',
        items=(('COLLECTION', "Keep Separate", "Export objects as they are in the collection without collapsing, your target engine may or may not automatically collapse the objects when importing", "POINTCLOUD_DATA", 0),
               ('COLLAPSED',  "Collapse Objects",
                F"Collapse all objects into a collection to a single object, excludes objects with {' '.join(EXCLUSION_PREFIXES)} prefixes", "FUND", 1),
               # ('CHILDREN', "Child Collections", "Export all child collections as separate files, requires that each collection has a single root object.", "GROUP", 2)
               ),
        default='COLLECTION', options=set())

    export_format: EnumProperty(
        name='Export Format',
        items=(('PROJECT', "Project Default", "Uses the same format as the rest of the project"),
               ('FBX', "FBX", "Export as FBX"),
               ('GLTF', "GLTF", "Export as GLTF"),
               ('USD', "USD", "Export as USD")),
        default='PROJECT', options=set())

    offset_method: EnumProperty(
        name='Offset Method',
        items=(
            ('NONE', 'No Offset', 'Do not offset', 'BLANK1', 0),
            ('HEAD', 'Head Offset', 'Offset to the collection head. Requires a head object, falls back to collection offset if no head is set', 'USER', 1),
            ('PARENT', 'Parent Offset', 'Offset to the collection heads parent. Requires a head object with a parent, falls back to head, then collection offset', 'ORIENTATION_PARENT', 2),
            ('OBJECT', 'Object Offset',
             'Offset the collection by an arbitrary object, either inside the collection or outside', 'OBJECT_ORIGIN', 3),
            ('COLLECTION', 'Collection Offset',
             'Use collections instance offset', 'OUTLINER_COLLECTION', 4),
            # ('CUSTOM', 'Custom Offset', 'Use a custom offset', '', 'BLANK1', 5) #TODO
        ),
        default='HEAD', options=set())

    offset_target_object: PointerProperty(
        type=bpy.types.Object,
        name='Offset Target Object',
        description='Object to use for offset', options=set())

    use_rotation_offset: BoolProperty(name='Use Rotation Offset',
                                      description='Rotate this export collection by the inverse of the object used for location offsets',
                                      default=False)

    auto_offset: BoolProperty(
        name="Auto Offset",
        description="Centers the exported file on the collection Head if it is set",
        default=True, options=set())

    use_parent_auto_offset: BoolProperty(
        name="Auto Offset to Parent",
        description="Centers the exported file on the collection Heads parent if it is set",
        default=False, options=set())

    # animation
    anim_subpath: StringProperty(
        name='Export Animation Subpath',
        description='Location prefix to file name when splitting animations.\nNote: You must include your own path separators, ie. /Animations/', options=set())

    static_action: StringProperty(
        name='Static Action',
        description='Static(Rest Pose) action for object export',
        default="", options=set())

    animation: BoolProperty(
        name='Export Animation',
        description='Export Animation in this collection',
        default=True, options=set())

    optimize: BoolProperty(
        name='Optimize Animation',
        description='Optimize Animation in this collection',
        default=True, options=set())

    disable_blend_shapes: BoolProperty(
        name='Disable Blend Shapes',
        description='Zero all blend shapes in this collection',
        default=True, options=set())

    split_nla_tracks: CollectionProperty(
        type=SplitExportTrackOptions, options=set())

    split_nla_tracks_objects: CollectionProperty(
        type=SplitExportOptions, options=set())


def findAllChildLayers(collection, collections):
    for c in collection.children:
        if len(c.collection.objects) > 0:
            collections.append(c)
        collection = findAllChildLayers(c, collections)

    return collections


def findAllViewLayerCollections(scene):
    collections = []
    if (len(scene.view_layers) > 0):
        layer_collection = scene.view_layers[0].layer_collection
        return findAllChildLayers(layer_collection, collections)
    return collections


def addExportCollection(self, context, operation):

    scene = context.scene
    collections = findAllViewLayerCollections(scene)

    scene.engine_export_active_export_collection_index = min(
        len(scene.engine_export_collections)-1,
        max(0, scene.engine_export_active_export_collection_index))

    result = None

    if operation == 'ADD_SUBFOLDER':

        context.collection['export_subpath'] = ''
        # context.collection.id_properties_ui('export_subpath').update()
        # 'Name to use when exporting children of this collection, defaults to collection name when left blank'

    elif operation == 'REMOVE_SUBFOLDER':

        del context.collection['export_subpath']

    elif operation == 'RENDER':

        for view_collection in collections:
            collection = view_collection.collection

            do_continue = False

            if collection.hide_render:
                continue

            for export_collection in scene.engine_export_collections:
                if export_collection.collection == collection:
                    do_continue = True
                    break

            if do_continue:
                continue

            new_collection = scene.engine_export_collections.add()
            new_collection.collection = collection
            new_collection.name = collection.name

            if collection.name in collection.objects:
                new_collection.head = collection.objects[collection.name]

            new_collection.do_export = True

    elif operation == 'CLEAR':

        scene.engine_export_collections.clear()

    elif operation == 'LEGACY':

        for view_collection in collections:
            collection = view_collection.collection

            if not collection.engine_export_export:
                continue

            do_continue = False

            for export_collection in scene.engine_export_collections:
                if (export_collection.collection == collection):
                    do_continue = True
                    break

            if do_continue:
                continue

            new_collection = scene.engine_export_collections.add()
            new_collection.collection = collection

            new_collection.subpath = collection.engine_export_subpath
            new_collection.do_export = collection.engine_export_export
            new_collection.static_action = collection.engine_export_static_action

            new_collection.export_type = collection.engine_export_export_type
            new_collection.animation = collection.engine_export_animation
            new_collection.optimize = collection.engine_export_optimize
            new_collection.disable_blend_shapes = collection.engine_export_disable_blend_shapes

    elif operation == 'REMOVE_ACTIVE':

        if len(scene.engine_export_collections) > 0:
            scene.engine_export_collections.remove(
                scene.engine_export_active_export_collection_index)

    elif operation == 'AUTO_NAME':
        source = scene.engine_export_collections[scene.engine_export_active_export_collection_index]
        if source.collection is not None:
            source.name = source.collection.name

    elif operation == 'ADD':

        result = scene.engine_export_collections.add()
        scene.engine_export_active_export_collection_index = len(
            scene.engine_export_collections) - 1

    elif operation == 'ADD_ACTIVE':

        if context.collection is not None:
            result = scene.engine_export_collections.add()
            scene.engine_export_active_export_collection_index = len(
                scene.engine_export_collections) - 1
            source = scene.engine_export_collections[scene.engine_export_active_export_collection_index]
            source.collection = context.collection
            source.name = source.collection.name

            if self.explicit_head:
                source.head = SCENE_OT_engine_export_modify_collection.collection_map[self.selected]

            else:
                if source.name in source.collection.objects:
                    source.head = source.collection.objects[source.name]

                elif len(source.collection.objects) == 1:
                    source.head = source.collection.objects[0]

                elif len(source.collection.objects) > 1:
                    for obj in source.collection.objects:
                        if not is_exportable(obj):
                            continue

                        source.head = obj

                        break

            if source.head is not None:

                if self.auto_rename == 'HEAD':
                    original_name = source.head.name
                    source.head.name = source.name

                    data = source.head.data
                    only_one_user = data.users == 1 or (data.users == 2 and data.use_fake_user)

                    if not data.name.startswith("__") and (data.name == original_name or (data.name not in bpy.data.objects and only_one_user)):
                        data.name = source.name

                if self.auto_rename == 'COLLECTION':
                    source.collection.name = source.head.name
                    source.name = source.head.name

    elif operation == 'ADD_ACTIVE_OBJECT':

        if context.active_object is not None and context.active_object.users_collection[0] is not None:

            result = scene.engine_export_collections.add()
            scene.engine_export_active_export_collection_index = len(
                scene.engine_export_collections) - 1
            source = scene.engine_export_collections[scene.engine_export_active_export_collection_index]
            source.collection = context.active_object.users_collection[0]
            source.name = source.collection.name

            source.head = context.active_object

    elif operation == 'INSERT':

        index = scene.engine_export_active_export_collection_index
        collections = scene.engine_export_collections

        result = collections.add()
        collections.move(len(collections) - 1, index)

    elif operation == 'SORT':

        map = {}
        name_list = []
        i = 0

        for i, c in enumerate(scene.engine_export_collections):
            name = wahooney_engine_export_functions.get_collection_exportpath(
                c) + c.name
            name_list.append(name)
            map[name] = c.name

            i += 1

        name_list.sort()
        name_list.reverse()

        for n in name_list:
            i = scene.engine_export_collections.find(map[n])
            scene.engine_export_collections.move(i, 0)

    elif operation == 'DUPLICATE':

        destination = scene.engine_export_collections.add()
        source = scene.engine_export_collections[scene.engine_export_active_export_collection_index]

        copy_data(self, source, destination)
        scene.engine_export_collections.move(len(scene.engine_export_collections) - 1,
                                             scene.engine_export_active_export_collection_index)

        result = destination

    elif operation == 'MOVE_DOWN':

        index = scene.engine_export_active_export_collection_index
        scene.engine_export_active_export_collection_index += 1

    elif operation == 'MOVE_UP':

        index = scene.engine_export_active_export_collection_index
        scene.engine_export_collections.move(index, index - 1)
        scene.engine_export_active_export_collection_index -= 1

    scene.engine_export_active_export_collection_index = min(
        len(scene.engine_export_collections)-1,
        max(0, scene.engine_export_active_export_collection_index))

    return result


def moveExportCollection(self, context, up):

    scene = bpy.context.scene
    index = scene.engine_export_active_export_collection_index

    if not up:
        scene.engine_export_collections.move(index, index + 1)
        scene.engine_export_active_export_collection_index += 1
    else:
        scene.engine_export_collections.move(index, index - 1)
        scene.engine_export_active_export_collection_index -= 1


def copy_data(self, source, destination):
    for p in source.__annotations__.keys():
        try:
            setattr(destination, p, getattr(source, p))
        except:
            pass


def modify_collection_list(self, context):
    return SCENE_OT_engine_export_modify_collection.collection_list


class SCENE_OT_engine_export_modify_collection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_modify_collection"
    bl_label = "Modify Export Collection"
    bl_description = "Modify Collection for Export"
    bl_options = {'REGISTER', 'UNDO'}

    auto_rename: EnumProperty(
        items=(('NONE', 'None', 'Do not auto-rename'),
               ('COLLECTION', 'Collection',
                'Rename collection to the active object'),
               ('HEAD', 'Head', 'Rename the active object to the collection')),
        default='NONE')

    explicit_head: BoolProperty(default=False)

    selected: EnumProperty(items=modify_collection_list)

    operation: EnumProperty(
        items=(
            ('NONE', 'None', 'Perform no batch operations'),
            ('ADD', 'Add', 'Add an export collection'),
            ('ADD_ACTIVE', 'Add Active Collection',
             'Add the active collection as an export collection'),
            ('ADD_ACTIVE_OBJECT', 'Add Active Object',
             'Add the active object and it''s collection as an export collection'),
            ('SORT', 'Sort', 'Sort collections by subpath then name'),
            ('DUPLICATE', 'Duplicate', 'Duplicate the active export collection'),
            ('MOVE_UP', 'Move Up', 'Move the collection up the list'),
            ('MOVE_DOWN', 'Move Down', 'Move the collection down the list'),
            ('REMOVE_ACTIVE', 'Remove', 'Remove active export collection'),
            ('AUTO_NAME', 'Auto-Name', 'Rename export name to referenced collection'),
            ('ADD_SUBFOLDER', 'Mark As Subfolder',
             'Mark active collection as subfolder'),
            ('REMOVE_SUBFOLDER', 'Unmark As Subfolder',
             'Unmark active collection as subfolder'),
            ('RENDER', 'Add Renderable Collections',
             'Batch add renderable collections in the current scene'),
            ('CLEAR', 'Clear all collections',
             'Remove all collections'),
            ('LEGACY', 'Add Legacy Collections',
             'Batch add legacy collections, with their properties')
        ),
        default='NONE')

    collection_list = []
    collection_map = {}

    @classmethod
    def description(cls, context, properties):

        if properties.operation == 'ADD':
            return 'Add an export collection'

        if properties.operation == 'ADD_ACTIVE':
            return "Add '%s' for export" % (context.collection.name)

        if properties.operation == 'ADD_ACTIVE_OBJECT':
            return "Add '%s' and it's collection '%s'" % (context.active_object, context.active_object.users_collection[0].name)

        if properties.operation == 'SORT':
            return 'Sort collections by subpath then name'

        if properties.operation == 'DUPLICATE':
            return 'Duplicate the active export collection'

        if properties.operation == 'MOVE_UP':
            return 'Move the collection up the list'

        if properties.operation == 'MOVE_DOWN':
            return 'Move the collection down the list'

        if properties.operation == 'REMOVE_ACTIVE':
            return 'Remove active export collection'

        if properties.operation == 'ADD_SUBFOLDER':
            return 'Mark active collection as subfolder for the export collections in its hierarchy'

        if properties.operation == 'REMOVE_SUBFOLDER':
            return 'Unmark active collection as subfolder for the export collections in its hierarchy'

        if properties.operation == 'RENDER':
            return 'Batch add renderable collections in the current scene'

        if properties.operation == 'CLEAR':
            return 'Remove all collections'

        if properties.operation == 'LEGACY':
            return 'Batch add legacy collections, with their properties'

        return 'Perform no batch operations'

    def invoke(self, context, event):

        if self.operation == 'ADD_ACTIVE':
            if context.collection.name not in context.collection.objects:

                SCENE_OT_engine_export_modify_collection.collection_list = [(c.name, c.name, c.name)
                                                                            for c in context.collection.objects if not startswith(c.name, EXCLUSION_PREFIXES)]
                print(self.collection_list)

                for c in context.collection.objects:
                    SCENE_OT_engine_export_modify_collection.collection_map[c.name] = c

                self.explicit_head = True
                return context.window_manager.invoke_props_dialog(self)

        self.explicit_head = False
        self.auto_rename = 'NONE'
        return self.execute(context)

    def execute(self, context):
        addExportCollection(self, context, self.operation)
        return {'FINISHED'}

    def draw(self, context: Context):

        if self.operation != 'ADD_ACTIVE':
            return

        layout = self.layout

        if len(context.collection.objects) > 0:
            col = layout.column(align=True)
            col.prop(self, 'selected', expand=True)

        layout.label(text='Rename')
        row = layout.row(align=True)
        row.prop(self, 'auto_rename', expand=True)

        box = layout.box()
        if self.auto_rename == 'HEAD':
            box.label(text='Head will be renamed to match collection')

        elif self.auto_rename == 'COLLECTION':
            box.label(text='Collection will be renamed to match head')

        else:
            box.label(text='No renaming will occur')


class EngineExportAddExportCollection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_add_collection"
    bl_label = "Add Export Collection"
    bl_description = "Add Collection for Export"

    def execute(self, context):
        addExportCollection(self, context, 'ADD')
        return {'FINISHED'}


class EngineExportAddLegacyCollections(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_add_legacy_collections"
    bl_label = "Add Legacy Collections"
    bl_description = "Add Legacy Collections as Export Collections"

    def execute(self, context):
        addExportCollection(self, context, self.operation)
        return {'FINISHED'}


class EngineExportReorderCollection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_reorder_collection"
    bl_label = "Reorder Active Collections"
    bl_description = "Moves the active export collection up or down the list"

    up: BoolProperty(default=True)

    def execute(self, context):
        moveExportCollection(self, context, self.up)
        return {'FINISHED'}


class EngineExportAddRenderableCollections(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_add_renderable_collections"
    bl_label = "Add Renderable Collections"
    bl_description = "Add Renderable Collections as Export Collections"

    def execute(self, context):
        addExportCollection(self, context, self.operation)
        return {'FINISHED'}


class EngineExportRemoveExportCollection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_remove_collection"
    bl_label = "Remove Export Collection"
    bl_description = "Remove active Export Collection"

    def execute(self, context):
        addExportCollection(self, context, 'REMOVE_ACTIVE')
        return {'FINISHED'}


class EngineExportClearExportCollections(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_clear_collections"
    bl_label = "Clear Export Collection"
    bl_description = "Remove all Export Collections"

    def execute(self, context):
        addExportCollection(self, context, 'CLEAR')
        return {'FINISHED'}


class EngineExportDuplicateExportCollection(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_duplicate_collection"
    bl_label = "Duplicate Export Collection"
    bl_description = "Duplicate Export Collection"


class ENGINEEXPORTSCENE_UL_collections(bpy.types.UIList):

    use_filter_selection: BoolProperty(default=False)
    use_filter_visible: BoolProperty(default=False)

    @staticmethod
    def filter_items_by_name_i(pattern, bitflag, items, propname="name", flags=None, reverse=False):
        """
        Set FILTER_ITEM for items which name matches filter_name one (case-insensitive).
        pattern is the filtering pattern.
        propname is the name of the string property to use for filtering.
        flags must be a list of integers the same length as items, or None!
        return a list of flags (based on given flags if not None),
        or an empty list if no flags were given and no filtering has been done.
        """
        import fnmatch

        if not pattern or not items:  # Empty pattern or list = no filtering!
            return flags or []

        if flags is None:
            flags = [0] * len(items)

        # Implicitly add heading/trailing wildcards.
        pattern = "*" + pattern + "*"

        for i, item in enumerate(items):
            name = getattr(item, propname, None)
            # This is similar to a logical xor
            if bool(name and fnmatch.fnmatch(name, pattern)) is not bool(reverse):
                flags[i] |= bitflag
        return flags

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        collection = item

        if self.layout_type in {'DEFAULT', 'COMPACT'}:

            row = layout.row(align=True)

            scene = context.scene

            if collection.head is not None and startswith(collection.head.name, EXCLUSION_PREFIXES):
                row.label(icon='ERROR', text='')
            elif collection.head is not None and collection.head.parent is not None and collection.head.parent.type == 'MESH':
                row.label(icon='ERROR', text='')
            else:
                row.label(icon='DECORATE', text='')

            row.prop(collection, 'do_export', icon='EXPORT', text='')
            row.separator()

            if scene.engine_export_matrix_show_path:

                row.prop(collection, 'path_modifier', text='',
                         expand=scene.engine_export_matrix_show_expanded_matrix)

                if (collection.path_modifier == 'AUTO' or collection.path_modifier == 'COMBO') and collection.collection is not None:
                    row.label(
                        text=wahooney_engine_export_functions.get_collection_exportpath(collection))

                if collection.path_modifier == 'CUSTOM' or collection.path_modifier == 'COMBO':
                    row.prop(collection, 'subpath',
                             icon='FILE_FOLDER', text='')

            if scene.engine_export_matrix_show_origin:

                row2 = row.row(align=True)
                row2.prop(collection, 'offset_method', text='')

            if collection.name != '' and not collection.auto_name:
                row.prop(collection, 'name', icon='COPY_ID', text='')

            # row.prop(collection, 'auto_name', icon='AUTO', text='')
            row.label(text='', icon=(
                'BLANK1' if collection.head is None else 'USER'))

            row.prop(collection, 'collection', icon='GROUP' if collection.export_type ==
                     'COLLECTION' else 'APPEND_BLEND', text='')

            if scene.engine_export_matrix_show_export_type:
                row.prop(collection, 'export_type', text='',
                         expand=scene.engine_export_matrix_show_expanded_matrix)

            if scene.engine_export_matrix_show_animation:
                row.prop(collection, 'disable_blend_shapes',
                         icon='SHAPEKEY_DATA', text='')

                row.prop(collection, 'animation', icon='ANIM', text='')

                row = row.row(align=True)
                row.active = collection.animation
                row.prop(collection, 'optimize', icon='MOD_SIMPLIFY', text='')

        # 'GRID' layout type should be as compact as possible(typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)

    def draw_filter(self, context, layout):

        # Nothing much to say here, it's usual UI code...
        row = layout.row(align=True)

        # row = row.row(align=True)
        row.prop(self, "filter_name", text="")
        icon = 'SELECT_DIFFERENCE' if self.use_filter_invert else 'SELECT_INTERSECT'
        row.separator()
        row.prop(self, "use_filter_invert", text="", icon=icon)

        # row = layout.row(align=True)
        row.separator()
        row.prop(self, "use_filter_sort_alpha", text='', toggle=True)
        icon = 'SORT_DESC' if self.use_filter_sort_reverse else 'SORT_ASC'
        row.prop(self, "use_filter_sort_reverse", text="", icon=icon)

        row.separator()
        row.label(text="", icon='FILTER')
        row.prop(self, "use_filter_selection",
                 text="", icon='RESTRICT_SELECT_OFF')
        row.prop(self, "use_filter_visible", text="", icon='HIDE_OFF')

    def filter_items(self, context, data, propname):

        collections = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list
        rules = [c.collection for c in collections]

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Filtering by name
        if self.filter_name:
            flt_flags = ENGINEEXPORTSCENE_UL_collections.filter_items_by_name_i(
                self.filter_name, self.bitflag_filter_item, rules, "name", reverse=False)

        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(rules)

        if self.use_filter_selection:
            for i, collection in enumerate(rules):
                if collection is None or all(not elem[1].select_get() for elem in collection.all_objects.items()):
                    flt_flags[i] = 0

        if self.use_filter_visible:
            for i, collection in enumerate(rules):
                if collection is None or all(not elem[1].visible_get() for elem in collection.all_objects.items()):
                    flt_flags[i] = 0

        # Reorder by name or average weight.
        if self.use_filter_sort_alpha:
            flt_neworder = helper_funcs.sort_items_by_name(rules, "name")

        return flt_flags, flt_neworder
