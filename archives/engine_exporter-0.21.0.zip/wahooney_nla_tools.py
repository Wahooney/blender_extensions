# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
import os


def update_nla(context):

    active = bpy.context.active_object

    # remove empty tracks first
    tracks = active.animation_data.nla_tracks
    for t in tracks:

        # always skip locked tracks
        if t.lock:
            continue

        if len(t.strips) == 0:
            tracks.remove(t)

    tracks = active.animation_data.nla_tracks

    # inverse sort actions
    actions = list(a for a in bpy.data.actions)
    actions.sort(key=lambda x: x.name, reverse=True)

    for t in tracks:

        # always skip locked tracks
        if t.lock:
            continue

        if len(t.strips) == 0:
            tracks.remove(t)
        else:
            while len(t.strips) > 1:
                t.strips.remove(t.strips[1])

            if not t.strips[0].action is None:
                actions.remove(t.strips[0].action)

    for action in actions:
        track = tracks.new()
        strip = track.strips.new(name=action.name, start=1, action=action)
        track.name = action.name

    for t in tracks:
        for s in t.strips:
            s.name = s.action.name
            t.name = s.action.name
            print(t.name)


class UpdateNLA(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_update_nla"
    bl_label = "Update NLA"
    bl_description = "Pull all NLA data from actions"

    def execute(self, context):
        update_nla(context)
        return {'FINISHED'}
