# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
from mathutils import Vector

if "bpy" in locals():

    import importlib

    importlib.reload(wahooney_engine_export_functions)

else:

    import bpy

    from . import wahooney_engine_export_functions


startswith = wahooney_engine_export_functions.startswith
findstartswith = wahooney_engine_export_functions.findstartswith
EXCLUSION_PREFIXES = wahooney_engine_export_functions.EXCLUSION_PREFIXES


def get_operator(idname):
    op = bpy.ops
    for attr in idname.split("."):
        op = getattr(op, attr)
    return op


def draw_collection_objects(objects, layout_col, collection):

    for o in objects:

        is_split = False

        row = layout_col.row(align=True)

        row.prop(o, 'engine_export_export', emboss=True, text='', icon='EXPORT')
        row.prop(o, 'name', text='', icon='CON_CHILDOF' if not o.name in objects else 'OBJECT_DATA')

        if o.data != None:
            row.prop(o.data, 'name', text='', icon='MESH_DATA')
        elif o.instance_type == 'COLLECTION' and o.instance_collection != None:
            row.prop(o, 'instance_collection', text='', icon='OUTLINER_COLLECTION')

        row.prop(o, 'engine_export_use_rename',
                    text='', icon='FILE_TEXT')

        # tuple of type: warning message, array of fixes
        warnings = []

        if o.scale != Vector((1, 1, 1)):
            warnings.append((F'Object is Scaled',
                            ['engine_export.clear_scale', 'engine_export.apply_scale']))

        if o.animation_data is not None and o.animation_data.action is not None and o.type != 'ARMATURE':
            warnings.append((F'Non-armature animated',
                            ['engine_export.clear_animation_data']))

        if len(warnings) > 0:
            warn = layout_col.column(align=True)
            warn.alert = True
            warn.context_pointer_set('active_object', o)

            for warning in warnings:
                wrow = warn.row(align=True)
                wrow.label(text='', icon='BLANK1')
                wrow.label(text=warning[0], icon='ERROR')

                for fix in warning[1]:
                    if get_operator(fix).poll():
                        wrow.operator(fix)

            layout_col.separator()

        if o.engine_export_use_rename:
            layout_col.prop(o, 'engine_export_explicit_rename', text='', icon='FILE_TEXT')

        if collection is not None:
            if collection.animation and o.name in collection.split_nla_tracks_objects:
                row.prop(collection.split_nla_tracks_objects[o.name], 'include_in_split', icon='ANIM', icon_only=True)

            if collection.animation and o.animation_data is not None:
                row = row.row(align=True)
                row.alignment = 'LEFT'

                for nla in o.animation_data.nla_tracks:

                    track = collection.split_nla_tracks[nla.name]

                    row = layout_col.row(align=True)
                    row.label(icon='BLANK1')

                    subrow = row.row(align=True)
                    subrow.active = not track.is_static

                    if nla.name in collection.split_nla_tracks:
                        is_split = is_split or collection.split_nla_tracks[nla.name].use_split
                    else:
                        continue  # wtf?

                    subrow.prop(collection.split_nla_tracks[nla.name], 'do_export',
                                icon='EXPORT',
                                icon_only=True,
                                emboss=True, toggle=False)

                    subrow.prop(nla, 'mute',
                                icon='MUTE_IPO_OFF' if nla.mute else 'MUTE_IPO_ON',
                                text='',
                                emboss=True, invert_checkbox=True, toggle=False)

                    subrow.label(text=nla.name)

                    subrow.prop(collection.split_nla_tracks[nla.name], 'use_split',
                                icon='FILE_TICK',
                                icon_only=True,
                                emboss=True, toggle=False)

                    row.prop(collection.split_nla_tracks[nla.name], 'is_static',
                             icon='FREEZE',
                             icon_only=True,
                             emboss=True, toggle=False)

    if is_split:

        layout_col.separator()

        row = layout_col.row(align=True)
        row.label(icon='BLANK1')
        row.prop(collection, 'anim_subpath', text='', icon='FILE_FOLDER')

        layout_col.separator()


def draw_collection(self, context, export_data):

    layout = self.layout
    scene = context.scene

    modify_collection = self.modify_collection

    if export_data is not None and export_data.collection is not None:

        layout.separator()
        box = layout.box()

        subpath = wahooney_engine_export_functions.get_collection_exportpath(export_data)
        if export_data.name != '':
            filename = wahooney_engine_export_functions.add_prefix(context, export_data.name, False)
        else:
            filename = wahooney_engine_export_functions.add_prefix(context, export_data.collection.name, False)

        details_panel = box.panel_prop(context.scene, 'engine_export_expand_collection_details')
        details_panel[0].label(text=os.path.join(subpath, filename), icon='GROUP')

        if details_panel[1] is not None:

            if modify_collection:
                box.prop(export_data, 'collection', icon='GROUP')

            row = box.row()
            row.active = False
            row.prop(context.scene, 'engine_export_export_path')

            box.prop(export_data, 'is_utility_collection', icon='GHOST_ENABLED' if export_data.is_utility_collection else 'GHOST_DISABLED')

            # Name
            col = box.column(align=True)
            box2 = col.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Name")
            col2 = row.column(align=True)
            col2.prop(export_data, 'name_method', text='')

            if export_data.name_method == 'CUSTOM':
                col2.prop(export_data, 'name', icon='COPY_ID', text='')
            else:
                col2.label(text=export_data.collection.name, icon='COPY_ID')

            # Subpath
            col = box.column(align=True)
            box2 = col.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Path")
            col2 = row.column(align=True)
            col2.prop(export_data, 'path_modifier', text='')

            if export_data.path_modifier == 'CUSTOM':
                col2.prop(export_data, 'subpath', text='', icon='FILE_FOLDER')
            elif export_data.path_modifier == 'COMBO':
                col2.label(text=wahooney_engine_export_functions.get_collection_exportpath(export_data))
                col2.prop(export_data, 'subpath', text='', icon='FILE_FOLDER')
            else:
                col2.label(text=wahooney_engine_export_functions.get_collection_exportpath(export_data),
                           icon='FILE_FOLDER')

            # head object
            box2 = box.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Head Object")
            col2 = row.column(align=True)
            col2.prop_search(export_data, 'head', export_data.collection, 'all_objects', text='')

            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Export Offset")
            col2 = row.column(align=True)
            col2.prop(export_data, 'offset_method', text='')

            if export_data.collection is not None:
                col3 = col2.column(align=True)

                if export_data.offset_method == 'COLLECTION' or export_data.head is None:
                    col3.active = True
                    col3.prop(export_data.collection, 'instance_offset')

                elif export_data.offset_method == 'OBJECT':
                    col3.prop(export_data, 'offset_target_object', text='')
                    if export_data.offset_target_object is not None:
                        subcol = col3.column(align=True)
                        subcol.active = False
                        subcol.prop(export_data.offset_target_object, 'location', text='')

                elif export_data.head is not None:
                    col3.active = False
                    if export_data.offset_method == 'PARENT':
                        if export_data.head.parent is not None:
                            col3.prop(export_data.head.parent, 'location', text='')
                        else:
                            col3.label(text='No parent, expect weirdness', icon='ERROR')
                    elif export_data.offset_method == 'HEAD':
                        if export_data.head is not None:
                            col3.prop(export_data.head, 'location', text='')
                        else:
                            col3.label(text='Head, expect weirdness', icon='ERROR')

                if export_data.offset_method != 'COLLECTION' and export_data.head:
                    col2.prop(export_data, 'use_rotation_offset')

                # origin object add
                if export_data.offset_target_object is None:
                    col2.operator('engine_export.create_origin').collection_name = export_data.name

            # instance
            col = box.box()
            col.use_property_split = True
            col.prop(export_data, 'use_instances')

            # collapse
            col.prop(export_data, 'export_type')

            if export_data.export_type == 'COLLAPSED':

                # if collection.head is None:
                #    pass

                if export_data.head is not None and export_data.head.name in export_data.collection.all_objects and wahooney_engine_export_functions.pure_curve(export_data.head):
                    col.label(text=F'{export_data.head.name} is not a valid collapse head', icon='ERROR')

            elif export_data.export_type == 'CHILDREN':
                for c in export_data.collection.children:
                    objects = [o for o in c.objects if o.engine_export_export and not startswith(o.name, EXCLUSION_PREFIXES) and o.parent is None]
                    if len(objects) != 1 and c.name not in c.objects:
                        row = col.row()
                        row.alert = True
                        row.label(text=F'{c.name} needs exactly one root object, found {len(objects)} or an object that matches the collection name exactly', icon='ERROR')

            if export_data.head is not None and startswith(export_data.head.name, EXCLUSION_PREFIXES):

                prefix = findstartswith(export_data.head.name, EXCLUSION_PREFIXES)
                row = col.row()
                row.alert = True
                row.label(text=F"'{export_data.name}' has a {prefix} head, this will not export.", icon='ERROR')

            if export_data.head is not None and export_data.head.parent is not None and export_data.head.parent.type == 'MESH':
                row = col.row()
                row.alert = True
                row.label(text=F"The head of '{export_data.name}' is parented to another mesh '{export_data.head.parent.name}', this could cause problems.", icon='ERROR')

            # format
            col.prop(export_data, 'export_format')

        # animation
        if export_data.export_type == 'CHILDREN':
            ccol = box.box()
            ccol.label(text='Animation is disabled when export type is Child Collections', icon='ANIM')
        else:
            # box.separator()
            row = box.row(align=True)
            row.prop(export_data, 'animation', toggle=True, icon='ANIM')
            col = row.column(align=True)
            col.active = export_data.animation
            col.prop(export_data, 'optimize', toggle=True, icon='MOD_SIMPLIFY')

        # show objects
        col = box.column(align=True)

        if modify_collection:
            object_panel = col.panel_prop(scene, 'engine_export_expand_objects_detail')
            object_panel[0].label(text='Export Objects', icon='OBJECT_DATA')

            if object_panel[1] is not None:
                col = object_panel[1].column(align=True)
            else:
                col = None

        if col is not None and scene.engine_export_expand_objects_detail or not modify_collection:

            if export_data.export_type == 'CHILDREN':

                for c in export_data.collection.children:
                    if len(c.objects) > 0:
                        ccol = col.box().column(align=True)
                        ccol.label(text=c.name, icon='OUTLINER_COLLECTION')
                        draw_collection_objects(c.objects, ccol, None)
                        col.separator()
            else:

                draw_collection_objects(export_data.collection.all_objects[:], col, export_data)

                if modify_collection:
                    col.prop(scene, 'engine_export_expand_objects_detail', icon='TRIA_UP', emboss=True)
