# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import *
from bpy.types import Operator


class MakeActiveObjectSelectedCollectionHead(Operator):
    """Make the active object the head of the selected collection"""
    bl_idname = "object.make_active_object_selected_collection_head"
    bl_label = "Make Active Collection Head"

    selection: BoolVectorProperty(
        size=32,
        options={'SKIP_SAVE'}
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.active_object.users_collection) > 0

    def invoke(self, context, event):
        wm = context.window_manager
        wm.invoke_props_dialog(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        active = context.active_object

        for idx, collection in enumerate(context.active_object.users_collection):
            #row = layout.row(enabled=collection.engine_export_head is not active)
            #row = layout.row(enabled=collection.engine_export_head is not active)
            layout.prop(self, "selection", index=idx, text=collection.name,
                        toggle=True, icon='NONE' if collection.engine_export_head is not active else 'MONKEY')

    def execute(self, context):
        active = context.active_object

        for index, flag in enumerate(self.selection):
            if flag:
                active.users_collection[index].engine_export_head = active

        return{'FINISHED'}
