# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import *
from bpy.types import Operator


class MakeActiveObjectSelectedCollectionHead(Operator):
    """Make the active object the head of the selected collection"""
    bl_idname = "object.make_active_object_selected_collection_head"
    bl_label = "Make Active Collection Head"

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):

        targets = []

        act = context.active_object
        for act in context.selected_objects:
            for col in act.users_collection:
                for exp_col in context.scene.engine_export_collections:
                    if exp_col.collection == col:
                        if exp_col.head is act:
                            continue
                        elif len(col.objects) == 1:
                            exp_col.head = act
                        else:
                            targets.append(exp_col)

        return {'FINISHED'}
