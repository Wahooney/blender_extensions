# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from mathutils import Vector


def execute_smart_duplicate(context):

    collections = [context.collection]
    new_geos = []

    for c in collections:
        geos = []
        arms = []

        for ob in c.objects:
            if ob.type != 'ARMATURE':
                geos.append(ob)
            else:
                arms.append(ob)

        parent = None
        for col in bpy.data.collections:
            if c.name in col.children:
                parent = col
                break

        if parent is None:
            print("Collection '%s' has no parent" % (c.name))
            return

        collection = bpy.data.collections.new(c.name)
        parent.children.link(collection)

        # linke armatures
        for arm in arms:

            collection.objects.link(arm)

        # duplicate geometry
        for geo in geos:

            new_geo = geo.copy()
            new_geo.data = geo.data.copy()

            collection.objects.link(new_geo)

            if geo.name == c.name:
                collection.name = new_geo.name

            new_geos.append(new_geo)

    # deselect old geometry
    for sel in context.selected_objects:
        sel.select_set(False)

    # select new geometry
    for sel in new_geos:
        sel.select_set(False)

    # select armatures
    for sel in arms:
        sel.select_set(False)

    if context.active_object is None or not context.active_object.select_get():
        context.view_layer.objects.active = new_geos[0]


class COLLECTION_OT_SmartDuplicate(bpy.types.Operator):

    """Duplicates the collection and its contents, and links armatures into the new collection"""

    bl_idname = "collection.smart_duplicate"
    bl_label = "Smart Duplicate Collection"

    @classmethod
    def poll(cls, context):
        return context.collection is not None and len(context.collection.objects) > 0 and context.mode == 'OBJECT'

    def execute(self, context):
        execute_smart_duplicate(context)
        return {'FINISHED'}


class COLLECTION_OT_InstanceOffsetToHead(bpy.types.Operator):

    """Move instance offset to collection head"""

    bl_idname = "collection.instance_offset_to_tead"
    bl_label = "Instance Offset to Head"

    @classmethod
    def poll(cls, context):

        collections = context.scene.engine_export_collections

        if context.collection is not None:
            for collection in collections:
                if collection.collection == context.collection and collection.head is not None:
                    return True

        return False

    def execute(self, context):

        collection = context.collection
        scene = context.scene
        collections = scene.engine_export_collections

        if context.collection is not None:
            for collection in collections:
                if collection.collection == context.collection and collection.head is not None:
                    collection.collection.instance_offset = collection.head.location
                    break

        return {'FINISHED'}


class ENGINEEXPORT_OT_ClearAnimationData(bpy.types.Operator):

    """Removes animation data from target object"""

    bl_idname = "engine_export.clear_animation_data"
    bl_label = "Clear Anim"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        context.active_object.animation_data_clear()
        return {'FINISHED'}


class ENGINEEXPORT_OT_ApplyScale(bpy.types.Operator):

    """Applies the scale of the target object"""

    bl_idname = "engine_export.apply_scale"
    bl_label = "Apply"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.data is not None and context.active_object.data.users == 1

    def execute(self, context):
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        return {'FINISHED'}


class ENGINEEXPORT_OT_ClearScale(bpy.types.Operator):

    """Clears the scale of the target object to [1, 1, 1]"""

    bl_idname = "engine_export.clear_scale"
    bl_label = "Clear"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        context.active_object.scale = [1, 1, 1]
        return {'FINISHED'}


class ENGINEEXPORT_OT_CreateOrigin(bpy.types.Operator):

    """Creates an empty object at the head of the collection, or the center of the collection (if no head is set), assigns it as the origin object and makes the collections offset mode Object"""

    bl_idname = "engine_export.create_origin"
    bl_label = "Create Origin"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    collection_name: bpy.props.StringProperty(name="Collection Name", default="")

    @classmethod
    def poll(cls, context):
        return len(context.scene.engine_export_collections) > 0

    def execute(self, context):

        collection_name = self.collection_name
        export_collections = context.scene.engine_export_collections

        # check if export collection exists
        if collection_name not in export_collections:
            self.report({'ERROR'}, F"Collection '{collection_name}' not found in export collections")
            return {'CANCELLED'}

        export_data = export_collections[collection_name]
        collection = export_data.collection

        # check if export data has an assigned Blender Collection
        if collection is None:
            self.report({'ERROR'}, F"Export Collection '{collection_name}' doesn't have an assigned Collection")
            return {'CANCELLED'}

        # check if export data has an assigned origin object
        if export_data.offset_target_object is not None:
            self.report({'ERROR'}, F"Export Collection '{collection_name}' already has an Origin object")
            return {'CANCELLED'}

        origin = bpy.data.objects.new(F"REF_Origin_{collection.name}", None)
        collection.objects.link(origin)
        origin.empty_display_type = 'ARROWS'
        origin.empty_display_size = 1.0 / context.scene.unit_settings.scale_length

        if export_data.head is not None:
            origin.location = export_data.head.location
        else:
            center = Vector((0, 0, 0))

            for obj in collection.objects:
                center += obj.location

            center /= len(collection.objects)
            origin.location = center

        export_data.offset_target_object = origin
        export_data.offset_method = 'OBJECT'

        return {'FINISHED'}


'''import bpy


def main(context):
    
    print ("Smart Duplicating Collection")
    
    collections = []
    
    for sel in context.selected_objects:
        for c in sel.users_collection:
            if sel.name in c.objects:
                if c not in collections:
                    collections.append(c)
                    
    new_objs = []
    
    if len(collections) == 0:
        print("No eligible collections selected")
        return
                
    for c in collections:
        objs = []
        arms = []
        
        for ob in c.objects:
            if ob.type != 'ARMATURE':
                objs.append(ob)
            else:
                arms.append(ob)
                
        parent = None
        for col in bpy.data.collections:
            if c.name in col.children:
                parent = col
                break
            
        if parent is None:
            print("Collection %s has no parent so is probably not linked to the scene" % (c.name))
            return
        
        collection = bpy.data.collections.new(c.name)
        parent.children.link(collection)
        
        for arm in arms:
            collection.objects.link(arm)
            
        for ob in objs:
            new_ob = ob.copy()
            new_ob.data = ob.data.copy()
            
            collection.objects.link(new_ob)
            
            if ob.name == c.name:
                collection.name = new_ob.name
                
            new_objs.append(new_ob)
            
    for sel in context.selected_objects:
        if sel not in new_objs:
            sel.select_set(False)
            
    if not context.active_object.select_get() and len (new_objs) > 0:
        context.view_layer.objects.active = new_objs[0]


class Collection_OT_SmartDuplicate(bpy.types.Operator):
    """Duplicates the contents of the collection, and smart-links armatures in"""
    bl_idname = "collection.smart_duplicate"
    bl_label = "Smart Duplicate Collection"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        main(context)
        return {'FINISHED'}


def register():
    bpy.utils.register_class(Collection_OT_SmartDuplicate)


def unregister():
    bpy.utils.unregister_class(Collection_OT_SmartDuplicate)


if __name__ == "__main__":
    register()

    # test call
    #bpy.ops.collection.smart_duplicate()
'''
