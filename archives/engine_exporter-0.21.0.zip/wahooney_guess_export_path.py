# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy

#
#
# GUESS EXPORT OPERATOR
#
#


def replace(string, what_string, with_string):
    if(len(what_string) != len(with_string)):
        return string

    result = string

    for i, r in enumerate(what_string):
        result = result.replace(r, with_string[i])

    return result


def guess_export_path(context):
    filepath = context.blend_data.filepath

    if not filepath:
        return

    filepath = os.path.dirname(filepath)

    filepath = replace(filepath,
                       ["Author", "author"],
                       ["Assets", "assets"])

    if context.user_preferences.filepaths.use_relative_paths:
        context.scene.engine_export_export_path = bpy.path.relpath(filepath)
    else:
        context.scene.engine_export_export_path = bpy.path.abspath(filepath)


class GuessExportPath(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_export_guess_path"
    bl_label = "Guess Export Path"
    bl_description = "Guess the export path from the current .blend file path\nOnly works with Unity\nRespects User Preferences > Relative Paths"

    def execute(self, context):
        guess_export_path(context)
        return {'FINISHED'}

#
#
# GUESS TEXTURE EXPORT
#
#


def guess_texture_export_path(context):
    filepath = context.blend_data.filepath

    filepath = os.path.dirname(filepath)

    filepath = replace(filepath,
                       ["Author", "author", "models", "Models", "meshes", "Meshes"],
                       ["assets", "assets", "textures", "Textures", "textures", "Textures"])

    if context.user_preferences.filepaths.use_relative_paths:
        context.scene.engine_export_texture_export_path = bpy.path.relpath(
            filepath)
    else:
        context.scene.engine_export_texture_export_path = bpy.path.abspath(
            filepath)


class GuessTextureExportPath(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_texture_export_guess_path"
    bl_label = "Guess Texture Export Path"
    bl_description = "Guess the export path from the current .blend file path\nRespects User Preferences > Relative Paths"

    def execute(self, context):
        guess_texture_export_path(context)
        return {'FINISHED'}
