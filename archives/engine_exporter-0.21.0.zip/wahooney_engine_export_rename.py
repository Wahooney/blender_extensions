# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from bpy.types import Menu, Panel, Operator
from bl_operators.presets import AddPresetBase
import bpy
import re
from bpy.props import *


class RenameRuleItem(bpy.types.PropertyGroup):
    find: bpy.props.StringProperty(
        name="Find", description="Find this expression in all exported objects & data (uses regular expressions)", default="")
    replace: bpy.props.StringProperty(
        name="Replace", description="Replace with this expression in all exported objects & data that match the pattern", default="")

    # Rename Rules


def rename_all(target):

    s = target
    for rule in bpy.context.scene.engine_export_rename_rules:
        s = rename(rule.find, rule.replace, s)

    return s


def rename(replaceText, withText, target):
    return re.sub(replaceText, withText, target)


class ENGINEEXPORTSCENE_PT_RenameSubPanel(bpy.types.Panel):

    bl_label = 'Rename Options'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'
    bl_idname = 'ENGINEEXPORTSCENE_PT_RenameSubPanel'
    bl_parent_id = 'ENGINEEXPORTSCENE_PT_Panel'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):

        scene = context.scene
        layout = self.layout

        row = layout.row()
        row.template_list('ENGINEEXPORTSCENE_UL_rename_rules', '', bpy.context.scene,
                          'engine_export_rename_rules', scene, 'engine_export_active_rename_rule_index', rows=2)

        col = row.column(align=True)
        col.operator("scene.engine_export_add_rename_rule", icon='ADD',
                     text="").remove_active = False

        col.operator("scene.engine_export_add_rename_rule", icon='REMOVE',
                     text="").remove_active = True

        col = layout.column(align=True)
        col.prop(scene, 'engine_export_preview_renaming', toggle=True)

        active_collections = scene.engine_export_collections

        if (scene.engine_export_preview_renaming and scene.engine_export_active_export_collection_index < len(active_collections)):

            collection = active_collections[scene.engine_export_active_export_collection_index]
            
            if collection.collection is None:
                return
            
            for o in collection.collection.all_objects:
                row = col.row(align=True)
                row.active = o.engine_export_use_rename

                row.prop(o, "name", text='')
                newName = rename_all(o.name)
                row.label(text=newName)

                if newName != o.name and newName in bpy.data.objects:
                    row.prop(o, "engine_export_use_rename",
                             icon='ERROR', text='')
                else:
                    row.prop(o, "engine_export_use_rename",
                             icon='FILE_TEXT', text='')


def addRenameRule(self, context):
    scene = bpy.context.scene

    scene.engine_export_active_rename_rule_index = min(
        len(scene.engine_export_rename_rules),
        max(0, scene.engine_export_active_rename_rule_index))

    if self.remove_active:
        if len(scene.engine_export_rename_rules) > 0:
            scene.engine_export_rename_rules.remove(
                scene.engine_export_active_rename_rule_index)
    else:
        scene.engine_export_rename_rules.add()

    scene.engine_export_active_rename_rule_index = min(
        len(scene.engine_export_rename_rules),
        max(0, scene.engine_export_active_rename_rule_index))


class EngineExportAddRenameRule(bpy.types.Operator):
    ''''''
    bl_idname = "scene.engine_export_add_rename_rule"
    bl_label = "Add Rename Rule"
    bl_description = "Add Rename Rule for Collection Export"

    remove_active: BoolProperty()

    def execute(self, context):
        addRenameRule(self, context)
        return {'FINISHED'}


class ENGINEEXPORTSCENE_UL_rename_rules(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        ob = data
        collection = item

        if self.layout_type in {'DEFAULT', 'COMPACT'}:

            row = layout.row(align=True)
            row.prop(collection, 'find', icon='FILTER', text='')
            row.prop(collection, 'replace', icon='PASTEDOWN', text='')

        # 'GRID' layout type should be as compact as possible(typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)

        # TODO start here

    def draw_filter(self, context, layout):
        # Nothing much to say here, it's usual UI code...
        row = layout.row(align=True)
        scene = context.scene

        # row = row.row(align=True)
        row.prop(self, "filter_name", text="")
        icon = 'ZOOM_OUT' if self.use_filter_invert else 'ZOOM_IN'
        row.prop(self, "use_filter_invert", text="", icon=icon)

        # row = layout.row(align=True)
        row.separator()
        row.prop(self, "use_filter_sort_alpha", text='', toggle=True)
        icon = 'TRIA_UP' if self.use_filter_sort_reverse else 'TRIA_DOWN'
        row.prop(self, "use_filter_sort_reverse", text="", icon=icon)

    def filter_items(self, context, data, propname):

        rules = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Filtering by name
        if self.filter_name:
            flt_flags = helper_funcs.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item, rules, "find", reverse=self.use_filter_sort_reverse)

        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(rules)

        scene = context.scene

        # Reorder by name or average weight.
        if self.use_filter_sort_alpha:
            flt_neworder = helper_funcs.sort_items_by_name(rules, "find")

        return flt_flags, flt_neworder


class ENGINEEXPORTSCENE_RENAME_MT_presets(Menu):
    bl_label = "Rename Presets"
    preset_subdir = "engine_export_export_rename"
    preset_operator = "script.execute_preset"
    draw = Menu.draw_preset


class AddPresetEngineRename(AddPresetBase, Operator):
    """Add n Engine Export Rename Preset"""
    bl_idname = "scene.engine_export_preset_add"
    bl_label = "Add Renaming Preset"
    preset_menu = "engine_export_RENAME_MT_presets"

    # IMPORTANT: you need to specify below, what will be serialized to a preset file

    preset_defines = [
        "scene = bpy.context.scene"
    ]

    preset_values = [
        # "scene.engine_export_export_name_find",
        # "scene.engine_export_export_name_replace",
    ]

    # make sure it's the same as in your menu class
    preset_subdir = "engine_export_export_rename"
