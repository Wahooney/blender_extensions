# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import StringProperty, EnumProperty


class ExportCollectionRename(bpy.types.Operator):
    '''Rename export collections, objects or data'''
    bl_idname = "export_collection.rename"
    bl_label = "Rename Export"

    collection: StringProperty(default='', options={'HIDDEN'})
    operation: EnumProperty(items=(
        ('SYNC_COLLECTION_TO_HEAD', 'Rename collection to head', 'Rename collection to match head name'),
        ('SYNC_HEAD_TO_COLLECTION', 'Rename head to collection', 'Rename head object and data to match collection'),
        ('RENAME_OBJECTS_TO_DATA', 'Rename object to data', 'Rename the selected objects to their datas name'),
        ('RENAME_DATA_TO_OBJECTS', 'Renamd data to object', 'Rename the selected objects data to their objects name')
    ), name='Operation', options={'HIDDEN'})

    # @classmethod
    # def poll(cls, context):
    #    return context.active_object != None

    def execute(self, context):

        print(self.operation)

        if self.operation == 'SYNC_COLLECTION_TO_HEAD':

            if self.collection in context.scene.engine_export_collections:
                col = context.scene.engine_export_collections[self.collection]

                if col.head is not None:
                    print(F"Renaming {col.name} to {col.head.name}")
                    col.name = col.head.name
                    col.collection.name = col.head.name
                else:
                    print(F"{col.name} has no head.")

            elif self.collection == '':
                for sel in context.selected_objects:
                    for col in sel.users_collection:
                        if col.name not in context.scene.engine_export_collections:
                            print(F"{col.name} not marked for export")
                            continue

                        if context.scene.engine_export_collections[col.name].head is None:
                            print(F"{col.name} has no head")
                            continue

                        exp_col = context.scene.engine_export_collections[col.name]
                        col.name = exp_col.head.name
                        exp_col.name = col.name
            else:
                print(F"{self.collection} not in Engine Export")

        if self.operation == 'SYNC_HEAD_TO_COLLECTION':

            if self.collection in context.scene.engine_export_collections:
                col = context.scene.engine_export_collections[self.collection]

                if col.head is not None:
                    if col.head.name != col.name:
                        col.head.name = col.name

                    if col.head.data is not None and not col.head.data.name.startswith('__'):
                        if col.head.data.name != col.name:
                            col.head.data.name = col.name

            elif self.collection == '':
                for sel in context.selected_objects:
                    for col in sel.users_collection:
                        if col.name not in context.scene.engine_export_collections:
                            print(F"{col.name} not marked for export")
                            continue

                        if context.scene.engine_export_collections[col.name].head is None:
                            print(F"{col.name} has no head")
                            continue

                        context.scene.engine_export_collections[col.name].head.name = context.scene.engine_export_collections[col.name].name
            else:
                print(F"Collection {self.collection} not found")

        if self.operation == 'RENAME_OBJECTS_TO_DATA':

            for sel in context.selected_objects:
                sel.name = sel.data.name

        if self.operation == 'RENAME_DATA_TO_OBJECTS':

            for sel in context.selected_objects:
                sel.data.name = sel.name

        return {'FINISHED'}
