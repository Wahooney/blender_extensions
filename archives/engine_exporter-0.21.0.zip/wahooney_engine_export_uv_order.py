# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from bpy.props import CollectionProperty, EnumProperty, IntProperty, StringProperty

if "bpy" in locals():
    import importlib
    importlib.reload(wahooney_engine_export_functions)
else:
    import bpy
    from . import wahooney_engine_export_functions


UV_ORDER_MODE_ITEMS = (
    ('INHERIT', 'Inherit', 'Use the next broader UV order setting'),
    ('ARCHETYPE', 'Archetype', 'Use a named blend file UV archetype'),
    ('EXPLICIT', 'Explicit', 'Use the UV order list below'),
)


class UVOrderItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name='UV Layer',
        description='UV layer name in preferred export order',
        default='', options=set())


class UVOrderArchetype(bpy.types.PropertyGroup):
    name: StringProperty(
        name='Name',
        description='UV order archetype name',
        default='UV Archetype', options=set())

    uv_order: CollectionProperty(type=UVOrderItem, options=set())
    uv_order_index: IntProperty(name='Active UV Order Index', default=0, min=0, options=set())


def clean_uv_order(items):
    return list(dict.fromkeys([uv.name for uv in items if uv.name != '']))


def sort_uv_layers(mesh, layer_names):
    layers = mesh.uv_layers

    if len(layers) < 2:
        return

    active_name = layers.active.name if layers.active is not None else ''
    remove_names = []

    for i, name in enumerate(layer_names):
        if name in layers:
            layers.active = layers[name]
            remove_name = F'ENGINE_EXPORT_TEMP_UV_{name}_{i}'
            remove_names.append(remove_name)
            layers.active.name = remove_name
            layers.new(name=name, do_init=True)

    for layer in [uv.name for uv in layers]:
        if layer in remove_names:
            layers.remove(layers[layer])

    if active_name in layers:
        layers.active = layers[active_name]


def get_export_uv_order(scene, export_data, obj):
    def get_archetype_order(name):
        if name == '':
            return []

        if name in scene.engine_export_uv_archetypes:
            return clean_uv_order(scene.engine_export_uv_archetypes[name].uv_order)

        return []

    def get_owner_order(owner, order_attr, mode_attr, archetype_attr, default_mode='INHERIT'):
        mode = getattr(owner, mode_attr, default_mode)

        if mode == 'ARCHETYPE':
            return get_archetype_order(getattr(owner, archetype_attr, ''))

        if mode == 'EXPLICIT':
            return clean_uv_order(getattr(owner, order_attr))

        return []

    if obj is not None and hasattr(obj, 'engine_export_uv_order'):
        order = get_owner_order(obj, 'engine_export_uv_order', 'engine_export_uv_order_mode',
                                'engine_export_uv_order_archetype')
        if len(order) > 0:
            return order

    order = get_owner_order(export_data, 'uv_order', 'uv_order_mode', 'uv_order_archetype')
    if len(order) > 0:
        return order

    collections = wahooney_engine_export_functions.get_collection_hierarchy(export_data.collection)[:-1]
    collections.reverse()

    for collection in collections:
        if 'export_subpath' not in collection:
            continue

        order = get_owner_order(collection, 'engine_export_uv_order', 'engine_export_uv_order_mode',
                                'engine_export_uv_order_archetype')
        if len(order) > 0:
            return order

    return get_owner_order(scene, 'engine_export_uv_order', 'engine_export_uv_order_mode',
                           'engine_export_uv_order_archetype', default_mode='EXPLICIT')


def apply_export_uv_order(scene, export_data, obj, source_obj=None):
    if obj is None or obj.type != 'MESH' or obj.data is None:
        return

    order = get_export_uv_order(scene, export_data, source_obj or obj)

    if len(order) == 0:
        return

    local_names = [uv.name for uv in obj.data.uv_layers if uv.name not in order]
    sort_uv_layers(obj.data, order + local_names)


def get_uv_order_storage(context, scope):
    if scope == 'ARCHETYPE':
        if len(context.scene.engine_export_uv_archetypes) == 0:
            return context.scene.engine_export_uv_order, context.scene, 'engine_export_uv_order_index'

        index = min(context.scene.engine_export_active_uv_archetype_index,
                    len(context.scene.engine_export_uv_archetypes) - 1)
        archetype = context.scene.engine_export_uv_archetypes[index]
        return archetype.uv_order, archetype, 'uv_order_index'

    if scope == 'SCENE':
        return context.scene.engine_export_uv_order, context.scene, 'engine_export_uv_order_index'

    if scope == 'OBJECT':
        if context.active_object is not None:
            return context.active_object.engine_export_uv_order, context.active_object, 'engine_export_uv_order_index'
        return context.scene.engine_export_uv_order, context.scene, 'engine_export_uv_order_index'

    if scope == 'SUBPATH':
        return context.collection.engine_export_uv_order, context.collection, 'engine_export_uv_order_index'

    if len(context.scene.engine_export_collections) == 0:
        return context.scene.engine_export_uv_order, context.scene, 'engine_export_uv_order_index'

    index = min(context.scene.engine_export_active_export_collection_index,
                len(context.scene.engine_export_collections) - 1)
    collection = context.scene.engine_export_collections[index]
    return collection.uv_order, collection, 'uv_order_index'


def clamp_uv_order_index(owner, index_name, length):
    current = getattr(owner, index_name)
    setattr(owner, index_name, min(max(0, current), max(0, length - 1)))


def unique_name(base_name, names):
    if base_name not in names:
        return base_name

    index = 2
    while F"{base_name} {index}" in names:
        index += 1

    return F"{base_name} {index}"


def set_owner_explicit(owner):
    if hasattr(owner, 'uv_order_mode'):
        owner.uv_order_mode = 'EXPLICIT'
    elif hasattr(owner, 'engine_export_uv_order_mode'):
        owner.engine_export_uv_order_mode = 'EXPLICIT'


class ENGINEEXPORT_OT_CopyActiveUVOrder(bpy.types.Operator):
    bl_idname = "engine_export.copy_active_uv_order"
    bl_label = "Use Active UV Order"
    bl_description = "Use the active object's UV layer order as the export UV order"
    bl_options = {'UNDO'}

    scope: EnumProperty(items=(
        ('ARCHETYPE', 'UV Archetype', 'Use this order for the active UV archetype'),
        ('SCENE', 'Blend File', 'Use this order for the whole blend file'),
        ('SUBPATH', 'Subpath Collection', 'Use this order for the active subpath collection'),
        ('COLLECTION', 'Export Collection', 'Use this order for the active export collection'),
        ('OBJECT', 'Object', 'Use this order for the active object')),
        default='SCENE')

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        order, owner, index_name = get_uv_order_storage(context, self.scope)
        order.clear()

        for uv in context.active_object.data.uv_layers:
            item = order.add()
            item.name = uv.name

        set_owner_explicit(owner)
        setattr(owner, index_name, 0)
        return {'FINISHED'}


class ENGINEEXPORT_OT_ModifyUVOrder(bpy.types.Operator):
    bl_idname = "engine_export.modify_uv_order"
    bl_label = "Modify UV Order"
    bl_description = "Modify the export UV layer order"
    bl_options = {'UNDO'}

    scope: EnumProperty(items=(
        ('ARCHETYPE', 'UV Archetype', 'Use this order for the active UV archetype'),
        ('SCENE', 'Blend File', 'Use this order for the whole blend file'),
        ('SUBPATH', 'Subpath Collection', 'Use this order for the active subpath collection'),
        ('COLLECTION', 'Export Collection', 'Use this order for the active export collection'),
        ('OBJECT', 'Object', 'Use this order for the active object')),
        default='SCENE')

    operation: EnumProperty(items=(
        ('ADD', 'Add', 'Add UV layer name'),
        ('REMOVE', 'Remove', 'Remove selected UV layer name'),
        ('MOVE_UP', 'Move Up', 'Move selected UV layer name up'),
        ('MOVE_DOWN', 'Move Down', 'Move selected UV layer name down'),
        ('CLEAR', 'Clear', 'Clear UV layer order')),
        default='ADD')

    name: StringProperty(name='UV Layer', default='UVMap')

    def execute(self, context):
        order, owner, index_name = get_uv_order_storage(context, self.scope)
        index = getattr(owner, index_name)
        clamp_uv_order_index(owner, index_name, len(order))
        index = getattr(owner, index_name)

        if self.operation == 'ADD':
            item = order.add()
            item.name = self.name
            setattr(owner, index_name, len(order) - 1)
            set_owner_explicit(owner)

        elif self.operation == 'REMOVE' and len(order) > 0:
            order.remove(index)
            clamp_uv_order_index(owner, index_name, len(order))

        elif self.operation == 'MOVE_UP' and index > 0:
            order.move(index, index - 1)
            setattr(owner, index_name, index - 1)

        elif self.operation == 'MOVE_DOWN' and index < len(order) - 1:
            order.move(index, index + 1)
            setattr(owner, index_name, index + 1)

        elif self.operation == 'CLEAR':
            order.clear()
            setattr(owner, index_name, 0)

        return {'FINISHED'}

    def invoke(self, context, event):
        if self.operation == 'ADD':
            active = context.active_object
            if active is not None and active.type == 'MESH' and active.data.uv_layers.active is not None:
                self.name = active.data.uv_layers.active.name

        return self.execute(context)


class ENGINEEXPORT_UL_uv_order(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, 'name', text='', emboss=False, icon='GROUP_UVS')


class ENGINEEXPORT_UL_uv_archetypes(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, 'name', text='', emboss=False, icon='GROUP_UVS')


class ENGINEEXPORT_OT_ModifyUVArchetype(bpy.types.Operator):
    bl_idname = "engine_export.modify_uv_archetype"
    bl_label = "Modify UV Archetype"
    bl_description = "Modify blend file UV order archetypes"
    bl_options = {'UNDO'}

    operation: EnumProperty(items=(
        ('ADD', 'Add', 'Add UV archetype'),
        ('REMOVE', 'Remove', 'Remove selected UV archetype')),
        default='ADD')

    name: StringProperty(name='Name', default='Static Mesh')

    def execute(self, context):
        archetypes = context.scene.engine_export_uv_archetypes
        index = min(context.scene.engine_export_active_uv_archetype_index,
                    max(0, len(archetypes) - 1))

        if self.operation == 'ADD':
            archetype = archetypes.add()
            archetype.name = unique_name(self.name, [item.name for item in archetypes])
            context.scene.engine_export_active_uv_archetype_index = len(archetypes) - 1

        elif self.operation == 'REMOVE' and len(archetypes) > 0:
            archetypes.remove(index)
            context.scene.engine_export_active_uv_archetype_index = min(index, max(0, len(archetypes) - 1))

        return {'FINISHED'}


def draw_uv_archetypes(layout, context):
    scene = context.scene
    col = layout.column(align=True)
    row = col.row(align=True)
    row.template_list('ENGINEEXPORT_UL_uv_archetypes', '', scene, 'engine_export_uv_archetypes',
                      scene, 'engine_export_active_uv_archetype_index', rows=3)

    buttons = row.column(align=True)
    buttons.operator(ENGINEEXPORT_OT_ModifyUVArchetype.bl_idname, text='', icon='ADD').operation = 'ADD'
    buttons.operator(ENGINEEXPORT_OT_ModifyUVArchetype.bl_idname, text='', icon='REMOVE').operation = 'REMOVE'

    if len(scene.engine_export_uv_archetypes) > 0:
        index = min(scene.engine_export_active_uv_archetype_index, len(scene.engine_export_uv_archetypes) - 1)
        archetype = scene.engine_export_uv_archetypes[index]
        draw_uv_order(col, context, archetype.uv_order, archetype, 'uv_order_index', 'ARCHETYPE')


class ENGINEEXPORTSCENE_PT_UVArchetypePanel(bpy.types.Panel):

    bl_label = 'Engine Export UV Archetypes'
    bl_idname = 'ENGINEEXPORTSCENE_PT_UVArchetypePanel'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'

    def draw(self, context):
        draw_uv_archetypes(self.layout, context)


def draw_uv_order(layout, context, order, owner, index_name, scope):
    col = layout.column(align=True)

    if hasattr(owner, 'uv_order_mode'):
        col.prop(owner, 'uv_order_mode', text='')
    elif hasattr(owner, 'engine_export_uv_order_mode'):
        col.prop(owner, 'engine_export_uv_order_mode', text='')

    mode = getattr(owner, 'uv_order_mode', getattr(owner, 'engine_export_uv_order_mode', 'EXPLICIT'))
    if mode == 'ARCHETYPE':
        if hasattr(owner, 'uv_order_archetype'):
            col.prop_search(owner, 'uv_order_archetype', context.scene, 'engine_export_uv_archetypes', text='')
        elif hasattr(owner, 'engine_export_uv_order_archetype'):
            col.prop_search(owner, 'engine_export_uv_order_archetype', context.scene, 'engine_export_uv_archetypes', text='')
        return

    row = col.row(align=True)
    order_property = 'uv_order' if scope in {'COLLECTION', 'ARCHETYPE'} else 'engine_export_uv_order'
    row.template_list('ENGINEEXPORT_UL_uv_order', scope, owner, order_property, owner, index_name, rows=3)

    buttons = row.column(align=True)
    buttons.operator(ENGINEEXPORT_OT_CopyActiveUVOrder.bl_idname, text='', icon='EYEDROPPER').scope = scope
    buttons.operator(ENGINEEXPORT_OT_ModifyUVOrder.bl_idname, text='', icon='ADD').scope = scope
    op = buttons.operator(ENGINEEXPORT_OT_ModifyUVOrder.bl_idname, text='', icon='REMOVE')
    op.scope = scope
    op.operation = 'REMOVE'

    move = col.row(align=True)
    op = move.operator(ENGINEEXPORT_OT_ModifyUVOrder.bl_idname, text='', icon='TRIA_UP')
    op.scope = scope
    op.operation = 'MOVE_UP'
    op = move.operator(ENGINEEXPORT_OT_ModifyUVOrder.bl_idname, text='', icon='TRIA_DOWN')
    op.scope = scope
    op.operation = 'MOVE_DOWN'
    op = move.operator(ENGINEEXPORT_OT_ModifyUVOrder.bl_idname, text='', icon='X')
    op.scope = scope
    op.operation = 'CLEAR'

    if len(order) == 0:
        if scope == 'SCENE':
            col.label(text='No blend file UV order set', icon='INFO')
        else:
            col.label(text='Inherits UV order from broader export settings', icon='INFO')
