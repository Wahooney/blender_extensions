# engine export tools Copyright(C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation either version 2
# of the License, or(at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from mathutils import Vector
import os

if "bpy" in locals():

    import importlib

    importlib.reload(wahooney_engine_export_functions)

else:

    import bpy

    from . import wahooney_engine_export_functions


def get_operator(idname):
    op = bpy.ops
    for attr in idname.split("."):
        op = getattr(op, attr)
    return op


def draw_collection_objects(objects, layout_col, collection):
    
    for o in objects:

        is_split = False

        row = layout_col.row(align=True)

        row.prop(o, 'engine_export_export', emboss=True, text='', icon='EXPORT')
        row.prop(o, 'name', text='', icon='CON_CHILDOF' if not o.name in objects else 'OBJECT_DATA')

        if o.data != None:
            row.prop(o.data, 'name', text='', icon='MESH_DATA')
        elif o.instance_type == 'COLLECTION' and o.instance_collection != None:
            row.prop(o, 'instance_collection', text='', icon='OUTLINER_COLLECTION')

        row.prop(o, 'engine_export_use_rename',
                    text='', icon='FILE_TEXT')
        
        # tuple of type: warning message, array of fixes
        warnings = []

        if o.scale != Vector((1, 1, 1)):
            warnings.append((F'Object is Scaled', 
                            ['engine_export.clear_scale', 'engine_export.apply_scale']))

        if o.animation_data is not None and o.animation_data.action is not None and o.type != 'ARMATURE':
            warnings.append((F'Non-armature animated', 
                            ['engine_export.clear_animation_data']))

        if len(warnings) > 0:
            warn = layout_col.column(align=True)
            warn.alert = True
            warn.context_pointer_set('active_object', o)

            for warning in warnings:
                wrow = warn.row(align=True)
                wrow.label(text='', icon='BLANK1')
                wrow.label(text=warning[0], icon='ERROR')

                for fix in warning[1]:
                    if get_operator(fix).poll():
                        wrow.operator(fix)

            layout_col.separator()

        if o.engine_export_use_rename:
            layout_col.prop(o, 'engine_export_explicit_rename', text='', icon='FILE_TEXT')

        if collection is not None:
            if collection.animation and o.name in collection.split_nla_tracks_objects:
                row.prop(collection.split_nla_tracks_objects[o.name], 'include_in_split', icon='ANIM', icon_only=True)

            if collection.animation and o.animation_data is not None:
                row = row.row(align=True)
                row.alignment = 'LEFT'

                for nla in o.animation_data.nla_tracks:

                    track = collection.split_nla_tracks[nla.name]

                    row = layout_col.row(align=True)
                    row.label(icon='BLANK1')

                    subrow = row.row(align=True)
                    subrow.active = not track.is_static

                    if nla.name in collection.split_nla_tracks:
                        is_split = is_split or collection.split_nla_tracks[nla.name].use_split
                    else:
                        continue #wtf?

                    subrow.prop(collection.split_nla_tracks[nla.name], 'do_export',
                                icon='EXPORT',
                                icon_only=True,
                                emboss=True, toggle=False)

                    subrow.prop(nla, 'mute',
                            icon='MUTE_IPO_OFF' if nla.mute else 'MUTE_IPO_ON',
                            text='',
                            emboss=True, invert_checkbox=True, toggle=False)

                    subrow.label(text=nla.name)

                    subrow.prop(collection.split_nla_tracks[nla.name], 'use_split',
                                icon='FILE_TICK',
                                icon_only=True,
                                emboss=True, toggle=False)

                    row.prop(collection.split_nla_tracks[nla.name], 'is_static',
                                icon='FREEZE',
                                icon_only=True,
                                emboss=True, toggle=False)
    
    if is_split:

        layout_col.separator()

        row = layout_col.row(align=True)
        row.label(icon='BLANK1')
        row.prop(collection, 'anim_subpath', text='', icon='FILE_FOLDER')

        layout_col.separator()


def draw_collection(self, context, collection):

    layout = self.layout
    scene = context.scene

    modify_collection = self.modify_collection

    if collection is not None and collection.collection is not None:

        layout.separator()
        box = layout.box()

        subpath = wahooney_engine_export_functions.get_collection_exportpath(collection)
        if collection.name != '':
            filename = wahooney_engine_export_functions.add_prefix(context, collection.name, False)
        else:
            filename = wahooney_engine_export_functions.add_prefix(context, collection.collection.name, False)

        details_panel = box.panel_prop(context.scene, 'engine_export_expand_collection_details')
        details_panel[0].label(text=os.path.join(subpath, filename), icon='GROUP')

        if details_panel[1] is not None:

            if modify_collection:
                box.prop(collection, 'collection', icon='GROUP')

            row = box.row()
            row.active = False
            row.prop(context.scene, 'engine_export_export_path')

            box.prop(collection, 'is_utility_collection', icon ='GHOST_ENABLED' if collection.is_utility_collection else 'GHOST_DISABLED')

            # Name
            col = box.column(align=True)
            box2 = col.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Name")
            col2 = row.column(align=True)
            col2.prop(collection, 'name_method', text='')

            if collection.name_method == 'CUSTOM':
                col2.prop(collection, 'name', icon='COPY_ID', text='')
            else:
                col2.label(text=collection.collection.name, icon='COPY_ID')

            # Subpath
            col = box.column(align=True)
            box2 = col.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Path")
            col2 = row.column(align=True)
            col2.prop(collection, 'path_modifier', text='')

            if collection.path_modifier == 'CUSTOM':
                col2.prop(collection, 'subpath', text='', icon='FILE_FOLDER')
            elif collection.path_modifier == 'COMBO':
                col2.label(text=wahooney_engine_export_functions.get_collection_exportpath(collection))
                col2.prop(collection, 'subpath', text='', icon='FILE_FOLDER')
            else:
                col2.label(text=wahooney_engine_export_functions.get_collection_exportpath(collection), 
                        icon='FILE_FOLDER')

            # head object
            box2 = box.box()
            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Head Object")
            col2 = row.column(align=True)
            col2.prop_search(collection, 'head', collection.collection, 'all_objects', text='')

            row = box2.row()
            col2 = row.column(align=True)
            col2.scale_x = 0.8
            col2.label(text="Export Offset")
            col2 = row.column(align=True)
            col2.prop(collection, 'offset_method', text='')

            if collection.collection is not None:
                col3 = col2.column(align=True)

                if collection.offset_method == 'COLLECTION' or collection.head is None:
                    col3.active = True
                    col3.prop(collection.collection, 'instance_offset')

                elif collection.offset_method == 'OBJECT':
                    col3.prop(collection, 'offset_target_object', text='')
                    if collection.offset_target_object is not None:
                        subcol = col3.column(align=True)
                        subcol.active = False
                        subcol.prop(collection.offset_target_object, 'location', text='')

                elif collection.head is not None:
                    col3.active = False
                    if collection.offset_method == 'PARENT':
                        if collection.head.parent is not None:
                            col3.prop(collection.head.parent, 'location', text='')
                        else:
                            col3.label(text='No parent, expect weirdness', icon='ERROR')
                    elif collection.offset_method == 'HEAD':
                        if collection.head is not None:
                            col3.prop(collection.head, 'location', text='')
                        else:
                            col3.label(text='Head, expect weirdness', icon='ERROR')

            if collection.offset_method != 'COLLECTION' and collection.head:
                col2.prop(collection, 'use_rotation_offset')
            

            # instance
            col = box.box()
            col.use_property_split = True
            col.prop(collection, 'use_instances')


            # collapse
            col.prop(collection, 'export_type')

            if collection.export_type == 'COLLAPSED':

                if collection.head == None:
                    pass

                if collection.head is not None and collection.head.name in collection.collection.all_objects and wahooney_engine_export_functions.pure_curve(collection.head):
                    col.label(text='%s is not a valid collapse head' % collection.head, icon='ERROR')
            elif collection.export_type == 'CHILDREN':
                
                for c in collection.collection.children:

                    objects = [o for o in c.objects if o.engine_export_export and not o.name.startswith('UCX_') and o.parent is None]
                    if len(objects) != 1 and c.name not in c.objects:
                        row = col.row()
                        row.alert = True
                        row.label(text=F'{c.name} needs exactly one root object, found {len(objects)} or an object that matches the collection name exactly', icon='ERROR')

            if collection.head is not None and collection.head.name.startswith('UCX_'):
                row = col.row()
                row.alert = True
                row.label(text="'%s' has a UCX_ head, this will not export." % (collection.name), icon='ERROR')

            if collection.head is not None and collection.head.parent is not None and collection.head.parent.type == 'MESH':
                row = col.row()
                row.alert = True
                row.label(text="The head of '%s' is parented to another mesh '%s', this could cause problems." % (collection.name, collection.head.parent.name), icon='ERROR')


            # format
            col.prop(collection, 'export_format')


        # animation
        if collection.export_type == 'CHILDREN':
            ccol = box.box()
            ccol.label(text='Animation is disabled when export type is Child Collections', icon='ANIM')
        else:
            #box.separator()
            row = box.row(align=True)
            row.prop(collection, 'animation', toggle=True, icon='ANIM')
            col = row.column(align=True)
            col.active = collection.animation
            col.prop(collection, 'optimize', toggle=True, icon='MOD_SIMPLIFY')


        # show objects
        col = box.column(align=True)

        if modify_collection:
            object_panel = col.panel_prop(scene, 'engine_export_expand_objects_detail')
            object_panel[0].label(text='Export Objects', icon='OBJECT_DATA')

            if object_panel[1] is not None:
                col = object_panel[1].column(align=True)
            else:
                col = None

        if col is not None and scene.engine_export_expand_objects_detail or not modify_collection:

            if collection.export_type == 'CHILDREN':

                for c in collection.collection.children:
                    if len(c.objects) > 0:
                        ccol = col.box().column(align=True)
                        ccol.label(text=c.name, icon='OUTLINER_COLLECTION')
                        draw_collection_objects(c.objects, ccol, None)
                        col.separator()
            else:

                draw_collection_objects(collection.collection.all_objects[:], col, collection)

                if modify_collection:
                    col.prop(scene, 'engine_export_expand_objects_detail', icon='TRIA_UP', emboss=True)

