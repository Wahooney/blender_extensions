/*
wahooney_palette_map.py Copyright (C) 2023, Keith "Wahooney" Boshoff
***** BEGIN GPL LICENSE BLOCK *****

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ***** END GPL LICENCE BLOCK *****
*/


noperspective in vec4 rampColor;

out highp vec4 fragColor;

uniform vec4 colorTL;
uniform vec4 colorTR;
uniform vec4 colorBL;
uniform vec4 colorBR;

uniform float gamma;
uniform float padding;
uniform vec2 fullSize;

vec4 to_sRGB(vec4 linearRGB)
{
    return pow(linearRGB, vec4(2.22));
}

vec4 toLinear(vec4 sRGB)
{
    return pow(sRGB, vec4(0.450450));
}

vec2 remap(vec2 coord, float min, float max)
{
    return clamp((coord - min) / (max - min), 0.0, 1.0);
}

const highp float NOISE_GRANULARITY = 0.25/255.0;

highp float random(vec2 coords)
{
    return fract(sin(dot(coords.xy, vec2(12.9898,78.233))) * 43758.5453);
}

void main()
{
    vec2 coord;
    
    if (gamma > 0.0)
        coord = mix(rampColor.rg, toLinear(rampColor).rg, gamma);
    else
        coord = mix(rampColor.rg, to_sRGB(rampColor).rg, -gamma);

    vec2 pos = coord;
    vec2 seed = gl_FragCoord.xy;

    vec2 outCoord = remap(coord, padding, 1-padding);

    vec4 top = mix(colorTL, colorTR, outCoord.r);
    vec4 bottom = mix(colorBL, colorBR, outCoord.r);
    fragColor = mix(top, bottom, vec4(outCoord.g));

}