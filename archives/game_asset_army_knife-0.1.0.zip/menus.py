import bpy


class GAME_ASSET_ARMYKNIFE_MT_GameAssetUtilities(bpy.types.Menu):
    bl_label = "Game Assets"
    bl_idname = "GAME_ASSET_ARMYKNIFE_MT_GameAssetUtilities"

    def draw(self, context):
        layout = self.layout

        layout.operator("game_asset_army_knife.make_deferred_attached_duplicates")
        layout.operator("game_asset_army_knife.make_attached_duplicates")
        layout.separator()
        layout.operator("game_asset_army_knife.island_mesh_setup")
        layout.operator("game_asset_army_knife.face_mesh_setup")
        layout.operator("game_asset_army_knife.basic_mesh_setup")
        layout.separator()
        layout.operator("game_asset_army_knife.pull_updated_nodes_from_assets")
        layout.separator()
        layout.operator("game_asset_army_knife.place_objects_in_single_collections")


def draw_item(self, context):
    layout = self.layout
    layout.menu(GAME_ASSET_ARMYKNIFE_MT_GameAssetUtilities.bl_idname)


def clean_house():
    if hasattr(bpy.types.VIEW3D_MT_editor_menus, 'gaak'):
        old_draw = bpy.types.VIEW3D_MT_editor_menus.gaak
        bpy.types.VIEW3D_MT_editor_menus.remove(old_draw)
        del bpy.types.VIEW3D_MT_editor_menus.gaak


def register():

    clean_house()
    bpy.utils.register_class(GAME_ASSET_ARMYKNIFE_MT_GameAssetUtilities)
    bpy.types.VIEW3D_MT_editor_menus.gaak = draw_item
    bpy.types.VIEW3D_MT_editor_menus.append(draw_item)


def unregister():

    clean_house()
    bpy.utils.unregister_class(GAME_ASSET_ARMYKNIFE_MT_GameAssetUtilities)
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_item)
