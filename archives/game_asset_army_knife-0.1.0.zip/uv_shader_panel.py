# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import bpy
import bmesh
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
from mathutils import Vector

'''
TODO:
- Get variance textures working
Get this all working in Unreal
'''


################################################################################
# Common Functions

def lerp(a, b, x):
    return a + (b - a) * x


def inv_lerp(a, b, x):
    return (x - a) / (b - a)


def get_bounds_for_color(palette, color):
    return [color.position[0] / palette.columns,
            1.0 - color.position[1] / palette.rows -
            color.span[1] / palette.rows,
            color.position[0] / palette.columns +
            color.span[0] / palette.columns,
            1.0 - color.position[1] / palette.rows]


def get_local_coordinates(bounds, uv):
    return Vector((inv_lerp(bounds[0], bounds[2], uv[0]),
                   inv_lerp(bounds[1], bounds[3], uv[1])))


def get_uv_coordinates(bounds, local):
    return Vector((lerp(bounds[0], bounds[2], local[0]),
                   lerp(bounds[1], bounds[3], local[1])))


################################################################################
# Globals

color_settings = ['Color_Base', 'Color_1', 'Color_2', 'Color_3']

global_active_object = None
global_active_face_index = None
global_surface_current = None
global_face_surface_list = None

palette_enum_items = None
surface_type_enum_items = None


################################################################################
# Utility Functions

def get_palettes(scene, context):
    global palette_enum_items

    if palette_enum_items is not None and (len(palette_enum_items) - 1) == len(scene.palette_map.palettes):
        return palette_enum_items

    palette_enum_items = [('None', 'None', '', 0)]

    for i, palette in enumerate(scene.palette_map.palettes):
        palette_enum_items.append((palette.name, palette.name, '', i+1))

    return palette_enum_items


def get_palette_enums(operator, context):
    global palette_enum_items

    scene = context.scene

    if palette_enum_items is not None and (len(palette_enum_items) - 1) == len(scene.palette_map.palettes):
        return palette_enum_items

    palette_enum_items = [('None', 'None', '', 0)]

    for i, palette in enumerate(scene.palette_map.palettes):
        palette_enum_items.append((palette.name, palette.name, '', i+1))

    return palette_enum_items


def get_surface_types(scene, context):

    global surface_type_enum_items

    act = bpy.context.active_object
    palette_name = act['Palette']

    if surface_type_enum_items is not None and palette_name in surface_type_enum_items:
        if len(surface_type_enum_items[palette_name]) == len(scene.palette_map.palettes[palette_name].colors):
            return surface_type_enum_items[palette_name]

    surface_type_enum_items = {}

    for palette in scene.palette_map.palettes:
        surface_type_enum_items[palette.name] = [
            (color.name, color.name, '', i) for i, color in enumerate(palette.colors)]

    if palette in surface_type_enum_items:
        return surface_type_enum_items[palette_name]

    return None


def set_material(self, context):

    global surface_type_enum_items
    global global_surface_current
    global global_face_surface_list

    is_edit = context.active_object.mode == 'EDIT'
    if is_edit:
        bpy.ops.object.mode_set(mode='OBJECT')

    scene = context.scene

    act = context.active_object
    attrib = None

    surface_types = get_surface_types(scene, context)

    surface = None
    for s in surface_types:
        if s[0] == self.material:
            surface = s

    palette = scene.palette_map.palettes[act['Palette']]

    if surface is not None:

        global_surface_current = surface[0]
        target_bounds = get_bounds_for_color(
            palette, palette.colors[surface[0]])

        for sel in context.selected_objects:

            if sel.type != 'MESH':
                continue

            if 'PaletteUV' not in sel.data.attributes:
                sel.data.attributes.new('PaletteUV', 'FLOAT2', 'CORNER')

            palette_uv = sel.data.attributes['PaletteUV'].data
            local_uv = Vector((0.5, 0.5))

            if 'PaletteColor' not in sel.data.attributes:
                attrib = sel.data.attributes.new(
                    'PaletteColor', 'STRING', 'FACE')
            else:
                attrib = sel.data.attributes['PaletteColor']

            surface_bytes = surface[0].encode()

            for p in sel.data.polygons:

                if p.select:

                    old_color = attrib.data[p.index].value.decode()

                    current_bounds = None
                    if self.keep_relative and old_color in palette.colors:
                        current_bounds = get_bounds_for_color(
                            palette, palette.colors[attrib.data[p.index].value.decode()])

                    for l in p.loop_indices:

                        if self.keep_relative:
                            if current_bounds is not None:
                                local_uv = get_local_coordinates(
                                    current_bounds, palette_uv[l].vector)
                            else:
                                local_uv = Vector(
                                    ((palette_uv[l].vector[0] * palette.columns) % 1.0, (palette_uv[l].vector[1] * palette.rows) % 1.0))

                        palette_uv[l].vector = get_uv_coordinates(
                            target_bounds, local_uv)

                    attrib.data[p.index].value = surface_bytes

    attribs = act.data.attributes['PaletteColor']
    global_face_surface_list = [a.value.decode() for a in attribs.data]

    if is_edit:
        bpy.ops.object.mode_set(mode='EDIT')


def auto_detect_materials(self, context):

    global surface_type_enum_items
    global global_surface_current
    global global_face_surface_list

    is_edit = context.active_object.mode == 'EDIT'
    if is_edit:
        bpy.ops.object.mode_set(mode='OBJECT')

    scene = context.scene

    act = context.active_object

    surface_types = get_surface_types(scene, context)
    palette = scene.palette_map.palettes[act['Palette']]

    for sel in context.selected_objects:

        attrib = None
        surface_id_attr = None

        if sel.type != 'MESH':
            continue

        if 'PaletteUV' not in sel.data.attributes:
            sel.data.attributes.new('PaletteUV', 'FLOAT2', 'CORNER')

        palette_uv = sel.data.attributes['PaletteUV'].data
        local_uv = Vector((0.5, 0.5))
        updated = False

        if 'PaletteColor' not in sel.data.attributes:
            attrib = sel.data.attributes.new('PaletteColor', 'STRING', 'FACE')
            updated = True
        else:
            attrib = sel.data.attributes['PaletteColor']

        if 'SurfaceIdx' not in sel.data.attributes:
            surface_id_attr = sel.data.attributes.new('SurfaceIdx', 'INT', 'FACE')
            updated = True
        else:
            surface_id_attr = sel.data.attributes['SurfaceIdx']

        if updated:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')

        for p in sel.data.polygons:

            if p.select:

                surface_bytes = None

                for idx, color in enumerate(palette.colors):

                    current_bounds = get_bounds_for_color(palette, color)

                    in_current_bounds = 0

                    for l in p.loop_indices:

                        if current_bounds[0] <= palette_uv[l].vector[0] <= current_bounds[2] and current_bounds[1] <= palette_uv[l].vector[1] <= current_bounds[3]:
                            in_current_bounds += 1

                    if in_current_bounds == len(p.loop_indices):
                        surface_bytes = color.name.encode()
                        surface_idx = idx
                        break

                if surface_bytes is not None:
                    attrib.data[p.index].value = surface_bytes
                    surface_id_attr.data[p.index].value = surface_idx

    attribs = act.data.attributes['PaletteColor']
    global_face_surface_list = [a.value.decode() for a in attribs.data]

    if is_edit:
        bpy.ops.object.mode_set(mode='EDIT')


def select_material(self, context):

    global surface_type_enum_items
    global global_active_face_index
    global global_surface_current

    is_edit = context.active_object.mode == 'EDIT'
    if is_edit:
        bpy.ops.object.mode_set(mode='OBJECT')

    scene = context.scene

    act = context.active_object
    attrib = None

    surface_types = get_surface_types(scene, context)

    surface = None
    for s in surface_types:
        if s[0] == self.material:
            surface = s

    extend = self.extend

    if surface is not None:

        global_surface_current = surface[0]

        for sel in context.selected_objects:

            if sel.type != 'MESH':
                continue

            if 'PaletteColor' not in sel.data.attributes:
                attrib = sel.data.attributes.new(
                    'PaletteColor', 'STRING', 'FACE')
            else:
                attrib = sel.data.attributes['PaletteColor']

            if not extend:
                for p in sel.data.polygons:
                    p.select = False

                for e in sel.data.edges:
                    e.select = False

            affected_faces = []
            surface_bytes = surface[0].encode()

            for p in sel.data.polygons:

                if attrib.data[p.index].value == surface_bytes:
                    p.select = True
                    affected_faces.append(p)
                    global_surface_current = surface[0]

            if len(affected_faces) > 0:
                sel.data.polygons.active = affected_faces[0].index
                print(affected_faces[0].index)

                if sel == act:
                    global_active_face_index = affected_faces[0].index
                    global_surface_current = global_face_surface_list[global_active_face_index]

    if is_edit:
        bpy.ops.object.mode_set(mode='EDIT')


class ULTRASHADER_OT_clear_invalid_palettes(bpy.types.Operator):

    """ """
    bl_idname = "ultrashader.clear_invalid_palettes"
    bl_label = "Clear Invalid Palettes"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):

        for obj in bpy.data.objects:
            if 'Palette' not in obj:
                continue

            palette = obj['Palette']
            if palette not in context.scene.palette_map.palettes:
                del obj['Palette']

        return {'FINISHED'}


class ULTRASHADER_OT_remap_invalid_palettes(bpy.types.Operator):

    """ """
    bl_idname = "ultrashader.remap_invalid_palettes"
    bl_label = "Remap Invalid Palettes"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    palette: EnumProperty(name="Palette",
                          items=get_palette_enums)

    def invoke(self, context, event):
        wm = context.window_manager
        wm.invoke_props_dialog(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):

        for obj in bpy.data.objects:
            if 'Palette' not in obj:
                continue

            palette = obj['Palette']
            if palette not in context.scene.palette_map.palettes:
                obj['Palette'] = self.palette

        return {'FINISHED'}


class ULTRASHADER_OT_sync_colors(bpy.types.Operator):

    """Sets the UV Shader Material of the selected faces"""
    bl_idname = "ultrashader.sync_colors"
    bl_label = "Sync Colors to Selection"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):

        act = context.active_object

        for obj in context.selected_objects:

            if obj == act:
                continue

            for color in color_settings:

                if color in obj:
                    obj[color] = act[color]

        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

        return {'FINISHED'}


class ULTRASHADER_OT_set_material(bpy.types.Operator):

    """Sets the UV Shader Material of the selected faces"""
    bl_idname = "ultra_shader.set_material"
    bl_label = "Set Shader Material"
    # bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    material: StringProperty('Material Name', default='Plastic')
    keep_relative: BoolProperty('Keep Relative', default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        set_material(self, context)
        return {'FINISHED'}

    # def modal(self, context, event):
    #    set_material(self, context)
    #    return {'FINISHED'}

    # def invoke(self, context, event):
    #    print(event.type)
    #    return {'RUNNING_MODAL'}


class ULTRASHADER_OT_auto_detect_materials(bpy.types.Operator):

    """Determines the material of the selected faces by their existing PaletteUV coordinates"""
    bl_idname = "ultra_shader.auto_detect_material"
    bl_label = "Auto Detect Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        auto_detect_materials(self, context)

        return {'FINISHED'}


class ULTRASHADER_OT_set_color_swatch(bpy.types.Operator):

    """Sets face color swatch"""
    bl_idname = "ultra_shader.set_color_swatch"
    bl_label = "Set Color Swatch"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    index: IntProperty('Index', default=0)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        for sel in context.selected_objects:

            mesh = sel.data
            bm = bmesh.from_edit_mesh(mesh)

            if 'RCOMap' not in bm.loops.layers.uv:
                bm.loops.layers.uv.new("RCOMap")
            rco = bm.loops.layers.uv["RCOMap"]

            swatch = float(self.index)

            for f in bm.faces:

                if not f.select:
                    continue

                for l in f.loops:
                    l[rco].uv[0] = (l[rco].uv[0] % 1) + swatch

            bmesh.update_edit_mesh(mesh)

        return {'FINISHED'}


class ULTRASHADER_OT_select_color_swatch(bpy.types.Operator):

    """Selects faces by color watch"""
    bl_idname = "ultra_shader.selectt_color_swatch"
    bl_label = "Select Color Swatch"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    index: IntProperty('Index', default=0)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        from math import floor

        global global_active_face_index
        global global_surface_current

        act = context.active_object

        for sel in context.selected_objects:

            mesh = sel.data
            bm = bmesh.from_edit_mesh(mesh)

            if 'RCOMap' not in bm.loops.layers.uv:
                continue

            rco = bm.loops.layers.uv['RCOMap']

            swatch = float(self.index)

            affected_faces = []

            for p in bm.faces:

                select = 0

                for l in p.loops:
                    if floor(l[rco].uv[0]) == swatch:
                        select += 1

                p.select = select >= (len(p.loops) * 0.5)

                if p.select:
                    affected_faces.append(p)
                    print(affected_faces[0].index)

            if len(affected_faces) > 0:
                bm.faces.active = affected_faces[0]
                print(affected_faces[0].index)

                if sel == act:
                    global_active_face_index = affected_faces[0].index
                    global_surface_current = global_face_surface_list[global_active_face_index]

            print(sel.name)
            bmesh.update_edit_mesh(mesh)

        return {'FINISHED'}


class ULTRASHADER_OT_select_material(bpy.types.Operator):

    """Selects faces by material"""
    bl_idname = "ultra_shader.select_material"
    bl_label = "Select Shader Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    material: StringProperty('Material Name', default='Plastic')
    extend: BoolProperty('Keep Relative', default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        select_material(self, context)
        return {'FINISHED'}


class ULTRASHADER_OT_auto_assign_materials(bpy.types.Operator):

    """Auto assigns materials to selected faces from their PaletteUV"""
    bl_idname = "ultra_shader.auto_assign_materials"
    bl_label = "Auto Assign Materials"
    bl_options = {'REGISTER', 'UNDO'}

    relative: BoolProperty(name='Keep Relative', default=True)
    all_meshes: BoolProperty(name='All Palette Meshes', default=False)

    @classmethod
    def poll(cls, context):
        return True  # context.active_object is not None and context.active_object.type == 'MESH'

    def invoke(self, context, event):

        context.window_manager.invoke_props_dialog(self)

        return {'RUNNING_MODAL'}

    def execute(self, context):

        palettes = context.scene.palette_map.palettes

        release_deps_update()

        objects = context.view_layer.objects if self.all_meshes else context.selected_objects

        is_edit = context.active_object is not None and context.active_object.mode == 'EDIT'
        if is_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        for obj in objects:

            if obj.type != 'MESH' or 'Palette' not in obj:
                continue

            palette = palettes[obj['Palette']]
            mesh = obj.data

            if 'PaletteColor' not in mesh.attributes or 'PaletteUV' not in mesh.attributes:
                continue

            attrib = mesh.attributes['PaletteColor'].data
            uvs = mesh.attributes['PaletteUV'].data

            skips = []

            for poly in mesh.polygons:

                poly_color = attrib[poly.index].value.decode()

                if not poly.select and (not self.all_meshes or is_edit):
                    continue

                if poly_color == '':
                    skips.append(poly)
                    continue

                if poly_color not in palettes[obj['Palette']].colors:
                    continue

                color = palette.colors[poly_color]

                for loop in poly.loop_indices:

                    uv = uvs[loop].vector

                    local = Vector(((uv[0] * palette.columns) %
                                   1.0, (uv[1] * palette.rows) % 1.0))
                    bounds = get_bounds_for_color(palette, color)
                    uvs[loop].vector = get_uv_coordinates(bounds, local)

            if len(skips) > 0:
                print(F"Some faces unassigned on {obj.name} {len(skips)}")
                for poly in mesh.polygons:
                    poly.select = False

                for poly in skips:
                    poly.select = True

        register_deps_update()

        if is_edit:
            bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


class ULTRASHADER_PT_uv_shader_materials (bpy.types.Panel):

    """ """

    bl_label = 'UV Shader Properties'
    bl_idname = "ULTRASHADER_PT_uv_shader_materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Item'

    def draw_color(self, layout, obj, color, data_path):

        if color in obj:
            layout.prop(obj, data_path, icon='DOT', text='')
        else:
            layout.label(text='', icon='DOT')

    def draw(self, context):

        global surface_type_enum_items
        layout = self.layout

        layout.prop(context.scene, 'palette_map_value', text='')
        act = context.active_object

        if 'Palette' not in act:
            return

        surfaces = get_surface_types(context.scene, context)

        if surfaces is None:
            layout.label(text='Surface is invalid', icon='NOT_FOUND')
            layout.operator(ULTRASHADER_OT_remap_invalid_palettes.bl_idname)
            layout.operator(ULTRASHADER_OT_clear_invalid_palettes.bl_idname)
            return

        layout.operator(ULTRASHADER_OT_auto_assign_materials.bl_idname, icon='AUTO')
        layout.operator(ULTRASHADER_OT_auto_detect_materials.bl_idname, icon='AUTO')

        is_edit = act.mode == 'EDIT'

        if is_edit:
            row = layout.row(align=True)

            layout.prop(context.scene,
                        'palette_map_keep_relative', expand=True)

            col = row.column(align=True)
            col.prop(context.scene, 'palette_map_surface_type', expand=True)

            col = row.column(align=True)

            for s in surfaces:

                row = col.row(align=True)

                # ot = row.operator(ULTRASHADER_OT_set_material.bl_idname, text='')
                # ot.material = s[0]

                ot = row.operator(ULTRASHADER_OT_select_material.bl_idname, text='', icon='SELECT_SET')
                ot.material = s[0]
                ot.extend = False

                ot = row.operator(
                    ULTRASHADER_OT_select_material.bl_idname, text='', icon='SELECT_EXTEND')
                ot.material = s[0]
                ot.extend = True

        col = layout.column(align=True)
        row = col.row(align=True)
        row.label(text='Colors:')
        self.draw_color(row, act, 'Color_Base', '["Color_Base"]')
        self.draw_color(row, act, 'Color_1', '["Color_1"]')
        self.draw_color(row, act, 'Color_2', '["Color_2"]')
        self.draw_color(row, act, 'Color_3', '["Color_3"]')

        if is_edit:
            row = col.row(align=True)
            row.label(text='Set:')
            row.operator(ULTRASHADER_OT_set_color_swatch.bl_idname,
                         text='', icon='TRIA_UP').index = 0
            row.operator(ULTRASHADER_OT_set_color_swatch.bl_idname,
                         text='', icon='TRIA_UP').index = 1
            row.operator(ULTRASHADER_OT_set_color_swatch.bl_idname,
                         text='', icon='TRIA_UP').index = 2
            row.operator(ULTRASHADER_OT_set_color_swatch.bl_idname,
                         text='', icon='TRIA_UP').index = 3
            row = col.row(align=True)
            row.label(text='Select:')
            row.operator(ULTRASHADER_OT_select_color_swatch.bl_idname,
                         text='', icon='SELECT_SET').index = 0
            row.operator(ULTRASHADER_OT_select_color_swatch.bl_idname,
                         text='', icon='SELECT_SET').index = 1
            row.operator(ULTRASHADER_OT_select_color_swatch.bl_idname,
                         text='', icon='SELECT_SET').index = 2
            row.operator(ULTRASHADER_OT_select_color_swatch.bl_idname,
                         text='', icon='SELECT_SET').index = 3

        layout.operator(ULTRASHADER_OT_sync_colors.bl_idname)


def get_surface_type(self):

    global surface_type_enum_items
    global global_active_object
    global global_active_face_index
    global global_surface_current
    global global_face_surface_list

    if global_active_object is not None and global_face_surface_list is not None and global_active_face_index is not None:

        if global_active_face_index >= len(global_face_surface_list):
            global_active_face_index = len(global_face_surface_list) - 1

        if global_active_face_index < 0 or global_active_face_index >= len(global_face_surface_list):
            return 0

        data = global_face_surface_list[global_active_face_index]

        for s in surface_type_enum_items[global_active_object['Palette']]:
            if s[0] == data:
                global_surface_current = s[0]
                return s[3]

    elif global_surface_current is not None:
        return global_surface_current

    return 0


def set_surface_type(self, value):

    global global_surface_current
    global surface_type_enum_items

    for f in bpy.app.handlers.depsgraph_update_post[:]:
        if 'update_deps' in str(f):
            bpy.app.handlers.depsgraph_update_post.remove(f)

    bpy.ops.object.mode_set(mode='OBJECT')

    try:
        surface = None
        for s in surface_type_enum_items[bpy.context.active_object['Palette']]:
            if s[3] == value:
                surface = s

        relative = bpy.context.scene.palette_map_keep_relative
        bpy.ops.ultra_shader.set_material(
            material=surface[0], keep_relative=relative)

    except Exception as e:
        print(e)

    finally:
        bpy.app.handlers.depsgraph_update_post.append(update_deps)
        bpy.ops.object.mode_set(mode='EDIT')


def get_palette(self):

    global palette_enum_items

    act = bpy.context.active_object

    if 'Palette' in act:
        for p in palette_enum_items:
            if p[0] == act['Palette']:
                return p[3]

    return 0


def set_palette(self, value):

    global palette_enum_items

    for sel in bpy.context.selected_objects:

        if sel.type != 'MESH' or sel.name.startswith('UCX_'):
            continue

        for p in palette_enum_items:
            if value == p[3]:

                material = None

                for mat in bpy.data.materials:
                    if 'PaletteMaterialReference' in mat and mat['PaletteMaterialReference'] == p[0]:
                        material = mat
                        break

                sel['Palette'] = p[0]
                if material is not None and material is not sel.data.materials[0]:
                    sel.data.materials[0] = material


def update_deps(scene, depsgraph):

    global global_active_face_index
    global global_active_object
    global global_face_surface_list
    global global_surface_current

    act = bpy.context.active_object

    for op in bpy.context.window.modal_operators:
        # For UV Packmaster 3, operators often have "uvpackmaster3" in their bl_idname
        # For UV Packmaster 2, it may be "uvpackmaster2"
        if "uvpackmaster" in op.bl_idname.lower():
            print(F"Found {op.bl_idname} cancelling update")
            return

    if act is None or 'Palette' not in act:
        global_active_face_index = None
        global_active_object = None
        return

    global_active_object = act

    if act.mode == 'OBJECT' and 'Palette' in act:
        if 'PaletteColor' not in act.data.attributes:
            act.data.attributes.new('PaletteColor', 'STRING', 'FACE')
            print(F"Added PaletteColor to {act.name}")

        attribs = act.data.attributes['PaletteColor']
        global_face_surface_list = [a.value.decode() for a in attribs.data]

    if act.mode == 'EDIT' and 'Palette' in act and act.type == 'MESH':

        global_active_face_index = 0

        me = act.data
        bm = bmesh.from_edit_mesh(me)

        if bm.faces.active is None:
            for f in bm.faces:
                if f.select:
                    bm.faces.active = f
                    break

            if bm.faces.active is not None:
                global_active_face_index = bm.faces.active.index
                bmesh.update_edit_mesh(me)
            # else:
            #    print("========= BM freed")
            #    bm.free()

        else:
            global_active_face_index = bm.faces.active.index
            # print("========== BM freed")
            # bm.free()

        if global_face_surface_list is not None:
            if global_active_face_index < 0 or global_active_face_index >= len(global_face_surface_list):
                global_surface_current = global_face_surface_list[0]
            else:
                global_surface_current = global_face_surface_list[global_active_face_index]


classes = [
    ULTRASHADER_OT_clear_invalid_palettes,
    ULTRASHADER_OT_remap_invalid_palettes,
    ULTRASHADER_OT_sync_colors,
    ULTRASHADER_OT_set_color_swatch,
    ULTRASHADER_OT_select_color_swatch,
    ULTRASHADER_OT_set_material,
    ULTRASHADER_OT_select_material,
    ULTRASHADER_OT_auto_assign_materials,
    ULTRASHADER_OT_auto_detect_materials,
    ULTRASHADER_PT_uv_shader_materials,
]


def register_deps_update():
    bpy.app.handlers.depsgraph_update_post.append(update_deps)


def release_deps_update():
    for f in bpy.app.handlers.depsgraph_update_post[:]:
        if 'update_deps' in str(f):
            bpy.app.handlers.depsgraph_update_post.remove(f)


def init_scene_data():
    if bpy.context.active_object is not None:

        is_edit = bpy.context.active_object.mode == 'EDIT'
        if is_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        global global_active_face_index
        global global_active_object
        global global_face_surface_list
        global global_surface_current

        act = bpy.context.active_object

        if act is None or 'Palette' not in act:
            return

        global_active_object = act

        if act.mode == 'OBJECT' and 'Palette' in act:
            if 'PaletteColor' not in act.data.attributes:
                act.data.attributes.new('PaletteColor', 'STRING', 'FACE')
                print(F"Added PaletteColor to {act.name}")

            attribs = act.data.attributes['PaletteColor']
            global_face_surface_list = [a.value.decode() for a in attribs.data]
            global_active_face_index = max(0, act.data.polygons.active)
            if global_active_face_index < len(global_face_surface_list):
                global_surface_current = global_face_surface_list[global_active_face_index]
            else:
                global_surface_current = None

        if is_edit:
            bpy.ops.object.mode_set(mode='EDIT')


def initialize():

    release_deps_update()

    # i hate this
    bpy.app.timers.register(init_scene_data, first_interval=0.01)


enum_surface_action = (('SET', 'Set', ''), ('SELECT', 'Select', ''))


def register():

    initialize()

    register_deps_update()

    bpy.types.Scene.palette_map_surface_action = EnumProperty(name="Surface Action",
                                                              items=enum_surface_action)

    bpy.types.Scene.palette_map_surface_type = EnumProperty(name="Surface Type",
                                                            items=get_surface_types,
                                                            get=get_surface_type,
                                                            set=set_surface_type)

    bpy.types.Scene.palette_map_keep_relative = BoolProperty(name="Keep Relative",
                                                             default=True)

    bpy.types.Scene.palette_map_value = EnumProperty(name="Palettes",
                                                     items=get_palettes,
                                                     get=get_palette,
                                                     set=set_palette)

    for c in classes:
        bpy.utils.register_class(c)


def unregister():

    bpy.app.handlers.depsgraph_update_post.remove(update_deps)

    try:
        for c in classes:
            bpy.utils.unregister_class(c)
    finally:
        pass
