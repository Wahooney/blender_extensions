import bpy
import json
from pathlib import Path


def pull_updated_node_groups_from_libraries(context):

    asset_libraries = context.preferences.filepaths.asset_libraries[:]

    mod_map = {}
    dead_nodes = [node for node in bpy.data.node_groups if node.name.startswith('OLD_')]

    if len(dead_nodes) > 0:
        print(dead_nodes)

    apply_map = {}
    print()

    for a in asset_libraries:

        path = Path(a.path)
        blends = [str(fp) for fp in path.glob("**/*.blend") if fp.is_file()]

        for blend in blends:
            with bpy.data.libraries.load(blend, assets_only=True, link=False) as (contents, localdata):

                for n in contents.node_groups:
                    if n not in bpy.data.node_groups:
                        continue

                    print("====", n, type(contents))

                    for obj in bpy.data.objects:
                        for mod in obj.modifiers:

                            if mod.type != 'NODES':
                                continue

                            # skip nodes that are in libraries
                            if mod.node_group.library is not None:
                                continue

                            # check if we've already mapped this modifier, use that
                            if mod.node_group.name in mod_map:
                                apply_map[mod] = mod_map[mod.node_group.name]
                                print(F"  Rerouted: {obj.name} - {mod.name} - {mod_map[mod.node_group.name]}")
                                continue

                            # skip items that aren't matched
                            if mod.node_group.name != n:
                                continue

                            mod.node_group.name = 'OLD_' + mod.node_group.name
                            mod_map[mod.node_group.name] = n

                            apply_map[mod] = mod_map[mod.node_group.name]

                            dead_nodes.append(mod.node_group)

                            print(F"  {obj.name} - {mod.name} - {n}")
                            localdata.node_groups.append(n)

    for mod, group in apply_map.items():
        mod.node_group = bpy.data.node_groups[group]

    for node in dead_nodes:
        print("Removing", node.name, '...')
        bpy.data.node_groups.remove(node)


def has_more_than_one_user(data_block):
    user_count = data_block.users
    if data_block.use_fake_user:
        return user_count - 1 > 1
    return user_count > 1


class GAME_ASSET_ARMY_KNIFE_OT_PullUpdatedNodesFromAssets(bpy.types.Operator):
    """"""
    bl_idname = "game_asset_army_knife.pull_updated_nodes_from_assets"
    bl_label = "Pull Updated Nodes From Assets"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        pull_updated_node_groups_from_libraries(context)
        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_ConsolidateEmptyMeshes(bpy.types.Operator):
    """Replaces all empty mesh data-blocks with a single shared empty mesh data-block to save memory"""
    bl_idname = "game_asset_army_knife.consolidate_empty_meshes"
    bl_label = "Consolidate Empty Meshes"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        empty = None

        if '__SHARED_EMPTY_MESH_DATA__' in bpy.data.meshes:
            empty = bpy.data.meshes['__SHARED_EMPTY_MESH_DATA__']

            if len(empty.vertices) > 0:
                empty.name = '__NOT_REALLY_EMPTY_MESH__'
                empty = bpy.data.meshes.new('__SHARED_EMPTY_MESH_DATA__')
        else:
            empty = bpy.data.meshes.new('__SHARED_EMPTY_MESH_DATA__')

        changes = []
        old = []

        for obj in bpy.data.objects:
            if obj.type != 'MESH' or obj.data is empty:
                continue

            data = obj.data

            if len(data.vertices) == 0:
                old.append(data)
                obj.data = empty
                changes.append(obj.data.name)

        purges = 0

        for mesh in old:
            if mesh.use_fake_user:
                continue

            if mesh.users > 0:
                continue

            purges += 1
            bpy.data.meshes.remove(mesh)

        print(changes)
        self.report({'INFO'}, F"Consolidated {len(changes)} empty mesh(es). Purged {purges}.")

        bpy.ops.game_asset_army_knife.analyse_empty_meshes()

        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_DecoupleEmptyMeshes(bpy.types.Operator):
    """Replaces all shared empty mesh data-blocks with unique empty mesh data-blocks, for performance (current Blender bug)"""
    bl_idname = "game_asset_army_knife.decouple_empty_meshes"
    bl_label = "Decouple Empty Meshes"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        considered_meshes = [mesh for mesh in bpy.data.meshes if len(mesh.vertices) == 0 and has_more_than_one_user(mesh)]
        changes = []

        for obj in bpy.data.objects:
            if obj.type != 'MESH' or obj.data not in considered_meshes:
                continue

            data_name = F"{obj.name}__EMPTY_MESH__"
            obj.data = bpy.data.meshes.new(data_name)
            changes.append(data_name)

        print(changes)
        self.report({'INFO'}, F"Decoupled {len(changes)} empty mesh(es).")

        bpy.ops.game_asset_army_knife.analyse_empty_meshes()

        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_AnalyseEmptyMeshes(bpy.types.Operator):
    """Determines the number of unique and shared empty mesh data-blocks in the current file"""
    bl_idname = "game_asset_army_knife.analyse_empty_meshes"
    bl_label = "Analyse Empty Meshes"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    @classmethod
    def get_empty_mesh_report(cls):
        if hasattr(cls, 'empty_mesh_report'):
            return cls.empty_mesh_report
        return None

    @classmethod
    def set_empty_mesh_report(cls, report):
        cls.empty_mesh_report = report

    @classmethod
    def clean_house(cls):
        if hasattr(cls, 'empty_mesh_report'):
            del cls.empty_mesh_report

    def execute(self, context):

        bpy.types.GAME_ASSET_ARMY_KNIFE_OT_analyse_empty_meshes.clean_house()

        considered_meshes = [F"{mesh.name} : {mesh.users} {mesh.use_fake_user}" for mesh in bpy.data.meshes if len(mesh.vertices) == 0 and not has_more_than_one_user(mesh)]

        unique_report = None
        if len(considered_meshes) > 0:
            unique_report = F"Unique Empty Meshes: {len(considered_meshes)}"
            print(unique_report)

        empty_report = None
        if '__SHARED_EMPTY_MESH_DATA__' in bpy.data.meshes:
            empty = bpy.data.meshes['__SHARED_EMPTY_MESH_DATA__']
            empty_report = F"Shared Empty Mesh Uses: {empty.users}"
            print(empty_report)

        print(F"Unique Empty Meshes: {len(considered_meshes)}")
        print("Considered:", considered_meshes)

        bpy.types.GAME_ASSET_ARMY_KNIFE_OT_analyse_empty_meshes.set_empty_mesh_report((unique_report, empty_report))

        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_ObjectsToCollections(bpy.types.Operator):
    """Place each selected object in its own collection"""

    bl_idname = "game_asset_army_knife.objects_to_collections"
    bl_label = "Objects To Collections"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects) > 0

    def execute(self, context):

        for sel in bpy.context.selected_objects:
            col = sel.users_collection[0]

            if len(col.children) > 0 or len(col.objects) > 1:
                new_col = bpy.data.collections.new(sel.name)
                new_col.objects.link(sel)
                col.objects.unlink(sel)
                col.children.link(new_col)

        return {'FINISHED'}


def register():
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_PullUpdatedNodesFromAssets)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_ObjectsToCollections)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_ConsolidateEmptyMeshes)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_DecoupleEmptyMeshes)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_AnalyseEmptyMeshes)


def unregister():
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_PullUpdatedNodesFromAssets)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_ObjectsToCollections)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_ConsolidateEmptyMeshes)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_DecoupleEmptyMeshes)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_AnalyseEmptyMeshes)
