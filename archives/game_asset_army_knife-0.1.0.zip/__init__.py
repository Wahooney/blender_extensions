# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "Game Asset Army Knife",
    "author": "Keith 'Wahooney' Boshoff",
    "description": "A collection of game asset tools",
    "blender": (4, 5, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Mesh"
}

if "bpy" in locals():

    import importlib

    from . import attribute_editor_panel

    importlib.reload(uv_shader_panel)
    importlib.reload(utility_mesh_operators)
    importlib.reload(file_cleanup_operations)
    importlib.reload(aux_mesh_tools)
    importlib.reload(attribute_editor_panel)
    importlib.reload(menus)

else:

    import bpy

    from . import uv_shader_panel
    from . import utility_mesh_operators
    from . import file_cleanup_operations
    from . import aux_mesh_tools
    from . import attribute_editor_panel
    from . import menus


classes = [
    uv_shader_panel,
    utility_mesh_operators,
    file_cleanup_operations,
    aux_mesh_tools,
    attribute_editor_panel,

    # always keep this at the bottom
    menus
]


def register():
    for c in classes:
        c.register()


def unregister():
    for c in classes:
        c.unregister()
