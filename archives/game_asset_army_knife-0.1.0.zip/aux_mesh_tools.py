from os import path
import bpy
import os
from bpy.props import EnumProperty, BoolProperty

domain_items = (
    ('UCX', 'Colliders', ''),
    ('REF', 'Reference', ''))

select_action_items = (
    ('SELECT', 'Select', ''),
    ('DESELECT', 'Deselect', ''))

display_items = (
    ('TEXTURED', 'Normal', '', 'SHADING_TEXTURE', 0),
    ('SOLID', 'Solid', '', 'SHADING_SOLID', 1),
    ('WIRE', 'Wireframe', '', 'SHADING_WIRE', 2),
    ('BOUNDS', 'Bounds', '', 'PIVOT_BOUNDBOX', 3))

visibility_items = (
    ('SHOW', 'Show', '', 'VIS_SEL_11', 3),
    ('HIDE', 'Unselectable', '', 'VIS_SEL_10', 2),
    ('HIDE', 'Hide', '', 'VIS_SEL_01', 1))

DISPLAY_LUT = ('TEXTURED', 'SOLID', 'WIRE', 'BOUNDS')
TYPE_TO_IDX = {t: i for i, t in enumerate(DISPLAY_LUT)}

UCX_PREFIX = ("UCX_")
REF_PREFIX = ("REF_", "_REF_")


def _iter_prefix(domain, objs):
    startswith = str.startswith
    for obj in objs:
        if startswith(obj.name, domain):
            yield obj


def _set_display(domain, value):
    target = DISPLAY_LUT[value]
    objs = bpy.context.scene.objects

    for obj in _iter_prefix(domain, objs):
        if obj.display_type != target:
            obj.display_type = target


def _get_display(domain):
    counts = [0]*4
    objs = bpy.context.scene.objects

    for obj in _iter_prefix(domain, objs):
        idx = TYPE_TO_IDX.get(obj.display_type)

        if idx is not None:
            counts[idx] += 1

    return max(range(4), key=counts.__getitem__) if any(counts) else 0


def _set_visibility(domain, value):

    objs = bpy.context.scene.objects
    vis = (value & 2) <= 0
    sel = (value & 1) <= 0

    for obj in _iter_prefix(domain, objs):
        if obj.hide_viewport != vis:
            obj.hide_viewport = vis

        if obj.hide_select != sel:
            obj.hide_select = sel


def _get_visibility(domain):

    counts = [0]*4
    objs = bpy.context.scene.objects

    for obj in _iter_prefix(domain, objs):
        vis = 0 if obj.hide_viewport else 2
        sel = 0 if obj.hide_select else 1

        counts[vis | sel] += 1

    return max(range(4), key=counts.__getitem__) if any(counts) else 0


def _set_renderable(domain, value):

    objs = bpy.context.scene.objects

    for obj in _iter_prefix(domain, objs):
        if obj.hide_render != value:
            obj.hide_render = value


def _get_renderable(domain):

    counts = [0]*2
    objs = bpy.context.scene.objects

    for obj in _iter_prefix(domain, objs):
        render = 1 if obj.hide_render else 0
        counts[render] += 1

    return max(range(2), key=counts.__getitem__) if any(counts) else 0


class WAHOONEY_OT_select_aux_mesh(bpy.types.Operator):
    """Select Auxiliary Meshes by Domain, ie. Collider, Reference"""
    bl_idname = "object.select_aux_mesh"
    bl_label = "Select AUX Mesh"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    domain: EnumProperty(name='Domain', items=domain_items)
    action: EnumProperty(name='Action', items=select_action_items, default='SELECT')

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        objs = bpy.context.scene.objects

        local_domain = UCX_PREFIX
        if self.domain == 'REF':
            local_domain = REF_PREFIX

        layer_objects = context.view_layer.objects
        if self.action == 'SELECT':
            bpy.ops.object.select_all(action='DESELECT')

            for obj in _iter_prefix(local_domain, objs):
                if obj.name in layer_objects:
                    obj.select_set(True)

        elif self.action == 'DESELECT':
            for obj in _iter_prefix(local_domain, objs):
                if obj.name in layer_objects:
                    obj.select_set(False)

        return {'FINISHED'}


class WAHOONEY_OT_incremental_backup(bpy.types.Operator):
    """Save Incremental Backup"""
    bl_idname = "file.incremental_backup"
    bl_label = "Incremental Backup"
    bl_description = "Moves the current blend file to an incremented filename and saves a new copy as the original filename."
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return bpy.data.filepath != ""

    def execute(self, context):

        og_filepath = bpy.data.filepath
        parts = path.splitext(og_filepath)
        filepath = og_filepath
        counter = 0

        while path.exists(filepath):
            counter += 1
            filepath = F"{parts[0]}{counter:02}{parts[1]}"

        print(filepath)
        os.rename(og_filepath, filepath)
        bpy.ops.wm.save_as_mainfile(filepath=og_filepath, copy=False)
        self.report({'INFO'}, F"Saved Incremental Blend: {path.basename(filepath)}")

        return {'FINISHED'}


class WAHOONEY_PT_aux_meshes_view(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "Aux Mesh View"
    # bl_idname = "SCENE_PT_layout"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'View'
    # bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        main_row = layout.row(align=True)
        op = main_row.operator('object.select_aux_mesh', text='UCX', icon='SELECT_SET')
        op.domain = 'UCX'
        op.action = 'SELECT'

        op = main_row.operator('object.select_aux_mesh', text='', icon='SELECT_SUBTRACT')
        op.domain = 'UCX'
        op.action = 'DESELECT'

        col = main_row.column()
        row = col.row()
        row.prop(scene, 'collider_display', text='', icon_only=True, expand=True)

        row = col.row(align=True)
        row.prop(scene, 'collider_visibility', text='', icon_only=True, expand=True)
        row.prop(scene, 'collider_renderable', text='', icon='RESTRICT_RENDER_OFF', invert_checkbox=True)

        main_row = layout.row(align=True)
        op = main_row.operator('object.select_aux_mesh', text='REF', icon='SELECT_SET')
        op.domain = 'REF'
        op.action = 'SELECT'

        op = main_row.operator('object.select_aux_mesh', text='', icon='SELECT_SUBTRACT')
        op.domain = 'REF'
        op.action = 'DESELECT'

        col = main_row.column()
        row = col.row()
        row.prop(scene, 'reference_display', text='', icon_only=True, expand=True)

        row = col.row(align=True)
        row.prop(scene, 'reference_visibility', text='', icon_only=True, expand=True)
        row.prop(scene, 'reference_renderable', text='', icon='RESTRICT_RENDER_OFF', invert_checkbox=True)

        # attached duplicates
        layout.separator()
        col = layout.column(align=True)
        col.label(text="Attached Duplicates")
        row = col.row(align=True)
        row.operator("game_asset_army_knife.make_attached_duplicates", text='New')
        row.operator("game_asset_army_knife.make_deferred_attached_duplicates", text='Deferred')

        # empty meshes
        col = layout.column(align=True)
        col.label(text="Empty Meshes")

        col.operator("game_asset_army_knife.analyse_empty_meshes", text='Analyse')

        report = bpy.types.GAME_ASSET_ARMY_KNIFE_OT_analyse_empty_meshes.get_empty_mesh_report()
        if report is not None:
            box = col.box()
            report_col = box.column(align=True)
            if report[0] is not None:
                report_col.label(text=report[0])
            if report[1] is not None:
                report_col.label(text=report[1])

        row = col.row(align=True)
        row.operator("game_asset_army_knife.consolidate_empty_meshes", text='Consolidate')
        row.operator("game_asset_army_knife.decouple_empty_meshes", text='Decouple')

        # collections
        col = layout.column(align=True)
        col.separator()
        col.operator("game_asset_army_knife.objects_to_collections")
        col.operator("scene.engine_export_modify_collection", text="Selection to Export").operation = 'ADD_SELECTED_OBJECTS'

        # colliders
        col = layout.column(align=True)
        col.operator("object.rename_ucx_colliders")
        col.separator()
        col.operator("game_asset_army_knife.island_mesh_setup")
        col.operator("game_asset_army_knife.face_mesh_setup")
        col.operator("game_asset_army_knife.basic_mesh_setup")

        # node groups
        layout.operator("game_asset_army_knife.pull_updated_nodes_from_assets")


def set_collider_display(_, value):
    _set_display(UCX_PREFIX, value)


def get_collider_display(_):
    return _get_display(UCX_PREFIX)


def set_collider_visibility(_, value):
    _set_visibility(UCX_PREFIX, value)


def get_collider_visibility(_):
    return _get_visibility(UCX_PREFIX)


def set_collider_renderable(_, value):
    _set_renderable(UCX_PREFIX, value)


def get_collider_renderable(_):
    return _get_renderable(UCX_PREFIX)


def set_reference_display(_, value):
    _set_display(REF_PREFIX, value)


def get_reference_display(_):
    return _get_display(REF_PREFIX)


def set_reference_visibility(_, value):
    _set_visibility(REF_PREFIX, value)


def get_reference_visibility(_):
    return _get_visibility(REF_PREFIX)


def set_reference_renderable(_, value):
    _set_renderable(REF_PREFIX, value)


def get_reference_renderable(_):
    return _get_renderable(REF_PREFIX)


classes = [
    WAHOONEY_PT_aux_meshes_view,
    WAHOONEY_OT_select_aux_mesh,
    WAHOONEY_OT_incremental_backup,
]


def register():

    print("=================== REGISTER")

    bpy.types.Scene.collider_display = EnumProperty(name='Collider Display', items=display_items,
                                                    get=get_collider_display,
                                                    set=set_collider_display)

    bpy.types.Scene.collider_visibility = EnumProperty(name='Collider Visibility', items=visibility_items,
                                                       get=get_collider_visibility,
                                                       set=set_collider_visibility)

    bpy.types.Scene.collider_renderable = BoolProperty(name='Collider Renderable',
                                                       get=get_collider_renderable,
                                                       set=set_collider_renderable)

    bpy.types.Scene.reference_display = EnumProperty(name='Reference Display', items=display_items,
                                                     get=get_reference_display,
                                                     set=set_reference_display)

    bpy.types.Scene.reference_visibility = EnumProperty(name='Reference Visibility', items=visibility_items,
                                                        get=get_reference_visibility,
                                                        set=set_reference_visibility)

    bpy.types.Scene.reference_renderable = BoolProperty(name='Reference Renderable',
                                                        get=get_reference_renderable,
                                                        set=set_reference_renderable)

    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
