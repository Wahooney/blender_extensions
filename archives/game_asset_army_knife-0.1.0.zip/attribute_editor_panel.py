import bpy
import bmesh
from bpy.props import BoolProperty, FloatProperty, FloatVectorProperty, IntProperty


try:
    _REDRAW_TIMER_TOKEN += 1
except NameError:
    _REDRAW_TIMER_TOKEN = 0

try:
    _ATTRIBUTE_EDIT_CACHE
except NameError:
    _ATTRIBUTE_EDIT_CACHE = {
        'valid': False,
    }


SUPPORTED_DATA_TYPES = {
    'FLOAT',
    'FLOAT_COLOR',
    'FLOAT_VECTOR',
    'BYTE_COLOR',
    'INT',
    'BOOLEAN',
}

DATA_TYPE_LABELS = {
    'FLOAT': 'Float',
    'FLOAT_COLOR': 'Color',
    'FLOAT_VECTOR': 'Vector',
    'BYTE_COLOR': 'Color',
    'INT': 'Int',
    'BOOLEAN': 'Bool',
}

DOMAIN_LABELS = {
    'POINT': 'Vertex',
    'EDGE': 'Edge',
    'FACE': 'Face',
    'CORNER': 'Face Corner',
}

EDIT_LAYER_NAMES = {
    'FLOAT': 'float',
    'FLOAT_COLOR': 'float_color',
    'FLOAT_VECTOR': 'float_vector',
    'BYTE_COLOR': 'color',
    'INT': 'int',
    'BOOLEAN': 'bool',
}


def _active_mesh_object(context):
    obj = context.active_object
    if obj is None or obj.type != 'MESH':
        return None

    return obj


def _active_attribute(context):
    obj = _active_mesh_object(context)
    if obj is None:
        return None

    return obj.data.attributes.active


def _active_attribute_info(context):
    attribute = _active_attribute(context)
    if attribute is None:
        return None

    if attribute.data_type not in SUPPORTED_DATA_TYPES:
        return None

    return {
        'name': attribute.name,
        'data_type': attribute.data_type,
        'domain': attribute.domain,
    }


def _compatible_domains(context):
    obj = _active_mesh_object(context)
    if obj is None or obj.mode != 'EDIT':
        return {'POINT', 'EDGE', 'FACE', 'CORNER'}

    vertex_mode, edge_mode, face_mode = context.tool_settings.mesh_select_mode
    domains = set()

    if vertex_mode:
        domains.add('POINT')
    if edge_mode:
        domains.add('EDGE')
    if face_mode:
        domains.add('FACE')
        domains.add('CORNER')

    return domains


def _update_from_editmode(obj):
    if obj is not None and obj.mode == 'EDIT':
        try:
            obj.update_from_editmode()
        except RuntimeError:
            pass


def _is_face_selected(mesh, polygon, select_mode):
    if polygon.select:
        return True

    vertex_mode, edge_mode, face_mode = select_mode
    if face_mode:
        return False

    if vertex_mode and all(mesh.vertices[index].select for index in polygon.vertices):
        return True

    if edge_mode:
        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]
            if not mesh.edges[loop.edge_index].select:
                return False

        return True

    return False


def _selected_corner_indices(mesh, select_mode):
    vertex_mode, edge_mode, face_mode = select_mode
    selected = []

    for polygon in mesh.polygons:
        if face_mode and polygon.select:
            selected.extend(polygon.loop_indices)
            continue

        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]

            if vertex_mode and mesh.vertices[loop.vertex_index].select:
                selected.append(loop_index)
                continue

            if edge_mode and mesh.edges[loop.edge_index].select:
                selected.append(loop_index)

    return selected


def _iter_selected_bmesh_elements(bm, domain, context):
    # Keep this out of property getters and panel draw; use the edit cache there.
    vertex_mode, edge_mode, face_mode = context.tool_settings.mesh_select_mode

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    if domain == 'POINT':
        for vertex in bm.verts:
            if vertex.select:
                yield vertex

    elif domain == 'EDGE':
        for edge in bm.edges:
            if edge.select:
                yield edge

    elif domain == 'FACE':
        for face in bm.faces:
            if face.select:
                yield face
                continue

            if face_mode:
                continue

            if vertex_mode and all(vertex.select for vertex in face.verts):
                yield face
                continue

            if edge_mode and all(edge.select for edge in face.edges):
                yield face

    elif domain == 'CORNER':
        for face in bm.faces:
            if face_mode and face.select:
                yield from face.loops
                continue

            for loop in face.loops:
                if vertex_mode and loop.vert.select:
                    yield loop
                    continue

                if edge_mode and loop.edge.select:
                    yield loop


def _selected_indices(obj, domain, context):
    _update_from_editmode(obj)

    mesh = obj.data
    select_mode = context.tool_settings.mesh_select_mode

    if domain == 'POINT':
        return [vertex.index for vertex in mesh.vertices if vertex.select]

    if domain == 'EDGE':
        return [edge.index for edge in mesh.edges if edge.select]

    if domain == 'FACE':
        return [polygon.index for polygon in mesh.polygons if _is_face_selected(mesh, polygon, select_mode)]

    if domain == 'CORNER':
        return _selected_corner_indices(mesh, select_mode)

    return []


def _edit_cache_key(obj, info, context):
    return (
        obj.as_pointer(),
        obj.data.as_pointer(),
        info['name'],
        info['data_type'],
        info['domain'],
        tuple(context.tool_settings.mesh_select_mode),
    )


def _reset_edit_cache():
    global _ATTRIBUTE_EDIT_CACHE
    _ATTRIBUTE_EDIT_CACHE = {
        'valid': False,
    }


def _get_edit_cache(context):
    obj = _active_mesh_object(context)
    info = _active_attribute_info(context)

    if obj is None or info is None or obj.mode != 'EDIT':
        return None

    if not _ATTRIBUTE_EDIT_CACHE.get('valid', False):
        return None

    if _ATTRIBUTE_EDIT_CACHE.get('key') != _edit_cache_key(obj, info, context):
        return None

    return _ATTRIBUTE_EDIT_CACHE


def _modal_operator_is_busy():
    window = bpy.context.window
    if window is None or not hasattr(window, 'modal_operators'):
        return False

    return len(window.modal_operators) > 0


def _update_edit_cache(context):
    global _ATTRIBUTE_EDIT_CACHE

    obj = _active_mesh_object(context)
    info = _active_attribute_info(context)

    if obj is None or info is None or obj.mode != 'EDIT':
        _reset_edit_cache()
        return

    if _modal_operator_is_busy():
        return

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except RuntimeError:
        _reset_edit_cache()
        return

    layers = _edit_layers_for_domain(bm, info['domain'])
    layer = _get_edit_layer(layers, info['data_type'], info['name'])
    key = _edit_cache_key(obj, info, context)

    if layer is None:
        _ATTRIBUTE_EDIT_CACHE = {
            'valid': True,
            'key': key,
            'layer_available': False,
            'count': 0,
            'true_count': 0,
            'float': 0.0,
            'int': 0,
            'bool': False,
            'vector': (0.0, 0.0, 0.0),
            'color': (0.0, 0.0, 0.0, 1.0),
        }
        return

    values = []
    for element in _iter_selected_bmesh_elements(bm, info['domain'], context):
        value = _value_from_edit_layer(element[layer], info['data_type'])
        if value is not None:
            values.append(value)

    count = len(values)
    true_count = 0

    cache = {
        'valid': True,
        'key': key,
        'layer_available': True,
        'count': count,
        'true_count': 0,
        'float': 0.0,
        'int': 0,
        'bool': False,
        'vector': (0.0, 0.0, 0.0),
        'color': (0.0, 0.0, 0.0, 1.0),
    }

    if info['data_type'] == 'FLOAT':
        cache['float'] = _mean_scalar([float(value) for value in values], 0.0)

    elif info['data_type'] == 'INT':
        cache['int'] = int(round(_mean_scalar([int(value) for value in values], 0.0)))

    elif info['data_type'] == 'BOOLEAN':
        true_count = sum(1 for value in values if value)
        cache['true_count'] = true_count
        cache['bool'] = count > 0 and true_count >= count * 0.5

    elif info['data_type'] == 'FLOAT_VECTOR':
        cache['vector'] = _mean_vector(values, 3, (0.0, 0.0, 0.0))

    elif info['data_type'] in {'FLOAT_COLOR', 'BYTE_COLOR'}:
        cache['color'] = _mean_vector(values, 4, (0.0, 0.0, 0.0, 1.0))

    _ATTRIBUTE_EDIT_CACHE = cache


def _tag_view3d_redraw():
    window_manager = bpy.context.window_manager
    if window_manager is None:
        return

    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue

        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _attribute_editor_redraw_timer(_token=_REDRAW_TIMER_TOKEN):
    if _token != _REDRAW_TIMER_TOKEN:
        return None

    obj = bpy.context.active_object
    if obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT':
        _update_edit_cache(bpy.context)
        _tag_view3d_redraw()
    else:
        _reset_edit_cache()

    return 0.15


def _register_redraw_timer():
    if not bpy.app.timers.is_registered(_attribute_editor_redraw_timer):
        bpy.app.timers.register(_attribute_editor_redraw_timer, persistent=True)


def _unregister_redraw_timer():
    global _REDRAW_TIMER_TOKEN
    _REDRAW_TIMER_TOKEN += 1

    if bpy.app.timers.is_registered(_attribute_editor_redraw_timer):
        bpy.app.timers.unregister(_attribute_editor_redraw_timer)


def _attribute_data_for_object(obj, info):
    mesh = obj.data

    if info['name'] not in mesh.attributes:
        return None

    attribute = mesh.attributes[info['name']]
    if attribute.data_type != info['data_type'] or attribute.domain != info['domain']:
        return None

    return attribute.data


def _edit_layers_for_domain(bm, domain):
    if domain == 'POINT':
        return bm.verts.layers

    if domain == 'EDGE':
        return bm.edges.layers

    if domain == 'FACE':
        return bm.faces.layers

    if domain == 'CORNER':
        return bm.loops.layers

    return None


def _get_edit_layer(layers, data_type, name):
    if layers is None:
        return None

    layer_collection_name = EDIT_LAYER_NAMES.get(data_type)
    if layer_collection_name is None or not hasattr(layers, layer_collection_name):
        return None

    layer_collection = getattr(layers, layer_collection_name)

    try:
        return layer_collection.get(name)
    except AttributeError:
        try:
            return layer_collection[name]
        except KeyError:
            return None


def _value_from_attribute_item(item, data_type):
    if data_type in {'FLOAT', 'INT', 'BOOLEAN'}:
        return item.value

    if data_type == 'FLOAT_VECTOR':
        return tuple(item.vector)

    if data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}:
        return tuple(item.color)

    return None


def _value_from_edit_layer(value, data_type):
    if data_type in {'FLOAT', 'INT', 'BOOLEAN'}:
        return value

    if data_type in {'FLOAT_VECTOR', 'FLOAT_COLOR', 'BYTE_COLOR'}:
        return tuple(value)

    return None


def _set_attribute_item_value(item, data_type, value):
    if data_type == 'FLOAT':
        item.value = float(value)
    elif data_type == 'INT':
        item.value = int(round(value))
    elif data_type == 'BOOLEAN':
        item.value = bool(value)
    elif data_type == 'FLOAT_VECTOR':
        item.vector = value[:3]
    elif data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}:
        item.color = value[:4]


def _set_edit_layer_value(element, layer, data_type, value):
    if data_type == 'FLOAT':
        element[layer] = float(value)
    elif data_type == 'INT':
        element[layer] = int(round(value))
    elif data_type == 'BOOLEAN':
        element[layer] = bool(value)
    elif data_type == 'FLOAT_VECTOR':
        element[layer] = value[:3]
    elif data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}:
        element[layer] = value[:4]


def _iter_selected_attribute_items(context):
    obj = _active_mesh_object(context)
    info = _active_attribute_info(context)

    if obj is None or info is None:
        return

    data = _attribute_data_for_object(obj, info)
    if data is None:
        return

    for index in _selected_indices(obj, info['domain'], context):
        yield data[index], info['data_type']


def _selected_values(context):
    obj = _active_mesh_object(context)

    if obj is not None and obj.mode == 'EDIT':
        return []

    values = []

    for item, data_type in _iter_selected_attribute_items(context):
        value = _value_from_attribute_item(item, data_type)
        if value is not None:
            values.append(value)

    return values


def _mean_scalar(values, default=0.0):
    if len(values) == 0:
        return default

    return sum(values) / len(values)


def _mean_vector(values, size, default):
    if len(values) == 0:
        return default

    result = [0.0] * size

    for value in values:
        for index in range(size):
            result[index] += value[index]

    return tuple(component / len(values) for component in result)


def _set_selected_values(context, value):
    obj = _active_mesh_object(context)
    info = _active_attribute_info(context)

    if obj is None or info is None:
        return

    if obj.mode == 'EDIT':
        _set_selected_edit_layer_values(obj, info, context, value)
        _update_edit_cache(context)
        return

    data = _attribute_data_for_object(obj, info)
    if data is None:
        return

    for index in _selected_indices(obj, info['domain'], context):
        _set_attribute_item_value(data[index], info['data_type'], value)

    obj.data.update()
    obj.data.update_tag()


def _set_selected_edit_layer_values(obj, info, context, value):
    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except RuntimeError:
        return

    layers = _edit_layers_for_domain(bm, info['domain'])
    layer = _get_edit_layer(layers, info['data_type'], info['name'])
    if layer is None:
        return

    for element in _iter_selected_bmesh_elements(bm, info['domain'], context):
        _set_edit_layer_value(element, layer, info['data_type'], value)

    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _selected_count(context):
    obj = _active_mesh_object(context)
    info = _active_attribute_info(context)

    if obj is None or info is None:
        return 0

    if obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return 0

        return cache.get('count', 0)

    return len(_selected_indices(obj, info['domain'], context))


def _bool_selection_counts(context):
    obj = _active_mesh_object(context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return 0, 0

        return cache.get('true_count', 0), cache.get('count', 0)

    values = _selected_values(context)

    if len(values) == 0:
        return 0, 0

    true_count = sum(1 for value in values if value)
    return true_count, len(values)


def get_attribute_float(self):
    context = bpy.context
    obj = _active_mesh_object(context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return 0.0

        return cache.get('float', 0.0)

    values = _selected_values(context)
    return _mean_scalar([float(value) for value in values], 0.0)


def set_attribute_float(self, value):
    _set_selected_values(bpy.context, float(value))


def get_attribute_int(self):
    context = bpy.context
    obj = _active_mesh_object(context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return 0

        return cache.get('int', 0)

    values = _selected_values(context)
    return int(round(_mean_scalar([int(value) for value in values], 0.0)))


def set_attribute_int(self, value):
    _set_selected_values(bpy.context, int(value))


def get_attribute_bool(self):
    obj = _active_mesh_object(bpy.context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(bpy.context)
        if cache is None:
            return False

        return cache.get('bool', False)

    true_count, count = _bool_selection_counts(bpy.context)
    return count > 0 and true_count >= count * 0.5


def set_attribute_bool(self, value):
    _set_selected_values(bpy.context, bool(value))


def get_attribute_vector(self):
    context = bpy.context
    obj = _active_mesh_object(context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return (0.0, 0.0, 0.0)

        return cache.get('vector', (0.0, 0.0, 0.0))

    values = _selected_values(context)
    return _mean_vector(values, 3, (0.0, 0.0, 0.0))


def set_attribute_vector(self, value):
    _set_selected_values(bpy.context, tuple(value[:3]))


def get_attribute_color(self):
    context = bpy.context
    obj = _active_mesh_object(context)
    if obj is not None and obj.mode == 'EDIT':
        cache = _get_edit_cache(context)
        if cache is None:
            return (0.0, 0.0, 0.0, 1.0)

        return cache.get('color', (0.0, 0.0, 0.0, 1.0))

    values = _selected_values(context)
    return _mean_vector(values, 4, (0.0, 0.0, 0.0, 1.0))


def set_attribute_color(self, value):
    _set_selected_values(bpy.context, tuple(value[:4]))


class GAME_ASSET_ARMY_KNIFE_OT_CreateActiveAttributeOnSelected(bpy.types.Operator):
    """Create the active mesh attribute on selected mesh objects when it is missing"""

    bl_idname = "game_asset_army_knife.create_active_attribute_on_selected"
    bl_label = "Create Active Attribute on Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _active_mesh_object(context)
        if obj is None or obj.data.attributes.active is None:
            return False

        selected_meshes = [selected for selected in context.selected_objects if selected.type == 'MESH']
        return len(selected_meshes) > 1

    def execute(self, context):
        active = _active_mesh_object(context)
        source = active.data.attributes.active if active is not None else None

        if active is None or source is None:
            return {'CANCELLED'}

        source_name = source.name
        source_data_type = source.data_type
        source_domain = source.domain

        created = 0
        existing = 0
        failed = 0
        original_mode = active.mode

        if original_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except RuntimeError:
                self.report({'WARNING'}, "Could not leave edit mode to create attributes")
                return {'CANCELLED'}

        try:
            for obj in context.selected_objects:
                if obj is active or obj.type != 'MESH':
                    continue

                if source_name in obj.data.attributes:
                    existing += 1
                    continue

                try:
                    attribute = obj.data.attributes.new(source_name, source_data_type, source_domain)
                    obj.data.attributes.active = attribute
                    created += 1
                except TypeError:
                    failed += 1
                except RuntimeError:
                    failed += 1

        finally:
            if original_mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode=original_mode)
                except RuntimeError:
                    self.report({'WARNING'}, F"Could not restore {original_mode.lower()} mode")

        message = F"Created '{source_name}' on {created} object(s)"
        if existing > 0:
            message += F", skipped {existing} existing"
        if failed > 0:
            message += F", failed {failed}"

        self.report({'INFO'}, message)
        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_PT_MeshAttributeEditor(bpy.types.Panel):
    """Edit the active mesh attribute on selected geometry"""

    bl_label = "Mesh Attribute"
    bl_idname = "GAME_ASSET_ARMY_KNIFE_PT_mesh_attribute_editor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Item'

    @classmethod
    def poll(cls, context):
        return _active_mesh_object(context) is not None

    def draw_attribute_list(self, layout, obj):
        col = layout.column(align=True)
        col.label(text="Attributes")

        row = col.row()
        row.template_list("MESH_UL_attributes",
                          "attributes",
                          obj.data,
                          "attributes",
                          obj.data.attributes,
                          "active_index",
                          rows=3)

        controls = row.column(align=True)
        controls.operator("geometry.attribute_add", text="", icon='ADD')
        controls.operator("geometry.attribute_remove", text="", icon='REMOVE')
        controls.separator()
        controls.operator(GAME_ASSET_ARMY_KNIFE_OT_CreateActiveAttributeOnSelected.bl_idname,
                          text="",
                          icon='DUPLICATE')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = _active_mesh_object(context)

        self.draw_attribute_list(layout, obj)
        layout.separator()

        attribute = _active_attribute(context)

        if attribute is None:
            layout.label(text="No active mesh attribute", icon='INFO')
            return

        data_type = DATA_TYPE_LABELS.get(attribute.data_type, attribute.data_type)
        domain = DOMAIN_LABELS.get(attribute.domain, attribute.domain)
        layout.label(text=F"{data_type} - {domain}")

        if attribute.data_type not in SUPPORTED_DATA_TYPES:
            layout.label(text="Unsupported attribute type", icon='ERROR')
            return

        domains = _compatible_domains(context)
        if obj.mode == 'EDIT' and attribute.domain not in domains:
            layout.label(text="Switch selection mode for this domain", icon='INFO')
            return

        info = _active_attribute_info(context)
        if info is not None and obj.mode == 'EDIT':
            cache = _get_edit_cache(context)
            if cache is None:
                layout.label(text="Updating selection value", icon='TIME')
                return

            if not cache.get('layer_available', False):
                layout.label(text="Attribute layer unavailable in edit mode", icon='ERROR')
                return

        count = _selected_count(context)
        if count == 0:
            layout.label(text=F"No selected {domain.lower()} elements", icon='INFO')
            return

        layout.label(text=F"{count} selected - mean value")

        if attribute.data_type == 'FLOAT':
            layout.prop(scene, "game_asset_army_knife_attribute_float", text="Value")
        elif attribute.data_type == 'INT':
            layout.prop(scene, "game_asset_army_knife_attribute_int", text="Value")
        elif attribute.data_type == 'BOOLEAN':
            true_count, bool_count = _bool_selection_counts(context)
            row = layout.row(align=True)
            row.prop(scene, "game_asset_army_knife_attribute_bool", text="Value")
            row.label(text=F"{true_count}/{bool_count}")
        elif attribute.data_type == 'FLOAT_VECTOR':
            layout.prop(scene, "game_asset_army_knife_attribute_vector", text="Value")
        elif attribute.data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}:
            layout.prop(scene, "game_asset_army_knife_attribute_color", text="Value")


classes = [
    GAME_ASSET_ARMY_KNIFE_OT_CreateActiveAttributeOnSelected,
    GAME_ASSET_ARMY_KNIFE_PT_MeshAttributeEditor,
]


def register():
    _register_redraw_timer()

    bpy.types.Scene.game_asset_army_knife_attribute_float = FloatProperty(name="Attribute Float",
                                                                          get=get_attribute_float,
                                                                          set=set_attribute_float)

    bpy.types.Scene.game_asset_army_knife_attribute_int = IntProperty(name="Attribute Int",
                                                                      get=get_attribute_int,
                                                                      set=set_attribute_int)

    bpy.types.Scene.game_asset_army_knife_attribute_bool = BoolProperty(name="Attribute Bool",
                                                                        get=get_attribute_bool,
                                                                        set=set_attribute_bool)

    bpy.types.Scene.game_asset_army_knife_attribute_vector = FloatVectorProperty(name="Attribute Vector",
                                                                                 size=3,
                                                                                 get=get_attribute_vector,
                                                                                 set=set_attribute_vector)

    bpy.types.Scene.game_asset_army_knife_attribute_color = FloatVectorProperty(name="Attribute Color",
                                                                                subtype='COLOR',
                                                                                size=4,
                                                                                min=0.0,
                                                                                max=1.0,
                                                                                get=get_attribute_color,
                                                                                set=set_attribute_color)

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    _unregister_redraw_timer()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    for prop in (
        "game_asset_army_knife_attribute_color",
        "game_asset_army_knife_attribute_vector",
        "game_asset_army_knife_attribute_bool",
        "game_asset_army_knife_attribute_int",
        "game_asset_army_knife_attribute_float",
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
