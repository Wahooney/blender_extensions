# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import bpy
import bmesh
from pathlib import Path
import re

SHARED_EMPTY = '__SHARED_EMPTY_MESH_DATA__'

################################################################################
# Functions


################################################################################
# Shared Empty Mesh
#
# Find or create a shared empty mesh

def get_shared_empty_mesh():
    if SHARED_EMPTY in bpy.data.meshes:
        return bpy.data.meshes[SHARED_EMPTY]

    empty_mesh = bpy.data.meshes.new(SHARED_EMPTY)
    empty_mesh.use_fake_user = True
    return empty_mesh


def collapse_modifiers(obj):
    # apply all modifiers except armature
    for mod in obj.modifiers:
        mod.show_expanded = False


def get_node_groups_by_name(names):

    # check how many nodes we already have loaded
    import_names = [n for n in names if n not in bpy.data.node_groups]
    if len(import_names) == 0:
        print("We have it all")
        return [bpy.data.node_groups[n] for n in names if n in bpy.data.node_groups]

    asset_libraries = bpy.context.preferences.filepaths.asset_libraries[:]

    for a in asset_libraries:
        path = Path(a.path)

        blends = [str(fp) for fp in path.glob("**/*.blend") if fp.is_file()]
        for blend in blends:
            print(blend)

            with bpy.data.libraries.load(blend, assets_only=True, link=False) as (contents, localdata):

                for n in contents.node_groups:
                    if n not in import_names:
                        continue

                    localdata.node_groups.append(n)

    print("Imports needed")
    return [bpy.data.node_groups[n] for n in names if n in bpy.data.node_groups]


def get_node_group_by_name(name):
    result = get_node_groups_by_name([name])
    if len(result) > 0:
        return result[0]
    return None


def set_modifier_property(modifier, socket_name, value):
    if bpy.app.version < (5, 2, 0):
        if socket_name in modifier:
            modifier[socket_name] = value
    else:
        inputs = modifier.properties.inputs
        if hasattr(inputs, socket_name):
            inputs[socket_name]['value'] = value


def get_modifier_property(modifier, socket_name):
    if bpy.app.version < (5, 2, 0):
        if socket_name in modifier:
            return modifier[socket_name]
        return None
    else:
        return getattr(modifier.properties.inputs, socket_name, None)


def face_islands(bm):

    result = []
    used = set()

    bm.faces.ensure_lookup_table()

    for seed_face in bm.faces:

        if seed_face in used:
            continue

        used.add(seed_face)
        island = [seed_face]
        stack = [seed_face]  # Faces still to consider on this island.

        while stack:
            current_face = stack.pop()

            for v in current_face.edges:

                for f in v.link_faces:
                    if f is current_face or f in used:
                        continue

                    # `f` is part of island, add to island and stack
                    used.add(f)
                    island.append(f)
                    stack.append(f)

        result.append(island)

    return result


def evaluated_mesh_count(context, obj, method):

    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()

    try:
        if mesh is None:
            return 0

        if method == 'ISLANDS':
            bm = bmesh.new()
            try:
                bm.from_mesh(mesh)
                return len(face_islands(bm))
            finally:
                bm.free()

        if method == 'FACES':
            return len(mesh.polygons)

        return 0
    finally:
        eval_obj.to_mesh_clear()


def get_trailing_number(s):
    string_match = re.search(r'(\d+)$', s)
    if string_match:
        return int(string_match.group(1))
    return None


def get_or_add_object_by_name(name, collection):

    empty_mesh = get_shared_empty_mesh()

    c = None

    if name in bpy.data.objects:
        c = bpy.data.objects[name]
        if name not in collection.objects:
            collection.objects.link(c)
    else:
        c = bpy.data.objects.new(name, empty_mesh)
        collection.objects.link(c)

    return c


def advanced_mesh_setup(context, method, ignore_existing_colliders=False):

    ############################################################################################
    # Get the empty mesh
    empty_mesh = get_shared_empty_mesh()

    act = context.active_object
    target = None
    for sel in context.selected_objects:
        if sel is not act:
            target = sel
            break

    if target is None:
        return

    # this needs to be better
    sel = act
    all_colliders = []

    count = 0

    if method in {'ISLANDS', 'FACES'}:
        count = evaluated_mesh_count(context, target, method)

    col = get_best_collection(sel)
    colliders = []

    index_offset = 1

    if ignore_existing_colliders:
        highest = index_offset

        for ob in col.objects:
            if not ob.name.startswith("UCX_"):
                continue

            v = get_trailing_number(ob.name)
            if ob is not None:
                highest = max(v, highest)

        index_offset = highest + 1

    target.display_type = 'WIRE'

    attach, isolate, hull = get_node_groups_by_name(['Attach Geometry', 'Isolate Face By Index', 'Basic Hull'])

    for i in range(count):

        name = F"UCX_{col.name}_{i+index_offset:02}"
        c = get_or_add_object_by_name(name, col)

        colliders.append(c)

        if c.data == empty_mesh:
            c.data = empty_mesh
        c.matrix_world = sel.matrix_world

        mod = None
        if "Attach Geometry" not in c.modifiers:
            mod = c.modifiers.new("Attach Geometry", "NODES")
            mod.node_group = attach
        else:
            mod = c.modifiers["Attach Geometry"]

        if method == 'ISLANDS':
            set_modifier_property(mod, 'Socket_2', sel)
        elif method == 'FACES':
            set_modifier_property(mod, 'Socket_2', target)

            if "Isolate Face By Index" not in c.modifiers:
                mod = c.modifiers.new("Isolate Face By Index", "NODES")
                mod.node_group = isolate

            set_modifier_property(mod, 'Socket_3', i)

            if "Solidify" not in c.modifiers:
                mod = c.modifiers.new("Solidify", "SOLIDIFY")
                mod.thickness = 1.0 / context.scene.unit_settings.scale_length
                mod.offset = 0.0

        if "Attach Geometry - Int" not in c.modifiers:
            mod = c.modifiers.new("Attach Geometry - Int", "NODES")
            mod.node_group = attach
        else:
            mod = c.modifiers["Attach Geometry - Int"]

        if method == 'ISLANDS':
            set_modifier_property(mod, 'Socket_2', target)
        elif method == 'FACES':
            set_modifier_property(mod, 'Socket_2', sel)

        set_modifier_property(mod, 'Socket_7', 5)

        if method == 'ISLANDS':
            set_modifier_property(mod, 'Socket_6', i)

        if "Triangulate" not in c.modifiers:
            c.modifiers.new("Triangulate", "TRIANGULATE")

        if "Decimate - Planar" not in c.modifiers:
            mod = c.modifiers.new("Decimate - Planar", "DECIMATE")
            mod.decimate_type = 'DISSOLVE'

        if "Basic Hull" not in c.modifiers:
            mod = c.modifiers.new("Basic Hull", "NODES")
            mod.node_group = hull

        if "Decimate" not in c.modifiers:
            c.modifiers.new("Decimate", "DECIMATE")

        all_colliders += colliders

    bpy.ops.object.select_all(action='DESELECT')

    for ob in col.objects:
        collapse_modifiers(ob)
        if ob.name.startswith("UCX_"):
            all_colliders.append(ob)

    all_colliders = list(set(all_colliders))

    if len(all_colliders) > 0:
        for col in all_colliders:
            col.select_set(True)

        context.view_layer.objects.active = colliders[0]
        bpy.ops.object.rename_ucx_colliders()


def get_best_collection(obj):
    cols = [c for c in obj.users_collection]

    if len(cols) == 0:
        return None

    if len(cols) == 1:
        return cols[0]

    cols = sorted(cols, key=lambda c: len(c.objects))
    return cols[0]


def basic_mesh_setup(context):  # , one_collider_per_collection=True):

    ############################################################################################
    # Get the empty mesh
    empty_mesh = get_shared_empty_mesh()

    all_colliders = []

    groups = {}

    for sel in context.selected_objects:

        if sel.name.startswith("UCX_"):
            continue

        col = get_best_collection(sel)

        if col not in groups:
            groups[col] = [sel]
        else:
            groups[col].append(sel)

    for col, objects in groups.items():

        colliders = [o for o in col.objects if o.name.startswith("UCX_")]

        pairs = []
        used_col = []
        used_ob = []

        for ob in objects:

            # check if this object is linked to a collider already
            for c in colliders:
                if c in used_col:
                    continue

                if "Attach Geometry" in c.modifiers:
                    mod = c.modifiers["Attach Geometry"]
                    if get_modifier_property(mod, 'Socket_2') == ob:
                        pairs.append((ob, c))
                        used_col.append(c)
                        used_ob.append(ob)
                        print(F"Reconnected '{ob.name}' '{col.name}'")
                        break

            if ob in used_ob:
                continue

            # create a new collider
            new_collider = bpy.data.objects.new(F"UCX_{col.name}_{len(colliders)+1:02}", empty_mesh)
            col.objects.link(new_collider)
            colliders.append(new_collider)
            pairs.append((ob, new_collider))
            used_col.append(new_collider)
            used_ob.append(ob)
            print(F"Created new collider for {ob.name}")

        attach, hull = get_node_groups_by_name(['Attach Geometry', 'Basic Hull'])

        for ob, c in pairs:

            c.matrix_world = ob.matrix_world

            if c.data == empty_mesh and len(c.modifiers) != 0:
                continue

            c.data = empty_mesh

            if "Attach Geometry" not in c.modifiers:
                mod = c.modifiers.new("Attach Geometry", "NODES")
                mod.node_group = attach
                set_modifier_property(mod, 'Socket_2', ob)

            if "Basic Hull" not in c.modifiers:
                mod = c.modifiers.new("Basic Hull", "NODES")
                mod.node_group = hull

            if "Decimate" not in c.modifiers:
                c.modifiers.new("Decimate", "DECIMATE")

        all_colliders += colliders
        print(len(colliders))

    bpy.ops.object.select_all(action='DESELECT')

    if len(all_colliders) > 0:
        for col in all_colliders:
            col.select_set(True)
            collapse_modifiers(col)

        context.view_layer.objects.active = colliders[0]
        bpy.ops.object.rename_ucx_colliders()


class GAME_ASSET_ARMY_KNIFE_OT_BasicMeshSetup(bpy.types.Operator):
    """"""
    bl_idname = "game_asset_army_knife.basic_mesh_setup"
    bl_label = "Basic Mesh Setup"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        basic_mesh_setup(context)
        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_FaceMeshSetup(bpy.types.Operator):
    """"""
    bl_idname = "game_asset_army_knife.face_mesh_setup"
    bl_label = "Face Mesh Setup"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 1

    def execute(self, context):
        advanced_mesh_setup(context, 'FACES', ignore_existing_colliders=True)
        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_IslandMeshSetup(bpy.types.Operator):
    """"""
    bl_idname = "game_asset_army_knife.island_mesh_setup"
    bl_label = "Island Mesh Setup"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 1

    def execute(self, context):
        advanced_mesh_setup(context, 'ISLANDS', ignore_existing_colliders=True)
        return {'FINISHED'}


def unique_name(name, domain):

    re_match = re.search(r'(\d+)$', name)

    if not re_match:

        # lets remove any trailing . in case
        if name.endswith('.'):
            name = name[:-1]

        # if we don't have end with a number,
        # add standard blender numbers at the end '.001'
        idx = 1
        fill = 3  # in case we go beyond .999 (unlikely but let's do it)
        result = f'{name}.{str(idx).zfill(fill)}'

        while result in domain:
            idx += 1
            fill = max(fill, len(str(idx)))
            result = f'{name}.{str(idx).zfill(fill)}'

        return F'{result}'

    # otherwise carry on with the current numbering scheme
    # just iterate the number
    idx = int(re_match.group(1)) + 1
    length = len(re_match.group(1))
    stripped_name = name[:-length]
    result = f'{stripped_name}{str(idx).zfill(length)}'

    while result in domain:
        idx += 1
        result = f'{stripped_name}{str(idx).zfill(length)}'

    return result


def add_attach_modifiers(target, source):

    attach = get_node_group_by_name('Attach Geometry')
    mod = target.modifiers.new("Attach Geometry", "NODES")
    mod.node_group = attach
    set_modifier_property(mod, 'Socket_2', source)

    return mod


def make_attached_duplicate(context, flipped=False):

    selection = context.selected_objects[:]

    empty = get_shared_empty_mesh()

    new_objs = []

    for sel in selection:

        new_name = unique_name(sel.name, bpy.data.objects)

        if flipped:
            new_name = f'REF_{sel.name}'

        data = sel.data if flipped else empty

        obj = bpy.data.objects.new(new_name, data)
        get_best_collection(sel).objects.link(obj)

        obj.parent = sel.parent
        obj.matrix_world = sel.matrix_world

        if flipped:
            sel.data = empty
            add_attach_modifiers(sel, obj)
            sel.modifiers.move(len(sel.modifiers)-1, 0)

        else:
            add_attach_modifiers(obj, sel)

        new_objs.append(obj)

    if len(new_objs) > 0:
        bpy.ops.object.select_all(action='DESELECT')

        for obj in new_objs:
            obj.select_set(True)

        context.view_layer.objects.active = new_objs[0]


class GAME_ASSET_ARMY_KNIFE_OT_MakeAttachedDuplicate(bpy.types.Operator):
    """Makes attached duplicates of the selected objects"""
    bl_idname = "game_asset_army_knife.make_attached_duplicates"
    bl_label = "Make Attached Duplicates"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        make_attached_duplicate(context)
        return {'FINISHED'}


class GAME_ASSET_ARMY_KNIFE_OT_MakeDeferredAttachedDuplicate(bpy.types.Operator):
    """Makes the selected objects attached duplicates, making the original objects reference objects"""
    bl_idname = "game_asset_army_knife.make_deferred_attached_duplicates"
    bl_label = "Make Deferred Attached Duplicates"
    bl_options = {'UNDO', 'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        make_attached_duplicate(context, flipped=True)
        return {'FINISHED'}


# Register and add to the "object" menu (required to also use F3 search "Simple Object Operator" for quick access).
def register():
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_MakeAttachedDuplicate)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_MakeDeferredAttachedDuplicate)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_BasicMeshSetup)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_FaceMeshSetup)
    bpy.utils.register_class(GAME_ASSET_ARMY_KNIFE_OT_IslandMeshSetup)


def unregister():
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_MakeAttachedDuplicate)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_MakeDeferredAttachedDuplicate)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_BasicMeshSetup)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_FaceMeshSetup)
    bpy.utils.unregister_class(GAME_ASSET_ARMY_KNIFE_OT_IslandMeshSetup)


# if __name__ == "__main__":
#    register()

#    test call
#    bpy.ops.object.make_deferred_attached_duplicates()
#    bpy.ops.object.make_attached_duplicates()
#    bpy.ops.object.island_mesh_setup()
#    bpy.ops.object.face_mesh_setup()
#    bpy.ops.object.basic_mesh_setup()
