# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import bpy

VALUE_KEY = 'wofc_optimized_face_count_stored'


class OBJECT_OT_OptimizeFaceCount(bpy.types.Operator):
    bl_idname = "mesh.optimize_face_count"
    bl_label = "Optimize Face Count"
    bl_options = {'REGISTER', 'UNDO'}

    override_stored_count: bpy.props.BoolProperty(
        name="Override Stored Count",
        description="Override the stored optimized face count for the selected objects",
        default=True
    )

    target_face_count: bpy.props.IntProperty(
        name="Target Face Count",
        description="The desired face count for the selected objects",
        default=500,
        min=1
    )

    def update_face_count(self, obj):
        bpy.context.view_layer.update()
        bpy.context.window_manager.windows.update()

        eval = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        count = len(eval.data.polygons)
        eval.to_mesh_clear()

        return count

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):

        for obj in context.selected_objects:

            mod = None

            # always use the last decimate > collapse modifier
            for m in obj.modifiers:
                if m.type == 'DECIMATE' and m.decimate_type == 'COLLAPSE':
                    mod = m

            if mod is None:
                continue

            print(mod.name)

            target_face_count = self.target_face_count

            if VALUE_KEY in obj and not self.override_stored_count:
                target_face_count = obj[VALUE_KEY]
            else:
                obj[VALUE_KEY] = target_face_count

            face_count = self.update_face_count(obj)

            if face_count == target_face_count:
                self.report({'INFO'}, f"Object {obj.name} already has {target_face_count} faces.")
                continue

            mod.use_collapse_triangulate = True

            mod.ratio = 1.0
            face_count = self.update_face_count(obj)

            if face_count <= target_face_count:
                self.report({'INFO'}, f"Object {obj.name} already has {target_face_count} ({face_count}) faces.")
                continue

            '''ratio = target_face_count / face_count
            lower, upper = ratio - ratio * 0.1, ratio + ratio * 0.1
            print(F"Starting ratio {ratio} Lower {lower} Upper {upper}")
            mod.ratio = ratio
            face_count = self.update_face_count(obj)'''

            # this works, but the above might get us there faster
            lower, upper = 0.0, 1.0
            mod.ratio = (upper + lower) / 2
            face_count = self.update_face_count(obj)

            attempts = 50
            while attempts > 0 and face_count != target_face_count:

                attempts -= 1

                if face_count < target_face_count:
                    lower = mod.ratio
                else:
                    upper = mod.ratio

                mod.ratio = (upper + lower) / 2
                face_count = self.update_face_count(obj)

                # if we're close enough, just give us a few more tries to get on target
                if target_face_count - face_count == 1 and attempts > 5:
                    attempts = 5

            self.report({'INFO'}, f"Final face count: {face_count}, Ratio: {mod.ratio} Attempts: {50 - attempts}")

        self.report({'INFO'}, "Optimization complete.")
        return {'FINISHED'}

    def draw(self, context):

        layout = self.layout

        current = [VALUE_KEY in obj for obj in context.selected_objects if obj.type == 'MESH']
        count = current.count(False)

        if count > 0:
            layout.label(text=F"{count} selected objects don't have a preferred face count. Using Target Face Count.", icon='INFO')

        if count >= 0:
            layout.prop(self, 'override_stored_count')

        layout.prop(self, 'target_face_count')


def menu_func(self, context):
    self.layout.operator(OBJECT_OT_OptimizeFaceCount.bl_idname)


def register():
    bpy.utils.register_class(OBJECT_OT_OptimizeFaceCount)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.utils.unregister_class(OBJECT_OT_OptimizeFaceCount)
    bpy.types.VIEW3D_MT_object.remove(menu_func)


if __name__ == "__main__":
    register()
