# wahooney_palette_map.py Copyright (C) 2020, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****


if 'bpy' in locals():

    import importlib
    importlib.reload(wahooney_palette_update_functions)

else:

    import bpy
    from . import wahooney_palette_update_functions


import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, Matrix, Color
from bpy.props import StringProperty

has_update_block = wahooney_palette_update_functions.has_update_block
request_update_block = wahooney_palette_update_functions.request_update_block
release_update_block = wahooney_palette_update_functions.release_update_block

bl_info = {
    'name': 'Palette Map',
    'author': 'Keith (Wahooney) Boshoff',
    'version': (1, 1, 0),
    'blender': (3, 6, 0),
    'category': 'Rendering'}


def clamp(value, min_value, max_value):
    return max(min_value, min(value, max_value))


def lerp(a, b, time):
    return a + (b - a) * time


def lerp_wrap(a, b, time):
    if abs(a - b) > abs(a - b + 1):
        c = lerp(b, a + 1, 1-time)
        return c if c <= 1 else c-1
    return lerp(a, b, time)


def lerp3(a, b, time):
    return (lerp(a[0], b[0], time),
            lerp(a[1], b[1], time),
            lerp(a[2], b[2], time))


def lerp4(a, b, time, use_gamma=1):

    if use_gamma != 1:
        time = pow(time, use_gamma)

    return (lerp(a[0], b[0], time),
            lerp(a[1], b[1], time),
            lerp(a[2], b[2], time),
            lerp(a[3], b[3], time))


def lerp_hsv(a, b, time):

    col_a = Color((a[0], a[1], a[2]))
    col_b = Color((b[0], b[1], b[2]))

    r = Color((0, 0, 0))
    r.hsv = (lerp_wrap(col_a.h, col_b.h, time),
             lerp(col_a.s, col_b.s, time),
             lerp(col_a.v, col_b.v, time))

    return (r.r, r.g, r.b,
            lerp(a[3], b[3], time))


def to_rgba(stop):

    value = stop.color
    alpha = 1

    return (value[0], value[1], value[2], alpha)


def get_color_corners(color_data, channel):

    color = color_data.channel_colors[channel]

    color0 = to_rgba(color.stops[0])

    if color.mode != 'SINGLE':

        color1 = to_rgba(color.stops[1])

        if color.mode == 'VERTICAL':
            return (color0, color0, color1, color1)

        elif color.mode == 'HORIZONTAL':
            return (color0, color1, color0, color1)

        elif color.mode == 'BIDIRECTION':
            return (color0, color1,
                    to_rgba(color.stops[2]),
                    to_rgba(color.stops[3]))

    return (color0, color0, color0, color0)


def copy_data(self, source, destination):
    for p in source.__annotations__.keys():
        try:
            setattr(destination, p, getattr(source, p))
        except:
            pass


def render_palette(context, palette, channel=''):

    channel_image_map = {}

    for channel_data in palette.channels:

        channel_image_map[channel_data.id] = channel_data.image

        if channel_data.image is not None:

            image_name = F'{context.scene.palette_map.texture_prefix}{palette.name}_{channel_data.name}'

            if channel_data.image.name != image_name:
                channel_data.image.name = image_name

    width = palette.width
    height = palette.height

    print("render palette")

    def draw_color(color_data, width, height, channel=''):

        colors = get_color_corners(color_data, channel)

        scale = color_data.span[0] * width, color_data.span[1] * height

        coords = []
        colors_list = []

        span_x = color_data.span[0]
        span_y = color_data.span[1]

        step_x = scale[0] / span_x
        step_y = scale[1] / span_y

        norm_steps_x = []
        norm_steps_y = []

        ramp_colors = [
            (0, 0, 0, 1),
            (1, 0, 0, 1),
            (0, 1, 0, 1),
            (1, 1, 0, 1)
        ]

        for x in range(span_x+1):
            norm_steps_x.append(x / span_x)

        for y in range(span_y+1):
            norm_steps_y.append(y / span_y)

        if color_data.method == 'SMOOTH':

            x = span_x * width
            y = span_y * height

            coords.append((0,        0))
            coords.append((0,        0))
            coords.append((0,        -scale[1]))
            coords.append((scale[0], 0))
            coords.append((scale[0], -scale[1]))
            coords.append((scale[0], -scale[1]))

            colors_list.append(ramp_colors[0])
            colors_list.append(ramp_colors[0])
            colors_list.append(ramp_colors[2])
            colors_list.append(ramp_colors[1])
            colors_list.append(ramp_colors[3])
            colors_list.append(ramp_colors[3])

        else:

            for y in range(span_y):

                norm_y = 0 if span_y < 2 else y / (span_y - 1)

                for x in range(span_x):

                    norm_x = 0 if span_x < 2 else x / (span_x - 1)

                    coords.append((x * step_x, y * -step_y))
                    coords.append((x * step_x, y * -step_y))
                    coords.append((x * step_x, (y + 1) * -step_y))
                    coords.append(((x + 1) * step_x, y * -step_y))
                    coords.append(((x + 1) * step_x, (y + 1) * -step_y))
                    coords.append(((x + 1) * step_x, (y + 1) * -step_y))

                    if color_data.method == 'SMOOTH':

                        c = lerp4(lerp4(ramp_colors[0], ramp_colors[1], norm_steps_x[x], use_gamma=color_data.bias),
                                  lerp4(ramp_colors[2], ramp_colors[3], norm_steps_x[x], use_gamma=color_data.bias), norm_steps_y[y], use_gamma=color_data.bias)

                        c1 = lerp4(lerp4(ramp_colors[0], ramp_colors[1], norm_steps_x[x], use_gamma=color_data.bias),
                                   lerp4(ramp_colors[2], ramp_colors[3], norm_steps_x[x], use_gamma=color_data.bias), norm_steps_y[y+1], use_gamma=color_data.bias)

                        c2 = lerp4(lerp4(ramp_colors[0], ramp_colors[1], norm_steps_x[x+1], use_gamma=color_data.bias),
                                   lerp4(ramp_colors[2], ramp_colors[3], norm_steps_x[x+1], use_gamma=color_data.bias), norm_steps_y[y], use_gamma=color_data.bias)

                        c3 = lerp4(lerp4(ramp_colors[0], ramp_colors[1], norm_steps_x[x+1], use_gamma=color_data.bias),
                                   lerp4(ramp_colors[2], ramp_colors[3], norm_steps_x[x+1], use_gamma=color_data.bias), norm_steps_y[y+1], use_gamma=color_data.bias)

                        colors_list.append(c)
                        colors_list.append(c)
                        colors_list.append(c1)
                        colors_list.append(c2)
                        colors_list.append(c3)
                        colors_list.append(c3)

                    elif color_data.method == 'STEPPED':

                        c = lerp4(lerp4(ramp_colors[0], ramp_colors[1], norm_x, use_gamma=color_data.bias),
                                  lerp4(ramp_colors[2], ramp_colors[3], norm_x, use_gamma=color_data.bias), norm_y, use_gamma=color_data.bias)

                        colors_list.append(c)
                        colors_list.append(c)
                        colors_list.append(c)
                        colors_list.append(c)
                        colors_list.append(c)
                        colors_list.append(c)

        ramp_colors = tuple(colors_list)
        coords = tuple(coords)

        # load shader file

        # TODO: Add HSV Shader

        import os
        working_path = os.path.dirname(os.path.realpath(__file__))

        with open(os.path.join(working_path, 'vertex_shader.glsl'), 'r') as file:
            vertex_shader = file.read()

        with open(os.path.join(working_path, 'fragment_shader.glsl'), 'r') as file:
            fragment_shader = file.read()

        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)

        shader.uniform_float("colorTL", colors[0])
        shader.uniform_float("colorTR", colors[1])
        shader.uniform_float("colorBL", colors[2])
        shader.uniform_float("colorBR", colors[3])
        shader.uniform_float("gamma", palette.gamma)
        shader.uniform_float("padding", palette.padding)

        batch = batch_for_shader(shader, 'TRI_STRIP', {"pos": coords, "color": ramp_colors})

        position = Vector(color_data.position)
        position.x = position.x * width
        position.y = 1 - position.y * height

        with gpu.matrix.push_pop():
            gpu.matrix.translate(position)
            shader.bind()
            batch.draw(shader)

    def draw_colors(context, palette, width, height, channel=''):

        gpu.state.blend_set('ALPHA')

        for color in palette.colors:
            if channel in color.channel_colors:
                draw_color(color, width, height, channel=channel)
            else:
                print(F"Draw Colors : {channel} doesn't exist")

        gpu.state.blend_set('NONE')

    def save_pixels(image, pixel_data, width, height, channel=''):

        methods = []

        try:

            methods = [func for func in bpy.app.handlers.depsgraph_update_post]
            bpy.app.handlers.depsgraph_update_post.clear()

            filepath = image.filepath_raw

            image.source = 'GENERATED'
            image.use_generated_float = True
            image.use_half_precision = False
            image.generated_width = width
            image.generated_height = height
            image.generated_color = (0, 0, 0, 0)

            image.colorspace_settings.name = 'sRGB' if channel == 'PBR' else 'Linear Rec.709'
            image.use_view_as_render = channel != 'PBR'

            image.pixels = pixel_data
            image.pack()

            image.filepath_raw = filepath

        except Exception as e:
            print(e)

        finally:

            for method in methods:
                bpy.app.handlers.depsgraph_update_post.append(method)

            pass

    def get_normalize_uvs_matrix():
        '''matrix maps x and y coordinates from [0, 1] to [-1, 1]'''
        matrix = Matrix.Identity(4)
        matrix.col[3][0] = -1
        matrix.col[3][1] = -1
        matrix[0][0] = 2
        matrix[1][1] = 2
        return matrix

    for channel, target in channel_image_map.items():

        if target is None:
            continue

        offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA32F')
        offscreen.bind()

        try:
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 0.0))

            with gpu.matrix.push_pop():

                gpu.matrix.load_matrix(get_normalize_uvs_matrix())
                gpu.matrix.load_projection_matrix(Matrix.Identity(4))

                draw_colors(context, palette,
                            width / palette.columns / width,
                            height / palette.rows / height,
                            channel=channel)

            pixel_data = fb.read_color(0, 0, width, height, 4, 0, 'FLOAT')
            pixel_data.dimensions = width * height * 4
            save_pixels(target, pixel_data, width, height, channel=channel)

        except Exception as e:
            print(e)

        finally:
            offscreen.unbind()
            offscreen.free()


class PALETTEMAP_OT_render(bpy.types.Operator):
    ''' '''
    bl_idname = 'palette_map.render'
    bl_label = 'Render'

    channel_id: StringProperty(default='')

    @classmethod
    def poll(cls, context):

        palette = None
        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index and context.scene.palette_map.active_index >= 0:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        return palette is not None

    def execute(self, context):

        if has_update_block(context.scene):
            print("Palette Map Render: Updating Blocked")
            return {'CANCELLED'}

        request_update_block(context.scene, 'Rendering')

        palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]

        render_palette(context, palette, channel='Base')

        release_update_block(context.scene, 'Rendering')

        return {'FINISHED'}
