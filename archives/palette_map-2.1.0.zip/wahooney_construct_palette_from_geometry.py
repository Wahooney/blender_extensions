from array import array
from math import ceil, sqrt

import bpy
from bpy.props import BoolProperty, FloatProperty, StringProperty
from mathutils import Color

from . import wahooney_palette_functions
from . import wahooney_palette_render_functions
from . import wahooney_palette_update_functions

get_palette_map = wahooney_palette_functions.get_palette_map
request_update_block = wahooney_palette_update_functions.request_update_block
release_update_block = wahooney_palette_update_functions.release_update_block


def get_image_pixels(image):
    width, height = image.size
    pixels = array('f', [0.0]) * (width * height * 4)
    image.pixels.foreach_get(pixels)
    return pixels, width, height


def sample_pixels(pixels, width, height, uv):
    x = min(width - 1, max(0, int(uv[0] * width)))
    y = min(height - 1, max(0, int(uv[1] * height)))
    index = (y * width + x) * 4
    return (pixels[index], pixels[index + 1], pixels[index + 2])


def colors_match(a, b, threshold):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]), abs(a[2] - b[2])) <= threshold


def color_sort_key(color):
    hue, saturation, value = Color(color).hsv

    if saturation < 0.05:
        return (0, value, color[0], color[1], color[2])

    return (1, hue, value, saturation)


def get_polygon_uv(uv_data, polygon):
    uv_x = 0.0
    uv_y = 0.0

    for loop_index in polygon.loop_indices:
        loop_uv = uv_data[loop_index].uv
        uv_x += loop_uv.x
        uv_y += loop_uv.y

    count = len(polygon.loop_indices)
    return (uv_x / count, uv_y / count)


def find_or_add_color(color, colors, threshold):
    for index, existing_color in enumerate(colors):
        if colors_match(color, existing_color, threshold):
            return index

    colors.append(color)
    return len(colors) - 1


def collect_face_colors(objects, image, source_uv_name, threshold):
    pixels, width, height = get_image_pixels(image)
    processed = set()
    colors = []
    face_assignments = {}
    skipped = []

    for obj in objects:
        if obj.type != 'MESH':
            continue

        mesh = obj.data
        mesh_key = mesh.as_pointer()

        if mesh_key in processed:
            continue

        processed.add(mesh_key)
        uv_layer = mesh.uv_layers.get(source_uv_name)

        if uv_layer is None:
            skipped.append(obj.name)
            continue

        mesh_assignments = []
        uv_data = uv_layer.data

        for polygon in mesh.polygons:
            uv = get_polygon_uv(uv_data, polygon)
            sampled_color = sample_pixels(pixels, width, height, uv)
            color_index = find_or_add_color(sampled_color, colors, threshold)
            mesh_assignments.append(color_index)

        face_assignments[mesh_key] = (mesh, mesh_assignments)

    return colors, face_assignments, skipped


def remap_face_assignments(face_assignments, index_map):
    for mesh_key, (mesh, color_indices) in face_assignments.items():
        face_assignments[mesh_key] = (mesh, [index_map[index] for index in color_indices])


def sort_colors_and_assignments(colors, face_assignments):
    sorted_items = sorted(enumerate(colors), key=lambda item: color_sort_key(item[1]))
    index_map = {old_index: new_index for new_index, (old_index, _) in enumerate(sorted_items)}
    remap_face_assignments(face_assignments, index_map)
    return [color for _, color in sorted_items]


def fit_palette_grid(palette, color_count):
    color_count = max(1, color_count)
    palette.columns = max(1, ceil(sqrt(color_count)))
    palette.rows = max(1, ceil(color_count / palette.columns))


def ensure_palette_capacity(palette, color_count):
    if palette.columns * palette.rows >= color_count:
        return

    columns = max(1, palette.columns)
    rows = max(1, palette.rows)

    while columns * rows < color_count:
        if columns <= rows:
            columns += 1
        else:
            rows += 1

    palette.columns = columns
    palette.rows = rows


def ensure_base_channel(palette_map, palette):
    channel = palette.find_channel_by_id('Base')

    if channel is None:
        channel = palette.channels.add()
        channel.initialize()
        channel.id = 'Base'
        channel.name = 'Base'
        channel.channel_type = 'COLOR'
        channel.image_color_space = 'sRGB'
        channel.use_as_render = True

    if channel.image is None:
        channel.image = bpy.data.images.new(
            wahooney_palette_render_functions.get_channel_image_name(palette_map, palette, channel),
            palette.width,
            palette.height,
            alpha=True,
            float_buffer=True)

    return channel


def set_palette_color_data(palette_color, channel, color):
    channel_color = palette_color.channel_colors.get(channel.id)

    if channel_color is None:
        channel_color = palette_color.channel_colors.add()
        channel_color.name = channel.id

    channel_color.mode = 'SINGLE'

    while len(channel_color.stops) < 4:
        channel_color.stops.add()

    for stop in channel_color.stops:
        stop.color = color


def add_palette_color(palette, channel, color):
    color_index = len(palette.colors)
    palette_color = palette.colors.add()
    palette_color.name = F'Color {color_index + 1:03d}'
    palette_color.position = (color_index % palette.columns, color_index // palette.columns)
    palette_color.span = (1, 1)
    set_palette_color_data(palette_color, channel, color)
    return palette_color


def get_palette_color_value(palette_color, channel):
    channel_color = palette_color.channel_colors.get(channel.id)

    if channel_color is None or len(channel_color.stops) == 0:
        return None

    color = channel_color.stops[0].color
    return (color[0], color[1], color[2])


def get_active_palette(palette_map):
    if palette_map.active_index < 0 or palette_map.active_index >= len(palette_map.palettes):
        return None

    return palette_map.palettes[palette_map.active_index]


def build_palette(palette_map, palette_name, colors, face_assignments, target_uv_name):
    colors = sort_colors_and_assignments(colors, face_assignments)

    palette = palette_map.palettes.add()
    palette.name = palette_name
    palette.palette_uv_attribute = target_uv_name
    fit_palette_grid(palette, len(colors))

    channel = ensure_base_channel(palette_map, palette)

    for color in colors:
        add_palette_color(palette, channel, color)

    palette.validate()
    palette.update_state('Construct From Geometry')

    palette_map.active_index = len(palette_map.palettes) - 1
    return palette, len(colors)


def expand_palette(palette_map, palette, colors, face_assignments, target_uv_name, threshold):
    palette.palette_uv_attribute = target_uv_name
    channel = ensure_base_channel(palette_map, palette)
    palette_colors = []

    for palette_color in palette.colors:
        color = get_palette_color_value(palette_color, channel)
        palette_colors.append(color)

    sampled_to_palette = {}
    new_colors = []

    for color_index, color in enumerate(colors):
        palette_color_index = None

        for existing_index, existing_color in enumerate(palette_colors):
            if existing_color is not None and colors_match(color, existing_color, threshold):
                palette_color_index = existing_index
                break

        if palette_color_index is None:
            for new_index, new_color in enumerate(new_colors):
                if colors_match(color, new_color, threshold):
                    palette_color_index = len(palette_colors) + new_index
                    break

        if palette_color_index is None:
            palette_color_index = len(palette_colors) + len(new_colors)
            new_colors.append(color)

        sampled_to_palette[color_index] = palette_color_index

    sorted_new_items = sorted(enumerate(new_colors), key=lambda item: color_sort_key(item[1]))
    sorted_new_colors = [color for _, color in sorted_new_items]
    new_index_map = {old_index: new_index for new_index, (old_index, _) in enumerate(sorted_new_items)}

    for sampled_index, palette_index in list(sampled_to_palette.items()):
        if palette_index >= len(palette_colors):
            sampled_to_palette[sampled_index] = len(palette_colors) + new_index_map[palette_index - len(palette_colors)]

    ensure_palette_capacity(palette, len(palette_colors) + len(sorted_new_colors))

    for color in sorted_new_colors:
        add_palette_color(palette, channel, color)

    remap_face_assignments(face_assignments, sampled_to_palette)
    palette.validate()
    palette.update_state('Expand From Geometry')

    return palette, len(sorted_new_colors)


def get_palette_uv(palette, color_index):
    color = palette.colors[color_index]
    return ((color.position[0] + 0.5) / palette.columns,
            1.0 - (color.position[1] + 0.5) / palette.rows)


def assign_palette_uvs(face_assignments, palette, target_uv_name):
    for mesh, color_indices in face_assignments.values():
        target_uv_layer = mesh.uv_layers.get(target_uv_name)

        if target_uv_layer is None:
            target_uv_layer = mesh.uv_layers.new(name=target_uv_name)

        target_uv_data = target_uv_layer.data

        for polygon, color_index in zip(mesh.polygons, color_indices):
            palette_uv = get_palette_uv(palette, color_index)

            for loop_index in polygon.loop_indices:
                target_uv_data[loop_index].uv = palette_uv


class PALETTEMAP_OT_construct_palette_from_geometry(bpy.types.Operator):
    bl_idname = 'palette_map.construct_palette_from_geometry'
    bl_label = 'Construct Palette From Geometry'
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name='Image')
    palette_name: StringProperty(name='Palette Name', default='Constructed Palette')
    source_uv_name: StringProperty(name='Source UV', default='UVMap')
    target_uv_name: StringProperty(name='Target UV', default='PaletteUV')
    merge_threshold: FloatProperty(
        name='Merge Threshold',
        default=1.0 / 255.0,
        min=0.0,
        soft_max=0.05,
        precision=6)
    selected_only: BoolProperty(name='Selected Objects Only', default=True)
    expand_active_palette: BoolProperty(name='Expand Active Palette', default=True)
    render_palette: BoolProperty(name='Render Palette', default=True)

    @classmethod
    def poll(cls, context):
        return any(obj.type == 'MESH' for obj in context.view_layer.objects)

    def draw(self, context):
        layout = self.layout
        layout.prop_search(self, 'image_name', bpy.data, 'images')
        layout.prop(self, 'palette_name')
        layout.prop(self, 'source_uv_name')
        layout.prop(self, 'target_uv_name')
        layout.prop(self, 'merge_threshold')
        layout.prop(self, 'selected_only')
        layout.prop(self, 'expand_active_palette')
        layout.prop(self, 'render_palette')

    def invoke(self, context, event):
        if self.image_name == '' and context.area is not None and context.area.type == 'IMAGE_EDITOR':
            image = context.space_data.image

            if image is not None:
                self.image_name = image.name

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        image = bpy.data.images.get(self.image_name)

        if image is None:
            self.report({'ERROR'}, 'Choose an image to sample')
            return {'CANCELLED'}

        objects = context.selected_objects if self.selected_only else context.view_layer.objects
        objects = [obj for obj in objects if obj.type == 'MESH']

        if not objects:
            self.report({'ERROR'}, 'No mesh objects to process')
            return {'CANCELLED'}

        active_object = context.active_object
        active_mode = active_object.mode if active_object is not None else None

        if active_object is not None and active_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        request_update_block(context.scene, 'Construct Palette From Geometry')

        try:
            colors, face_assignments, skipped = collect_face_colors(
                objects, image, self.source_uv_name, self.merge_threshold)

            if not colors:
                self.report({'ERROR'}, F'No colors found using UV layer "{self.source_uv_name}"')
                return {'CANCELLED'}

            palette_map = get_palette_map(context.scene)
            active_palette = get_active_palette(palette_map)

            if self.expand_active_palette and active_palette is not None:
                palette, color_count = expand_palette(
                    palette_map,
                    active_palette,
                    colors,
                    face_assignments,
                    self.target_uv_name,
                    self.merge_threshold)
                action = F'Added {color_count} new palette colors'
            else:
                palette, color_count = build_palette(
                    palette_map,
                    self.palette_name,
                    colors,
                    face_assignments,
                    self.target_uv_name)
                action = F'Created {color_count} palette colors'

            assign_palette_uvs(face_assignments, palette, self.target_uv_name)

            if self.render_palette:
                wahooney_palette_render_functions.render_palette(context, palette, channel_id=None, deferred=True)

            message = F'{action} from {len(face_assignments)} mesh data-block(s)'
            if skipped:
                message += F'; skipped {len(skipped)} without "{self.source_uv_name}"'

            self.report({'INFO'}, message)

        finally:
            release_update_block(context.scene, 'Construct Palette From Geometry')

            if active_object is not None and active_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=active_mode)

        return {'FINISHED'}
