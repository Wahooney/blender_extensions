# wahooney_palette_map.py Copyright (C) 2023, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

# TODO: only show "Create Material" if that material doesn't exist??

import bpy, os

def load_material(material_name):

    script_dir = os.path.dirname(os.path.realpath(__file__))
    blend_file_path = os.path.join(script_dir, 'blends', 'materials.blend')

    if not os.path.exists(blend_file_path):
        return None

    print(blend_file_path)

    with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
        if material_name in data_from.materials:
            data_to.materials.append(material_name)
        else:
            return None
    if material_name in bpy.data.materials:
        return bpy.data.materials[material_name]
    
    return None


def integrate_material(palette_name, load_mat):

    new_mat = None
    if palette_name in bpy.data.materials:
        new_mat = bpy.data.materials[palette_name]

    if load_mat is None:
        return None

    if new_mat is not None:

        for obj in bpy.context.scene.objects:
                if obj.type == 'MESH' or obj.type == 'CURVE':
                    for slot in obj.material_slots:
                        if slot.material == new_mat:
                            slot.material = load_mat

        for mesh in bpy.data.meshes:
            for i, material in enumerate(mesh.materials):
                if material == new_mat:
                    mesh.materials[i] = load_mat

        for curve in bpy.data.curves:
            for i, material in enumerate(curve.materials):
                if material == new_mat:
                    curve.materials[i] = load_mat

        if new_mat.users == 0:
            bpy.data.materials.remove(new_mat)
    
    else:
        new_mat = load_mat
        new_mat.name = palette_name

    return new_mat


def replace_image(material, image, image_node_name):

    if material is not None and image_node_name in material.node_tree.nodes:

        old_image = material.node_tree.nodes[image_node_name].image
        material.node_tree.nodes[image_node_name].image = bpy.data.images[image]

        # remove the old image if it's not used anymore
        if old_image.users == 0:
            bpy.data.images.remove(old_image)
    
    else:
        print(F"Material or image node not found {image_node_name}")


def create_painted_material(palette_name, base_image, pbr_image, emission_image):

    new_mat = integrate_material(palette_name, load_material('REFERENCE_MI_Painted_Material'))

    replace_image(new_mat, base_image, 'Base Image')
    replace_image(new_mat, pbr_image, 'PBR Image')
    replace_image(new_mat, emission_image, 'Emission Image')

    return new_mat


def create_ultra_material(palette_name, base_image, pbr_image, emission_image):

    new_mat = integrate_material(palette_name, load_material('REFERENCE_MI_Ultra_Material'))

    replace_image(new_mat, base_image, 'Base Image')
    replace_image(new_mat, pbr_image, 'PBR Image')
    replace_image(new_mat, emission_image, 'Emission Image')

    return new_mat


def create_basic_material(palette_name, base_image, pbr_image, emission_image):

    new_mat = integrate_material(palette_name, load_material('REFERENCE_MI_Material'))

    replace_image(new_mat, base_image, 'Base Image')
    replace_image(new_mat, pbr_image, 'PBR Image')
    replace_image(new_mat, emission_image, 'Emission Image')

    return new_mat


def poll_create_pbr_material(context):

    palette_map = context.scene.palette_map

    if palette_map.active_index < 0 or palette_map.active_index >= len(palette_map.palettes):
        #print("Out of range")
        return False
    
    palette = palette_map.palettes[palette_map.active_index]

    return 'Base' in palette.channels and palette.channels['Base'].image is not None and \
            'PBR' in palette.channels and palette.channels['PBR'].image is not None and \
            'Emission' in palette.channels and palette.channels['Emission'].image is not None


def create_palette_material(self, context, create_function, identifier, uv_attribute):
    
    palette_map = context.scene.palette_map
    palette = palette_map.palettes[palette_map.active_index]
    palette.palette_uv_attribute = uv_attribute
    prefix = palette_map.material_prefix

    if 'Base' not in palette.channels or 'PBR' not in palette.channels or 'Emission' not in palette.channels:
        self.report({'ERROR'}, "Missing one or more channels for this palette")
        return {'CANCELLED'}

    base = palette.channels['Base'].image
    pbr = palette.channels['PBR'].image
    emission = palette.channels['Emission'].image

    if base is None or pbr is None or emission is None:
        self.report({'ERROR'}, "Missing image for one or more channels")
        return {'CANCELLED'}

    name = F"{prefix}{identifier}{palette.name}"
    palette.material = create_function(name, base.name, pbr.name, emission.name)

    bpy.ops.palette_map.assign_palette_material()

    return {'FINISHED'}


class PALETTEMAP_OT_create_basic_material(bpy.types.Operator):
    
    """Create a basic PBR material"""
    bl_idname = "palette_map.create_basic_material"
    bl_label = "Create Basic Material"
    bl_options = {'REGISTER', 'UNDO'}


    @classmethod
    def poll(cls, context):
        return poll_create_pbr_material(context)


    def execute(self, context):
        return create_palette_material(self, context, create_basic_material, "", "UVMap")


class PALETTEMAP_OT_create_painted_material(bpy.types.Operator):

    """Create a Painted PBR Material that's 'Painted' by the vertex color channel 'Color'"""
    bl_idname = "palette_map.create_painted_material"
    bl_label = "Create Painted Material"
    bl_options = {'REGISTER', 'UNDO'}


    @classmethod
    def poll(cls, context):
        return poll_create_pbr_material(context)


    def execute(self, context):
        return create_palette_material(self, context, create_painted_material, "Painted_", "UVMap")


class PALETTEMAP_OT_create_ultra_material(bpy.types.Operator):

    """Create an Ultra Shader Material and assign to selected objects"""
    bl_idname = "palette_map.create_ultra_material"
    bl_label = "Create Ultra Material"
    bl_options = {'REGISTER', 'UNDO'}


    @classmethod
    def poll(cls, context):
        return poll_create_pbr_material(context)


    def execute(self, context):
        return create_palette_material(self, context, create_ultra_material, "Ultra_", "PaletteUV")


class PALETTEMAP_OT_assign_palette_material(bpy.types.Operator):

    """Assign palette material to selected objects"""
    bl_idname = "palette_map.assign_palette_material"
    bl_label = "Assign Palette Material"
    bl_options = {'REGISTER', 'UNDO'}


    @classmethod
    def poll(cls, context):

        palette_map = context.scene.palette_map
        if palette_map.active_index < 0 or palette_map.active_index >= len(palette_map.palettes):
            return False
        
        palette = palette_map.palettes[palette_map.active_index]

        return palette.material is not None


    def execute(self, context):
        
        palette_map = context.scene.palette_map
        palette = palette_map.palettes[palette_map.active_index]

        for sel in context.selected_objects:

            if sel.type != 'MESH':
                continue

            if len(sel.data.materials) > sel.active_material_index:
                sel.data.materials[sel.active_material_index] = palette.material
            elif palette.material.name not in sel.data.materials:
                sel.data.materials.append(palette.material)
                sel.active_material_index = len(sel.data.materials) - 1

        return {'FINISHED'}
