/*
wahooney_palette_map.py Copyright (C) 2023, Keith "Wahooney" Boshoff
***** BEGIN GPL LICENSE BLOCK *****

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ***** END GPL LICENCE BLOCK *****
*/

#ifndef BLENDER_4_5_NEXT
uniform mat4 ModelViewProjectionMatrix;
in vec2 pos;
in vec4 color;
noperspective out vec4 rampColor;
#endif

void main()
{
    gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);
    rampColor = color;
}