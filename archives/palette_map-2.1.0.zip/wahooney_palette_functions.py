import bpy


def get_palette_map(scene):
    if scene.palette_viewer_scene is not None:
        return scene.palette_viewer_scene.palette_map
    return scene.palette_map
