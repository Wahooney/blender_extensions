# wahooney_palette_map.py Copyright (C) 2023, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from mathutils import Color


# function cribbed from Wahooney UV Army Knife
def sort_layers(mesh, layer_names):

    layers = mesh.uv_layers

    if len(layers) < 2:
        return

    act_name = layers.active.name

    for name in layer_names:
        if name in layers:
            layers.active = layers[name]
            layers.active.name = F'UVAK_TEMP_NAME_{layers.active.name}_{layers.active_index}'
            layers.new(name=name, do_init=True)
            layers.remove(layers.active)

    layers.active = layers[act_name]


class PALETTE_OT_prepare_for_paint(bpy.types.Operator):
    """Adds the required vertex color layer and properties to the selected object(s) to work with Painted Palette Map Material"""

    bl_idname = "object.prepare_for_paint"
    bl_label = "Prepare for Paint"
    bl_description = "Prepare Active object for Painted Material"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):

        def add(obj, prop_name, default_color):

            if prop_name not in obj:
                obj[prop_name] = default_color

            obj.id_properties_ui(prop_name).update(subtype='COLOR',
                                                   min=0.0,
                                                   max=20.0,
                                                   soft_min=0.0, soft_max=1.0)

            obj[prop_name] = default_color

        act = context.active_object
        selection = context.selected_objects

        for sel in selection:

            if sel.type != 'MESH':
                continue

            add(sel, 'Color_Base', [1.0, 1.0, 1.0])
            add(sel, 'Color_1', [1.0, 0.0, 0.0])
            add(sel, 'Color_2', [0.0, 1.0, 0.0])
            add(sel, 'Color_3', [0.0, 0.0, 1.0])

            # We will need a vertex color layer for the material to paint on.
            attributes = sel.data.attributes

            if 'Color' not in attributes:
                # let's add one...
                attributes.new('Color', 'FLOAT_COLOR', 'CORNER')
                color_attributes = attributes['Color']

                # and fill it with a neutral color
                for d in color_attributes.data:
                    d.color = (0, 0, 0, 1)

            # the flattened UV map
            if 'UVMap' not in attributes:
                # let's add one...
                attributes.new('UVMap', 'FLOAT2', 'CORNER')
                uv_attributes = attributes['UVMap']

                # and fill it with a neutral value
                for d in uv_attributes.data:
                    d.vector = (0, 0)

            # the palette UV map
            if 'PaletteUV' not in attributes:
                # let's add one...
                attributes.new('PaletteUV', 'FLOAT2', 'CORNER')
                uv_attributes = attributes['PaletteUV']

                # and fill it with a neutral value
                for d in uv_attributes.data:
                    d.vector = (0, 1)

            sort_layers(sel.data, ['UVMap', 'PaletteUV'])

        context.view_layer.objects.active = act

        # this is dumb, need a better way to do this
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

        return {'FINISHED'}


class PALETTE_OT_prepare_for_ultra(bpy.types.Operator):
    """Adds the required attributes and object properties to the selected object(s) to work with Ultra Palette Map Material"""

    bl_idname = "object.prepare_for_ultra"
    bl_label = "Prepare for Ultra"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):

        def add(obj, prop_name, default_color):

            if prop_name not in obj:
                obj[prop_name] = default_color

            obj.id_properties_ui(prop_name).update(subtype='COLOR',
                                                   min=0.0,
                                                   max=20.0,
                                                   soft_min=0.0, soft_max=1.0)

            obj[prop_name] = default_color

        act = context.active_object
        selection = context.selected_objects

        for sel in selection:

            if sel.type != 'MESH':
                continue

            add(sel, 'Color_Base', [1.0, 1.0, 1.0])
            add(sel, 'Color_1', [1.0, 0.0, 0.0])
            add(sel, 'Color_2', [0.0, 1.0, 0.0])
            add(sel, 'Color_3', [0.0, 0.0, 1.0])

            attributes = sel.data.attributes

            # we need certain attributes to make the ultra palette material to work

            # the flattened UV map
            if 'UVMap' not in attributes:
                # let's add one...
                attributes.new('UVMap', 'FLOAT2', 'CORNER')
                uv_attributes = attributes['UVMap']

                # and fill it with a neutral value
                for d in uv_attributes.data:
                    d.vector = (0, 0)

            # the palette UV map
            if 'PaletteUV' not in attributes:
                # let's add one...
                attributes.new('PaletteUV', 'FLOAT2', 'CORNER')
                uv_attributes = attributes['PaletteUV']

                # and fill it with a neutral value
                for d in uv_attributes.data:
                    d.vector = (0, 1)

            # the roughness power, color and occlusion values (RCO)
            # roughness power: derived from the fractional value of U value
            # color: derived from the whole number of the U value
            # occlusion: derived from the V value, where 0 is completely occluded and 1 is completely visible
            if 'RCOMap' not in attributes:

                # let's add one...
                attributes.new('RCOMap', 'FLOAT2', 'CORNER')
                uv_attributes = attributes['RCOMap']

                # and initialize it with something sane
                for d in uv_attributes.data:
                    d.vector = (0.99, 0.99)

            sort_layers(sel.data, ['UVMap', 'PaletteUV', 'RCOMap'])

        context.view_layer.objects.active = act

        # this is dumb, need a better way to do this
        try:
            if context.active_object is None:
                context.view_layer.objects.active = selection[0]

            bpy.ops.object.editmode_toggle()
            bpy.ops.object.editmode_toggle()
        finally:
            print("Something stupid went wrong")

        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator(PALETTE_OT_prepare_for_paint.bl_idname,
                         text=PALETTE_OT_prepare_for_paint.bl_label)


# Register and add to the "object" menu (required to also use F3 search "Simple Object Operator" for quick access).
def register():
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_object.remove(menu_func)
