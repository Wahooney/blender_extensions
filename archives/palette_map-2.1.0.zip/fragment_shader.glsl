/*
wahooney_palette_map.py Copyright (C) 2023, Keith "Wahooney" Boshoff
***** BEGIN GPL LICENSE BLOCK *****

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ***** END GPL LICENCE BLOCK *****
*/

#ifdef BLENDER_4_5_NEXT
precision mediump int;
precision highp float;

#define colorTL paletteParams.colorTL
#define colorTR paletteParams.colorTR
#define colorBL paletteParams.colorBL
#define colorBR paletteParams.colorBR
#define alphaCorners paletteParams.alphaCorners
#define gamma paletteParams.curve.x
#define padding paletteParams.curve.y
#define gradientGamma paletteParams.curve.zw
#define colorInterpolation paletteParams.options.x
#else
noperspective in vec4 rampColor;
out highp vec4 fragColor;

uniform vec4 colorTL;
uniform vec4 colorTR;
uniform vec4 colorBL;
uniform vec4 colorBR;
uniform vec4 alphaCorners;
uniform float gamma;
uniform vec2 gradientGamma;
uniform float colorInterpolation;
uniform float padding;
// not a thing anymore apparently - uniform vec2 fullSize;
#endif

vec4 to_sRGB(vec4 linearRGB)
{
    return pow(linearRGB, vec4(2.22));
}

vec4 toLinear(vec4 sRGB)
{
    return pow(sRGB, vec4(0.450450));
}

vec2 remap(vec2 coord, float min, float max)
{
    return clamp((coord - min) / (max - min), 0.0, 1.0);
}

vec2 applyGamma(vec2 coord, vec2 curve)
{
    return pow(clamp(coord, vec2(0.0), vec2(1.0)), max(curve, vec2(0.0001)));
}

vec3 rgbToHsv(vec3 color)
{
    vec4 k = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(color.bg, k.wz), vec4(color.gb, k.xy), step(color.b, color.g));
    vec4 q = mix(vec4(p.xyw, color.r), vec4(color.r, p.yzx), step(p.x, color.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;

    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)),
                d / (q.x + e),
                q.x);
}

vec3 hsvToRgb(vec3 color)
{
    vec3 p = abs(fract(color.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return color.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), color.y);
}

float mixHue(float a, float b, float time)
{
    float delta = b - a;

    if (abs(delta) > 0.5)
        delta -= sign(delta);

    return fract(a + delta * time);
}

vec4 mixColor(vec4 a, vec4 b, float time)
{
    if (colorInterpolation < 0.5)
        return mix(a, b, time);

    vec3 hsvA = rgbToHsv(a.rgb);
    vec3 hsvB = rgbToHsv(b.rgb);
    vec3 hsv = vec3(mixHue(hsvA.x, hsvB.x, time),
                    mix(hsvA.y, hsvB.y, time),
                    mix(hsvA.z, hsvB.z, time));

    return vec4(hsvToRgb(hsv), mix(a.a, b.a, time));
}

const highp float NOISE_GRANULARITY = 0.25/255.0;

highp float random(vec2 coords)
{
    return fract(sin(dot(coords.xy, vec2(12.9898,78.233))) * 43758.5453);
}

void main()
{
    vec2 coord;
    
    if (gamma > 0.0)
        coord = mix(rampColor.rg, toLinear(rampColor).rg, gamma);
    else
        coord = mix(rampColor.rg, to_sRGB(rampColor).rg, -gamma);

    coord = applyGamma(coord, gradientGamma);

    vec2 pos = coord;
    vec2 seed = gl_FragCoord.xy;

    vec2 outCoord = remap(coord, padding, 1-padding);

    vec4 top = mixColor(colorTL, colorTR, outCoord.r);
    vec4 bottom = mixColor(colorBL, colorBR, outCoord.r);
    //fragColor = blender_srgb_to_framebuffer_space(mix(top, bottom, vec4(outCoord.g)));
    fragColor = mixColor(top, bottom, outCoord.g);
    fragColor.a *= mix(mix(alphaCorners.x, alphaCorners.y, outCoord.r),
                       mix(alphaCorners.z, alphaCorners.w, outCoord.r),
                       outCoord.g);
}
