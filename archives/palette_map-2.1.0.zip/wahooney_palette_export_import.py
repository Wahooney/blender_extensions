# wahooney_palette_map.py Copyright (C) 2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
import json
import bpy

from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy.props import StringProperty, EnumProperty, IntProperty
from . import wahooney_palette_functions
get_palette_map = wahooney_palette_functions.get_palette_map

################################################################################
# Export/Import Functions


# ------------------------------------------------------------------------
#  Low‑level helpers
# ------------------------------------------------------------------------

_SIMPLE_KINDS = {"INT", "FLOAT", "BOOLEAN", "STRING", "ENUM"}


def _serialize_pg(pg):
    out = {}
    for prop in pg.bl_rna.properties:
        pid = prop.identifier
        if pid == "rna_type":
            continue

        val = getattr(pg, pid)
        kind = prop.type

        # collections
        if kind == 'COLLECTION':
            out[pid] = [_serialize_pg(item) for item in val]

        # pointers
        elif kind == 'POINTER':
            out[pid] = (_serialize_pg(val)                        # nested PG
                        if isinstance(val, bpy.types.PropertyGroup)
                        else val.name if val else None)           # datablock

        # strings (including Enum identifiers)
        elif kind == 'STRING' or isinstance(val, str):
            out[pid] = val

        # scalars / numeric arrays
        elif kind in _SIMPLE_KINDS:
            # Float/Int/Bool can be scalar or array → check array length
            if getattr(prop, "array_length", 1) > 1:
                out[pid] = list(val)          # vector -> JSON‑friendly
            else:
                out[pid] = val

        # silently skip the rest
    return out


# ------------------------------------------------------------------ DESERIALISE
def _apply_pg(pg, data: dict):
    """
    Recursively copy *data* (plain Python dict produced by _serialize_pg)
    into the property group instance *pg*.  Missing keys are ignored; extra
    keys in *data* are also ignored, so the function is schema‑tolerant.
    """
    print()
    # print(data.keys())

    for prop in pg.bl_rna.properties:

        pid = prop.identifier
        # print(1, pid, prop.identifier)

        if pid == "rna_type" or pid not in data:
            # print("XXXX", prop.identifier, " --- ", pid)
            continue

        incoming = data[pid]
        kind = prop.type
        # print(2, kind, prop.identifier)

        # COLLECTION  (array of PropertyGroups)
        if kind == 'COLLECTION':
            print(prop.type)
            col = getattr(pg, pid)
            col.clear()
            for item_data in incoming or []:
                _apply_pg(col.add(), item_data)

        # POINTER  (either nested PG or datablock)
        elif kind == 'POINTER':
            current_val = getattr(pg, pid)

            # ① Nested PropertyGroup → recurse
            if isinstance(current_val, bpy.types.PropertyGroup):
                _apply_pg(current_val, incoming or {})

            # ② Datablock pointer (Image, Material, …) ---------------
            else:
                if incoming is None:
                    setattr(pg, pid, None)
                elif isinstance(incoming, str):
                    # Best‑effort lookup: turn "Image" → bpy.data.images
                    type_hint = getattr(prop, "fixed_type", None)
                    if type_hint:
                        coll_name = type_hint.identifier.lower() + "s"
                        datablocks = getattr(bpy.data, coll_name, None)
                        targ = datablocks.get(incoming) if datablocks else None
                        if targ:
                            setattr(pg, pid, targ)
                # if it's not None/str we silently ignore it

        # Scalars & arrays (INT, FLOAT, BOOL, ENUM, STRING)
        else:
            try:
                setattr(pg, pid, incoming)
            except Exception:
                pass  # stale data, leave it


# ------------------------------------------------------------------------
#  Public API
# ------------------------------------------------------------------------

def palette_map_to_json(palette_map) -> str:
    """
    Serialize a PaletteMap (or any PropertyGroup) to pretty JSON text.
    """
    return json.dumps(_serialize_pg(palette_map), indent=2, sort_keys=True)


def palette_map_from_json(palette_map, text: str):
    """
    Apply *text* (previously produced by palette_map_to_json) to *palette_map*.
    Existing data that is absent from the JSON remains untouched.
    """
    _apply_pg(palette_map, json.loads(text))


# serialize palette map data to json
def serialize_object(data_object):
    return _serialize_pg(data_object)


# deserialize palette map data from json
def deserialize_palette(data, palette):

    palette_map = get_palette_map(bpy.context.scene)
    update_method = palette_map.update_method
    palette_map.update_method = 'MANUAL'

    if 'name' in data:
        name = data['name']
        # palette = palette_map.palettes.add()
        palette.name = name
        _apply_pg(palette, data)
        palette_map.active_index = palette_map.palettes.find(palette.name)

    palette_map.update_method = update_method
    bpy.ops.palette_map.render()


################################################################################
# Export/Import Panels

class PALETTEMAP_PT_export_palette(bpy.types.Panel):

    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_label = 'Export Palette'
    bl_parent_id = 'FILE_PT_operator'

    @classmethod
    def poll(cls, context):
        sfile = context.space_data
        operator = sfile.active_operator

        return operator.bl_idname == 'PALETTEMAP_OT_save_palette_to_file'

    '''def draw_header(self, context):
        sfile = context.space_data
        operator = sfile.active_operator

        self.layout.prop(operator, 'bake_anim', text='')
    '''

    def draw(self, context):

        layout = self.layout
        # layout.use_property_split = True
        # layout.use_property_decorate = False  # No animation.

        sfile = context.space_data
        operator = sfile.active_operator

        # layout.prop(operator, 'palette', text='Palette', expand=True)


################################################################################
# Export/Import Operators

def get_palette_maps(self, context):

    if len(get_palette_maps.list) > 0:
        return get_palette_maps.list

    palette_map = get_palette_map(context.scene)
    get_palette_maps.list = [(str(i), F'{palette.name}', F'Export {palette.name}')
                             for i, palette in enumerate(palette_map.palettes)]
    print(len(get_palette_maps.list))
    return get_palette_maps.list


get_palette_maps.list = []


class PALETTEMAP_OT_export_palette(bpy.types.Operator, ExportHelper):
    ''' '''
    bl_idname = 'palette_map.export'
    bl_label = 'Export Palette to File'

    filename_ext = '.json'

    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    palette: EnumProperty(items=get_palette_maps)

    @classmethod
    def poll(cls, context):
        palette = -1
        palette_map = get_palette_map(context.scene)
        active_index = palette_map.active_index
        if len(palette_map.palettes) > active_index and active_index >= 0:
            palette = palette_map.palettes[palette_map.active_index]
        return palette is not -1

    def execute(self, context):
        return self.export(context)

    def export(self, context):

        palette = -1
        index = int(palette)

        palette_map = get_palette_map(context.scene)

        if len(palette_map.palettes) > index:
            palette = palette_map.palettes[index]

        data = serialize_object(palette)
        text = json.dumps(data, indent=4)

        # save text to disk
        path = bpy.path.abspath(self.filepath)

        # ensure the name ends with .json
        if not path.endswith('.json'):
            path += '.json'

        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))

        with open(path, 'w') as f:
            f.write(text)

        get_palette_maps.list = []

        return {'FINISHED'}

    def invoke(self, context, event):

        palette_map = get_palette_map(context.scene)
        index = palette_map.active_index
        self.palette = str(index)

        palette = 'Palette'

        if len(palette_map.palettes) > index:
            palette = palette_map.palettes[index]
            print(palette)

        self.filepath = palette.name + '.json'

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}

    def cancel(self, context):

        get_palette_maps.list = []

    def draw(self, context):

        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, 'palette', text='Palette', expand=True)


class PALETTEMAP_OT_import_palette(bpy.types.Operator, ImportHelper):
    '''Import Palette from a JSON File'''

    bl_idname = 'palette_map.import'
    bl_label = 'Import Palette from File'

    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    target_palette: IntProperty(default=-1)

    @classmethod
    def description(cls, context, properties):

        if properties.target_palette < 0:
            return 'Load New Palette from File'
        else:
            palette_map = get_palette_map(context.scene)
            return F'Load Palette from File into Palette "{palette_map.palettes[properties.target_palette].name}"'

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        return self.import_data(context)

    def import_data(self, context):

        palette = None
        index = -1
        palette_map = get_palette_map(context.scene)

        if self.target_palette >= 0 and self.target_palette < len(palette_map.palettes):
            palette = palette_map.palettes[self.target_palette]
            index = self.target_palette
        else:
            index = len(palette_map.palettes)
            palette = palette_map.palettes.add()

        # load data file from data path
        path = bpy.path.abspath(self.filepath)

        # check the file exists
        if not os.path.exists(path):
            return {'FINISHED'}

        with open(path, 'r') as f:
            data = json.loads(f.read())
            deserialize_palette(data, palette)

        palette_map.active_index = index

        return {'FINISHED'}

    def invoke(self, context, event):

        self.filepath = ''

        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
