# wahooney_palette_map.py Copyright (C) 2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import os
import json
import bpy

from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy.props import StringProperty, EnumProperty, IntProperty


################################################################################
# Export/Import Functions

# serialize palette map data to json
def serialize_object(data_object):

    data = {}

    if 'name' in data_object:
        data['name'] = data_object.name

    for prop in data_object.__annotations__.keys():

        attr = getattr(data_object, prop)
        if isinstance(attr, bpy.types.PropertyGroup):
            data[prop] = serialize_object(attr)
        elif isinstance(attr, bpy.types.CollectionProperty):
            data[prop] = [serialize_object(item) for item in attr]
        elif type(attr).__name__ == 'bpy_prop_collection_idprop':
            data[prop] = [serialize_object(item) for item in attr]
        elif type(attr).__name__ == 'Color':
            data[prop] = [attr.r, attr.g, attr.b]
        elif type(attr).__name__ == 'bpy_prop_array':
            data[prop] = [item for item in attr]
        elif type(attr).__name__ == 'set':
            data[prop] = list(attr)
            # data[prop] = [property_group_to_dict(item) for item in attr]
            pass
        else:
            if isinstance(attr, bpy.types.ID):
                # print(F'* {prop} = {attr} :: {type(attr)}')
                data[prop] = attr.name
                pass
            else:
                # print(F'  {prop} = {attr} :: {type(attr)}')
                data[prop] = attr

    return data


# deserialize palette map data from json
def deserialize_palette(data, palette):

    from . import PaletteMapChannelData

    update_method = bpy.context.scene.palette_map.update_method
    bpy.context.scene.palette_map.update_method = 'MANUAL'

    for k in data.keys():

        expected_type = type(palette).__annotations__.get(k, None)

        attr = getattr(palette, k)

        if expected_type:
            if 'type' in expected_type.keywords:

                t = expected_type.keywords['type']

                if t == bpy.types.Image:

                    if data[k] in bpy.data.images:
                        setattr(palette, k, bpy.data.images[data[k]])

                elif t == bpy.types.PaletteColor:

                    # process colors
                    for c in data[k]:

                        col = palette.colors.add()

                        for kc in c.keys():
                            if kc == 'stops':
                                for i, s in enumerate(c[kc]):

                                    if i < len(col.stops):
                                        stop = col.stops[i]
                                    else:
                                        stop = col.stops.add()

                                    for a in s.keys():
                                        if type(s[a]).__name__ == 'list':
                                            setattr(stop, a, tuple(s[a]))
                                        else:
                                            setattr(stop, a, s[a])
                                pass

                            elif kc == 'channel_colors':
                                pass
                            elif type(getattr(col, kc)).__name__ == 'set':
                                setattr(col, kc, set(c[kc]))
                            else:
                                setattr(col, kc, c[kc])

                elif PaletteMapChannelData:
                    pass
                else:
                    print(F'==== {k}::{t} = {data[k]}')

            else:
                setattr(palette, k, data[k])

        else:
            setattr(palette, k, data[k])

    bpy.context.scene.palette_map.update_method = update_method
    bpy.ops.palette_map.render()


################################################################################
# Export/Import Panels

class PALETTEMAP_PT_export_palette(bpy.types.Panel):

    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_label = 'Export Palette'
    bl_parent_id = 'FILE_PT_operator'

    @classmethod
    def poll(cls, context):
        sfile = context.space_data
        operator = sfile.active_operator

        return operator.bl_idname == 'PALETTEMAP_OT_save_palette_to_file'

    '''def draw_header(self, context):
        sfile = context.space_data
        operator = sfile.active_operator

        self.layout.prop(operator, 'bake_anim', text='')
    '''

    def draw(self, context):

        layout = self.layout
        # layout.use_property_split = True
        # layout.use_property_decorate = False  # No animation.

        sfile = context.space_data
        operator = sfile.active_operator

        # layout.prop(operator, 'palette', text='Palette', expand=True)


################################################################################
# Export/Import Operators

def get_palette_maps(self, context):

    if len(get_palette_maps.list) > 0:
        return get_palette_maps.list

    get_palette_maps.list = [(str(i), F'{palette.name}', F'Export {palette.name}')
                             for i, palette in enumerate(context.scene.palette_map.palettes)]
    print(len(get_palette_maps.list))
    return get_palette_maps.list


get_palette_maps.list = []


class PALETTEMAP_OT_export_palette(bpy.types.Operator, ExportHelper):
    ''' '''
    bl_idname = 'palette_map.export'
    bl_label = 'Export Palette to File'

    filename_ext = '.json'

    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    palette: EnumProperty(items=get_palette_maps)

    @classmethod
    def poll(cls, context):
        palette = -1
        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        return palette is not -1

    def execute(self, context):
        return self.export(context)

    def export(self, context):

        palette = -1
        index = int(palette)

        if len(context.scene.palette_map.palettes) > index:
            palette = context.scene.palette_map.palettes[index]

        data = serialize_object(palette)
        text = json.dumps(data, indent=4)

        # save text to disk
        path = bpy.path.abspath(self.filepath)

        # ensure the name ends with .json
        if not path.endswith('.json'):
            path += '.json'

        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))

        with open(path, 'w') as f:
            f.write(text)

        get_palette_maps.list = []

        return {'FINISHED'}

    def invoke(self, context, event):

        index = context.scene.palette_map.active_index
        self.palette = str(index)

        palette = 'Palette'

        if len(context.scene.palette_map.palettes) > index:
            palette = context.scene.palette_map.palettes[index]
            print(palette)

        self.filepath = palette.name + '.json'

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}

    def cancel(self, context):

        get_palette_maps.list = []

    def draw(self, context):

        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, 'palette', text='Palette', expand=True)


class PALETTEMAP_OT_import_palette(bpy.types.Operator, ImportHelper):
    '''Import Palette from a JSON File'''

    bl_idname = 'palette_map.import'
    bl_label = 'Import Palette from File'

    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    target_palette: IntProperty(default=-1)

    @classmethod
    def description(cls, context, properties):

        if properties.target_palette < 0:
            return 'Load New Palette from File'
        else:
            return F'Load Palette from File into Palette "{context.scene.palette_map.palettes[properties.target_palette].name}"'

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        return self.import_data(context)

    def import_data(self, context):

        palette = None
        index = -1

        if self.target_palette >= 0 and self.target_palette < len(context.scene.palette_map.palettes):
            palette = context.scene.palette_map.palettes[self.target_palette]
            index = self.target_palette
        else:
            index = len(context.scene.palette_map.palettes)
            palette = context.scene.palette_map.palettes.add()

        # load data file from data path
        path = bpy.path.abspath(self.filepath)

        # check the file exists
        if not os.path.exists(path):
            return {'FINISHED'}

        with open(path, 'r') as f:
            data = json.loads(f.read())
            deserialize_palette(data, palette)

        context.scene.palette_map.active_index = index

        return {'FINISHED'}

    def invoke(self, context, event):

        self.filepath = ''

        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
