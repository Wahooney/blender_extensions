# wahooney_palette_map.py Copyright (C) 2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

palette_update_block = 'palette_update_block'
palette_update_block_counter = 0

def request_update_block(scene, reason):
    global palette_update_block
    
    if palette_update_block not in scene:
        scene[palette_update_block] = [reason]
    else:
        blockers = list(scene[palette_update_block])
        blockers.append(reason)
        scene[palette_update_block] = blockers


def release_update_block(scene, reason):
    global palette_update_block

    if palette_update_block in scene:
        if reason in scene[palette_update_block]:
            blockers = list(scene[palette_update_block])
            blockers.remove(reason)

            if len(blockers) == 0:
                del scene[palette_update_block]
            else:
                scene[palette_update_block] = blockers


def has_update_block(scene):

    global palette_update_block
    return palette_update_block in scene and len(scene[palette_update_block]) > 0
