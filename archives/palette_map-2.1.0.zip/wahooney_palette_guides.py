import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader


class PALETTEMAP_OT_PaletteGuideRender(bpy.types.Operator):

    bl_idname = 'palettemap.guide_render'
    bl_description = 'Render guides for palette map slots'
    bl_label = 'Map Details'

    __handle = None

    @classmethod
    def poll(cls, context):
        return True

    @classmethod
    def is_running(cls, _):
        return 1 if cls.__handle else 0

    @classmethod
    def handle_add(cls, obj, context):
        img_editor = bpy.types.SpaceImageEditor
        cls.__handle = img_editor.draw_handler_add(
            PALETTEMAP_OT_PaletteGuideRender.draw, (obj, context),
            'WINDOW', 'POST_PIXEL')

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()

    @classmethod
    def handle_remove(cls):
        if cls.__handle is not None:
            bpy.types.SpaceImageEditor.draw_handler_remove(
                cls.__handle, 'WINDOW')

            cls.__handle = None

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()

    @staticmethod
    def draw(_, context):

        def process(t1, t2):
            return (t1[0] + t2[0], t1[1] + t2[1])

        scene = context.scene

        if not PALETTEMAP_OT_PaletteGuideRender.is_running(context):
            return

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')

        index = scene.palette_map.active_index
        palette = scene.palette_map.palettes[index]
        cols = palette.columns
        rows = palette.rows
        span_c = 1.0 / cols
        span_r = 1.0 / rows

        v2r = context.region.view2d.view_to_region

        shadowcolor = context.scene.palette_map.guide_shadow
        softshadow = (shadowcolor[0], shadowcolor[1],
                      shadowcolor[2], shadowcolor[3] * 0.1)

        color = context.scene.palette_map.guide_color
        blf.color(0, color[0], color[1], color[2], color[3])
        blf.enable(0, blf.SHADOW)
        blf.enable(0, blf.CLIPPING)
        blf.shadow(0, 5, shadowcolor[0], shadowcolor[1],
                   shadowcolor[2], shadowcolor[3])

        dims = [(c.position[0] * span_c,
                 1.0 - c.position[1] * span_r,
                 c.span[0] * span_c,
                 c.span[1] * span_r) for c in palette.colors]

        coordsets = [
            [process(v2r(dims[i][0],              dims[i][1],              clip=False), (0, -1)),
             process(v2r(dims[i][0] + dims[i][2], dims[i]
                     [1],              clip=False), (-1, -1)),
             process(v2r(dims[i][0] + dims[i][2], dims[i]
                     [1] - dims[i][3], clip=False), (-1,  0)),
             process(v2r(dims[i][0],              dims[i][1] - dims[i][3], clip=False), (0,  0))] for i, c in enumerate(palette.colors)]

        gpu.state.blend_set('ALPHA')

        for i, c in enumerate(palette.colors):

            coords = coordsets[i]

            gpu.state.line_width_set(3.0)
            shader.bind()
            shader.uniform_float("color", softshadow)
            batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": coords})
            batch.draw(shader)

            gpu.state.line_width_set(5.0)
            shader.bind()
            shader.uniform_float("color", softshadow)
            batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": coords})
            batch.draw(shader)

        gpu.state.blend_set('ALPHA')
        for i, c in enumerate(palette.colors):

            coords = coordsets[i]

            gpu.state.line_width_set(1.0)
            shader.bind()
            shader.uniform_float("color", color)
            batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": coords})
            batch.draw(shader)

        gpu.state.blend_set('NONE')

        for i, c in enumerate(palette.colors):

            coords = coordsets[i]

            x = dims[i][0]
            y = dims[i][1]
            w = dims[i][2]
            h = dims[i][3]

            xx, yy = v2r(x, y-h, clip=False)
            _, size = v2r(0, y-h + span_c / 3.0, clip=False)
            size -= yy

            # draw some text
            blf.position(0, xx + 5, yy + 5, 0)
            blf.clipping(0, coords[0][0], coords[2][1],
                         coords[2][0], coords[0][1])
            blf.size(0, size)
            blf.draw(0, F"[{c.name}]" if i == palette.active_index else c.name)

        blf.disable(0, blf.CLIPPING)

        blf.size(0, size * 2)
        xx, yy = v2r(0, 1, clip=False)
        blf.position(0, xx + 10, yy + 10, 0)
        blf.draw(0, palette.name)

        blf.disable(0, blf.SHADOW)

    def invoke(self, context, _):
        if not PALETTEMAP_OT_PaletteGuideRender.is_running(context):
            PALETTEMAP_OT_PaletteGuideRender.handle_add(self, context)
        else:
            PALETTEMAP_OT_PaletteGuideRender.handle_remove()

        return {'FINISHED'}
