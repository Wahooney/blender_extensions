import bpy
from bpy.props import EnumProperty
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector


image = None
texture = None
shader = None
line_shader = None
color = None
color_uv = None
channel_index = 0
channel = None


def lerp(a, b, x):
    return a + (b - a) * x


def clamp01(uv):
    return (min(0.995, max(0.005, uv[0])),
            min(0.995, max(0.005, uv[1])))


def wrap(value, min_val, max_val):
    range_size = max_val - min_val
    wrapped_value = ((value - min_val) % range_size) + min_val
    return wrapped_value


def get_uv_coordinates(bounds, local):
    return Vector((lerp(bounds[0], bounds[2], local[0]),
                   lerp(bounds[1], bounds[3], local[1])))


def get_bounds_for_color(palette, color):
    return [color.position[0] / palette.columns,
            1.0 - color.position[1] / palette.rows -
            color.span[1] / palette.rows,
            color.position[0] / palette.columns +
            color.span[0] / palette.columns,
            1.0 - color.position[1] / palette.rows]


def calc_diff(self, scale):
    diff = ((self.mouse_path[1][0] - self.mouse_path[0][0]) / scale,
            (self.mouse_path[1][1] - self.mouse_path[0][1]) / scale)

    if self.properties.axis == 'X':
        diff = (diff[0], 0)

    if self.properties.axis == 'Y':
        diff = (0, diff[1])

    return diff


def update_palette_data(self, context):

    global image, texture, color, color_uv, channel_index, channel
    palette_data = context.scene.palette_map.palettes[context.scene.palette_map.active_index]

    if len(palette_data.channels) < channel_index:
        self.report({'WARNING'}, 'Active palette has no channels')
        return False

    channel = palette_data.channels[channel_index]
    image = channel.image

    if image is None:
        self.report({'WARNING'}, 'Channel has no image')
        return False

    texture = gpu.texture.from_image(image)
    color = palette_data.colors[palette_data.active_index]

    color_uv = get_bounds_for_color(palette_data, color)

    return True


def set_vertex_uvs(obj, new_uvs):

    # Ensure the object is a mesh
    if obj.type != 'MESH':
        return

    # Ensure the object has UV layers
    if not obj.data.uv_layers:
        print('No UVs')
        return

    # Get the bmesh representation
    import bmesh
    bm = bmesh.from_edit_mesh(obj.data)

    uv_layer = bm.loops.layers.uv.verify()

    # Ensure we are only affecting the selected vertices of visible faces
    for face in bm.faces:
        if face.hide:
            continue

        for loop in face.loops:
            vert = loop.vert
            if vert.select:
                loop_uv = loop[uv_layer]
                loop_uv.uv = new_uvs

    # Update the mesh
    bmesh.update_edit_mesh(obj.data)


def draw_callback_px(self, context):

    global shader, line_shader, texture, color_uv, color, channel

    try:
        font_id = 0  # XXX, need to find out how best to get this.

        diff = calc_diff(self, 200)

        palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]

        # draw some text
        col = context.preferences.themes[0].view_3d.space.text
        blf.color(font_id, col.r, col.g, col.b, 1)

        ui_scale = context.preferences.view.ui_scale

        axis = {'XY': '', 'X': '- X', 'Y': '- Y'}[self.properties.axis]

        blf.position(font_id, 15, 30, 0)
        blf.size(font_id, 13.0 * ui_scale)
        blf.draw(font_id, F'Hello Word {diff[0]}, {diff[1]}')

        blf.position(font_id, 15, 15, 0)
        blf.size(font_id, 11.0 * ui_scale)
        blf.draw(font_id,
                 F'[X/Y] Change Axis {axis} - [P] Cycle Palette - [A/D] Cycle Color - [W/S] Cycle Channel')

        blf.position(font_id, 15, 165 + 15.0 * ui_scale, 0)
        blf.size(font_id, 12.0 * ui_scale)
        blf.draw(font_id, F'{palette.name}')

        blf.position(font_id, 15, 165, 0)
        blf.size(font_id, 12.0 * ui_scale)
        blf.draw(font_id, F'{channel.name} > {color.name}')

        if shader is None:
            shader = gpu.shader.from_builtin('IMAGE')

        bounds = (15, 50, 115, 150)
        batch = batch_for_shader(shader, 'TRI_FAN', {
            'pos': ((bounds[0], bounds[1]), (bounds[2], bounds[1]), (bounds[2], bounds[3]), (bounds[0], bounds[3])),
            'texCoord': ((color_uv[0], color_uv[1]), (color_uv[2], color_uv[1]), (color_uv[2], color_uv[3]), (color_uv[0], color_uv[3])),
        },)

        shader.bind()
        shader.uniform_sampler('image', texture)
        batch.draw(shader)

        gpu.state.point_size_set(10.0)

        if line_shader is None:
            line_shader = gpu.shader.from_builtin('UNIFORM_COLOR')

        uv = clamp01((0.5 + diff[0], 0.5 + diff[1]))
        points = [tuple(get_uv_coordinates(bounds, uv))]

        batch = batch_for_shader(line_shader, 'POINTS', {'pos': points}, )
        line_shader.bind()
        line_shader.uniform_float('color', (1.0, 0.0, 0.0, 1.0))
        batch.draw(line_shader)

    except:

        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    finally:

        # restore opengl defaults
        gpu.state.point_size_set(1.0)
        gpu.state.blend_set('NONE')


class PALETTEMAP_OT_modify_palette_uvs(bpy.types.Operator):

    '''Draw a line with the mouse'''
    bl_idname = 'uvs.modify_palette_uvs'
    bl_label = 'Modify Palette UVs'
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(name='Axis', default='XY', items=[
                       ('XY', 'XY', ''), ('X', 'X', ''), ('Y', 'Y', '')])

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH' and context.active_object.mode == 'EDIT'

    def modal(self, context, event):

        global channel_index, color_uv

        context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            self.mouse_path[1] = (event.mouse_region_x, event.mouse_region_y)

            diff = calc_diff(self, 200)
            uv = clamp01((0.5 + diff[0], 0.5 + diff[1]))
            uvs = get_uv_coordinates(color_uv, uv)

            for sel in context.selected_objects:
                if sel.type == 'MESH':
                    set_vertex_uvs(sel, uvs)

        elif event.type == 'LEFTMOUSE':
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}

        elif event.value == 'PRESS':

            # cycle palette
            if event.type == 'P':
                palette_map = context.scene.palette_map
                palette_map.active_index = wrap(
                    palette_map.active_index + 1, 0, len(palette_map.palettes))
                update_palette_data(self, context)

            # cycle color forwards
            elif event.type == 'D':

                palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
                palette.active_index = wrap(
                    palette.active_index + 1, 0, len(palette.colors))
                update_palette_data(self, context)

            # cycle color backwards
            elif event.type == 'A':

                palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
                palette.active_index = wrap(
                    palette.active_index - 1, 0, len(palette.colors))
                update_palette_data(self, context)

            # cycle channel forwards
            elif event.type == 'W':
                palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
                channel_index = wrap(channel_index + 1, 0,
                                     len(palette.channels))
                update_palette_data(self, context)

            # cycle channel backwards
            elif event.type == 'S':
                palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
                channel_index = wrap(channel_index - 1, 0,
                                     len(palette.channels))
                update_palette_data(self, context)

            # change axis
            elif event.type == 'X':
                if self.properties.axis == 'X':
                    self.properties.axis = 'XY'
                else:
                    self.properties.axis = 'X'
                pass

            elif event.type == 'Y':
                if self.properties.axis == 'Y':
                    self.properties.axis = 'XY'
                else:
                    self.properties.axis = 'Y'
                pass

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):

        if context.area.type == 'VIEW_3D':

            update_palette_data(self, context)

            # the arguments we pass the the callback
            args = (self, context)
            # Add the region OpenGL drawing callback
            # draw in view space with 'POST_VIEW' and 'PRE_VIEW'
            self._handle = bpy.types.SpaceView3D.draw_handler_add(
                draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            self.mouse_path = 2 * \
                [(event.mouse_region_x, event.mouse_region_y)]

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        else:
            self.report({'WARNING'}, 'View3D not found, cannot run operator')
            return {'CANCELLED'}


def register():

    bpy.utils.register_class(PALETTEMAP_OT_modify_palette_uvs)


def unregister():

    try:
        bpy.utils.unregister_class(PALETTEMAP_OT_modify_palette_uvs)

    finally:
        pass


if __name__ == '__main__':
    register()
