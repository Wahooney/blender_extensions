# wahooney_palette_map.py Copyright (C) 2020, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****


import uuid
from bpy.app.handlers import persistent
from mathutils import Vector
from bpy.props import *

bl_info = {
    'name': 'Palette Map',
    'author': 'Keith (Wahooney) Boshoff',
    'version': (2, 0, 0),
    'blender': (4, 1, 0),
    'category': 'Rendering'}

if 'bpy' in locals():

    import importlib

    importlib.reload(wahooney_palette_render_functions)
    importlib.reload(wahooney_palette_create_shaders)
    importlib.reload(wahooney_palette_prepare_for_paint)
    importlib.reload(wahooney_palette_guides)
    importlib.reload(wahooney_palette_export_import)
    importlib.reload(wahooney_palette_update_functions)
    importlib.reload(wahooney_palette_modify_uvs)

else:

    import bpy

    from . import wahooney_palette_render_functions
    from . import wahooney_palette_create_shaders
    from . import wahooney_palette_prepare_for_paint
    from . import wahooney_palette_guides
    from . import wahooney_palette_export_import
    from . import wahooney_palette_update_functions
    from . import wahooney_palette_modify_uvs


has_update_block = wahooney_palette_update_functions.has_update_block
request_update_block = wahooney_palette_update_functions.request_update_block
release_update_block = wahooney_palette_update_functions.release_update_block


################################################################################
# CONSTANTS

VERSION = 2
CHANNEL_PLACEHOLDERS = ['Red Name', 'Green Name', 'Blue Name', 'Alpha Name']
CHANNEL_NAMES = ['Red', 'Green', 'Blue', 'Alpha']

e_update_method = [('MANUAL', 'Manual',  '', 'VIEW_PAN', 1),
                   ('AUTO',   'Auto',    '', 'AUTO',     2)]

e_export_format = [('PNG', 'PNG',     '', 'IMAGE_DATA', 1),
                   ('EXR', 'OpenEXR', '', 'IMAGE_DATA', 2),
                   ('JPG', 'JPEG',    '', 'IMAGE_DATA', 3)]

e_color_mode = [('SINGLE', 'Single', 'Single Color', 'MESH_PLANE', 0),
                ('HORIZONTAL', 'Horizontal Gradient',
                 'Horizontal gradient between two colors', 'SPLIT_VERTICAL', 1),
                ('VERTICAL', 'Vertical Gradient',
                 'Vertical gradient between two colors', 'SPLIT_HORIZONTAL', 2),
                ('BIDIRECTION', 'Bi-directional', 'Bi-directional gradient between four colors', 'MESH_GRID', 3)]

e_interpolation_method = [('SMOOTH', 'Smooth', 'Smooth gradient between colors', 'IPO_EASE_IN_OUT', 0),
                          ('STEPPED', 'Stepped', 'Stepped gradient between colors', 'IPO_CONSTANT', 1)]

e_channel_type = [('COLOR', 'Color',  'Color Channel (Linear RGBA)'),
                  ('VALUE', 'Values', 'Separate Values')]


################################################################################
# Common Functions

def lerp(a, b, x):
    return a + (b - a) * x


def inv_lerp(a, b, x):
    return (x - a) / (b - a)


def get_bounds_for_color(palette, color):
    return [color.position[0] / palette.columns,
            1.0 - color.position[1] / palette.rows -
            color.span[1] / palette.rows,
            color.position[0] / palette.columns +
            color.span[0] / palette.columns,
            1.0 - color.position[1] / palette.rows]


def get_last_bounds_for_color(palette, color):

    pos = color.last_position
    return [pos[0] / palette.last_columns,
            1 - pos[1] / palette.last_rows -
            color.last_span[1] / palette.last_rows,
            pos[0] / palette.last_columns +
            color.last_span[0] / palette.last_columns,
            1 - pos[1] / palette.last_rows]


def get_local_coordinates(bounds, uv):
    return Vector((inv_lerp(bounds[0], bounds[2], uv[0]),
                   inv_lerp(bounds[1], bounds[3], uv[1])))


def get_uv_coordinates(bounds, local):
    return Vector((lerp(bounds[0], bounds[2], local[0]),
                   lerp(bounds[1], bounds[3], local[1])))


def update_palette_layout(palette):

    if not bpy.context.scene.palette_map.auto_restructure_uv:
        palette.update_state("Manual Restructure")
        return

    attribute_name = palette.palette_uv_attribute

    if palette.material is None or attribute_name == '':
        return

    # cache and exit edit mode
    is_edit_mode = bpy.context.active_object.mode == 'EDIT'
    bpy.ops.object.mode_set(mode='OBJECT')

    for mesh in bpy.data.meshes:
        if palette.material.name not in mesh.materials or attribute_name not in mesh.attributes:
            continue

        uvs = mesh.attributes[attribute_name]

        affected = len(uvs.data) * [False]

        for col in palette.colors:
            last_bounds = get_last_bounds_for_color(palette, col)
            bounds = get_bounds_for_color(palette, col)

            for uv_idx, uv in enumerate(uvs.data):

                if affected[uv_idx]:
                    continue

                local_uv = get_local_coordinates(last_bounds, uv.vector)

                if local_uv[0] < 0 or local_uv[0] > 1 or local_uv[1] < 0 or local_uv[1] > 1:
                    continue

                uvs.data[uv_idx].vector = get_uv_coordinates(bounds, local_uv)
                affected[uv_idx] = True

    palette.update_state("Auto Restructure")

    if is_edit_mode:
        bpy.ops.object.mode_set(mode='EDIT')


def update_structure(self, context):

    palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
    update_palette_layout(palette)

    if not has_update_block(context.scene):
        update(self, context)


def update_position(self, context):

    palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
    update_palette_layout(palette)

    if not has_update_block(context.scene):
        update(self, context)


def update_channel_stops(self, context):

    while len(self.stops) < 4:
        self.stops.add()


def update(self, context):

    if context.scene.palette_map.update_method == 'AUTO' and len(context.scene.palette_map.palettes) > 0:
        bpy.ops.palette_map.render()


def update_mode(self, context):

    if not has_update_block(context.scene):
        update(self, context)


def update_color(self, context):

    if has_update_block(context.scene):
        return

    if type(self) == PaletteColor:
        update_channel_stops(self, context)

    update(self, context)


################################################################################
# AUTOMATIC UPDATES

@persistent
def palette_map_validate_graph(scene):

    if has_update_block(scene):
        return

    try:
        request_update_block(scene, 'Validating Graph')

        for palette in scene.palette_map.palettes:
            palette.validate()

    except Exception as e:
        print(e)

    finally:
        release_update_block(scene, 'Validating Graph')


@persistent
def palette_map_load_post(filename):

    palette_map = bpy.context.scene.palette_map

    # upgrade rows to show_value property
    for palette in palette_map.palettes:
        for channel in palette.channels:
            for definition in channel.definitions:
                if definition.row < 0:
                    definition.show_value = False
                    definition.row = 0

        palette.update_state("Load Post")

    # upgrade palette maps to version 2 if there aren't any palettes and we won't make a fuss about it
    if palette_map.version < 2:
        if len(palette_map.palettes) == 0:
            palette_map.version = 2


################################################################################
# GUIDES

def update_guides(_, __):
    bpy.ops.palettemap.guide_render('INVOKE_REGION_WIN')


def get_show_guides(_):
    return wahooney_palette_guides.PALETTEMAP_OT_PaletteGuideRender.is_running(bpy.context)


def set_show_guides(_, __):
    pass


################################################################################
# Panels

class PALETTEMAP_PT_palette_map(bpy.types.Panel):
    '''Creates the main Palette Map Panel'''

    bl_label = 'Palette Map'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Palette Map'

    def draw_list(self, template, data, data_path, index_data, index_path, row, data_type, type='DEFAULT', columns=5):

        items = getattr(data, data_path)
        idx = getattr(index_data, index_path)
        index = wahooney_palette_render_functions.clamp(idx, 0, len(items)-1)

        if len(items) > 1:
            if idx != index:
                pass  # setattr(data, index_path, index)

        row.template_list(template, '',
                          data, data_path, data, index_path, rows=5, type=type, columns=columns)

        # management
        manage_col = row.column(align=True)
        modify_ot_name = PALETTEMAP_OT_modify_list.bl_idname

        op = manage_col.operator(modify_ot_name, icon='ADD', text='')
        op.data_type = data_type
        op.action = 'ADD'

        if data_type == 'COLOR':

            op = manage_col.operator(modify_ot_name, icon='TRIA_LEFT', text='')
            op.data_type = data_type
            op.action = 'INSERT'

            op = manage_col.operator(modify_ot_name, icon='DUPLICATE', text='')
            op.data_type = data_type
            op.action = 'DUPLICATE'

        op = manage_col.operator(modify_ot_name, icon='REMOVE', text='')
        op.data_type = data_type
        op.action = 'REMOVE'

        manage_col.separator()

        # reordering
        if data_type == 'COLOR':

            order_col = manage_col.column(align=True)
            order_col.enabled = index > 0

            op = order_col.operator(
                modify_ot_name, icon='TRIA_UP_BAR', text='')
            op.data_type = data_type
            op.action = 'MOVE_TOP'

            op = order_col.operator(modify_ot_name, icon='TRIA_UP', text='')
            op.data_type = data_type
            op.action = 'MOVE_UP'

            order_col = manage_col.column(align=True)
            order_col.enabled = index < len(items) - 1

            op = order_col.operator(modify_ot_name, icon='TRIA_DOWN', text='')
            op.data_type = data_type
            op.action = 'MOVE_DOWN'

            op = order_col.operator(
                modify_ot_name, icon='TRIA_DOWN_BAR', text='')
            op.data_type = data_type
            op.action = 'MOVE_BOTTOM'

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        palette_map = scene.palette_map
        def_index = palette_map.active_index

        ########################################################################
        # GLOBAL SETTINGS AREA

        panel = layout.panel_prop(palette_map, 'expanded_settings')
        panel[0].label(text='Global Settings')

        if panel[1] is not None:
            col = panel[1].column(align=True)
            col.prop(palette_map, 'path')
            col.prop(palette_map, 'material_prefix')
            col.prop(palette_map, 'texture_prefix')
            col.prop(palette_map, 'export_format')

            col.separator()

            row = col.row(align=True)

            row.operator(wahooney_palette_export_import.PALETTEMAP_OT_export_palette.bl_idname,
                         text='Export Palette', icon='EXPORT')
            row.operator(wahooney_palette_export_import.PALETTEMAP_OT_import_palette.bl_idname,
                         text='Import Palette', icon='IMPORT').target_palette = def_index

        ########################################################################
        # PALETTE MAP AREA

        row = layout.row()
        self.draw_list('PALETTEMAP_UL_palette_maps', palette_map, 'palettes',
                       palette_map, 'active_index', row, 'PALETTE')

        if len(palette_map.palettes) == 0:
            return

        palette = palette_map.palettes[palette_map.active_index]

        ########################################################################
        # UPDATE TO DYNAMIC PALETTE AREA

        if palette.target_albedo or palette.target_pbr or palette.target_emission is not None or palette_map.version < 2:

            box = layout.box()

            # TODO: Deprecated

            col = box.column(align=True)
            col.alert = True
            row = col.row()
            row.scale_y = 2
            row.operator(PALETTEMAP_OT_upgrade_to_dynamic_palette.bl_idname)
            col.separator()

            if palette.target_albedo is not None:
                col.prop(palette, 'target_albedo')
            if palette.target_pbr is not None:
                col.prop(palette, 'target_pbr')
            if palette.target_emission is not None:
                col.prop(palette, 'target_emission')

        ########################################################################
        # STRUCTURE AREA

        struct_panel = layout.panel_prop(palette_map, 'expanded_structure')
        struct_panel[0].label(text='Palette Structure')

        if struct_panel[1] is not None:
            row = struct_panel[1].row(align=True)
            row.prop(palette, 'columns')
            row.prop(palette, 'rows')
            struct_panel[1].prop(
                palette_map, 'auto_restructure_uv', icon='AUTO')

            row = struct_panel[1].row(align=True)
            row.prop(palette, 'width')
            row.prop(palette, 'height')

            col = struct_panel[1].column(align=True)
            col.prop(palette, 'gamma', slider=True)
            col.prop(palette, 'padding', slider=True)

        ########################################################################
        # CHANNELS AREA

        panel = layout.panel_prop(palette_map, 'expanded_channels')
        channel_row = panel[0].row()
        channel_row.label(text='Channel Definitions')
        channel_row.operator(PALETTEMAP_OT_save_map.bl_idname,
                             text='', icon='FILE_TICK').channel_id = ''

        if panel[1] is not None:

            col = panel[1].column(align=True)

            if len(palette.channels) > 0:

                for channel in palette.channels:

                    panel = col.panel(channel.name, default_closed=True)
                    row = panel[0]

                    row.prop(channel, 'name', text='', icon='COPY_ID')

                    if channel.image is not None:
                        row.operator(PALETTEMAP_OT_view_map.bl_idname,
                                     text='', icon='HIDE_OFF').channel_id = channel.id
                        row.operator(PALETTEMAP_OT_save_map.bl_idname,
                                     text='', icon='FILE_TICK').channel_id = channel.id

                    else:
                        row.operator(PALETTEMAP_OT_create_map.bl_idname,
                                     text='', icon='IMAGE').channel_id = channel.id
                        row.label(text='', icon='BLANK1')

                    if panel[1] is not None:

                        panel_row = panel[1].row()

                        channel_col = panel_row.column(align=True)
                        channel_col.prop(channel, 'image', text='')
                        channel_col.prop(channel, 'channel_type', text='Type')
                        channel_col.separator()

                        if channel.channel_type == 'VALUE':
                            for idx, definition in enumerate(channel.definitions):

                                value_row = channel_col.row(align=True)
                                value_row.prop(
                                    definition, 'name', placeholder=CHANNEL_PLACEHOLDERS[idx], text='')
                                value_row.prop(
                                    definition, 'show_value', text='', icon='HIDE_OFF')

                                if definition.show_value:
                                    channel_col.prop(
                                        channel, 'default_color', text='Default', index=idx, slider=True)

                                channel_col.separator()

                        elif channel.channel_type == 'COLOR':

                            color_row = channel_col.row(align=True)
                            color_row.prop(
                                channel, 'show_name', icon='COPY_ID')
                            color_row.prop(channel, 'use_compact',
                                           icon='FULLSCREEN_EXIT')
                            color_row = channel_col.row(align=True)
                            color_row.prop(channel, 'default_color')

                        op = panel_row.operator(
                            PALETTEMAP_OT_manage_color_channel.bl_idname, text='', icon='REMOVE')
                        op.operation = 'REMOVE'
                        op.channel_id = channel.id
                        col.separator()

            else:
                col.label(text='No Channels')
                col.separator()
                col.operator(PALETTEMAP_OT_manage_color_channel.bl_idname,
                             text='Add PBR Channels').operation = 'PBR'

            col.operator(PALETTEMAP_OT_manage_color_channel.bl_idname,
                         text='Add New Channel')

        ########################################################################
        # MATERIAL AREA

        panel = layout.panel_prop(palette_map, 'expanded_materials')

        panel[0].label(text='Manage Materials')

        if panel[1] is not None:
            manage_col = panel[1].column(align=True)

            row = manage_col.row(align=True)
            row.prop(palette, 'material', text='')
            row.operator(wahooney_palette_create_shaders.PALETTEMAP_OT_assign_palette_material.bl_idname,
                         text='', icon='MATERIAL_DATA')

            manage_col.separator()

            row = manage_col.row(align=True)
            row.operator(
                wahooney_palette_create_shaders.PALETTEMAP_OT_create_basic_material.bl_idname, text='Basic')

            row = manage_col.row(align=True)
            row.operator(
                wahooney_palette_create_shaders.PALETTEMAP_OT_create_painted_material.bl_idname, text='Painted')
            row.operator(
                wahooney_palette_prepare_for_paint.PALETTE_OT_prepare_for_paint.bl_idname, text='', icon='TPAINT_HLT')

            row = manage_col.row(align=True)
            row.operator(
                wahooney_palette_create_shaders.PALETTEMAP_OT_create_ultra_material.bl_idname, text='Ultra')
            row.operator(
                wahooney_palette_prepare_for_paint.PALETTE_OT_prepare_for_ultra.bl_idname, text='', icon='TPAINT_HLT')

        ########################################################################
        # RENDER AREA

        box = layout.box()
        box.operator(
            wahooney_palette_render_functions.PALETTEMAP_OT_render.bl_idname)
        box.prop(palette_map, 'update_method')

        ########################################################################
        # GUIDE AREA

        panel = layout.panel_prop(palette_map, 'expanded_guides')
        row = panel[0].row()
        row.prop(palette_map, 'show_guides', text='Show Guides')

        if panel[1] is not None:

            col = panel[1].column(align=True)
            col.use_property_split = True
            col.prop(palette_map, 'guide_color', icon='BLANK1')
            col.prop(palette_map, 'guide_shadow', icon='BLANK1')

        ########################################################################
        # COLOR AREA

        if len(palette_map.palettes) > 0:

            box = layout.box()
            palette = palette_map.palettes[def_index]
            box.label(text=palette.name)

            row = box.row()
            self.draw_list('PALETTEMAP_UL_colors', palette, 'colors',
                           palette, 'active_index', row, 'COLOR')

            act = context.active_object

            if len(palette.colors) > 0:

                color = palette.colors[palette.active_index]

                color_panel = box.panel_prop(
                    palette_map, 'expanded_color_span')
                color_panel[0].prop(color, 'name', text='')

                if color_panel[1] is not None:

                    row = color_panel[1].row(align=True)
                    row.label(icon='CON_LOCLIMIT')
                    row.prop(color, 'position', text='')

                    row = color_panel[1].row(align=True)
                    row.label(icon='CON_SIZELIMIT')
                    row.prop(color, 'span', text='')

                    row = color_panel[1].row(align=True)
                    row.prop(color, 'method', expand=True)

                    color_panel[1].prop(
                        palette_map, 'auto_restructure_uv', icon='AUTO')
                    if act is not None and act.type == 'MESH':
                        color_panel[1].prop_search(
                            palette, 'palette_uv_attribute', act.data, 'uv_layers')
                    else:
                        color_panel[1].prop(palette, 'palette_uv_attribute')

                col = box.column()

                for channel in palette.channels:

                    channel_color = color.channel_colors[channel.id]

                    row = col.row(align=True)
                    row.label(text=channel.name)
                    row.prop(channel_color, 'mode', text='', expand=True)

                    row.separator()
                    row.operator(PALETTEMAP_OT_view_map.bl_idname,
                                 text='', icon='HIDE_OFF').channel_id = channel.id

                    col_count = 1
                    total_count = 1

                    if channel_color.mode == 'HORIZONTAL':
                        col_count = 2
                        total_count = 2

                    elif channel_color.mode == 'VERTICAL':
                        col_count = 1
                        total_count = 2

                    elif channel_color.mode == 'BIDIRECTION':
                        col_count = 2
                        total_count = 4

                    if channel.channel_type == 'COLOR':

                        grid = col.grid_flow(
                            row_major=True, columns=col_count, even_columns=True, even_rows=True, align=True)
                        for stop in channel_color.stops[:total_count]:
                            grid.prop(stop, 'color', text='')

                    elif channel.channel_type == 'VALUE':

                        for idx, definition in enumerate(channel.definitions):

                            if not definition.show_value:
                                continue

                            if definition.name == '':
                                col.label(text=CHANNEL_NAMES[idx])
                            else:
                                col.label(text=definition.name)

                            grid = col.grid_flow(
                                row_major=True, columns=col_count, even_columns=True, even_rows=True, align=True)
                            for stop in channel_color.stops[:total_count]:
                                grid.prop(stop, 'color', text='',
                                          index=idx, slider=True)


class PALETTEMAP_OT_modify_list(bpy.types.Operator):
    '''Change the list of palettes or colors'''

    bl_idname = 'palette_map.modify_list'
    bl_label = 'Manage Palette List'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    index: IntProperty()
    new_index: IntProperty()
    data_type: EnumProperty(items=[('PALETTE', '', ''), ('COLOR', '', '')])

    action: EnumProperty(items=[
        ('MOVE_TOP',    'Move Up',   '', 'TRIA_UP_BAR',   0),
        ('MOVE_UP',     'Move Up',   '', 'TRIA_UP',       1),
        ('MOVE_DOWN',   'Move Down', '', 'TRIA_DOWN',     2),
        ('MOVE_BOTTOM', 'Move Down', '', 'TRIA_DOWN_BAR', 3),
        ('ADD',         'Add',       '', 'ADD',           4),
        ('REMOVE',      'Remove',    '', 'REMOVE',        5),
        ('INSERT',      'Insert',    '', 'TRIA_LEFT',     6),
        ('DUPLICATE',   'Duplicate', '', 'TRIA_LEFT',     7),
    ])

    @classmethod
    def poll(cls, context):
        return True

    @classmethod
    def description(cls, context, properties):

        if properties.action == 'MOVE_UP':
            return 'Move to the top'
        elif properties.action == 'MOVE_BOTTOM':
            return 'Move to the bottom'
        elif properties.action == 'MOVE_UP':
            return 'Move Up'
        elif properties.action == 'MOVE_DOWN':
            return 'Move Down'

        if properties.data_type == 'PALETTE':
            if properties.action == 'REMOVE':
                return 'Remove Active Palette'
            elif properties.action == 'ADD':
                return 'Add New Palette'
            elif properties.action == 'INSERT':
                return 'Insert Palette at current position'
            elif properties.action == 'DUPLICATE':
                return 'Duplicate the Palette at current position'

        if properties.data_type == 'COLOR':
            if properties.action == 'REMOVE':
                return 'Remove Active Color'
            elif properties.action == 'ADD':
                return 'Add New Color'
            elif properties.action == 'INSERT':
                return 'Insert Color at current position'
            elif properties.action == 'DUPLICATE':
                return 'Duplicate the Color at current position'

        return 'UNKNOWN ACTION'

    def execute(self, context):

        request_update_block(context.scene, 'Manage List')

        scene = context.scene
        data = scene.palette_map

        data_list = None
        data_index = None
        new_name = None

        if self.data_type == 'PALETTE':
            data_list = data.palettes
            data_index = data
            new_name = 'PaletteMap'

        elif self.data_type == 'COLOR':
            data_index = data.palettes[data.active_index]
            data_list = data_index.colors
            new_name = 'Color'

        item_index = data_index.active_index

        if self.action == 'MOVE_TOP':

            data_list.move(item_index, 0)
            data_index.active_index = 0

        elif self.action == 'MOVE_BOTTOM':

            data_list.move(item_index, len(data_list) - 1)
            data_index.active_index = len(data_list) - 1

        elif self.action == 'MOVE_UP':

            data_list.move(item_index, item_index - 1)
            data_index.active_index = item_index - 1

        elif self.action == 'MOVE_DOWN':

            data_list.move(item_index, item_index + 1)
            data_index.active_index = item_index + 1

        elif self.action == 'REMOVE':

            if item_index >= 0 and item_index < len(data_list):
                data_list.remove(item_index)
                data_index.active_index = min(item_index, len(data_list) - 1)

        elif self.action == 'ADD':

            item = data_list.add()
            item.name = new_name

            if self.data_type == 'COLOR':

                item.validate(data_index)

                for channel in data_index.channels:

                    channel_color = item.find_channel_color_by_id(channel.id)

                    if channel_color is None:
                        continue

                    while len(channel_color.stops) < 4:
                        channel_color.stops.add()

                    for idx, stop in enumerate(channel_color.stops):

                        if channel.channel_type == 'VALUE':
                            for idx, definition in enumerate(channel.definitions):
                                if idx < len(stop.color):
                                    stop.color[idx] = channel.default_color[idx]

                        elif channel.channel_type == 'COLOR':
                            stop.color = channel.default_color

            else:

                item.validate()

            data_index.active_index = len(data_list) - 1

        elif self.action == 'INSERT':

            item = data_list.add()
            item.name = new_name

            if self.data_type == 'COLOR':
                item.validate(data_index)
            else:
                item.validate()

            data_list.move(len(data_list) - 1, item_index)

        elif self.action == 'DUPLICATE':
            destination = data_list.add()
            source = data_list[item_index]

            wahooney_palette_render_functions.copy_data(
                self, source, destination)

            destination.name = F'{source.name} - Copy'

            if self.data_type == 'COLOR':
                destination.validate(data_index)
            else:
                destination.validate()

            if self.data_type == 'COLOR':
                for i in range(len(source.stops)):

                    if i >= len(destination.stops):
                        destination.stops.add()

                    wahooney_palette_render_functions.copy_data(
                        self, source.stops[i], destination.stops[i])

            data_list.move(len(data_list)-1, item_index+1)

        for palette in bpy.context.scene.palette_map.palettes:
            palette.update_state('Register')

        release_update_block(context.scene, 'Manage List')
        update(self, context)

        return {'FINISHED'}


class PALETTEMAP_OT_manage_color_channel(bpy.types.Operator):
    '''Adds, Removes, or otherwise manage color channels '''

    bl_idname = 'palette_map.manage_color_channel'
    bl_label = 'Manage Color Channel'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    channel_name: StringProperty(default='Channel')
    channel_id: StringProperty(default='')
    operation: EnumProperty(
        items=[('CREATE', '', ''), ('REMOVE', '', ''), ('PBR', '', '')], default='CREATE')

    @classmethod
    def poll(cls, context):

        palette = None
        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        return palette is not None

    def execute(self, context):

        palette_map = context.scene.palette_map
        palette = palette_map.palettes[context.scene.palette_map.active_index]

        if self.operation == 'CREATE':

            channel = palette.channels.add()
            channel.initialize()
            channel.name = self.channel_name

            for color in palette.colors:

                channel_color = color.channel_colors.add()
                channel_color.name = channel.id

                while len(channel_color.stops) < 4:
                    channel_color.stops.add()

        elif self.operation == 'PBR':

            ####################################################################
            # BASE

            channel = palette.channels.add()
            channel.initialize()

            channel.name = 'Base'
            channel.channel_type = 'COLOR'
            channel.use_as_render = True
            channel.use_compact = True
            channel.default_color = (0.75, 0.75, 0.75)

            ####################################################################
            # PBR

            channel = palette.channels.add()
            channel.initialize()

            channel.name = 'PBR'
            channel.channel_type = 'VALUE'

            while len(channel.definitions) < 4:
                channel.definitions.add()

            channel.definitions[0].name = 'Metallic'
            channel.definitions[0].show_value = True
            channel.default_color[0] = 0

            channel.definitions[1].name = 'Roughness'
            channel.definitions[1].show_value = True
            channel.default_color[1] = 0.5

            channel.definitions[2].name = 'Specular'
            channel.definitions[2].show_value = True
            channel.default_color[2] = 0.5

            channel.definitions[3].name = ''
            channel.definitions[3].show_value = False

            channel.use_as_render = False

            ####################################################################
            # EMISSION

            channel = palette.channels.add()
            channel.initialize()
            channel.name = 'Emission'
            channel.channel_type = 'COLOR'
            channel.use_as_render = True
            channel.show_name = True
            channel.use_compact = True
            channel.default_color = (0, 0, 0)

        elif self.operation == 'REMOVE':

            palette_map = context.scene.palette_map
            palette = palette_map.palettes[context.scene.palette_map.active_index]

            for channel in palette.channels:

                if channel.id != self.channel_id:
                    continue

                idx = -1

                # we do this because we're iterating through a collection and removing items
                # we have to reiterate through to remove the correct indexed item
                for i, c in enumerate(palette.channels.items()):
                    if c[1] == channel:
                        idx = i
                        break

                if idx < 0:
                    continue

                palette.channels.remove(idx)

                # clean up additional color stops
                for color in palette.colors:

                    if self.channel_id in color.channel_colors:

                        channel_color = color.channel_colors.find(
                            self.channel_id)
                        color.channel_colors.remove(channel_color)

            pass

        palette.validate()

        return {'FINISHED'}


class PALETTEMAP_OT_create_map(bpy.types.Operator):
    '''Create an image for the selected channel'''

    bl_idname = 'palette_map.create_map'
    bl_label = 'Create Image'
    bl_options = {'REGISTER',  'INTERNAL'}

    channel_id: StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        palette = None
        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        return palette is not None

    def execute(self, context):

        palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        prefix = context.scene.palette_map.texture_prefix
        channel = palette.find_channel_by_id(self.channel_id)

        if channel is None:
            return {'FINISHED'}

        new_name = F'{prefix}{palette.name}_{channel.name}'
        image = None

        if new_name in bpy.data.images:
            image = bpy.data.images[new_name]
        else:
            image = bpy.data.images.new(
                new_name, palette.width, palette.height, alpha=True, float_buffer=True)

        channel.image = image
        channel.image.colorspace_settings.name = 'Linear Rec.709' if channel.use_as_render else 'Non-Color'
        channel.image.use_view_as_render = channel.use_as_render

        context.space_data.image = image

        return {'FINISHED'}


class PALETTEMAP_OT_save_map(bpy.types.Operator):
    '''Save image to disk'''

    bl_idname = 'palette_map.save'
    bl_label = 'Save Image'
    bl_options = {'REGISTER',  'INTERNAL'}

    channel_id: StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        palette = None
        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        return palette is not None

    @classmethod
    def description(cls, context, properties):

        if properties.channel_id == '':
            return 'Save all channel images to disk'

        palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]
        channel = palette.find_channel_by_id(properties.channel_id)

        if channel is None:
            return 'Invalid save operation'

        return F'Save {channel.name} to disk'

    def execute(self, context):

        palette_map = context.scene.palette_map
        palette = palette_map.palettes[context.scene.palette_map.active_index]
        image = None

        channel = palette.find_channel_by_id(self.channel_id)

        channels = [channel]

        if self.channel_id == '':
            channels = [channel for channel in palette.channels]

        bpy.ops.palette_map.render()

        for channel in channels:

            image = channel.image

            if image == None:
                continue

            format = '.png'
            if palette_map.export_format == 'EXR':
                format = '.exr'
            elif palette_map.export_format == 'JPG':
                format = '.jpg'

            image.save(
                filepath=f'{bpy.path.abspath(palette_map.path)}{image.name}{format}')
            print(f'{bpy.path.abspath(palette_map.path)}{image.name}{format}')
            image.filepath_raw = ''

        return {'FINISHED'}


class PALETTEMAP_OT_view_map(bpy.types.Operator):
    '''View image in current image editor'''

    bl_idname = 'palette_map.view_map'
    bl_label = 'View Image'
    bl_options = {'REGISTER',  'INTERNAL'}

    channel_id: StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):

        palette = None

        if len(context.scene.palette_map.palettes) > context.scene.palette_map.active_index:
            palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]

        return palette is not None

    def execute(self, context):

        palette = context.scene.palette_map.palettes[context.scene.palette_map.active_index]

        channel = palette.find_channel_by_id(self.channel_id)
        if channel is not None:
            context.space_data.image = channel.image

        return {'FINISHED'}


################################################################################
# Lists

class PALETTEMAP_UL_base(bpy.types.UIList):

    @staticmethod
    def filter_items_by_name_i(pattern, bitflag, items, propname='name', flags=None, reverse=False):
        import fnmatch

        if not pattern or not items:  # Empty pattern or list = no filtering!
            return flags or []

        if flags is None:
            flags = [0] * len(items)

        # Implicitly add heading/trailing wildcards.
        pattern = F'*{pattern}*'

        for i, item in enumerate(items):
            name = getattr(item, propname, None)
            # This is similar to a logical xor
            if bool(name and fnmatch.fnmatch(name, pattern)) is not bool(reverse):
                flags[i] |= bitflag
        return flags

    def draw_filter(self, context, layout):
        # Nothing much to say here, it's usual UI code...
        row = layout.row(align=True)

        row.prop(self, 'filter_name', text='')
        row.separator()
        row.prop(self, 'use_filter_invert', text='',
                 icon='SELECT_DIFFERENCE' if self.use_filter_invert else 'SELECT_INTERSECT')

        row.separator()
        row.prop(self, 'use_filter_sort_alpha', text='', toggle=True)
        row.prop(self, 'use_filter_sort_reverse', text='',
                 icon='SORT_DESC' if self.use_filter_sort_reverse else 'SORT_ASC')

    def filter_items(self, context, data, propname):

        helper_funcs = bpy.types.UI_UL_list
        rules = []

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Filtering by name
        if self.filter_name:
            flt_flags = PALETTEMAP_UL_base.filter_items_by_name_i(
                self.filter_name, self.bitflag_filter_item, rules, 'name', reverse=False)

        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(rules)

        # Reorder by name or average weight.
        if self.use_filter_sort_alpha:
            flt_neworder = helper_funcs.sort_items_by_name(rules, 'name')

        return flt_flags, flt_neworder


class PALETTEMAP_UL_palette_maps(PALETTEMAP_UL_base):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(icon='GRIP')
            row.prop(item, 'name', text='', icon='COLOR')

        # 'GRID' layout type should be as compact as possible(typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text='', icon_value=icon)


class PALETTEMAP_UL_colors(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(icon='GRIP')
            row.prop(item, 'name', text='')

        # 'GRID' layout type should be as compact as possible(typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text='')


################################################################################
# Property Groups

class PaletteColorStop(bpy.types.PropertyGroup):

    color: FloatVectorProperty(name='Color', subtype='COLOR', min=0, max=1, default=(
        1, 1, 1), update=update_color)

    # TODO: Deprecated
    albedo: FloatVectorProperty(subtype='COLOR', options={'HIDDEN'})
    alpha: FloatProperty(options={'HIDDEN'})
    pbr: FloatVectorProperty(size=3, options={'HIDDEN'})
    emission: FloatVectorProperty(subtype='COLOR', options={'HIDDEN'})


class PaletteChannelColor(bpy.types.PropertyGroup):

    stops: CollectionProperty(type=PaletteColorStop)
    mode: EnumProperty(name='Mode', items=e_color_mode,
                       default='SINGLE', update=update_mode)


class PaletteColor(bpy.types.PropertyGroup):

    active_index: IntProperty()
    position: IntVectorProperty(name='Position', size=2, min=0, default=[
                                0, 0], update=update_position)
    span: IntVectorProperty(name='Color Span', size=2, min=1, default=[
                            1, 1], update=update_position)
    channel_colors: CollectionProperty(type=PaletteChannelColor)

    method: EnumProperty(name='Method', items=e_interpolation_method,
                         default='SMOOTH', update=update_mode)

    sRGB: BoolProperty(name='sRGB')
    bias: FloatProperty(name='Bias', min=0.001, default=1.0, update=update)

    last_position: IntVectorProperty(
        size=2, min=0, default=[0, 0], options={'HIDDEN', 'SKIP_SAVE'})
    last_span: IntVectorProperty(size=2, min=1, default=[
                                 1, 1], options={'HIDDEN', 'SKIP_SAVE'})

    # TODO: Deprecated
    stops: CollectionProperty(type=PaletteColorStop, options={'HIDDEN'})
    mode: EnumProperty(items=e_color_mode, default='SINGLE')

    def find_stop_by_id(self, id):
        return next((stop for stop in self.stops if stop.id == id), None)

    def find_channel_color_by_id(self, id):
        return next((color for color in self.channel_colors if color.name == id), None)

    def validate(self, map_data):

        for channel in map_data.channels:
            color = None

            if channel.id not in self.channel_colors:
                color = self.channel_colors.add()
                color.name = channel.id
            else:
                color = self.channel_colors[channel.id]

            if color is not None:
                while len(color.stops) < 4:
                    color.stops.add()


class PaletteMapChannelDefinition(bpy.types.PropertyGroup):

    show_value: BoolProperty(name='Show Value', default=True)

    # TODO: Deprecated
    row: IntProperty(name='Row', default=0, options={'HIDDEN'})


class PaletteMapChannelData(bpy.types.PropertyGroup):

    id: StringProperty(name='ID', default='')
    image: PointerProperty(name='Image', type=bpy.types.Image)
    show_name: BoolProperty(name='Show Name', default=True)
    use_compact: BoolProperty(name='Compact', default=True)
    default_color: FloatVectorProperty(
        name='Default Color', subtype='COLOR', min=0, max=1, default=(1, 1, 1))
    channel_type: EnumProperty(
        name='Channel Type', items=e_channel_type, default='COLOR')
    use_as_render: BoolProperty(name='Linear Color', default=True)
    definitions: CollectionProperty(type=PaletteMapChannelDefinition)

    def initialize(self):

        while (len(self.definitions) < 4):
            self.definitions.add()

        # assign guid
        if self.id.strip() == '':
            self.id = str(uuid.uuid4())


class PaletteMapData(bpy.types.PropertyGroup):

    active_index: IntProperty()

    id: StringProperty(name='ID', default='')

    palette_uv_attribute: StringProperty(name='UV Attribute', default='UVMap')

    channels: CollectionProperty(type=PaletteMapChannelData)
    colors: CollectionProperty(type=PaletteColor)
    columns: IntProperty(name='Columns', min=1, default=8,
                         update=update_structure)
    rows: IntProperty(name='Rows', min=1, default=8, update=update_structure)
    width: IntProperty(name='Width', min=1, default=256, update=update)
    height: IntProperty(name='Height', min=1, default=256, update=update)
    gamma: FloatProperty(name='Gamma', default=0.0,
                         min=-2, max=2, update=update)
    padding: FloatProperty(name='Padding', default=0.01,
                           min=0, max=0.1, step=0.01, update=update)
    material: PointerProperty(name='Material', type=bpy.types.Material)

    last_columns: IntProperty(name='Last Columns', options={
                              'HIDDEN', 'SKIP_SAVE'})
    last_rows: IntProperty(name='Last Rows', options={'HIDDEN', 'SKIP_SAVE'})

    # TODO: Deprecated
    target_albedo: PointerProperty(name='Albedo', type=bpy.types.Image)
    target_pbr: PointerProperty(name='PBR', type=bpy.types.Image)
    target_emission: PointerProperty(name='Emit', type=bpy.types.Image)

    def validate(self):

        if self.id.strip() == '':
            self.id = str(uuid.uuid4())

        for col in self.colors:
            col.validate(self)

    def find_channel_by_id(self, id: str):
        return next((channel for channel in self.channels if channel.id == id), None)

    def update_state(self, reason):

        print(F'Updating State {reason}')

        for color in self.colors:
            color.last_position = color.position[:]
            color.last_span = color.span[:]

        self.last_rows = self.rows
        self.last_columns = self.columns

    def upgrade_to_dynamic_palette(self):

        changed = False

        if bpy.context.scene.palette_map.version < 2:

            ####################################################################
            # The Dynamic Palette Update
            ####################################################################

            ####################################################################
            # Upgrade to the dynamic palette system

            if self.target_albedo is not None and 'Base' not in self.channels:

                channel = self.channels.add()
                channel.initialize()

                channel.id = 'Base'
                channel.name = 'Base'
                channel.channel_type = 'COLOR'
                channel.image = self.target_albedo
                channel.use_as_render = True

                for color in self.colors:

                    print(F'Updating Color {color.name}')

                    channel_color = color.channel_colors.add()
                    channel_color.name = 'Base'
                    channel_color.mode = color.mode

                    while (len(channel_color.stops) < 4):
                        channel_color.stops.add()

                    for i, stop in enumerate(color.stops):
                        channel_color.stops[i].color = stop.albedo.copy()
                        print(channel_color.stops[i].color)

                self.target_albedo = None

                changed = True

                print(F'Added Base Channel {self.name}')

            if self.target_pbr is not None and 'PBR' not in self.channels:

                channel = self.channels.add()
                channel.initialize()

                channel.id = 'PBR'
                channel.name = 'PBR'
                channel.channel_type = 'VALUE'

                while len(channel.definitions) < 3:
                    channel.definitions.add()

                channel.definitions[0].name = 'Metallic'
                channel.definitions[0].show_value = True
                channel.definitions[1].name = 'Roughness'
                channel.definitions[1].show_value = True
                channel.definitions[2].name = 'Specular'
                channel.definitions[2].show_value = True
                channel.definitions[3].name = ''
                channel.definitions[3].show_value = False

                channel.image = self.target_pbr
                channel.use_as_render = False

                for color in self.colors:

                    print(F'Updating PBR {color.name}')

                    channel_color = color.channel_colors.add()
                    channel_color.name = 'PBR'
                    channel_color.mode = color.mode

                    while (len(channel_color.stops) < 4):
                        channel_color.stops.add()

                    for i, stop in enumerate(color.stops):
                        channel_color.stops[i].color = (
                            stop.pbr[0], stop.pbr[1], stop.pbr[2])
                        print(channel_color.stops[i].color)

                    self.target_pbr = None

                changed = True

                print(F'Added PBR Channel {self.name}')

            if self.target_emission is not None and 'Emission' not in self.channels:

                channel = self.channels.add()
                channel.initialize()

                channel.id = 'Emission'
                channel.name = 'Emission'
                channel.channel_type = 'COLOR'
                channel.image = self.target_emission
                channel.use_as_render = True
                channel.show_name = True
                channel.use_compact = True

                for color in self.colors:

                    print(F'Updating Emission {color.name}')

                    channel_color = color.channel_colors.add()
                    channel_color.name = 'Emission'
                    channel_color.mode = color.mode

                    while (len(channel_color.stops) < 4):
                        channel_color.stops.add()

                    for i, stop in enumerate(color.stops):
                        channel_color.stops[i].color = stop.emission.copy()
                        print(channel_color.stops[i].color)

                self.target_emission = None

                changed = True

                print(F'Added Emission Channel {self.name}')

            ####################################################################
            # Upgrade color mode to per channel color system

            channel = self.channels['Base']
            for color in self.colors:
                for channel_color in color.channel_colors:
                    if channel_color.mode != color.mode:
                        channel_color.mode = color.mode
                        changed = True

            channel = self.channels['PBR']
            for color in self.colors:
                for channel_color in color.channel_colors:
                    if channel_color.mode != color.mode:
                        channel_color.mode = color.mode
                        changed = True

            channel = self.channels['Emission']
            for color in self.colors:
                for channel_color in color.channel_colors:
                    if channel_color.mode != color.mode:
                        channel_color.mode = color.mode
                        changed = True

        return changed


class PaletteMap(bpy.types.PropertyGroup):

    active_index: IntProperty()

    palettes: CollectionProperty(type=PaletteMapData)
    path: StringProperty(name='Path', subtype='DIR_PATH')

    update_method: EnumProperty(name='Update',
                                description='Automatically update the palette map when changes are made, otherwise you must manually update the map',
                                items=e_update_method, default='AUTO')

    export_format: EnumProperty(name='Format',
                                description='Format to export the palette map to',
                                items=e_export_format, default='PNG')

    auto_restructure_uv: BoolProperty(name='Auto Restructure UVs', default=False, options={
                                      'SKIP_SAVE'}, description='Automatically change object UVs when the palette maps structure is changed.')

    # guides
    show_guides: BoolProperty(name='Show Guides', default=False,
                              get=get_show_guides, set=set_show_guides, update=update_guides)
    guide_color: FloatVectorProperty(
        name='Guide Color', subtype='COLOR', size=4, min=0, max=1, default=(1, 0, 0, 1))
    guide_shadow: FloatVectorProperty(
        name='Shadow Color', subtype='COLOR', size=4, min=0, max=1, default=(0, 0, 0, 0.5))

    # prefixes
    texture_prefix: StringProperty(name='Texture Prefix', default='T_')
    material_prefix: StringProperty(name='Material Prefix', default='MI_')

    # expansion properties
    expanded_settings:  BoolProperty(default=True, options=set())
    expanded_guides:    BoolProperty(default=True, options=set())
    expanded_structure: BoolProperty(default=True, options=set())
    expanded_channels:  BoolProperty(default=True, options=set())
    expanded_materials: BoolProperty(default=True, options=set())
    expanded_color_span: BoolProperty(default=True, options=set())

    # palette version
    version: IntProperty(name='Version', default=1)

    def find_palette_by_id(self, id: str):
        return next((palette for palette in self.palettes if palette.id == id), None)

    def validate(self):
        for palette in self.palettes:
            palette.validate()


class PALETTEMAP_OT_upgrade_to_dynamic_palette(bpy.types.Operator):

    bl_idname = 'palette_map.upgrade_to_dynamic_palette'
    bl_label = 'Update Palette'

    def execute(self, context):

        update_method = context.scene.palette_map.update_method
        context.scene.palette_map.update_method = 'MANUAL'

        try:
            if context.scene.palette_map.version < VERSION:

                changes = [palette.upgrade_to_dynamic_palette()
                           for palette in context.scene.palette_map.palettes]

                context.scene.palette_map.version = 2

                change_count = changes.count(True)
                if change_count > 0:
                    print(
                        F'Upgraded {change_count} palette map(s) to version {context.scene.palette_map.version}.')

        except Exception as e:
            print(e)

        finally:
            context.scene.palette_map.update_method = update_method

        return {'FINISHED'}


classes = [

    # utility operators
    wahooney_palette_guides.PALETTEMAP_OT_PaletteGuideRender,

    # lists
    PALETTEMAP_UL_colors,
    PALETTEMAP_UL_palette_maps,

    # operators
    wahooney_palette_render_functions.PALETTEMAP_OT_render,
    PALETTEMAP_OT_modify_list,
    PALETTEMAP_OT_create_map,
    PALETTEMAP_OT_manage_color_channel,
    PALETTEMAP_OT_view_map,
    PALETTEMAP_OT_save_map,
    PALETTEMAP_OT_upgrade_to_dynamic_palette,
    wahooney_palette_export_import.PALETTEMAP_OT_export_palette,
    wahooney_palette_export_import.PALETTEMAP_OT_import_palette,
    wahooney_palette_modify_uvs.PALETTEMAP_OT_modify_palette_uvs,

    # material operators
    wahooney_palette_create_shaders.PALETTEMAP_OT_assign_palette_material,
    wahooney_palette_create_shaders.PALETTEMAP_OT_create_basic_material,
    wahooney_palette_create_shaders.PALETTEMAP_OT_create_painted_material,
    wahooney_palette_create_shaders.PALETTEMAP_OT_create_ultra_material,

    # prepare for paint
    wahooney_palette_prepare_for_paint.PALETTE_OT_prepare_for_paint,
    wahooney_palette_prepare_for_paint.PALETTE_OT_prepare_for_ultra,

    # panels
    PALETTEMAP_PT_palette_map,
    wahooney_palette_export_import.PALETTEMAP_PT_export_palette,

    # data
    PaletteMapChannelDefinition,
    PaletteColorStop,
    PaletteChannelColor,
    PaletteColor,
    PaletteMapChannelData,
    PaletteMapData,
    PaletteMap,
]


def menu_func_load_palette(self, context):
    self.layout.operator(
        wahooney_palette_export_import.PALETTEMAP_OT_import_palette.bl_idname, text='Palette Map (.json)')


def menu_func_save_palette(self, context):
    self.layout.operator(
        wahooney_palette_export_import.PALETTEMAP_OT_export_palette.bl_idname, text='Palette (.json)')


def register():

    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.palette_map = PointerProperty(type=PaletteMap)

    # menu functions
    bpy.types.TOPBAR_MT_file_import.append(menu_func_load_palette)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_save_palette)

    for func in bpy.app.handlers.depsgraph_update_post:
        if func.__name__ == 'palette_map_validate_graph':
            bpy.app.handlers.depsgraph_update_post.remove(func)

    bpy.app.handlers.depsgraph_update_post.append(palette_map_validate_graph)
    bpy.app.handlers.load_post.append(palette_map_load_post)

    # if bpy.context.scene.palette_map is not None: bpy.context.scene.palette_map.validate()


def unregister():

    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass

    # menu functions
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_load_palette)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_save_palette)

    bpy.app.handlers.depsgraph_update_post.remove(palette_map_validate_graph)
    bpy.app.handlers.load_post.remove(palette_map_load_post)

    for func in bpy.app.handlers.depsgraph_update_post:
        if func.__name__ == 'palette_map_validate_graph':
            bpy.app.handlers.depsgraph_update_post.remove(func)


if __name__ == '__main__':
    register()
