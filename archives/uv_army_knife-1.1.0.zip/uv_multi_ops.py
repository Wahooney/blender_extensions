# wahooney_uv_army_knife.py Copyright (C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.props import StringProperty, EnumProperty


def make_active(context, layername):

    uvs = context.active_object.data.uv_layers

    if layername in uvs:
        uvs.active = uvs[layername]
        return True

    return False


def move_to_bottom(context, layername):

    if not make_active(context, layername):
        return

    bpy.ops.mesh.uv_texture_add()
    make_active(context, layername)
    bpy.ops.mesh.uv_texture_remove()

    uvs = context.active_object.data.uv_layers
    uvs.active_index = len(uvs) - 1
    uvs.active.name = layername


# loops integer between 0 and max, 0 inclusive, max exclusive

def loop_int(i, max):
    if i < 0:
        return (max - abs(i) % max) % max
    if i >= max:
        return i % max
    return i


class UV_OT_ManageMultipleUVs(bpy.types.Operator):
    """Affects all selected objects, if the active object has the named UV layer"""
    bl_idname = "uv.manage_multiple_uvs_by_name"
    bl_label = "Manage multiple UVs by Name"
    bl_description = "Manage UV maps across objects in the selection"

    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    affect_uv_layer_name: StringProperty(name='UV Layer', options={'HIDDEN'})
    new_uv_layer_name: StringProperty(name='New Name')
    tooltip: StringProperty(name='Tooltip', options={'HIDDEN'})

    operation: EnumProperty(items=(
        ('GUARANTEE', 'Guarantee',
         'Guarantee the a UV layer with the supplied name exists on all objects'),
        ('MATCH_ORDER', 'Match Order',
         'Reorder UV layers of all selected objects to match the active objects UV layers'),
        ('ADD', 'Add', 'Add a new UV layer with the supplied from all objects'),
        ('SET_ACTIVE', 'Set', 'Set active UV layer with the supplied from all objects'),
        ('CYCLE_ACTIVE_NEXT', 'Next UV',
         'Set active UV layer to the next in the list'),
        ('CYCLE_ACTIVE_PREV', 'Previous UV',
         'Set active UV layer to the previous in the list'),
        ('REMOVE', 'Remove',
         'Remove the a UV layer with the supplied name from all objects'),
        ('RENAME', 'Rename',
         'Rename the a UV layer with the supplied name from all objects'),
        ('SELECT', 'Select', 'Select only the objects that have the supplied UV layer'),
        ('DESELECT', 'Deselect',
         'Deselect all objects that have the supplied UV layer'),
    ), name='Operation', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    @classmethod
    def description(cls, context, properties):

        if properties.operation == 'GUARANTEE':
            return F"Guarantee that UV Layer {properties.affect_uv_layer_name} is on all selected objects, {properties.tooltip}"

        if properties.operation == 'MATCH_ORDER':
            return F"Reorder UV layers of all selected objects to match {context.active_object.data.name} UV layers"

        if properties.operation == 'ADD':
            return "Add new UV Layer, won't add the layer if the layer already exists"

        if properties.operation == 'REMOVE':
            return F"Remove UV layer {properties.affect_uv_layer_name}"

        if properties.operation == 'RENAME':
            return F"Rename {properties.affect_uv_layer_name}"

        if properties.operation == 'SET_ACTIVE':
            return F"Set {properties.affect_uv_layer_name} as active layer for all objects that have it"

        if properties.operation == 'SELECT':
            return F"Select only the objects that have UV layer {properties.affect_uv_layer_name}"

        if properties.operation == 'DESELECT':
            return F"Deselect all objects that have UV layer {properties.affect_uv_layer_name}"

        return "Manage UV maps across objects in the selection"

    def execute(self, context):

        def is_valid(ob):
            return ob.data is not None and ob.data.uv_layers.active is not None

        if self.operation == 'MATCH_ORDER':

            selected = [
                sel for sel in context.selected_objects if is_valid(sel)]
            act = context.active_object
            uv_names = act.data.uv_layers.keys().copy()

            for sel in selected:
                for uv in uv_names:

                    # select all that have the uv layer
                    context.view_layer.objects.active = sel
                    act_uv = sel.data.uv_layers.active.name
                    move_to_bottom(context, uv)
                    make_active(context, act_uv)

            context.view_layer.objects.active = act

        else:

            act = context.active_object
            idx = act.data.uv_layers.active_index

            layer_name = self.affect_uv_layer_name

            if self.operation == 'CYCLE_ACTIVE_NEXT':
                idx = loop_int(idx + 1, len(act.data.uv_layers))
                layer_name = act.data.uv_layers[idx].name

                for window in context.window_manager.windows:
                    for area in window.screen.areas:
                        area.tag_redraw()

            elif self.operation == 'CYCLE_ACTIVE_PREV':
                idx = loop_int(idx - 1, len(act.data.uv_layers))
                layer_name = act.data.uv_layers[idx].name

                for window in context.window_manager.windows:
                    for area in window.screen.areas:
                        area.tag_redraw()

            for sel in context.selected_objects:

                if sel.data is None or sel.type != 'MESH':
                    continue

                uv_layers = sel.data.uv_layers

                if self.operation in ('CYCLE_ACTIVE_NEXT', 'CYCLE_ACTIVE_PREV') and layer_name in uv_layers:
                    uv_layers.active_index = uv_layers.find(
                        layer_name)

                if self.operation == 'GUARANTEE' and layer_name not in uv_layers:
                    uv = uv_layers.new(name=layer_name)
                    uv_layers.active = uv

                if self.operation == 'ADD' and self.new_uv_layer_name not in uv_layers:
                    uv = uv_layers.new(name=self.new_uv_layer_name)
                    print(layer_name)
                    uv_layers.active = uv

                if self.operation == 'REMOVE' and layer_name in uv_layers:
                    uv_layers.remove(uv_layers[layer_name])

                if self.operation == 'RENAME' and layer_name in uv_layers:
                    uv_layers[layer_name].name = self.new_uv_layer_name

                if self.operation == 'SET_ACTIVE' and layer_name in uv_layers:
                    uv_layers.active_index = uv_layers.find(
                        layer_name)

                if self.operation == 'SELECT' and layer_name not in uv_layers:
                    sel.select_set(False)

                if self.operation == 'DESELECT' and layer_name in uv_layers:
                    sel.select_set(False)

            if context.active_object not in context.selected_objects and len(context.selected_objects) > 0:
                context.view_layer.objects.active = context.selected_objects[0]

        return {'FINISHED'}

    def invoke(self, context, event):

        if self.operation == 'ADD' or self.operation == 'RENAME':
            return context.window_manager.invoke_props_dialog(self)

        return self.execute(context)
