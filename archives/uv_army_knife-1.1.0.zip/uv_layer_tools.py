# wahooney_palette_map.py Copyright (C) 2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
from bpy.types import Operator


def sort_layers(mesh, layer_names):

    layers = mesh.uv_layers

    if len(layers) < 2:
        return

    act_name = layers.active.name

    for name in layer_names:
        if name in layers:
            layers.active = layers[name]
            layers.active.name = F'UVAK_TEMP_NAME_{layers.active.name}_{layers.active_index}'
            layers.new(name=name, do_init=True)
            layers.remove(layers.active)

    layers.active = layers[act_name]


class MESH_OT_uvak_move_layer_up(Operator):

    bl_idname = "mesh.uvak_move_layer_up"
    bl_label = "Move UV Up"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if context.active_object is None:
            return False

        act = context.active_object
        return act.type == 'MESH' and act.data.uv_layers.active_index > 0

    def execute(self, context):

        completed = []

        for obj in context.selected_objects:

            if obj.type != 'MESH' or obj.data in completed:
                continue

            mesh = obj.data
            completed.append(mesh)
            layers = mesh.uv_layers

            if len(layers) < 2 or layers.active_index <= 0:
                continue

            name = layers.active.name
            names = [uv.name for uv in layers]

            idx = layers.active_index
            del names[idx]
            names.insert(idx-1, name)

            sort_layers(mesh, names)

        return {'FINISHED'}


class MESH_OT_uvak_move_layer_down(Operator):

    bl_idname = "mesh.uvak_move_layer_down"
    bl_label = "Move UV Down"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if context.active_object is None:
            return False

        act = context.active_object
        return act.type == 'MESH' and act.data.uv_layers.active_index < len(act.data.uv_layers) - 1

    def execute(self, context):

        completed = []

        for obj in context.selected_objects:

            if obj.type != 'MESH' or obj.data in completed:
                continue

            mesh = obj.data
            completed.append(mesh)
            layers = mesh.uv_layers

            if len(layers) < 2 or layers.active_index >= len(layers) - 1:
                continue

            name = layers.active.name
            names = [uv.name for uv in layers]

            idx = layers.active_index
            del names[idx]
            names.insert(idx + 1, name)

            sort_layers(mesh, names)

        return {'FINISHED'}


class MESH_OT_uvak_sort_ascending(Operator):

    bl_idname = 'mesh.uvak_sort_ascending'
    bl_label = 'Sort Ascending'
    bl_description = "Sorting UV layers by name ascending"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):

        if context.active_object is None:
            return False

        act = context.active_object
        return act.type == 'MESH' and len(act.data.uv_layers) > 1

    def execute(self, context):

        completed = []
        for obj in context.selected_objects:

            if obj.type != 'MESH' or obj.data in completed:
                continue

            mesh = obj.data
            completed.append(mesh)
            layers = mesh.uv_layers

            if len(layers) < 2:
                continue

            names = [uv.name for uv in layers]
            names.sort()

            sort_layers(mesh, names)

        return {"FINISHED"}


class MESH_OT_uvak_sort_descending(Operator):

    bl_idname = 'mesh.uvak_sort_descending'
    bl_label = 'Sort Descending'
    bl_description = "Sorting UV layers by name descending"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):

        if context.active_object is None:
            return False

        act = context.active_object
        return act.type == 'MESH' and len(act.data.uv_layers) > 1

    def execute(self, context):

        completed = []
        for obj in context.selected_objects:

            if obj.type != 'MESH' or obj.data in completed:
                continue

            mesh = obj.data
            completed.append(mesh)
            layers = mesh.uv_layers

            if len(layers) < 2:
                continue

            names = [uv.name for uv in layers]
            names.sort()
            names.reverse()

            sort_layers(mesh, names)

        return {"FINISHED"}


class MESH_OT_uvak_match_active_order(Operator):

    bl_idname = 'mesh.uvak_match_active_order'
    bl_label = 'Match Active UV Layer Order'
    bl_description = "Reorders the uv layers of selected objects to match the active object's uv layer order. "\
                     "Non-matching layers on the selected objects will be moved to the end."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):

        if context.active_object is None:
            return False

        act = context.active_object
        return act.type == 'MESH' and len(act.data.uv_layers) > 1 and len(context.selected_objects) > 1

    def execute(self, context):

        act = context.active_object
        names = [uv.name for uv in act.data.uv_layers]

        completed = []
        for obj in context.selected_objects:

            if obj.type != 'MESH' or obj.data in completed:
                continue

            mesh = obj.data
            completed.append(mesh)
            local_names = [
                uv.name for uv in act.data.uv_layers if uv.name not in names]

            sort_layers(mesh, names + local_names)

            if act.data.uv_layers.active.name in mesh.uv_layers:
                mesh.uv_layers.active = mesh.uv_layers[act.data.uv_layers.active.name]

        return {"FINISHED"}


def uvak_tools(self, context):

    layout = self.layout
    layout.label(text="UV Army Knife")

    row = layout.row()

    col = row.column(align=True)
    col.operator(MESH_OT_uvak_move_layer_up.bl_idname, icon='TRIA_UP')
    col.operator(MESH_OT_uvak_move_layer_down.bl_idname, icon='TRIA_DOWN')

    layout.separator()

    col = row.column(align=True)
    col.operator(MESH_OT_uvak_sort_ascending.bl_idname,
                 text='Asc', icon='SORT_ASC')
    col.operator(MESH_OT_uvak_sort_descending.bl_idname,
                 text='Desc', icon='SORT_DESC')

    if len(context.selected_objects) > 1:
        layout.operator(MESH_OT_uvak_match_active_order.bl_idname,
                        icon='UV_SYNC_SELECT')


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        # image editor
        km = kc.keymaps.new(
            name="Image", space_type='IMAGE_EDITOR', region_type='WINDOW', modal=False)

        # forward cycle uv (image editor)
        kmi = km.keymap_items.new(
            "uv.manage_multiple_uvs_by_name", 'WHEELUPMOUSE', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.operation = 'CYCLE_ACTIVE_NEXT'

        # back cycle uv (image editor)
        kmi = km.keymap_items.new(
            "uv.manage_multiple_uvs_by_name", 'WHEELDOWNMOUSE', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.operation = 'CYCLE_ACTIVE_PREV'

        addon_keymaps.append(km)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            for kmi in km.keymap_items:
                km.keymap_items.remove(kmi)

            if km.name in wm.keyconfigs.addon.keymaps and len(km.keymap_items) == 0:
                wm.keyconfigs.addon.keymaps.remove(km)

    # clear the list
    del addon_keymaps[:]
