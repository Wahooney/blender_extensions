# wahooney_uv_army_knife.py Copyright (C) 2021, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
import bmesh
from bpy_extras import bmesh_utils
from mathutils import Vector


def calculate_uv_area(face, uv_layer):
    uv_area = 0.0
    for loop in face.loops:
        uv_area += loop[uv_layer].uv.x * loop.link_loop_next[uv_layer].uv.y - \
            loop[uv_layer].uv.y * loop.link_loop_next[uv_layer].uv.x
    uv_area = abs(uv_area) * 0.5
    return uv_area


def calculate_uv_center(face, uv_layer):
    center = Vector((0, 0))
    for loop in face.loops:
        center += loop[uv_layer].uv
    return center / len(face.loops)


def face_selected(f, uv_layer, sync):

    if sync:
        return f.select and not f.hide

    selected = False

    for l in f.loops:
        if l[uv_layer].select:
            selected = True
            break

    return f.select and not f.hide and selected


def calculate_scale_factor(area_unselected_face_3D, area_selected_face_3D, area_selected_uv, area_unselected_uv):

    # Calculate the average UV to 3D area ratio for unselected faces
    avg_ratio_unselected = area_unselected_uv / area_unselected_face_3D

    # Calculate the target UV area for selected faces
    target_area_selected_uv = avg_ratio_unselected * area_selected_face_3D

    # Calculate the scale factor
    scale_factor = (target_area_selected_uv / area_selected_uv) ** 0.5

    return scale_factor


class UV_OT_IslandFromSelection(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "uv.island_from_selection"
    bl_label = "Island From Selection"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        obj = context.active_object
        sync = context.scene.tool_settings.use_uv_select_sync

        bm = bmesh.from_edit_mesh(obj.data)

        for e in bm.edges:

            faces = e.link_faces

            if len(faces) == 0:
                continue

            boundary = 0
            selected = 0
            num = len(faces)

            for f in faces:

                if f.select:
                    boundary += 1
                    selected += 1
                else:
                    boundary -= 1

            seam = False

            if selected > 0:

                if (num == 1 and boundary > 0) or (num > 1 and boundary == 0):
                    seam = True

                e.seam = seam

        # get average center
        center = Vector((0, 0))
        count = 0
        uv_layer = bm.loops.layers.uv.verify()

        for f in bm.faces:
            if face_selected(f, uv_layer, sync):
                center += calculate_uv_center(f, uv_layer)
                count += 1

        bmesh.update_edit_mesh(obj.data)

        if count > 0:
            center /= count

            bpy.ops.uv.unwrap(method='CONFORMAL')
            bpy.ops.uv.average_selected_island_scale(
                custom_center=True, center=center)

        '''# we will scale the selected island to match the average scale of the unselected islands
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sync = context.scene.tool_settings.use_uv_select_sync

        selected_uv_area = 0
        selected_area = 0
        unselected_uv_area = 0
        unselected_area = 0

        # calculate the selected island areas
        for f in bm.faces:
            if face_selected(f, uv_layer, sync):
                selected_uv_area += calculate_uv_area(f, uv_layer)
                selected_area += f.calc_area()
            else:
                unselected_uv_area += calculate_uv_area(f, uv_layer)
                unselected_area += f.calc_area()

        if unselected_area >= 0 and selected_area > 0:

            ratio = calculate_scale_factor(unselected_area, selected_area, selected_uv_area, unselected_uv_area)

            for f in bm.faces:
                if face_selected(f, uv_layer, sync):
                    for l in f.loops:
                        l[uv_layer].uv = center + (l[uv_layer].uv - center) * ratio

        bmesh.update_edit_mesh(obj.data)'''

        return {'FINISHED'}


class UV_OT_AverageSelectedIslandScale(bpy.types.Operator):
    """Scales the selected island so it's scale matches the average scale of the unselected islands"""
    bl_idname = "uv.average_selected_island_scale"
    bl_label = "Average Selected Island Scale"

    custom_center: bpy.props.BoolProperty(
        name="Custom Center", default=False, options={'HIDDEN'})

    center: bpy.props.FloatVectorProperty(
        name="Center", size=2, default=(0, 0), options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        obj = context.active_object
        sync = context.scene.tool_settings.use_uv_select_sync

        bpy.ops.uv.average_islands_scale()

        bm = bmesh.from_edit_mesh(obj.data)

        # get average center
        center = Vector((0, 0))
        count = 0
        uv_layer = bm.loops.layers.uv.verify()

        islands = bmesh_utils.bmesh_linked_uv_islands(bm, uv_layer)

        centers = {}
        off_centers = {}

        for i, island in enumerate(islands):

            center = Vector((0, 0))
            count = 0

            for f in island:
                if face_selected(f, uv_layer, sync):
                    center += calculate_uv_center(f, uv_layer)
                    count += 1

            if count > 0:
                if self.custom_center:
                    centers[i] = Vector(self.center)
                else:
                    centers[i] = center / count

                off_centers[i] = center / count

        # we will scale the selected island to match the average scale of the unselected islands
        uv_layer = bm.loops.layers.uv.verify()

        selected_uv_area = 0
        selected_area = 0
        unselected_uv_area = 0
        unselected_area = 0

        # calculate the selected island areas
        for f in bm.faces:

            if face_selected(f, uv_layer, sync):

                selected_uv_area += calculate_uv_area(f, uv_layer)
                selected_area += f.calc_area()

            else:

                unselected_uv_area += calculate_uv_area(f, uv_layer)
                unselected_area += f.calc_area()

        if unselected_area >= 0 and selected_area > 0:

            ratio = calculate_scale_factor(
                unselected_area, selected_area, selected_uv_area, unselected_uv_area)

            for i, island in enumerate(islands):

                if i not in centers:
                    continue

                center = centers[i]
                off_center = off_centers[i]

                for f in island:
                    if face_selected(f, uv_layer, sync):
                        for l in f.loops:
                            l[uv_layer].uv = center + \
                                (l[uv_layer].uv - off_center) * ratio

            # for f in bm.faces:
            #     if face_selected(f, uv_layer, sync):
            #         for l in f.loops:
            #             l[uv_layer].uv = center + (l[uv_layer].uv - center) * ratio

        bmesh.update_edit_mesh(obj.data)

        return {'FINISHED'}


class UV_OT_AverageSelectedIslandBounds(bpy.types.Operator):
    """Scales the selected islands' bounds so it matches the average bounds of all selected islands"""
    bl_idname = "uv.average_selected_island_bounds"
    bl_label = "Average Selected Island Bounds"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):

        objs = [sel for sel in context.selected_objects if sel.type == 'MESH']
        bms = [bmesh.from_edit_mesh(obj.data)
               for obj in objs if obj.type == 'MESH']

        bounds = {}
        valid_islands = {}

        average = Vector((0, 0))

        count = 0

        # calculate bounds
        for bm in bms:

            uv_layer = bm.loops.layers.uv.verify()
            islands = bmesh_utils.bmesh_linked_uv_islands(bm, uv_layer)

            bounds[bm] = []
            valid_islands[bm] = []

            for i, island in enumerate(islands):

                min_x = 1000000
                min_y = 1000000
                max_x = -1000000
                max_y = -1000000

                selected = 0

                for f in island:
                    if island[0].select:
                        selected += 1

                if selected == 0:
                    continue

                for f in island:

                    for loop in f.loops:

                        min_x = min(loop[uv_layer].uv[0], min_x)
                        min_y = min(loop[uv_layer].uv[1], min_y)
                        max_x = max(loop[uv_layer].uv[0], max_x)
                        max_y = max(loop[uv_layer].uv[1], max_y)

                count += 1
                bounds[bm].append(
                    (min_x, min_y, max_x, max_y, max_x - min_x, max_y - min_y))
                valid_islands[bm].append(island)

                average.x += max_x - min_x
                average.y += max_y - min_y

        # average island bounds
        average.x /= count
        average.y /= count

        # scale bounds
        for idx, bm in enumerate(bms):

            uv_layer = bm.loops.layers.uv.verify()

            for i, island in enumerate(valid_islands[bm]):

                bound = bounds[bm][i]
                min_x, min_y, max_x, max_y, size_x, size_y = bound
                center = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5))

                for f in island:

                    for loop in f.loops:

                        uv = loop[uv_layer].uv
                        uv[0] = ((uv.x - center.x) /
                                 size_x * average.x) + center.x
                        uv[1] = ((uv.y - center.y) /
                                 size_y * average.y) + center.y
                        loop[uv_layer].uv = uv

            bmesh.update_edit_mesh(objs[idx].data)

        return {'FINISHED'}


def menu_func_island_from_selection(self, context):
    self.layout.operator(UV_OT_IslandFromSelection.bl_idname,
                         text=UV_OT_IslandFromSelection.bl_label)
    self.layout.operator(UV_OT_AverageSelectedIslandBounds.bl_idname,
                         text=UV_OT_AverageSelectedIslandBounds.bl_label)
