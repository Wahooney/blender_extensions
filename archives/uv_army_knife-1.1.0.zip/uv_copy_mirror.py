# copy_mirror_uvs.py Copyright (C) 2009-2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bmesh
import bpy
from bpy.props import *

# function checks if two vectors are similar, within an error threshold


def vec_similar(v1, v2, error):
    return abs(v2.x - v1.x) < error and abs(v2.y - v1.y) < error and abs(v2.z - v1.z) < error

# copy uv coordinates from one uv face to another


def copy_uvs(uv_layer, src, dst, x_off, y_off, axis, error):

    # cycle through the source vertices
    for vs, loop_src in enumerate(src.loops):

        uvs = loop_src[uv_layer]
        co = src.verts[vs].co.copy()

        # cycle through the destination vertices
        for vd, loop_dst in enumerate(dst.loops):

            uvd = loop_dst[uv_layer]
            coo = dst.verts[vd].co.copy()

            if axis == 'X':
                coo.x = -coo.x
            elif axis == 'Y':
                coo.y = -coo.y
            elif axis == 'Z':
                coo.z = -coo.z

            # find the vertex that is on the axis-mirror side of the object and assign the uv's to it
            if vec_similar(co, coo, error):
                uvd.uv.x = uvs.uv.x + x_off
                uvd.uv.y = uvs.uv.y + y_off


class UV_OT_CopyMirrorUVs(bpy.types.Operator):
    '''Copy UVs from the mirrored side of the selected faces'''

    bl_idname = "uv.copy_mirror_uvs"
    bl_label = "Copy UVs from Mirror"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(items=(
        ('X', "X", "Mirror Along X axis"),
        ('Y', "Y", "Mirror Along Y axis"),
        ('Z', "Z", "Mirror Along Z axis")),
        name="Axis",
        description="Mirror Axis",
        default='X')

    error: FloatProperty(name="Error", description="Error threshold",
                         default=0.001,
                         min=0.0,
                         max=100.0,
                         soft_min=0.0,
                         soft_max=1.0)

    x_offset: FloatProperty(name="X Position",
                            description="Offset UV on the X axis",
                            default=0.0,
                            min=-100.0,
                            max=100.0,
                            soft_min=-1.0,
                            soft_max=1.0)

    y_offset: FloatProperty(name="Y Offset",
                            description="Offset UV on the Y axis",
                            default=0.0,
                            min=-100.0,
                            max=100.0,
                            soft_min=-1.0,
                            soft_max=1.0)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH')

    def execute(self, context):

        obj = context.active_object
        mesh = obj.data

        bm = bmesh.from_edit_mesh(mesh)

        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        error = self.properties.error
        axis = self.properties.axis

        x_off = self.properties.x_offset
        y_off = self.properties.y_offset

        uv_layer = bm.loops.layers.uv.active

        for face_dst in bm.faces:
            if not face_dst.select:
                continue

            for loop in face_dst.loops:

                uv = loop[uv_layer]

                if not uv.select:
                    continue

                count = len(face_dst.verts)

                for face_src in bm.faces:
                    if face_src.index == face_dst.index:
                        continue

                    if count != len(face_src.verts):
                        continue

                    dst = face_dst.calc_center_median()
                    src = face_src.calc_center_median()

                    # test if the vertices x values are the same sign, continue if they are
                    if (dst.x > 0 and src.x > 0) or (dst.x < 0 and src < 0):
                        continue

                    # axis invert source
                    if axis == 'X':
                        src.x = -src.x
                    elif axis == 'Y':
                        src.y = -src.z
                    elif axis == 'Z':
                        src.z = -src.z

                    if vec_similar(dst, src, error):
                        copy_uvs(uv_layer, face_src, face_dst,
                                 x_off, y_off, axis, error)

        bmesh.update_edit_mesh(mesh)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        props = self.properties

        col = layout.column()

        col.prop(props, "axis")

        col2 = col.column(align=True)
        col2.label(text="Offset")
        col2.prop(props, "x_offset")
        col2.prop(props, "y_offset")

        col.prop(props, "error", slider=True)


def menu_func(self, context):

    self.layout.operator(UV_OT_CopyMirrorUVs.bl_idname)
