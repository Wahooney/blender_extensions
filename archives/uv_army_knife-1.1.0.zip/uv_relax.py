# uv_relax.py Copyright (C) 2022-2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
import bmesh
from mathutils import Vector
from bpy.props import BoolProperty, IntProperty, FloatProperty


class UV_OT_RelaxUv(bpy.types.Operator):

    """Relax UVs"""

    bl_idname = "uv.relax_uvs"
    bl_label = "Relax UVs"
    bl_options = {'REGISTER', 'UNDO'}

    connect_uvs: BoolProperty(name="Connect UVs",
                              description='Connects disjointed UVs into a single point',
                              default=True)

    iterations: IntProperty(name="Iterations",
                            description='Number of times to run the relax function',
                            min=1, max=100, default=1)

    factor: FloatProperty(name="Factor",
                          description='Strength of the relax function',
                          min=-1, max=1, default=0.5)

    tighten: BoolProperty(name="Tighten UVs",
                          description='Relaxes and counter relaxes the UVs, keeping more of the original UVs while still smoothing the result',
                          default=False)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):

        me = context.active_object.data
        bm = bmesh.from_edit_mesh(me)

        uv_layer = bm.loops.layers.uv.verify()

        sync = context.scene.tool_settings.use_uv_select_sync

        # Accumulate uv data
        uv_loops = []
        connect = []

        for vert in bm.verts:
            loops = []
            connected = []

            if vert.select:
                for ed in vert.link_edges:
                    other = None

                    if ed.verts[0] == vert:
                        other = ed.verts[1]
                    elif ed.verts[1] == vert:
                        other = ed.verts[0]

                    for face in other.link_faces:

                        if not face.select and not sync:
                            continue

                        for loop in face.loops:
                            loop_uv = loop[uv_layer]

                            if loop.vert.index == other.index:
                                connected.append(loop_uv)

                            if loop.vert.index == vert.index:
                                connected.append(loop_uv)

                for face in vert.link_faces:

                    if not face.select and not sync:
                        continue

                    for loop in face.loops:
                        loop_uv = loop[uv_layer]

                        # and loop_uv.select:
                        if loop.vert.index == vert.index:
                            loops.append(loop_uv)

                if len(connected) > 0 and len(loops) > 0:
                    connect.append(connected)
                    uv_loops.append(loops)

        # Combine UVs
        if self.properties.connect_uvs:
            for batch in uv_loops:

                uv = Vector((0, 0))
                for loops in batch:
                    uv += loops.uv

                uv /= len(batch)

                for loops in batch:
                    if loops.select:
                        loops.uv = uv

        iterations = self.properties.iterations
        factor = self.properties.factor
        tighten = self.properties.tighten

        # Relax
        for _ in range(iterations):
            relaxed_uv = []
            for i, batch in enumerate(uv_loops):

                connected = connect[i]
                avg = Vector((0, 0))

                for c in connected:
                    avg += c.uv

                avg /= len(connected)

                relaxed_uv.append(avg)

            for i, batch in enumerate(uv_loops):
                for loops in batch:
                    if loops.select or sync:
                        loops.uv = Vector.lerp(loops.uv, relaxed_uv[i], factor)
                        if tighten:
                            loops.uv = Vector.lerp(
                                loops.uv, relaxed_uv[i], -factor)

        bmesh.update_edit_mesh(me)

        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator(UV_OT_RelaxUv.bl_idname, text="Relax UVs")

