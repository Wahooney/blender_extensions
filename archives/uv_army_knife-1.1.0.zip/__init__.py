# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from bpy.props import BoolProperty

bl_info = {
    "name": "Uv Army Knife",
    "author": "Keith 'Wahooney' Boshoff",
    "description": "A collection of UV tools",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Generic"
}

if "bpy" in locals():

    import importlib

    importlib.reload(uv_cycle_images)
    importlib.reload(uv_copy_mirror)
    importlib.reload(uv_layer_tools)
    importlib.reload(uv_quad_unwrap)
    importlib.reload(uv_multi_ops)
    importlib.reload(uv_normalize)
    importlib.reload(uv_islands)
    importlib.reload(uv_relax)
    importlib.reload(uv_panels)

else:

    import bpy

    from . import uv_cycle_images
    from . import uv_copy_mirror
    from . import uv_layer_tools
    from . import uv_quad_unwrap
    from . import uv_multi_ops
    from . import uv_normalize
    from . import uv_islands
    from . import uv_relax
    from . import uv_panels


classes = [
    uv_normalize.UV_OT_NormalizeUV,
    uv_copy_mirror.UV_OT_CopyMirrorUVs,

    uv_layer_tools.MESH_OT_uvak_match_active_order,
    uv_layer_tools.MESH_OT_uvak_move_layer_up,
    uv_layer_tools.MESH_OT_uvak_move_layer_down,
    uv_layer_tools.MESH_OT_uvak_sort_ascending,
    uv_layer_tools.MESH_OT_uvak_sort_descending,

    uv_quad_unwrap.UV_OT_QuadUnwrap,
    uv_cycle_images.UV_OT_CycleUVImages,
    uv_multi_ops.UV_OT_ManageMultipleUVs,
    uv_relax.UV_OT_RelaxUv,
    uv_islands.UV_OT_IslandFromSelection,
    uv_islands.UV_OT_AverageSelectedIslandBounds,
    uv_islands.UV_OT_AverageSelectedIslandScale,

    # panels
    uv_panels.IMAGE_PT_WahooneyUVTools,
]


menu_funcs = [
    (bpy.types.VIEW3D_MT_object, uv_islands.menu_func_island_from_selection),
    (bpy.types.VIEW3D_MT_object, uv_relax.menu_func),
    (bpy.types.VIEW3D_MT_object, uv_copy_mirror.menu_func),
    (bpy.types.DATA_PT_uv_texture, uv_layer_tools.uvak_tools)
]


def register():

    bpy.types.Scene.show_uv_objects = BoolProperty(
        name="Show UV Objects",
        default=False, options={'SKIP_SAVE'})

    bpy.types.Scene.show_uv_objects_inv = BoolProperty(
        name="Invert Shown UV Objects",
        default=False, options={'SKIP_SAVE'})

    for c in classes:
        bpy.utils.register_class(c)

    uv_quad_unwrap.register_keymaps()
    uv_cycle_images.register_keymaps()
    uv_layer_tools.register_keymaps()
    uv_normalize.register_keymaps()

    for menu, func in menu_funcs:
        menu.append(func)


def unregister():

    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        finally:
            pass

    uv_quad_unwrap.unregister_keymaps()
    uv_cycle_images.unregister_keymaps()
    uv_layer_tools.unregister_keymaps()
    uv_normalize.unregister_keymaps()

    for menu, func in menu_funcs:
        menu.remove(func)
