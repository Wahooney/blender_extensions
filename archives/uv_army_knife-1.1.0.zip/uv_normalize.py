# uv_normalize.py Copyright (C) 2009-2024, Keith 'Wahooney' Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****


import bpy
import bmesh
from bpy.props import *
from mathutils import Vector
from bpy_extras import bmesh_utils


class UV_OT_NormalizeUV(bpy.types.Operator):
    '''Stretch the selected UVs across the whole UV space'''

    bl_idname = 'uv.normalize_uvs'
    bl_label = 'Normalize UVs'
    bl_options = {'REGISTER', 'UNDO'}

    auto_fit_x: BoolProperty(name='Auto-Fit X',
                             description='Automatically fit the vertices into U space',
                             default=True)

    auto_fit_y: BoolProperty(name='Auto-Fit Y',
                             description='Automatically fit the vertices into V space',
                             default=True)

    axis: EnumProperty(items=(
        ('AUTO', 'Best-Fit', 'Scaled by the largest axis'),
        ('XY', 'Fit X & Y', 'Both axis are affected'),
        ('X', 'Fit X', 'X is normalized, y is scaled proportionally'),
        ('Y', 'Fit Y', 'Y is normalized, x is scaled proportionally')),
        name='Axis',
        description='Fit Axis',
        default='AUTO')

    x_size: FloatProperty(name='X Size', description='Total X Size',
                          default=1.0,
                          min=0.0,
                          max=100,
                          soft_min=0.0,
                          soft_max=1.0)

    y_size: FloatProperty(name='Y Size', description='Total Y Size',
                          default=1.0,
                          min=0.0,
                          max=100,
                          soft_min=0.0,
                          soft_max=1.0)

    lock_size: BoolProperty(name='Lock Size',
                            description='Lock X and Y Size',
                            default=True)

    x_position: FloatProperty(name='X Position',
                              description='Proportional position on the X axis',
                              default=0.0,
                              min=-100.0,
                              max=100.0,
                              soft_min=0.0,
                              soft_max=1.0)

    y_position: FloatProperty(name='Y Position',
                              description='Proportional position on the Y axis',
                              default=0.0,
                              min=-100.0,
                              max=100.0,
                              soft_min=0.0,
                              soft_max=1.0)

    padding: FloatProperty(name='Padding',
                           description='Edge padding',
                           default=0.0,
                           min=0.0,
                           max=0.5,
                           soft_min=0.0,
                           soft_max=0.05)

    whole_islands: BoolProperty(name='Whole Island',
                                description='Affects the Whole Island even if only partially selected',
                                default=True)

    include_unselected: BoolProperty(name='Include unselected',
                                     description='Scales and positions unselected uv vertices, selected vertices are used to determine ranges.',
                                     default=False)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH')

    def execute(self, context):

        # get properties
        axis = self.properties.axis

        x_size = self.properties.x_size
        y_size = self.properties.y_size

        padding = self.properties.padding

        auto_fit_x = self.properties.auto_fit_x
        auto_fit_y = self.properties.auto_fit_y

        whole_islands = self.properties.whole_islands
        include_unselected = self.properties.include_unselected

        if self.properties.lock_size:
            y_size = x_size

        x_position = self.properties.x_position
        y_position = self.properties.y_position

        # get mesh data and bmeshes

        meshes = {}

        for obj in context.selected_objects:

            if obj.type != 'MESH':
                continue

            mesh = obj.data

            bm = bmesh.from_edit_mesh(mesh)

            if not mesh.uv_layers.active:
                bpy.ops.mesh.uv_texture_add()

            meshes[obj] = (mesh, bm)

        # get min/max uvs
        min_uv = Vector((10000, 10000))
        max_uv = Vector((-10000, -10000))

        for obj, (mesh, bm) in meshes.items():

            uv_layer = bm.loops.layers.uv.verify()

            for face in bm.faces:
                if not face.select:
                    continue

                for loop in face.loops:

                    uv = loop[uv_layer]

                    if not uv.select:  # and not uv.invisible:
                        continue

                    # find the absolutes
                    if uv.uv.x < min_uv.x:
                        min_uv.x = uv.uv.x

                    if uv.uv.y < min_uv.y:
                        min_uv.y = uv.uv.y

                    if uv.uv.x > max_uv.x:
                        max_uv.x = uv.uv.x

                    if uv.uv.y > max_uv.y:
                        max_uv.y = uv.uv.y

        # get uv bottom/left offsets
        off_x = min_uv.x
        off_y = min_uv.y

        # initialize multipliers to 0, helps catch divisions by zero
        mult_x = 1.0
        mult_y = 1.0

        if auto_fit_x:
            # get multiplier to fit uvs into 0.0 - 1.0 space
            if (max_uv.x - min_uv.x) != 0:
                mult_x = 1.0 / (max_uv.x - min_uv.x)

        if auto_fit_y:
            if (max_uv.y - min_uv.y) != 0:
                mult_y = 1.0 / (max_uv.y - min_uv.y)

        # if an axis range is zero, use the other range
        if mult_x == 0 or mult_y == 0:
            if mult_y == 0:
                mult_y = mult_x
            elif mult_x == 0:
                mult_x = mult_y

        # if both ranges are zero there is nothing to do
        if mult_x == 0 and mult_y == 0:
            return {'CANCELLED'}

        # copy multiplier from one to the other, based on axis restrictions
        elif auto_fit_x and auto_fit_y:
            if axis == 'AUTO':
                if mult_x <= mult_y:
                    mult_y = mult_x
                else:
                    mult_x = mult_y
            elif axis == 'X':
                mult_y = mult_x
            elif axis == 'Y':
                mult_x = mult_y

        mult_x = mult_x * x_size
        mult_y = mult_y * y_size

        # get remaining space (for positioning)
        sx = 1.0 - (max_uv.x - min_uv.x) * mult_x
        sy = 1.0 - (max_uv.y - min_uv.y) * mult_y

        # get padding inverse scaling
        pad_mult = 1.0 - padding * 2

        islands = {}

        # check if we need to operate on whole islands if partially selected
        if whole_islands:

            for obj, (mesh, bm) in meshes.items():
                uv_layer = bm.loops.layers.uv.verify()

                # get the islands
                uv_islands = bmesh_utils.bmesh_linked_uv_islands(bm, uv_layer)

                print(f"Found {len(uv_islands)}")

                mesh_islands = []

                for island in uv_islands:
                    for face in island:
                        if face.select:
                            print(f"Found 1")
                            mesh_islands.extend(island)
                            break

            if len(mesh_islands) > 0:
                print(f"Found {len(mesh_islands)} island faces")
                islands[obj] = mesh_islands

        for obj, (mesh, bm) in meshes.items():

            uv_layer = bm.loops.layers.uv.verify()

            for face in bm.faces:
                if not face.select:
                    continue

                force_inclusion = False
                if obj in islands:
                    force_inclusion = face in islands[obj]

                for loop in face.loops:
                    uv = loop[uv_layer]

                    if uv.select or include_unselected or force_inclusion:

                        # apply the location of the vertex as a UV
                        loop[uv_layer].uv.x = padding + \
                            ((loop[uv_layer].uv.x - off_x) *
                             mult_x + sx * x_position) * pad_mult
                        loop[uv_layer].uv.y = padding + \
                            ((loop[uv_layer].uv.y - off_y) *
                             mult_y + sy * y_position) * pad_mult

            bmesh.update_edit_mesh(mesh)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        props = self.properties

        layout.label(text='Auto-Fit')

        row = layout.row()

        row.prop(props, 'auto_fit_x', text='Auto X')
        row.prop(props, 'auto_fit_y', text='Auto Y')

        if props.auto_fit_x and props.auto_fit_y:
            layout.prop(props, 'axis', expand=True)

        row = layout.row()
        row.prop(props, 'whole_islands', toggle=True)
        row.prop(props, 'include_unselected', toggle=True)

        row = layout.row()

        col = row.column(align=True)
        col.label(text='Size')

        if (self.properties.lock_size):
            col.prop(props, 'x_size', text='Size')
        else:
            col.prop(props, 'x_size')
            col.prop(props, 'y_size')

        col.prop(props, 'lock_size')

        col = layout.column(align=True)

        col.label(text='Position')
        col.prop(props, 'x_position')
        col.prop(props, 'y_position')

        col = layout.column()

        col.prop(props, 'padding', slider=True)


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        km = kc.keymaps.new(name='UV Editor', space_type='EMPTY',
                            region_type='WINDOW', modal=False)

        # Normalize, include unselected
        kmi = km.keymap_items.new(
            'uv.normalize_uvs', 'N', 'PRESS', ctrl=False, shift=True, alt=True)
        kmi.properties.include_unselected = True

        # Normalize, only selected
        kmi = km.keymap_items.new(
            'uv.normalize_uvs', 'N', 'PRESS', ctrl=False, shift=True, alt=False)
        kmi.properties.include_unselected = False

        addon_keymaps.append(km)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            for kmi in km.keymap_items:
                km.keymap_items.remove(kmi)

            if km.name in wm.keyconfigs.addon.keymaps and len(km.keymap_items) == 0:
                wm.keyconfigs.addon.keymaps.remove(km)

    # clear the list
    del addon_keymaps[:]
