# uv_quad_unwrap.py Copyright (C) 2015-2024, Keith "Wahooney" Boshoff
# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

from bpy.props import BoolProperty, EnumProperty
from mathutils import Vector
import bmesh
import bpy

"""
HISTORY:

1.3:
 - Blender 4.0.0 compatibility
 - Don't try to straighten an already straight quad

1.2:
 - Blender 2.8.0 compatibility

1.1:
 - Blender 2.76 compatibility

1.0:
 - Initial implementation

"""


def main(self, context):

    def is_near_zero(val, threshold=1e-5):
        return abs(val) < threshold

    def is_near_equal(val1, val2, threshold=1e-5):
        return abs(val1 - val2) < threshold

    def is_rectangle(uvs, threshold=1e-5):
        vectors = [
            uvs[1] - uvs[0],
            uvs[2] - uvs[1],
            uvs[3] - uvs[2],
            uvs[0] - uvs[3]
        ]

        for i in range(4):
            dot_product = vectors[i].dot(vectors[(i+1) % 4])
            if not is_near_zero(dot_product, threshold):
                return False

        if not (is_near_equal(vectors[0].length, vectors[2].length, threshold) and
                is_near_equal(vectors[1].length, vectors[3].length, threshold)):
            return False

        return True

    use_linked = self.properties.use_linked
    mode = self.properties.mode

    obj = context.active_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)

    uv_layer = bm.loops.layers.uv.verify()
    # bm.faces.layers.face_map.verify()

    f = bm.faces.active

    if f is None:
        self.report({'INFO'}, "Active face required.")
        return

    if len(f.loops) != 4:
        self.report({'INFO'}, "Active face must have exactly 4 vertices.")
        return

    # get uvs and average edge lengths
    orig_uv1 = f.loops[0][uv_layer]
    orig_uv2 = f.loops[1][uv_layer]
    orig_uv3 = f.loops[2][uv_layer]
    orig_uv4 = f.loops[3][uv_layer]

    length1 = ((f.verts[0].co - f.verts[1].co).length +
               (f.verts[2].co - f.verts[3].co).length) / 2

    length2 = ((f.verts[1].co - f.verts[2].co).length +
               (f.verts[3].co - f.verts[0].co).length) / 2

    orig_uvs = [orig_uv1.uv, orig_uv2.uv, orig_uv3.uv, orig_uv4.uv]

    # Try to fit into old coords
    uLength = ((orig_uv1.uv - orig_uv2.uv).length +
               (orig_uv3.uv - orig_uv4.uv).length) / 2
    vLength = ((orig_uv2.uv - orig_uv3.uv).length +
               (orig_uv4.uv - orig_uv1.uv).length) / 2

    uScale = uLength
    vScale = vLength

    # the following ensures a preferred horizontal orientation
    if length1 < length2:
        uScale = vLength * (length1 / length2)
    else:
        vScale = uLength * (length2 / length1)

    # the following will try to retain the original orientation
    center = (orig_uv1.uv + orig_uv2.uv + orig_uv3.uv + orig_uv4.uv) / 4
    uvs = [center + Vector((-uScale, -vScale)) / 2,
           center + Vector((uScale, -vScale)) / 2,
           center + Vector((uScale,  vScale)) / 2,
           center + Vector((-uScale,  vScale)) / 2]

    if is_rectangle(orig_uvs):
        pass
    else:
        orig_uv1.uv = uvs[0]
        orig_uv2.uv = uvs[1]
        orig_uv3.uv = uvs[2]
        orig_uv4.uv = uvs[3]

        bmesh.update_edit_mesh(me)

    # store selection
    selection = []

    for f in bm.faces:
        if f.select:
            selection.append(f)

    # select linked
    if use_linked:
        bpy.ops.mesh.select_linked(delimit={'SEAM'})

    # follow active quads
    bpy.ops.uv.follow_active_quads(mode=mode)

    # restore selection
    for f in bm.faces:
        f.select = False

    for f in selection:
        f.select = True


class UV_OT_QuadUnwrap (bpy.types.Operator):
    """Unwrap selection from to contiguous uniform quad layout"""
    bl_idname = "uv.quad_unwrap"
    bl_label = "Quad Unwrap"
    bl_options = {'UNDO', 'REGISTER'}

    use_linked: BoolProperty(name="Quad Linked Faces", description="Apply Quad Unwrap to linked faces",
                             default=False)

    mode: EnumProperty(items=(
        ('EVEN', 'Even', ''),
        ('LENGTH', 'Length', ''),
        ('LENGTH_AVERAGE', 'Average Length', '')),
        name="Unwrap Mode",
        description="Average length selection mode",
        default='LENGTH_AVERAGE')

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH')

    def execute(self, context):
        main(self, context)
        return {'FINISHED'}


addon_keymaps = []


def register_keymaps():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:
        # Quad unwrap - image area
        kmuv = kc.keymaps.new(
            name="UV Editor", space_type='EMPTY', region_type='WINDOW', modal=False)

        kmi = kmuv.keymap_items.new(
            "uv.quad_unwrap", 'Q', 'PRESS', ctrl=False, shift=True, alt=False)
        kmi.properties.use_linked = False

        kmi = kmuv.keymap_items.new(
            "uv.quad_unwrap", 'Q', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.use_linked = True

        addon_keymaps.append(kmuv)

        # Quad unwrap - view 3d
        km3d = kc.keymaps.new(name="Mesh")
        kmi = km3d.keymap_items.new("uv.quad_unwrap", 'Q', 'PRESS', ctrl=False, shift=True, alt=False)
        kmi.properties.use_linked = False

        kmi = km3d.keymap_items.new("uv.quad_unwrap", 'Q', 'PRESS', ctrl=True, shift=True, alt=False)
        kmi.properties.use_linked = True

        addon_keymaps.append(km3d)


def unregister_keymaps():

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            try:
                for kmi in km.keymap_items:
                    km.keymap_items.remove(kmi)

                if km.name in wm.keyconfigs.addon.keymaps and len(km.keymap_items) == 0:
                    wm.keyconfigs.addon.keymaps.remove(km)

            finally:
                pass

    # clear the list
    del addon_keymaps[:]
