import bpy


class VSE_OT_FitTimeToSelection(bpy.types.Operator):
    """Moves the time range to fit the current selection, if there is no selection, it will fit all top-level strips"""
    bl_idname = "sequencer.fit_time_to_selection"
    bl_label = "Fit Time To Selection"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.sequence_editor is not None and len(context.scene.sequence_editor.strips) > 0

    def execute(self, context):

        print("!")

        scene = context.scene
        seq_ed = scene.sequence_editor

        strips = context.selected_strips[:]

        if len(strips) == 0:
            strips = seq_ed.strips[:]

        min_t = strips[0].frame_final_start
        max_t = strips[0].frame_final_end

        for strip in strips:

            min_t = min(min_t, strip.frame_final_start)
            max_t = max(max_t, strip.frame_final_end)

        scene.frame_start = min_t
        scene.frame_end = max_t

        return {'FINISHED'}
