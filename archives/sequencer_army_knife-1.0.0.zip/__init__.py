if 'bpy' in locals():

    import importlib

    importlib.reload(bake_meta_strip)
    importlib.reload(fit_time_to_selection)

else:

    import bpy

    from . import bake_meta_strip
    from . import fit_time_to_selection


addon_keymaps = []


def register_keymap():

    kc = bpy.context.window_manager.keyconfigs.addon

    if kc:

        print("!!")
        km = kc.keymaps.new(name='Sequence Editor', space_type='SEQUENCE_EDITOR')
        kmi = km.keymap_items.new(fit_time_to_selection.VSE_OT_FitTimeToSelection.bl_idname, type='HOME', value='PRESS', ctrl=True, shift=True)
        addon_keymaps.append((km, kmi))


def unregister_keymap():

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)

    addon_keymaps.clear()


classes = [
    fit_time_to_selection.VSE_OT_FitTimeToSelection,
    bake_meta_strip.VSE_OT_BakeMetaToDisk]


def register():
    for c in classes:
        bpy.utils.register_class(c)

    register_keymap()


def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    unregister_keymap()


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.sequencer.fit_time_to_selection()
