import bpy
import os
import uuid


def get_data(target):

    state = {}

    for a in dir(target):
        state[a] = getattr(target, a)

    return state


def set_data(target, state):

    for k in state:
        try:
            setattr(target, k, state[k])
        except AttributeError:
            pass


def find_by_uuid(context, uid):

    scene = context.scene
    seq_ed = scene.sequence_editor

    for s in seq_ed.sequences_all:
        if 'UUID' in s:
            if uid == s['UUID']:
                return s

    return None


def complete_render(scene):

    scene['BAKING_STATE'] = "COMPLETE"


def cancel_render(scene):

    scene['BAKING_STATE'] = "CANCELLED"


class VSE_OT_BakeMetaToDisk(bpy.types.Operator):
    """Bake the selected meta-strip to disk"""
    bl_idname = "sequencer.bake_meta_to_disk"
    bl_label = "Bake Meta To Disk"
    bl_options = {"REGISTER", "UNDO"}

    _timer = None
    as_image = False
    active = None
    filename = ''
    reldir = ''
    filelocation = ''

    store_start = 0
    store_end = 0
    store_path = ''
    store_ffmpeg = None
    store_image_settings = None

    @classmethod
    def poll(cls, context):
        return context.scene.sequence_editor is not None and len(context.scene.sequence_editor.strips) > 0

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        self.bake_meta_sequence(context)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):

        if 'BAKING_STATE' not in context.scene:
            return {"PASS_THROUGH"}

        print(event.type)

        baking_state = context.scene['BAKING_STATE']

        if baking_state == "RENDERING":
            return {"PASS_THROUGH"}

        if baking_state == "COMPLETE":
            self.wrap_bake_meta_render(context)
            return {"FINISHED"}

        if baking_state == "CANCELLED":
            self.clean_house(context)
            return {"CANCELLED"}

    def bake_meta_sequence(self, context):

        self.as_image = False

        scene = context.scene
        seq_ed = scene.sequence_editor
        active = seq_ed.active_strip
        self.active = active

        if active is None:
            return

        if active.type == 'IMAGE':
            if 'SOURCE_META' in active:
                active = find_by_uuid(context, active['SOURCE_META'])
            else:
                return

        if active.type != 'META':
            return

        active.mute = False

        if 'UUID' not in active:
            active['UUID'] = str(uuid.uuid4())

        if 'CACHE' in active:

            reference = find_by_uuid(context, active['CACHE'])
            if reference is not None:
                seq_ed.sequences.remove(find_by_uuid(context, active['CACHE']))

            del active['CACHE']

        self.store_start = scene.frame_start
        self.store_end = scene.frame_end
        self.store_path = scene.render.filepath

        self.store_ffmpeg = get_data(scene.render.ffmpeg)
        self.store_image_settings = get_data(scene.render.image_settings)

        # setup
        filename = active.name
        self.filename = filename
        abspath = bpy.data.filepath.replace(".blend", "_CACHE")
        directory = os.path.join(abspath, active.name)
        reldir = bpy.path.relpath(directory)
        self.reldir = reldir

        filelocation = os.path.join(reldir, F"{filename}_")

        self.filelocation = filelocation
        scene.frame_start = active.frame_final_start
        scene.frame_end = active.frame_final_end
        scene.render.filepath = filelocation

        if self.as_image:
            scene.render.image_settings.file_format = 'PNG'
        else:
            scene.render.image_settings.file_format = 'FFMPEG'
            scene.render.ffmpeg.constant_rate_factor = 'LOSSLESS'

        # render
        scene['BAKING_STATE'] = "RENDERING"
        bpy.app.handlers.render_complete.append(complete_render)
        bpy.app.handlers.render_cancel.append(cancel_render)
        bpy.ops.render.render('INVOKE_DEFAULT', animation=True)

    def wrap_bake_meta_render(self, context):

        bpy.app.handlers.render_complete.remove(complete_render)
        bpy.app.handlers.render_cancel.remove(cancel_render)

        scene = context.scene
        seq_ed = scene.sequence_editor
        active = seq_ed.active_strip

        img_seq = None

        filelocation = self.filelocation
        reldir = self.reldir

        if self.as_image:
            filename = self.filename
            files = [{"name": F"{filename}_{i:04}.png"} for i in range(scene.frame_start, scene.frame_end)]
            img_seq = seq_ed.sequences.new_image(active.name + "_CACHE", files[0]['name'], active.channel + 1, frame_start=active.frame_final_start)
            img_seq.frame_final_end = active.frame_final_end
            img_seq['UUID'] = str(uuid.uuid4())
            img_seq['SOURCE_META'] = active['UUID']
            seq_ed.active_strip = img_seq
            bpy.ops.sequencer.change_path(filepath=files[0]['name'], directory=reldir, files=files)

        else:
            start_frame = str(scene.frame_start).zfill(4)
            end_frame = str(scene.frame_end).zfill(4)
            filename = F"{filelocation}{start_frame}-{end_frame}.mp4"

            img_seq = seq_ed.sequences.new_movie(active.name + "_CACHE", filename, active.channel + 1, frame_start=active.frame_final_start)
            img_seq.frame_final_end = active.frame_final_end
            img_seq['UUID'] = str(uuid.uuid4())
            img_seq['SOURCE_META'] = active['UUID']
            seq_ed.active_strip = img_seq

        active.mute = True
        active['CACHE'] = img_seq['UUID']

        self.clean_house(context)

    def clean_house(self, context):

        print("Cleaning House...")

        wm = context.window_manager
        wm.event_timer_remove(self._timer)

        scene = context.scene
        del scene['BAKING_STATE']

        # restore
        set_data(scene.render.ffmpeg, self.store_ffmpeg)
        set_data(scene.render.image_settings, self.store_image_settings)

        scene.frame_start = self.store_start
        scene.frame_end = self.store_end
        scene.render.filepath = self.store_path
