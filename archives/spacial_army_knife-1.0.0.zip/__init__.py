# spacial_army_knife Copyright (C) 2024, Keith (Wahooney) Boshoff
#
# centers the object's origin to the mesh selection 2.53 add->mesh menu
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import bpy
import bmesh
from mathutils import Vector
from bpy.props import EnumProperty


bl_info = {
    "name": "Spacial Army Knife",
    "author": "Keith 'Wahooney' Boshoff",
    "description": "",
    "blender": (4, 20, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Generic"
}


class OBJECT_OT_CenterOriginToMeshSelection(bpy.types.Operator):
    '''Center the object origin to the selected vertices, '''\
        '''either by averaging their positions or using the bounding box'''

    bl_idname = "object.center_origin_to_mesh_selection"
    bl_label = "Center Origin to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    method: bpy.props.EnumProperty(name="Method",
                                   items=(
                                       ('AVERAGE', "Average",
                                        "Position of averaged vertex locations"),
                                       ('BOUNDS', "Bounds", "Bounding box center of vertex locations")),
                                   description="Method of determining origin location",
                                   default='AVERAGE')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.mode == "EDIT" and obj.type in ("MESH", "CURVE")

    def execute(self, context):

        obj = context.active_object

        store_cursor = context.scene.cursor.location.copy()

        if self.method == 'AVERAGE':
            bpy.ops.view3d.snap_cursor_to_selected()
        else:

            tm = obj.matrix_world

            has_v = False

            min_p = Vector()
            max_p = Vector()

            for v in obj.data.vertices:

                co = v.co @ tm

                if v.select:
                    if not has_v:
                        min_p = co
                        max_p = co
                        has_v = True

                    else:
                        min_p.x = min(min_p.x, co.x)
                        min_p.y = min(min_p.y, co.y)
                        min_p.z = min(min_p.z, co.z)

                        max_p.x = max(max_p.x, co.x)
                        max_p.y = max(max_p.y, co.y)
                        max_p.z = max(max_p.z, co.z)

            if has_v:
                context.scene.cursor.location = (min_p + max_p) / 2

        is_editmode = obj.mode == 'EDIT'

        if is_editmode:
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        # context.scene.cursor.location = store_cursor

        if is_editmode:
            bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


def calculate_center_of_mass_volume(depsgraph, obj):

    obj_eval = obj.evaluated_get(depsgraph)

    bm = bmesh.new()
    bm.from_mesh(obj_eval.to_mesh())
    obj_eval.to_mesh_clear()

    bmesh.ops.triangulate(bm, faces=bm.faces)
    center = Vector()
    volume = 0

    for face in bm.faces:

        a, b, c = (v.co for v in face.verts)
        v = a.cross(b).dot(c) / 6
        center += v * (a + b + c) / 4
        volume += v

    if volume == 0:
        print("No volume")
    else:
        center = center / volume

    return (volume, obj.matrix_world @ center)


def calculate_center_of_mass_surface(depsgraph, obj):

    obj_eval = obj.evaluated_get(depsgraph)

    bm = bmesh.new()
    bm.from_mesh(obj_eval.to_mesh())
    obj_eval.to_mesh_clear()

    bmesh.ops.triangulate(bm, faces=bm.faces)
    center = Vector()
    area = 0

    for face in bm.faces:

        face_area = face.calc_area()
        area += face_area
        center += face.calc_center_median() * face_area

    if area == 0:
        print("No area")
    else:
        center = center / area

    return (area, obj.matrix_world @ center)


def update_origin(self, context):

    cursor = context.scene.cursor.location.copy()
    active = context.active_object

    mode = active.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    selection = [ob for ob in context.selected_objects]

    for sel in selection:
        sel.select_set(False)

    for sel in selection:

        if sel.type != 'MESH':
            continue

        volume = 0
        center = Vector()

        if self.properties.type == 'VOLUME':
            volume, center = calculate_center_of_mass_volume(
                context.evaluated_depsgraph_get(), sel)

        elif self.properties.type == 'SURFACE':
            volume, center = calculate_center_of_mass_surface(
                context.evaluated_depsgraph_get(), sel)

        context.view_layer.objects.active = sel
        sel.select_set(True)

        if volume > 0:
            context.scene.cursor.location = center
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        else:
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')

        sel.select_set(False)

    for sel in selection:
        sel.select_set(True)

    context.view_layer.objects.active = active
    context.scene.cursor.location = cursor

    if active.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


def update_cursor(self, context):

    active = context.active_object

    mode = active.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    location = Vector((0, 0, 0))
    count = 0

    for sel in context.selected_objects:

        if sel.type != 'MESH':
            continue

        volume = 0
        center = Vector()

        if self.properties.type == 'VOLUME':
            volume, center = calculate_center_of_mass_volume(
                context.evaluated_depsgraph_get(), sel)

        elif self.properties.type == 'SURFACE':
            volume, center = calculate_center_of_mass_surface(
                context.evaluated_depsgraph_get(), sel)

        if volume > 0:
            location += center
            count += 1

    if count > 0:
        context.scene.cursor.location = location

    if active.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


class OBJECT_OT_OriginToCenterOfMass(bpy.types.Operator):

    """Calculates the center of mass of a mesh after all modifiers are applied"""

    bl_idname = "object.origin_to_center_of_mass"
    bl_label = "Origin to Center of Mass"
    bl_options = {'REGISTER', 'UNDO'}

    type: EnumProperty(name="Type", items=[
        ('VOLUME', "From Volume",
         "Calculates the center of mass from the volume of the mesh, mesh needs to be closed and manifold"),
        ('SURFACE', "From Surface",
         "Calculates the center of mass from the surface of the mesh")
    ], default='VOLUME')

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        update_origin(self, context)
        return {'FINISHED'}


class VIEW3D_OT_CursorToCenterOfMass(bpy.types.Operator):

    """Moves the cursor the center of mass of all selected meshes"""

    bl_idname = "view3d.cursor_to_center_of_mass"
    bl_label = "Cursor to Center of Mass"
    bl_options = {'REGISTER', 'UNDO'}

    type: EnumProperty(name="Type", items=[
        ('VOLUME', "From Volume",
         "Calculates the center of mass from the volume of the mesh, mesh needs to be closed and manifold"),
        ('SURFACE', "From Surface",
         "Calculates the center of mass from the surface of the mesh")
    ], default='VOLUME')

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 0

    def execute(self, context):
        update_cursor(self, context)
        return {'FINISHED'}


def line_line_intersect(p1, p2, p3, p4):
    # based on Paul Bourke's Shortest Line Between 2 lines

    min_value = 0.0000001

    v1 = Vector((p1.x - p3.x, p1.y - p3.y, p1.z - p3.z))
    v2 = Vector((p4.x - p3.x, p4.y - p3.y, p4.z - p3.z))

    if abs(v2.x) < min_value and abs(v2.y) < min_value and abs(v2.z) < min_value:
        return None

    v3 = Vector((p2.x - p1.x, p2.y - p1.y, p2.z - p1.z))

    if abs(v3.x) < min_value and abs(v3.y) < min_value and abs(v3.z) < min_value:
        return None

    d1 = v1.dot(v2)
    d2 = v2.dot(v3)
    d3 = v1.dot(v3)
    d4 = v2.dot(v2)
    d5 = v3.dot(v3)

    d = d5 * d4 - d2 * d2

    if abs(d) < min_value:
        return None

    n = d1 * d2 - d3 * d4

    mua = n / d
    mub = (d1 + d2 * (mua)) / d4

    return [Vector((p1.x + mua * v3.x, p1.y + mua * v3.y, p1.z + mua * v3.z)),
            Vector((p3.x + mub * v2.x, p3.y + mub * v2.y, p3.z + mub * v2.z))]


def edge_intersect(self, context):

    obj = context.active_object

    if obj.type != "MESH":
        self.report({'ERROR'}, "Object must be a mesh")
        return None

    edges = []
    mesh = obj.data
    verts = mesh.vertices

    is_editmode = obj.mode == 'EDIT'
    if is_editmode:
        bpy.ops.object.mode_set(mode='OBJECT')

    for e in mesh.edges:
        if e.select:
            edges.append([verts[e.vertices[0]].co, verts[e.vertices[1]].co])

    if is_editmode:
        bpy.ops.object.mode_set(mode='EDIT')

    if len(edges) != 2:
        self.report({'ERROR'}, "Operator requires exactly 2 selected edges.")
        return None

    line = line_line_intersect(
        edges[0][0], edges[0][1], edges[1][0], edges[1][1])

    if line is None:
        self.report({'ERROR'}, "Selected edges are parallel.")
        return None

    point = obj.matrix_world @ ((line[0] + line[1]) / 2)

    context.scene.cursor.location = point

    return point


class VIEW3D_OT_CursorToEdgeIntersection(bpy.types.Operator):
    '''Finds the mid-point of the shortest distance between two edges, the point may '''\
        '''not lie between the edges as the edges are projected beyond their bounds'''

    bl_idname = "view3d.snap_cursor_to_edge_intersection"
    bl_label = "Cursor to Edge Intersection"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        mode = bpy.context.scene.tool_settings.mesh_select_mode
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT' and not mode[0] and mode[1] and not mode[2]

    def execute(self, context):
        edge_intersect(self, context)
        return {'FINISHED'}


def menu_func(self, context):

    self.layout.operator_menu_enum(OBJECT_OT_OriginToCenterOfMass.bl_idname,
                                   text=OBJECT_OT_OriginToCenterOfMass.bl_label, property="type")
    self.layout.operator_menu_enum(VIEW3D_OT_CursorToCenterOfMass.bl_idname,
                                   text=VIEW3D_OT_CursorToCenterOfMass.bl_label, property="type")


classes = [
    OBJECT_OT_CenterOriginToMeshSelection,
    OBJECT_OT_OriginToCenterOfMass,
    VIEW3D_OT_CursorToCenterOfMass,
    VIEW3D_OT_CursorToEdgeIntersection
]


def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.VIEW3D_MT_object.append(menu_func)
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)


def unregister():

    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        finally:
            pass

    try:
        bpy.types.VIEW3D_MT_object.remove(menu_func)
        bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func)

    finally:
        pass


if __name__ == "__main__":
    register()
