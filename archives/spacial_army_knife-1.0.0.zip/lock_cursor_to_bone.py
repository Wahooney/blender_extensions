import bpy
from bpy.props import BoolProperty

_act = bpy.context.active_object
_bone = bpy.context.active_pose_bone
_last_loc = None
_last_rot = None


def constrain_cursor():

    global _last_loc, _last_rot

    mat = _bone.matrix @ _act.matrix_world
    bpy.context.scene.cursor.location = mat.to_translation()
    bpy.context.scene.cursor.rotation_euler = mat.to_euler()

    _last_loc = bpy.context.scene.cursor.location.copy()
    _last_rot = bpy.context.scene.cursor.rotation_euler.copy()


def check_cursor_constraint():
    cursor = bpy.context.scene.cursor
    if cursor.rotation_euler != _last_rot or cursor.location != _last_loc \
            or _act is None or _bone is None:
        release_handlers()


def lock_cursor_pre(c1, c2):
    check_cursor_constraint()


def lock_cursor_post(c1, c2):
    constrain_cursor()


def lock_cursor_deps_pre(c1, c2):
    check_cursor_constraint()


def lock_cursor_deps_post(c1, c2):
    constrain_cursor()


def release_handler(handlers_container):
    handlers = handlers_container[:]
    for h in handlers:
        if h.__name__.startswith("lock_cursor"):
            handlers_container.remove(h)


def release_handlers():

    release_handler(bpy.app.handlers.frame_change_pre)
    release_handler(bpy.app.handlers.frame_change_post)
    release_handler(bpy.app.handlers.depsgraph_update_pre)
    release_handler(bpy.app.handlers.depsgraph_update_post)


def bind_handlers():

    release_handlers()
    constrain_cursor()

    # we check _pre handlers to see if the user cam change the cursor location elsewhere
    # and we don't want them to fight the system

    # _post handlers chase the tracked bones

    # update on frame changes
    bpy.app.handlers.frame_change_pre.append(lock_cursor_pre)
    bpy.app.handlers.frame_change_post.append(lock_cursor_post)

    # update on potential movement of the tracked bone
    bpy.app.handlers.depsgraph_update_post.append(lock_cursor_deps_post)
    bpy.app.handlers.depsgraph_update_pre.append(lock_cursor_deps_pre)


def has_cursor_lock(context):

    for f in bpy.app.handlers.frame_change_pre:
        if f.__name__.startswith("lock_cursor"):
            return True

    return False


def set_cursor_lock(context, value):

    print(value, _act is not None, _bone is not None)
    if value and _act is not None and _bone is not None:
        bind_handlers()
    else:
        release_handlers()


def draw(self, context):
    if context.mode != 'POSE':
        return

    layout = self.layout
    layout.prop(context.scene, "use_cursor_lock", text='', icon='ORIENTATION_CURSOR')


def clean_house():

    release_handlers()

    # we've stored the draw function before and we want to remove it if we're registering again
    if hasattr(bpy.types.VIEW3D_HT_tool_header, "_cursor_lock_draw"):
        old_draw = bpy.types.VIEW3D_HT_tool_header._cursor_lock_draw
        bpy.types.VIEW3D_HT_tool_header.remove(old_draw)
        del bpy.types.VIEW3D_HT_tool_header._cursor_lock_draw


def register():

    clean_house()

    # we store our draw function so we can remove it later
    bpy.types.VIEW3D_HT_tool_header._cursor_lock_draw = draw
    bpy.types.VIEW3D_HT_tool_header.append(draw)
    bpy.types.Scene.use_cursor_lock = BoolProperty(name="Cursor Lock", get=has_cursor_lock, set=set_cursor_lock)


def unregister():

    clean_house()
    del bpy.types.Scene.use_cursor_lock


if __name__ == "__main__":
    register()
