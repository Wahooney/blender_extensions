import bpy
from bpy.props import BoolProperty

STORAGE_ATTRS = ("last_loc", "last_rot", "bone", "act")
HANDLER_NAMES = {
    "lock_cursor_pre",
    "lock_cursor_post",
    "lock_cursor_deps_pre",
    "lock_cursor_deps_post",
}


def storage():
    return bpy.types.VIEW3D_HT_tool_header


def is_our_handler(handler):
    return (getattr(handler, "__module__", None) == __name__
            and getattr(handler, "__name__", None) in HANDLER_NAMES)


def clear_info():
    owner = storage()
    for attr in STORAGE_ATTRS:
        if hasattr(owner, attr):
            delattr(owner, attr)


def pull_info(scene=None):
    owner = storage()
    scene = scene or bpy.context.scene
    last_loc = getattr(owner, "last_loc", scene.cursor.location.copy())
    last_rot = getattr(owner, "last_rot", scene.cursor.rotation_euler.copy())
    bone = getattr(owner, "bone", None)
    act = getattr(owner, "act", None)

    return (last_loc, last_rot, bone, act)


def push_info(loc, rot, bone, act):
    owner = storage()
    owner.last_loc = loc
    owner.last_rot = rot
    owner.bone = bone
    owner.act = act


def constrain_cursor(scene=None):
    scene = scene or bpy.context.scene
    _, __, bone, act = pull_info(scene)

    if act is None or bone is None:
        release_handlers(clear=True)
        return

    mat = act.matrix_world @ bone.matrix
    scene.cursor.location = mat.to_translation()
    scene.cursor.rotation_euler = mat.to_euler()

    push_info(scene.cursor.location.copy(),
              scene.cursor.rotation_euler.copy(),
              bone, act)


def check_cursor_constraint(scene=None):
    scene = scene or bpy.context.scene

    last_loc, last_rot, bone, act = pull_info(scene)
    cursor = scene.cursor
    if cursor.rotation_euler != last_rot \
            or cursor.location != last_loc \
            or act is None \
            or bone is None:
        release_handlers(clear=True)


def lock_cursor_pre(scene, _depsgraph):
    check_cursor_constraint(scene)


def lock_cursor_post(scene, _depsgraph):
    constrain_cursor(scene)


def lock_cursor_deps_pre(scene, _depsgraph):
    check_cursor_constraint(scene)


def lock_cursor_deps_post(scene, _depsgraph):
    constrain_cursor(scene)


def release_handler(handlers_container):
    handlers = handlers_container[:]
    for h in handlers:
        if is_our_handler(h):
            handlers_container.remove(h)


def release_handlers(clear=False):
    release_handler(bpy.app.handlers.frame_change_pre)
    release_handler(bpy.app.handlers.frame_change_post)
    release_handler(bpy.app.handlers.depsgraph_update_pre)
    release_handler(bpy.app.handlers.depsgraph_update_post)
    if clear:
        clear_info()


def bind_handlers(scene=None):

    release_handlers()
    constrain_cursor(scene)

    # we check _pre handlers to see if the user can change the cursor location elsewhere
    # and we don't want them to fight the system

    # _post handlers chase the tracked bones

    # update on frame changes
    bpy.app.handlers.frame_change_pre.append(lock_cursor_pre)
    bpy.app.handlers.frame_change_post.append(lock_cursor_post)

    # update on potential movement of the tracked bone
    bpy.app.handlers.depsgraph_update_post.append(lock_cursor_deps_post)
    bpy.app.handlers.depsgraph_update_pre.append(lock_cursor_deps_pre)


def has_cursor_lock(_):

    handler_containers = (
        bpy.app.handlers.frame_change_pre,
        bpy.app.handlers.frame_change_post,
        bpy.app.handlers.depsgraph_update_pre,
        bpy.app.handlers.depsgraph_update_post,
    )
    for handlers in handler_containers:
        for handler in handlers:
            if is_our_handler(handler):
                return True

    return False


def set_cursor_lock(scene, value):

    bone = bpy.context.active_pose_bone
    act = bpy.context.active_object

    if value and act is not None and bone is not None:
        push_info(scene.cursor.location.copy(),
                  scene.cursor.rotation_euler.copy(),
                  bone, act)
        bind_handlers(scene)
    else:
        release_handlers(clear=True)


def draw(self, context):
    if context.mode != 'POSE':
        return

    layout = self.layout
    layout.prop(context.scene, "use_cursor_lock", text='', icon='ORIENTATION_CURSOR')


def clean_house():

    release_handlers(clear=True)

    # we've stored the draw function before and we want to remove it if we're registering again
    if hasattr(bpy.types.VIEW3D_HT_tool_header, "cursor_lock_draw"):
        old_draw = bpy.types.VIEW3D_HT_tool_header.cursor_lock_draw
        bpy.types.VIEW3D_HT_tool_header.remove(old_draw)
        del bpy.types.VIEW3D_HT_tool_header.cursor_lock_draw


def register():

    clean_house()

    # we store our draw function so we can remove it later
    bpy.types.VIEW3D_HT_tool_header.cursor_lock_draw = draw
    bpy.types.VIEW3D_HT_tool_header.append(draw)
    bpy.types.Scene.use_cursor_lock = BoolProperty(name="Cursor Lock", get=has_cursor_lock, set=set_cursor_lock)


def unregister():

    clean_house()
    if hasattr(bpy.types.Scene, "use_cursor_lock"):
        del bpy.types.Scene.use_cursor_lock


if __name__ == "__main__":
    register()
